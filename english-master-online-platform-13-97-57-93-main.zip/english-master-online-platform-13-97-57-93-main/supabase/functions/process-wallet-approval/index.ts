
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    console.log('بدء معالجة طلب المحفظة...')
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const requestBody = await req.json()
    const { request_id, student_id, amount_to_add, payment_method, transfer_number } = requestBody

    console.log('بيانات الطلب المستلمة:', {
      request_id,
      student_id,
      amount_to_add,
      payment_method,
      transfer_number
    })

    // التحقق من وجود البيانات المطلوبة
    if (!request_id || !student_id || amount_to_add === undefined || amount_to_add === null) {
      console.error('البيانات المطلوبة غير مكتملة:', { request_id, student_id, amount_to_add })
      throw new Error('البيانات المطلوبة غير مكتملة')
    }

    // استخدام database function للتعامل مع العملية بشكل آمن وموثوق
    console.log('استدعاء database function لمعالجة العملية...')
    
    const { data: functionResult, error: functionError } = await supabaseClient
      .rpc('process_wallet_approval_transaction', {
        p_request_id: request_id,
        p_student_id: student_id,
        p_amount_to_add: Number(amount_to_add),
        p_payment_method: payment_method || 'غير محدد',
        p_transfer_number: transfer_number || 'غير محدد'
      })

    console.log('نتيجة database function:', { functionResult, functionError })

    if (functionError) {
      console.error('خطأ في database function:', functionError)
      throw new Error(`فشل في معالجة العملية: ${functionError.message}`)
    }

    if (!functionResult) {
      console.error('Database function returned null result')
      throw new Error('لم يتم إرجاع نتيجة من العملية')
    }

    // تحويل النتيجة إذا كانت string
    let parsedResult = functionResult
    if (typeof functionResult === 'string') {
      try {
        parsedResult = JSON.parse(functionResult)
      } catch (parseError) {
        console.error('خطأ في تحويل النتيجة:', parseError)
        throw new Error('خطأ في معالجة النتيجة')
      }
    }

    if (!parsedResult.success) {
      console.error('Database function returned unsuccessful result:', parsedResult)
      throw new Error(parsedResult.error || 'العملية لم تكتمل بنجاح')
    }

    console.log('تم تأكيد العملية بنجاح:', parsedResult)

    const result = {
      success: true,
      message: parsedResult.message || 'تم تأكيد العملية بنجاح',
      old_balance: parsedResult.old_balance,
      new_balance: parsedResult.new_balance,
      amount_added: parsedResult.amount_added
    }

    console.log('تم تأكيد العملية بنجاح:', result)

    return new Response(
      JSON.stringify(result),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (error) {
    console.error('خطأ في معالجة طلب المحفظة:', error)
    
    // إرسال تفاصيل أكثر عن الخطأ
    const errorDetails = {
      success: false,
      error: error.message || 'حدث خطأ غير متوقع',
      details: error.stack || 'لا توجد تفاصيل إضافية',
      timestamp: new Date().toISOString()
    }
    
    return new Response(
      JSON.stringify(errorDetails),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})
