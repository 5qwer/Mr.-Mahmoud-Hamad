-- إصلاح سياسات جدول activity_logs
DROP POLICY IF EXISTS "Allow activity logs creation" ON public.activity_logs;

-- إنشاء سياسة جديدة تسمح بالإدراج للمستخدمين المصادقين فقط
CREATE POLICY "Authenticated users can create activity logs" ON public.activity_logs 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- إنشاء سياسة تسمح للنظام بإنشاء السجلات (للعمليات التلقائية)
CREATE POLICY "System can create activity logs" ON public.activity_logs 
FOR INSERT 
TO service_role
WITH CHECK (true);

-- تحديث سياسة العرض لتشمل المستخدمين المصادقين فقط
DROP POLICY IF EXISTS "Allow viewing activity logs" ON public.activity_logs;

CREATE POLICY "Authenticated users can view activity logs" ON public.activity_logs 
FOR SELECT 
TO authenticated
USING (auth.uid() = user_id);

-- إضافة الاشتراكات لجميع الصفوف الدراسية
INSERT INTO public.subscriptions (title, description, price, duration_days, grade, cover_image) VALUES
('اشتراك الصف الأول الثانوي - شهري', 'جميع حصص الصف الأول الثانوي لمدة شهر كامل مع الامتحانات والواجبات', 100.00, 30, '1', '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png'),
('اشتراك الصف الثاني الثانوي - شهري', 'جميع حصص الصف الثاني الثانوي لمدة شهر كامل مع الامتحانات والواجبات', 120.00, 30, '2', '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png'),
('اشتراك الصف الثالث الثانوي - شهري', 'جميع حصص الصف الثالث الثانوي لمدة شهر كامل مع الامتحانات والواجبات', 150.00, 30, '3', '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png');