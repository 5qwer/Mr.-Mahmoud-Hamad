-- إضافة سياسة جديدة للاشتراكات تسمح لجميع الطلاب بمشاهدة الاشتراكات
CREATE POLICY "Students can view all subscriptions" ON public.subscriptions_users 
FOR SELECT 
USING (true);

-- تحديث سياسة user_subscriptions أيضاً
DROP POLICY IF EXISTS "Users can view their own subscriptions" ON public.user_subscriptions;

CREATE POLICY "Users can view all subscriptions" ON public.user_subscriptions 
FOR SELECT 
USING (true);