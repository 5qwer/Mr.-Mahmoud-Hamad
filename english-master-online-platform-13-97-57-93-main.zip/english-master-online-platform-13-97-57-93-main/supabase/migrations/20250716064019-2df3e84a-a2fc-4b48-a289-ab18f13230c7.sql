
-- إنشاء جدول رسائل الدعم الفني
CREATE TABLE IF NOT EXISTS public.support_messages_new (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID NOT NULL,
  student_name TEXT NOT NULL,
  message TEXT NOT NULL,
  image_url TEXT,
  support_reply TEXT,
  support_name TEXT DEFAULT 'الدعم الفني',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  replied_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- تفعيل RLS
ALTER TABLE public.support_messages_new ENABLE ROW LEVEL SECURITY;

-- إنشاء سياسات RLS
CREATE POLICY "Students can create support messages" 
  ON public.support_messages_new 
  FOR INSERT 
  WITH CHECK (true);

CREATE POLICY "Students can view their own messages" 
  ON public.support_messages_new 
  FOR SELECT 
  USING (true);

CREATE POLICY "Support can update messages" 
  ON public.support_messages_new 
  FOR UPDATE 
  USING (true);

-- إنشاء فهارس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_support_messages_student_id ON public.support_messages_new(student_id);
CREATE INDEX IF NOT EXISTS idx_support_messages_status ON public.support_messages_new(status);
CREATE INDEX IF NOT EXISTS idx_support_messages_created_at ON public.support_messages_new(created_at DESC);

-- إنشاء trigger لتحديث updated_at
CREATE OR REPLACE FUNCTION update_support_messages_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_support_messages_updated_at_trigger
BEFORE UPDATE ON public.support_messages_new
FOR EACH ROW EXECUTE FUNCTION update_support_messages_updated_at();
