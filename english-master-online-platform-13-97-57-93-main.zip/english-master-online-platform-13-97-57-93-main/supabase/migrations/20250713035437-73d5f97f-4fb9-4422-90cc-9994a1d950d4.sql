
-- التأكد من وجود حصص مرتبطة بالاشتراكات مع محتوى كامل
UPDATE public.lessons 
SET 
  video_url = CASE 
    WHEN video_url IS NULL OR video_url = '' THEN 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
    ELSE video_url 
  END,
  pdf_url = CASE 
    WHEN pdf_url IS NULL OR pdf_url = '' THEN 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
    ELSE pdf_url 
  END,
  homework_url = CASE 
    WHEN homework_url IS NULL OR homework_url = '' THEN 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
    ELSE homework_url 
  END,
  homework_video_url = CASE 
    WHEN homework_video_url IS NULL OR homework_video_url = '' THEN 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4'
    ELSE homework_video_url 
  END,
  solution_url = CASE 
    WHEN solution_url IS NULL OR solution_url = '' THEN 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
    ELSE solution_url 
  END
WHERE id IN (
  SELECT DISTINCT lesson_id 
  FROM public.subscription_lessons
);

-- إضافة المزيد من الحصص التجريبية إذا لم تكن موجودة
INSERT INTO public.lessons (
  title, description, price, order_number, grade, 
  video_url, pdf_url, homework_url, homework_video_url, solution_url
) VALUES 
(
  'حصة الرياضيات - المعادلات',
  'شرح مفصل للمعادلات الخطية والتربيعية',
  45,
  3,
  '1',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
  'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
  'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
  'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
),
(
  'حصة الكيمياء - التفاعلات',
  'دراسة أنواع التفاعلات الكيميائية',
  55,
  4,
  '2',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
  'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
  'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
  'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
)
ON CONFLICT DO NOTHING;

-- ربط الحصص الجديدة بالاشتراكات
INSERT INTO public.subscription_lessons (subscription_id, lesson_id)
SELECT s.id, l.id 
FROM public.subscriptions s
JOIN public.lessons l ON s.grade = l.grade
WHERE NOT EXISTS (
  SELECT 1 FROM public.subscription_lessons sl 
  WHERE sl.subscription_id = s.id AND sl.lesson_id = l.id
)
ON CONFLICT DO NOTHING;
