
-- تحديث سياسات Row Level Security لجدول payment_methods
-- حذف السياسات القديمة إذا كانت موجودة
DROP POLICY IF EXISTS "Anyone can view payment methods" ON public.payment_methods;
DROP POLICY IF EXISTS "Students can read" ON public.payment_methods;
DROP POLICY IF EXISTS "Teachers can manage payment methods" ON public.payment_methods;

-- إنشاء سياسات جديدة للسماح بالعمليات المطلوبة
-- السماح للجميع بمشاهدة وسائل الدفع (للطلاب والمعلمين)
CREATE POLICY "Anyone can view payment methods"
  ON public.payment_methods
  FOR SELECT
  USING (true);

-- السماح للجميع بإضافة وسائل دفع (للمعلمين)
CREATE POLICY "Allow inserting payment methods"
  ON public.payment_methods
  FOR INSERT
  WITH CHECK (true);

-- السماح للجميع بتحديث وسائل الدفع
CREATE POLICY "Allow updating payment methods"
  ON public.payment_methods
  FOR UPDATE
  USING (true);

-- السماح للجميع بحذف وسائل الدفع (للمعلمين مع كلمة المرور)
CREATE POLICY "Allow deleting payment methods"
  ON public.payment_methods
  FOR DELETE
  USING (true);
