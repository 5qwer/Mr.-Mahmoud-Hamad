
-- Fix wallet_requests table structure and constraints
-- First, check if there are any problematic constraints and fix them

-- Drop the existing table if it has conflicts
DROP TABLE IF EXISTS public.wallet_requests CASCADE;

-- Recreate the table with the correct structure
CREATE TABLE public.wallet_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  amount DECIMAL(10,2) NOT NULL CHECK (amount > 0),
  payment_method TEXT NOT NULL,
  transfer_id TEXT NOT NULL,
  transfer_number TEXT NOT NULL,
  transfer_time TIMESTAMPTZ NOT NULL,
  transfer_image TEXT,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  reject_reason TEXT,
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.wallet_requests ENABLE ROW LEVEL SECURITY;

-- Create policies for wallet requests
CREATE POLICY "Users can insert their own wallet requests" ON public.wallet_requests
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view wallet requests" ON public.wallet_requests
  FOR SELECT USING (true);

CREATE POLICY "Support can update wallet requests" ON public.wallet_requests
  FOR UPDATE USING (true);

-- Create indexes for better performance
CREATE INDEX idx_wallet_requests_user_id ON public.wallet_requests(user_id);
CREATE INDEX idx_wallet_requests_status ON public.wallet_requests(status);
CREATE INDEX idx_wallet_requests_created_at ON public.wallet_requests(created_at DESC);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_wallet_requests_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update updated_at
CREATE TRIGGER wallet_requests_updated_at
  BEFORE UPDATE ON public.wallet_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.update_wallet_requests_updated_at();
