
-- إنشاء جدول الرسائل العامة للطلاب
CREATE TABLE public.general_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('urgent', 'warning', 'normal')),
  target_grades TEXT[] DEFAULT '{}',
  target_all BOOLEAN DEFAULT true,
  created_by TEXT DEFAULT 'المعلم',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- تفعيل Row Level Security
ALTER TABLE public.general_messages ENABLE ROW LEVEL SECURITY;

-- سياسة للسماح للجميع بقراءة الرسائل العامة
CREATE POLICY "Anyone can view general messages" 
  ON public.general_messages 
  FOR SELECT 
  USING (true);

-- سياسة للسماح بإنشاء رسائل عامة (للمعلمين)
CREATE POLICY "Teachers can create general messages" 
  ON public.general_messages 
  FOR INSERT 
  WITH CHECK (true);

-- سياسة للسماح بتحديث الرسائل العامة (للمعلمين)
CREATE POLICY "Teachers can update general messages" 
  ON public.general_messages 
  FOR UPDATE 
  USING (true);

-- سياسة للسماح بحذف الرسائل العامة (للمعلمين)
CREATE POLICY "Teachers can delete general messages" 
  ON public.general_messages 
  FOR DELETE 
  USING (true);

-- إنشاء trigger لتحديث updated_at تلقائياً
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_general_messages_updated_at 
  BEFORE UPDATE ON public.general_messages 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
