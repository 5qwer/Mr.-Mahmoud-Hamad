
-- Fix wallet_requests table structure to prevent conflicts

-- First, let's make sure we have the correct structure
-- Drop and recreate the table if there are conflicts
DROP TABLE IF EXISTS public.wallet_requests CASCADE;

CREATE TABLE public.wallet_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  amount DECIMAL(10,2) NOT NULL CHECK (amount > 0),
  payment_method TEXT NOT NULL,
  method_number TEXT, -- This is the new column name from the migration
  transfer_time TIMESTAMPTZ NOT NULL,
  transfer_image TEXT,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  reject_reason TEXT,
  reviewed_by UUID REFERENCES auth.users(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.wallet_requests ENABLE ROW LEVEL SECURITY;

-- Create policies for wallet requests
CREATE POLICY "Users can insert their own wallet requests" ON public.wallet_requests
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can view their own wallet requests" ON public.wallet_requests
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Support can view all wallet requests" ON public.wallet_requests
  FOR SELECT USING (true);

CREATE POLICY "Support can update wallet requests" ON public.wallet_requests
  FOR UPDATE USING (true);

-- Create indexes for better performance
CREATE INDEX idx_wallet_requests_user_id ON public.wallet_requests(user_id);
CREATE INDEX idx_wallet_requests_status ON public.wallet_requests(status);
CREATE INDEX idx_wallet_requests_created_at ON public.wallet_requests(created_at DESC);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_wallet_requests_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update updated_at
CREATE TRIGGER wallet_requests_updated_at
  BEFORE UPDATE ON public.wallet_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.update_wallet_requests_updated_at();
