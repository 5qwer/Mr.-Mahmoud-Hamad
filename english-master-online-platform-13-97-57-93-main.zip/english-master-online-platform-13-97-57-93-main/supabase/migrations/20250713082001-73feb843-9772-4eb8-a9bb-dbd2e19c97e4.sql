-- إنشاء storage buckets لحفظ ملفات الحصص
INSERT INTO storage.buckets (id, name, public) VALUES 
('lesson-videos', 'lesson-videos', true),
('lesson-files', 'lesson-files', true),
('lesson-images', 'lesson-images', true),
('homework-videos', 'homework-videos', true),
('solution-files', 'solution-files', true);

-- إنشاء policies للسماح بالوصول للملفات
CREATE POLICY "Allow public access to lesson videos" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'lesson-videos');

CREATE POLICY "Allow authenticated users to upload lesson videos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'lesson-videos' AND auth.role() = 'authenticated');

CREATE POLICY "Allow public access to lesson files" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'lesson-files');

CREATE POLICY "Allow authenticated users to upload lesson files" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'lesson-files' AND auth.role() = 'authenticated');

CREATE POLICY "Allow public access to lesson images" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'lesson-images');

CREATE POLICY "Allow authenticated users to upload lesson images" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'lesson-images' AND auth.role() = 'authenticated');

CREATE POLICY "Allow public access to homework videos" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'homework-videos');

CREATE POLICY "Allow authenticated users to upload homework videos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'homework-videos' AND auth.role() = 'authenticated');

CREATE POLICY "Allow public access to solution files" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'solution-files');

CREATE POLICY "Allow authenticated users to upload solution files" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'solution-files' AND auth.role() = 'authenticated');