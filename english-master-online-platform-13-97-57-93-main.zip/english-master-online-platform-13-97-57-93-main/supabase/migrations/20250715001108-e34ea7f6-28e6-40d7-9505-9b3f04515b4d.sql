-- إصلاح RLS policies لجدول activity_logs
DROP POLICY IF EXISTS "Users can create activity logs" ON public.activity_logs;

CREATE POLICY "System can create activity logs" ON public.activity_logs 
FOR INSERT 
WITH CHECK (true);

-- تحديث سياسة المشاهدة في activity_logs
DROP POLICY IF EXISTS "Users can view their own activity logs" ON public.activity_logs;

CREATE POLICY "Users can view their activity logs" ON public.activity_logs 
FOR SELECT 
USING (true);

-- تحديث سياسة الاشتراكات لتكون متاحة للجميع
DROP POLICY IF EXISTS "Students can view their own subscriptions" ON public.subscriptions_users;