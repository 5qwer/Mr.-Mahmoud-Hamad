
-- إنشاء جدول الاشتراكات
CREATE TABLE IF NOT EXISTS public.subscriptions (
    id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    title TEXT NOT NULL,
    description TEXT,
    price NUMERIC NOT NULL,
    duration_days INTEGER NOT NULL DEFAULT 30,
    cover_image TEXT,
    grade TEXT NOT NULL DEFAULT '1',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- إنشاء جدول ربط الاشتراكات بالحصص
CREATE TABLE IF NOT EXISTS public.subscription_lessons (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    subscription_id INTEGER NOT NULL REFERENCES public.subscriptions(id) ON DELETE CASCADE,
    lesson_id INTEGER NOT NULL REFERENCES public.lessons(id) ON DELETE CASCADE,
    UNIQUE(subscription_id, lesson_id)
);

-- إنشاء جدول اشتراكات المستخدمين
CREATE TABLE IF NOT EXISTS public.user_subscriptions (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    subscription_id INTEGER NOT NULL REFERENCES public.subscriptions(id),
    purchased_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL
);

-- تفعيل Row Level Security
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscription_lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;

-- إنشاء سياسات الأمان للاشتراكات
CREATE POLICY "Anyone can view subscriptions" ON public.subscriptions 
    FOR SELECT USING (true);

-- إنشاء سياسات الأمان لربط الحصص بالاشتراكات
CREATE POLICY "Anyone can view subscription lessons" ON public.subscription_lessons 
    FOR SELECT USING (true);

-- إنشاء سياسات الأمان لاشتراكات المستخدمين
CREATE POLICY "Users can view their own subscriptions" ON public.user_subscriptions 
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can subscribe" ON public.user_subscriptions 
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- إنشاء جدول طلبات شحن المحفظة
CREATE TABLE IF NOT EXISTS public.wallet_requests (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    amount NUMERIC NOT NULL,
    payment_method TEXT NOT NULL,
    transfer_id TEXT NOT NULL,
    transfer_time TEXT NOT NULL,
    transfer_number TEXT NOT NULL,
    transfer_image TEXT,
    message TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    reviewed_by TEXT,
    reject_reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    reviewed_at TIMESTAMP WITH TIME ZONE
);

-- تفعيل Row Level Security لطلبات شحن المحفظة
ALTER TABLE public.wallet_requests ENABLE ROW LEVEL SECURITY;

-- إنشاء سياسات الأمان لطلبات شحن المحفظة
CREATE POLICY "Students can view wallet requests" ON public.wallet_requests 
    FOR SELECT USING (true);

CREATE POLICY "Students can create wallet requests" ON public.wallet_requests 
    FOR INSERT WITH CHECK (true);

-- إدراج بيانات تجريبية للاشتراكات
INSERT INTO public.subscriptions (title, description, price, duration_days, grade, cover_image) 
VALUES 
    ('اشتراك الأول الثانوي - شهر يناير', 'جميع حصص الفيزياء للصف الأول الثانوي لشهر يناير', 100, 30, '1', 'https://images.unsplash.com/photo-1509062522246-3755977927d7?w=400'),
    ('اشتراك الثاني الثانوي - شهر يناير', 'حصص الفيزياء المتقدمة للصف الثاني الثانوي', 150, 30, '2', 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=400'),
    ('اشتراك الثالث الثانوي - مراجعة نهائية', 'مراجعة شاملة قبل امتحانات الثانوية العامة', 200, 45, '3', 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=400')
ON CONFLICT DO NOTHING;

-- إدراج بيانات تجريبية لربط الحصص بالاشتراكات (إذا كانت الحصص موجودة)
INSERT INTO public.subscription_lessons (subscription_id, lesson_id)
SELECT s.id, l.id 
FROM public.subscriptions s
CROSS JOIN public.lessons l
WHERE s.grade = l.grade
ON CONFLICT DO NOTHING;
