
-- إصلاح function مصادقة الدعم لحل مشكلة الـ ambiguous column reference
CREATE OR REPLACE FUNCTION public.authenticate_support(support_name text, support_code text)
 RETURNS TABLE(id uuid, full_name text)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    support_staff.id,
    support_staff.full_name
  FROM public.support_staff
  WHERE support_staff.full_name = support_name 
    AND support_staff.code = support_code
    AND support_staff.is_active = true;
    
  -- Update last login
  UPDATE public.support_staff 
  SET last_login = now() 
  WHERE support_staff.full_name = support_name 
    AND support_staff.code = support_code
    AND support_staff.is_active = true;
END;
$function$
