
-- إصلاح جدول subscriptions_users وإضافة العلاقات المطلوبة
ALTER TABLE public.subscriptions_users 
DROP CONSTRAINT IF EXISTS subscriptions_users_user_id_fkey;

-- إضافة عمود user_id إذا لم يكن موجوداً
ALTER TABLE public.subscriptions_users 
ALTER COLUMN user_id SET NOT NULL;

-- تحديث الجدول ليدعم العلاقة مع جدول students
ALTER TABLE public.subscriptions_users 
ADD CONSTRAINT subscriptions_users_user_id_fkey 
FOREIGN KEY (user_id) REFERENCES public.students(id) ON DELETE CASCADE;

-- إضافة trigger لتحديث expires_at تلقائياً
CREATE OR REPLACE FUNCTION public.update_subscription_expiry()
RETURNS TRIGGER AS $$
BEGIN
  -- حساب تاريخ انتهاء الاشتراك بناءً على مدة الاشتراك
  SELECT duration_days INTO NEW.expires_at 
  FROM public.subscriptions 
  WHERE id = NEW.subscription_id;
  
  -- إضافة المدة للتاريخ الحالي
  NEW.expires_at = NOW() + INTERVAL '1 day' * NEW.expires_at;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- إنشاء trigger لتحديث expires_at عند الإدراج
DROP TRIGGER IF EXISTS trigger_update_subscription_expiry ON public.subscriptions_users;
CREATE TRIGGER trigger_update_subscription_expiry
  BEFORE INSERT ON public.subscriptions_users
  FOR EACH ROW EXECUTE FUNCTION public.update_subscription_expiry();

-- تحديث سياسات RLS لجدول subscriptions_users
DROP POLICY IF EXISTS "Students can purchase subscriptions" ON public.subscriptions_users;
CREATE POLICY "Students can purchase subscriptions" 
ON public.subscriptions_users 
FOR INSERT 
WITH CHECK (true);

DROP POLICY IF EXISTS "Students can view their own subscriptions" ON public.subscriptions_users;
CREATE POLICY "Students can view their own subscriptions" 
ON public.subscriptions_users 
FOR SELECT 
USING (true);
