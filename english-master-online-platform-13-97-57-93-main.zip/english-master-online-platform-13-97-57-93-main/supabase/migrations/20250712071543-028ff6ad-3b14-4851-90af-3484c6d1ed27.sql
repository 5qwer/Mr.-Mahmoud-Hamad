
-- إزالة القيد المعطل وإنشاء قيد جديد صحيح
ALTER TABLE public.wallet_requests DROP CONSTRAINT IF EXISTS wallet_requests_status_check;

-- إنشاء قيد تحقق جديد للحالات المسموحة
ALTER TABLE public.wallet_requests ADD CONSTRAINT wallet_requests_status_check 
CHECK (status IN ('pending', 'approved', 'rejected'));

-- تحديث سياسات RLS للسماح لجميع المستخدمين برؤية طلبات المحفظة
DROP POLICY IF EXISTS "Users can view wallet requests" ON public.wallet_requests;
CREATE POLICY "Users can view wallet requests" 
ON public.wallet_requests 
FOR SELECT 
USING (true);

-- تحديث سياسة التعديل للسماح لفريق الدعم بتحديث الطلبات
DROP POLICY IF EXISTS "Support can update wallet requests" ON public.wallet_requests;
CREATE POLICY "Support can update wallet requests" 
ON public.wallet_requests 
FOR UPDATE 
USING (true) 
WITH CHECK (true);
