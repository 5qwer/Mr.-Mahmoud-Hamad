-- إنشاء دالة آمنة لحذف الاشتراك مع جميع البيانات المرتبطة
CREATE OR REPLACE FUNCTION public.delete_subscription_safely(subscription_id_param integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- حذف من جدول user_subscriptions
  DELETE FROM public.user_subscriptions 
  WHERE subscription_id = subscription_id_param;
  
  -- حذف من جدول subscriptions_users
  DELETE FROM public.subscriptions_users 
  WHERE subscription_id = subscription_id_param;
  
  -- حذف من جدول subscription_lessons
  DELETE FROM public.subscription_lessons 
  WHERE subscription_id = subscription_id_param;
  
  -- حذف الاشتراك نفسه
  DELETE FROM public.subscriptions 
  WHERE id = subscription_id_param;
END;
$$;