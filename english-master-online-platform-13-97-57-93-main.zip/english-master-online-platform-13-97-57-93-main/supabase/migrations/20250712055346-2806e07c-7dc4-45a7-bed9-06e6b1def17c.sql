
-- Create storage bucket for transfer receipts
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('transfer-receipts', 'transfer-receipts', true, 5242880, ARRAY['image/*'])
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for transfer receipts
CREATE POLICY "Anyone can upload transfer receipts" ON storage.objects 
    FOR INSERT WITH CHECK (bucket_id = 'transfer-receipts');

CREATE POLICY "Anyone can view transfer receipts" ON storage.objects 
    FOR SELECT USING (bucket_id = 'transfer-receipts');

-- Update wallet_requests table to include new fields
ALTER TABLE public.wallet_requests 
ADD COLUMN IF NOT EXISTS method_name text,
ADD COLUMN IF NOT EXISTS method_number text;

-- Rename existing column to match new structure
ALTER TABLE public.wallet_requests 
RENAME COLUMN transfer_id TO method_number;

-- Update the column if it was already named correctly
UPDATE public.wallet_requests 
SET method_number = transfer_id 
WHERE method_number IS NULL AND transfer_id IS NOT NULL;

-- Ensure transfer_time is properly typed
ALTER TABLE public.wallet_requests 
ALTER COLUMN transfer_time TYPE timestamp WITH TIME ZONE USING transfer_time::timestamp WITH TIME ZONE;

-- Create function to add balance to student wallet
CREATE OR REPLACE FUNCTION public.add_balance(student_id uuid, amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.students
  SET wallet_balance = wallet_balance + amount
  WHERE id = student_id;
END;
$$;

-- Update RLS policies for wallet_requests
DROP POLICY IF EXISTS "Students can update wallet requests" ON public.wallet_requests;

CREATE POLICY "Support can update wallet requests" ON public.wallet_requests 
    FOR UPDATE USING (true);
