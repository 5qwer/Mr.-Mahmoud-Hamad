
-- التحقق من الاشتراكات الموجودة وإضافة حصص تجريبية لها
DO $$
DECLARE
    sub_record RECORD;
    lesson_id_1 INTEGER;
    lesson_id_2 INTEGER;
    lesson_id_3 INTEGER;
BEGIN
    -- حذف الحصص الموجودة أولاً لتجنب التكرار
    DELETE FROM public.lessons WHERE title LIKE '%تجريبي%';
    
    -- إضافة حصص تجريبية جديدة لكل صف
    INSERT INTO public.lessons (
        title, description, price, order_number, grade, 
        video_url, pdf_url, homework_url, homework_video_url, solution_url
    ) VALUES 
    -- حصص الصف الأول الثانوي
    (
        'الرياضيات - الأعداد الحقيقية',
        'شرح مفصل للأعداد الحقيقية والعمليات عليها',
        50,
        1,
        '1',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
    ),
    (
        'الفيزياء - الحركة في خط مستقيم',
        'دراسة الحركة في خط مستقيم والسرعة والتسارع',
        45,
        2,
        '1',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
    ),
    (
        'الكيمياء - التركيب الذري',
        'فهم التركيب الذري والجدول الدوري',
        55,
        3,
        '1',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
    ),
    -- حصص الصف الثاني الثانوي
    (
        'الرياضيات - المتتاليات',
        'شرح المتتاليات الحسابية والهندسية',
        60,
        1,
        '2',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
    ),
    (
        'الفيزياء - الكهرباء التيارية',
        'دراسة التيار الكهربائي والمقاومة',
        65,
        2,
        '2',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
    ),
    -- حصص الصف الثالث الثانوي
    (
        'الرياضيات - التفاضل والتكامل',
        'مقدمة في التفاضل والتكامل',
        70,
        1,
        '3',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'
    );

    -- ربط الحصص بجميع الاشتراكات حسب الصف
    FOR sub_record IN 
        SELECT id, grade FROM public.subscriptions 
    LOOP
        -- ربط الحصص المناسبة لكل صف
        INSERT INTO public.subscription_lessons (subscription_id, lesson_id)
        SELECT sub_record.id, l.id 
        FROM public.lessons l 
        WHERE l.grade = sub_record.grade
        ON CONFLICT DO NOTHING;
    END LOOP;
    
    RAISE NOTICE 'تم إضافة الحصص وربطها بالاشتراكات بنجاح';
END $$;

-- التأكد من وجود بيانات اختبارية لاشتراك الطالب
INSERT INTO public.subscriptions_users (user_id, subscription_id, expires_at, is_active)
SELECT 
    s.id as user_id,
    sub.id as subscription_id,
    (NOW() + INTERVAL '30 days') as expires_at,
    true as is_active
FROM public.students s
CROSS JOIN public.subscriptions sub
WHERE NOT EXISTS (
    SELECT 1 FROM public.subscriptions_users su 
    WHERE su.user_id = s.id AND su.subscription_id = sub.id
)
LIMIT 5;
