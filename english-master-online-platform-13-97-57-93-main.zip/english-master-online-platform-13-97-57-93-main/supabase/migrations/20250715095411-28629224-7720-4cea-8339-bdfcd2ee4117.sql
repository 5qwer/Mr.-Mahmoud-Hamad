
-- إنشاء جدول لتتبع الجلسات النشطة للطلاب
CREATE TABLE IF NOT EXISTS public.active_student_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID NOT NULL,
  session_token TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_activity TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- إضافة فهرس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_active_sessions_student_id ON public.active_student_sessions(student_id);
CREATE INDEX IF NOT EXISTS idx_active_sessions_token ON public.active_student_sessions(session_token);

-- إنشاء دالة للتحقق من الجلسات النشطة
CREATE OR REPLACE FUNCTION public.check_active_session(p_student_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- التحقق من وجود جلسة نشطة للطالب (خلال آخر 30 دقيقة)
  RETURN EXISTS (
    SELECT 1 
    FROM public.active_student_sessions 
    WHERE student_id = p_student_id 
    AND is_active = true 
    AND last_activity > (now() - INTERVAL '30 minutes')
  );
END;
$$;

-- إنشاء دالة لإنشاء جلسة جديدة
CREATE OR REPLACE FUNCTION public.create_student_session(p_student_id UUID, p_session_token TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- إنهاء جميع الجلسات النشطة للطالب
  UPDATE public.active_student_sessions 
  SET is_active = false 
  WHERE student_id = p_student_id AND is_active = true;
  
  -- إنشاء جلسة جديدة
  INSERT INTO public.active_student_sessions (student_id, session_token)
  VALUES (p_student_id, p_session_token);
  
  RETURN true;
END;
$$;

-- إنشاء دالة لإنهاء الجلسة
CREATE OR REPLACE FUNCTION public.end_student_session(p_session_token TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.active_student_sessions 
  SET is_active = false 
  WHERE session_token = p_session_token AND is_active = true;
  
  RETURN true;
END;
$$;

-- إنشاء دالة لتحديث نشاط الجلسة
CREATE OR REPLACE FUNCTION public.update_session_activity(p_session_token TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.active_student_sessions 
  SET last_activity = now() 
  WHERE session_token = p_session_token AND is_active = true;
  
  RETURN true;
END;
$$;

-- إنشاء دالة لتنظيف الجلسات المنتهية الصلاحية
CREATE OR REPLACE FUNCTION public.cleanup_expired_sessions()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  cleaned_count INTEGER;
BEGIN
  UPDATE public.active_student_sessions 
  SET is_active = false 
  WHERE is_active = true 
  AND last_activity < (now() - INTERVAL '30 minutes');
  
  GET DIAGNOSTICS cleaned_count = ROW_COUNT;
  RETURN cleaned_count;
END;
$$;

-- إضافة RLS policies
ALTER TABLE public.active_student_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow session management" ON public.active_student_sessions
FOR ALL USING (true) WITH CHECK (true);
