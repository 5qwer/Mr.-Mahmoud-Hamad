-- إصلاح RLS policies لجدول activity_logs لتسمح بالوصول بدون مصادقة للنظام
-- وإضافة policy للنظام لإدراج activity logs

-- تحديث سياسة الإدراج في activity_logs للسماح للنظام بإدراج السجلات
DROP POLICY IF EXISTS "Users can create activity logs" ON public.activity_logs;

CREATE POLICY "System can create activity logs" ON public.activity_logs 
FOR INSERT 
WITH CHECK (true);

-- تحديث سياسة المشاهدة في activity_logs للسماح للمستخدمين بمشاهدة سجلاتهم
CREATE POLICY "Users can view their activity logs" ON public.activity_logs 
FOR SELECT 
USING (true);

-- إضافة سياسة للسماح بمشاهدة الاشتراكات لجميع الطلاب من نفس الصف
-- تحديث سياسة الاشتراكات لتكون متاحة للجميع بناءً على الصف
DROP POLICY IF EXISTS "Students can view their own subscriptions" ON public.subscriptions_users;

CREATE POLICY "Students can view all active subscriptions" ON public.subscriptions_users 
FOR SELECT 
USING (true);

-- إضافة سياسة للسماح للطلاب بالاشتراك
CREATE POLICY "Students can purchase subscriptions" ON public.subscriptions_users 
FOR INSERT 
WITH CHECK (true);