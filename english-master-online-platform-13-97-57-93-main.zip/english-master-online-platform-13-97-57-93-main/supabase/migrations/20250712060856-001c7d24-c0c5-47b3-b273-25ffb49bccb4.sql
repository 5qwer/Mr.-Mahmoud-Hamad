
-- Create storage bucket for transfer receipts if it doesn't exist
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('transfer-receipts', 'transfer-receipts', true, 5242880, ARRAY['image/*'])
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for transfer receipts
CREATE POLICY "Anyone can upload transfer receipts" ON storage.objects 
    FOR INSERT WITH CHECK (bucket_id = 'transfer-receipts');

CREATE POLICY "Anyone can view transfer receipts" ON storage.objects 
    FOR SELECT USING (bucket_id = 'transfer-receipts');

CREATE POLICY "Anyone can update transfer receipts" ON storage.objects 
    FOR UPDATE USING (bucket_id = 'transfer-receipts');

CREATE POLICY "Anyone can delete transfer receipts" ON storage.objects 
    FOR DELETE USING (bucket_id = 'transfer-receipts');
