
-- Update the function to remove notification creation and fix balance update
CREATE OR REPLACE FUNCTION public.process_wallet_approval_transaction(
  p_request_id UUID,
  p_student_id UUID,
  p_amount_to_add NUMERIC,
  p_payment_method TEXT,
  p_transfer_number TEXT
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance NUMERIC;
  new_balance NUMERIC;
  result JSON;
BEGIN
  -- Start transaction
  BEGIN
    -- Get current student balance
    SELECT wallet_balance INTO current_balance
    FROM public.students
    WHERE id = p_student_id;
    
    IF current_balance IS NULL THEN
      RAISE EXCEPTION 'Student not found';
    END IF;
    
    -- Calculate new balance
    new_balance := current_balance + p_amount_to_add;
    
    -- Update student balance
    UPDATE public.students
    SET wallet_balance = new_balance,
        updated_at = now()
    WHERE id = p_student_id;
    
    -- Update wallet request status
    UPDATE public.wallet_requests
    SET status = 'approved',
        reviewed_at = now(),
        reviewed_by = 'الدعم الفني',
        updated_at = now()
    WHERE id = p_request_id;
    
    -- Create wallet transaction record
    INSERT INTO public.wallet_transactions (
      student_id,
      type,
      amount,
      description,
      created_at
    ) VALUES (
      p_student_id,
      'charge',
      p_amount_to_add,
      'شحن المحفظة - ' || p_payment_method || ' - ' || p_transfer_number,
      now()
    );
    
    -- Return success result
    result := json_build_object(
      'success', true,
      'message', 'تم تأكيد العملية بنجاح وإضافة المبلغ للرصيد',
      'old_balance', current_balance,
      'new_balance', new_balance,
      'amount_added', p_amount_to_add
    );
    
    RETURN result;
    
  EXCEPTION WHEN OTHERS THEN
    -- Rollback transaction on error
    RAISE EXCEPTION 'فشل في معالجة طلب المحفظة: %', SQLERRM;
  END;
END;
$$;
