-- إصلاح trigger function لحساب تاريخ انتهاء الاشتراك
CREATE OR REPLACE FUNCTION public.update_subscription_expiry()
RETURNS TRIGGER AS $$
DECLARE
  subscription_duration INTEGER;
BEGIN
  -- الحصول على مدة الاشتراك
  SELECT duration_days INTO subscription_duration
  FROM public.subscriptions 
  WHERE id = NEW.subscription_id;
  
  -- حساب تاريخ انتهاء الاشتراك
  NEW.expires_at = NOW() + INTERVAL '1 day' * subscription_duration;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;