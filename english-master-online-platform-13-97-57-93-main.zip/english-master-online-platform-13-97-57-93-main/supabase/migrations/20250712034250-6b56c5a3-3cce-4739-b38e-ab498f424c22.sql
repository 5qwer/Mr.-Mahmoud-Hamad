
-- إنشاء bucket لصور الاشتراكات
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('subscription-images', 'subscription-images', true, 5242880, ARRAY['image/*'])
ON CONFLICT (id) DO NOTHING;

-- تعديل جدول الاشتراكات ليدعم مسار الصورة
ALTER TABLE public.subscriptions 
ADD COLUMN IF NOT EXISTS image_path text;

-- إنشاء جدول ربط الاشتراكات بالطلاب (المشتريات)
CREATE TABLE IF NOT EXISTS public.subscriptions_users (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    student_id UUID NOT NULL,
    subscription_id INTEGER NOT NULL REFERENCES public.subscriptions(id) ON DELETE CASCADE,
    paid BOOLEAN NOT NULL DEFAULT true,
    purchased_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- تفعيل Row Level Security
ALTER TABLE public.subscriptions_users ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان
CREATE POLICY "Students can view their own subscriptions" ON public.subscriptions_users 
    FOR SELECT USING (true);

CREATE POLICY "Students can purchase subscriptions" ON public.subscriptions_users 
    FOR INSERT WITH CHECK (true);

-- إنشاء function لخصم الرصيد من المحفظة
CREATE OR REPLACE FUNCTION public.deduct_balance(student_id uuid, amount numeric)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE public.students
  SET wallet_balance = wallet_balance - amount
  WHERE id = student_id;
END;
$$;

-- تحديث سياسات Storage للسماح بالرفع والعرض
CREATE POLICY "Anyone can upload subscription images" ON storage.objects 
    FOR INSERT WITH CHECK (bucket_id = 'subscription-images');

CREATE POLICY "Anyone can view subscription images" ON storage.objects 
    FOR SELECT USING (bucket_id = 'subscription-images');
