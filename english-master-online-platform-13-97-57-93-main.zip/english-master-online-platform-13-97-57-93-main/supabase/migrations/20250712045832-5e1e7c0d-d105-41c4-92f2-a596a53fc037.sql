
-- إنشاء جدول فريق الدعم الفني
CREATE TABLE public.support_team (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  online BOOLEAN NOT NULL DEFAULT false,
  last_login TIMESTAMP WITH TIME ZONE,
  last_logout TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- تفعيل Row Level Security
ALTER TABLE public.support_team ENABLE ROW LEVEL SECURITY;

-- سياسة للسماح بعرض البيانات للجميع (للمعلم ولأعضاء الدعم)
CREATE POLICY "Anyone can view support team"
  ON public.support_team
  FOR SELECT
  USING (true);

-- سياسة للسماح بإضافة أعضاء جدد (للمعلم)
CREATE POLICY "Allow inserting support members"
  ON public.support_team
  FOR INSERT
  WITH CHECK (true);

-- سياسة للسماح بتحديث حالة الاتصال
CREATE POLICY "Allow updating support status"
  ON public.support_team
  FOR UPDATE
  USING (true);

-- سياسة للسماح بحذف أعضاء الدعم
CREATE POLICY "Allow deleting support members"
  ON public.support_team
  FOR DELETE
  USING (true);

-- دالة مصادقة الدعم الفني (تحديث الدالة الموجودة)
CREATE OR REPLACE FUNCTION public.authenticate_support_team(support_name text, support_code text)
 RETURNS TABLE(id uuid, name text)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    support_team.id,
    support_team.name
  FROM public.support_team
  WHERE support_team.name = support_name 
    AND support_team.code = support_code;
    
  -- تحديث وقت آخر دخول
  UPDATE public.support_team 
  SET last_login = now(), online = true
  WHERE support_team.name = support_name 
    AND support_team.code = support_code;
END;
$function$
