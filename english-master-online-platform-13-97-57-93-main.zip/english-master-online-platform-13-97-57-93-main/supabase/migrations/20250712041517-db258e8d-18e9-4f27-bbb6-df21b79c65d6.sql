
-- إضافة سياسة للسماح بإدراج الاشتراكات (للمعلمين أو المشرفين)
CREATE POLICY "Allow inserting subscriptions" ON public.subscriptions 
    FOR INSERT WITH CHECK (true);

-- إضافة سياسة للسماح بتحديث الاشتراكات
CREATE POLICY "Allow updating subscriptions" ON public.subscriptions 
    FOR UPDATE USING (true);

-- إضافة سياسة للسماح بحذف الاشتراكات
CREATE POLICY "Allow deleting subscriptions" ON public.subscriptions 
    FOR DELETE USING (true);

-- إضافة سياسات مماثلة لجدول subscription_lessons
CREATE POLICY "Allow inserting subscription lessons" ON public.subscription_lessons 
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow updating subscription lessons" ON public.subscription_lessons 
    FOR UPDATE USING (true);

CREATE POLICY "Allow deleting subscription lessons" ON public.subscription_lessons 
    FOR DELETE USING (true);
