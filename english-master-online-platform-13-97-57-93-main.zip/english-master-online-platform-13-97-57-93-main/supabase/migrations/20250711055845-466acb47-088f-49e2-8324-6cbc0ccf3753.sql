
-- إنشاء جدول الطلاب
CREATE TABLE IF NOT EXISTS public.students (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    full_name TEXT NOT NULL,
    student_number TEXT,
    parent_number TEXT,
    password TEXT NOT NULL,
    grade TEXT NOT NULL DEFAULT '1',
    email TEXT,
    wallet_balance NUMERIC NOT NULL DEFAULT 0,
    points INTEGER NOT NULL DEFAULT 0,
    completed_lessons INTEGER NOT NULL DEFAULT 0,
    total_lessons INTEGER NOT NULL DEFAULT 0,
    is_blocked BOOLEAN NOT NULL DEFAULT false,
    block_reason TEXT,
    user_id UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- إنشاء جدول معاملات المحفظة
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    student_id UUID NOT NULL REFERENCES public.students(id),
    amount NUMERIC NOT NULL,
    type TEXT NOT NULL,
    description TEXT,
    lesson_id INTEGER,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- إنشاء جدول نشاط الطلاب
CREATE TABLE IF NOT EXISTS public.student_activity (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    student_id UUID NOT NULL REFERENCES public.students(id),
    activity_type TEXT NOT NULL,
    description TEXT NOT NULL,
    lesson_id INTEGER,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- إنشاء جدول المكافآت
CREATE TABLE IF NOT EXISTS public.rewards (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    student_id UUID NOT NULL REFERENCES public.students(id),
    points INTEGER NOT NULL DEFAULT 0,
    reason TEXT,
    lesson_id INTEGER,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- تفعيل Row Level Security
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_activity ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rewards ENABLE ROW LEVEL SECURITY;

-- إنشاء سياسات الأمان للطلاب
CREATE POLICY "Students can view their own data" ON public.students 
    FOR SELECT USING (true);

CREATE POLICY "Students can insert their own data" ON public.students 
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Students can update their own data" ON public.students 
    FOR UPDATE USING (true);

-- إنشاء سياسات الأمان لمعاملات المحفظة
CREATE POLICY "Students can view their own transactions" ON public.wallet_transactions 
    FOR SELECT USING (true);

CREATE POLICY "System can create transactions" ON public.wallet_transactions 
    FOR INSERT WITH CHECK (true);

-- إنشاء سياسات الأمان لنشاط الطلاب
CREATE POLICY "Students can view their own activity" ON public.student_activity 
    FOR SELECT USING (true);

CREATE POLICY "System can log activity" ON public.student_activity 
    FOR INSERT WITH CHECK (true);

-- إنشاء سياسات الأمان للمكافآت
CREATE POLICY "Students can view their own rewards" ON public.rewards 
    FOR SELECT USING (true);

CREATE POLICY "System can create rewards" ON public.rewards 
    FOR INSERT WITH CHECK (true);

-- إنشاء فانكشن لمصادقة الطلاب
CREATE OR REPLACE FUNCTION public.authenticate_student(
    student_name TEXT,
    student_password TEXT
)
RETURNS TABLE(
    id UUID,
    full_name TEXT,
    grade TEXT,
    parent_number TEXT,
    student_number TEXT,
    wallet_balance NUMERIC,
    points INTEGER,
    completed_lessons INTEGER,
    total_lessons INTEGER,
    is_blocked BOOLEAN,
    block_reason TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    s.id,
    s.full_name,
    s.grade,
    s.parent_number,
    s.student_number,
    s.wallet_balance,
    s.points,
    s.completed_lessons,
    s.total_lessons,
    s.is_blocked,
    s.block_reason
  FROM public.students s
  WHERE s.full_name = student_name AND s.password = student_password;
END;
$$;

-- إدراج بيانات تجريبية
INSERT INTO public.students (full_name, password, grade, student_number, parent_number, wallet_balance, points)
VALUES 
    ('أحمد محمد علي', '123456', 'first', 'ST001', '01123456789', 100, 50),
    ('فاطمة سعد محمود', '789012', 'second', 'ST002', '01187654321', 150, 75),
    ('محمد أحمد حسن', '456789', 'third', 'ST003', '01156789012', 200, 100)
ON CONFLICT DO NOTHING;
