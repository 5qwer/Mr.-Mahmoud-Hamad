
-- إضافة RLS policies للسماح بإنشاء وتعديل الحصص والاشتراكات
CREATE POLICY "Allow creating lessons" ON public.lessons FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow updating lessons" ON public.lessons FOR UPDATE USING (true);

-- إضافة RLS policies لربط الحصص بالاشتراكات  
CREATE POLICY "Allow managing subscription lessons" ON public.subscription_lessons FOR ALL USING (true);

-- التأكد من وجود trigger لتحديث updated_at
DROP TRIGGER IF EXISTS update_lessons_updated_at ON public.lessons;
CREATE TRIGGER update_lessons_updated_at 
  BEFORE UPDATE ON public.lessons 
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

DROP TRIGGER IF EXISTS update_subscriptions_updated_at ON public.subscriptions;
CREATE TRIGGER update_subscriptions_updated_at 
  BEFORE UPDATE ON public.subscriptions 
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();
