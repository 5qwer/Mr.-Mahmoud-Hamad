-- التأكد من وجود Buckets للتخزين
DO $$
BEGIN
  -- lesson-images bucket
  IF NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'lesson-images') THEN
    INSERT INTO storage.buckets (id, name, public) VALUES ('lesson-images', 'lesson-images', true);
  END IF;
  
  -- lesson-videos bucket
  IF NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'lesson-videos') THEN
    INSERT INTO storage.buckets (id, name, public) VALUES ('lesson-videos', 'lesson-videos', true);
  END IF;
  
  -- lesson-files bucket
  IF NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'lesson-files') THEN
    INSERT INTO storage.buckets (id, name, public) VALUES ('lesson-files', 'lesson-files', true);
  END IF;
  
  -- homework-videos bucket
  IF NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'homework-videos') THEN
    INSERT INTO storage.buckets (id, name, public) VALUES ('homework-videos', 'homework-videos', true);
  END IF;
  
  -- solution-files bucket
  IF NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'solution-files') THEN
    INSERT INTO storage.buckets (id, name, public) VALUES ('solution-files', 'solution-files', true);
  END IF;
END $$;