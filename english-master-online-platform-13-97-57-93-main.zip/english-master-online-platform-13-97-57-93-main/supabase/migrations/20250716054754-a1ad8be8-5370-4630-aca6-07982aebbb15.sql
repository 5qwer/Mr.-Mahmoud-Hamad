
-- إنشاء جدول طلبات حجز الكتب
CREATE TABLE public.book_reservations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID NOT NULL,
  student_name TEXT NOT NULL,
  student_grade TEXT NOT NULL,
  book_title TEXT NOT NULL,
  book_subject TEXT NOT NULL,
  book_grade TEXT NOT NULL,
  book_price NUMERIC NOT NULL,
  pickup_location TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  reviewed_by TEXT,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  notes TEXT
);

-- إنشاء جدول الكتب المتاحة (تحويل من localStorage إلى Supabase)
CREATE TABLE public.available_books (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  price NUMERIC NOT NULL,
  cover_image TEXT,
  grade TEXT NOT NULL,
  subject TEXT NOT NULL DEFAULT 'عام',
  pickup_location TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'unlimited',
  duration INTEGER,
  file_size TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by TEXT DEFAULT 'المعلم'
);

-- إضافة RLS policies للأمان
ALTER TABLE public.book_reservations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.available_books ENABLE ROW LEVEL SECURITY;

-- سياسات الأمان لطلبات الحجز
CREATE POLICY "Students can create book reservations" 
  ON public.book_reservations 
  FOR INSERT 
  WITH CHECK (true);

CREATE POLICY "Students can view book reservations" 
  ON public.book_reservations 
  FOR SELECT 
  USING (true);

CREATE POLICY "Support can update book reservations" 
  ON public.book_reservations 
  FOR UPDATE 
  USING (true);

-- سياسات الأمان للكتب المتاحة
CREATE POLICY "Everyone can view available books" 
  ON public.available_books 
  FOR SELECT 
  USING (true);

CREATE POLICY "Teachers can manage available books" 
  ON public.available_books 
  FOR ALL 
  USING (true);

-- إنشاء trigger لتحديث updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_book_reservations_updated_at 
  BEFORE UPDATE ON public.book_reservations 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_available_books_updated_at 
  BEFORE UPDATE ON public.available_books 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
