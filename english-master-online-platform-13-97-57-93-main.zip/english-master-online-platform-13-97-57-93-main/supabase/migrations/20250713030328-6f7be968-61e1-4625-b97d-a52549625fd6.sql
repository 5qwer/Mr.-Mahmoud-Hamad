
-- إضافة عمود subscription_id إلى جدول lessons إذا لم يكن موجود
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'lessons' AND column_name = 'subscription_id') THEN
        ALTER TABLE public.lessons ADD COLUMN subscription_id INTEGER;
        ALTER TABLE public.lessons ADD CONSTRAINT fk_lessons_subscription 
            FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE SET NULL;
    END IF;
END $$;

-- التأكد من وجود بيانات في جدول subscription_lessons
-- ربط الحصص الموجودة بالاشتراكات بناءً على الصف
INSERT INTO public.subscription_lessons (subscription_id, lesson_id)
SELECT s.id, l.id 
FROM public.subscriptions s
CROSS JOIN public.lessons l
WHERE s.grade = l.grade
AND NOT EXISTS (
    SELECT 1 FROM public.subscription_lessons sl 
    WHERE sl.subscription_id = s.id AND sl.lesson_id = l.id
)
ON CONFLICT DO NOTHING;

-- إضافة بعض الحصص التجريبية إذا لم تكن موجودة
INSERT INTO public.lessons (
    title, description, price, order_number, grade, video_url, pdf_url
) VALUES 
(
    'حصة الفيزياء - الحركة الدائرية',
    'شرح مفصل للحركة الدائرية والقوة المركزية',
    50,
    1,
    '1',
    'https://example.com/video1.mp4',
    'https://example.com/pdf1.pdf'
),
(
    'حصة الفيزياء - الموجات',
    'دراسة خصائص الموجات والاهتزازات',
    60,
    2,
    '1',
    'https://example.com/video2.mp4',
    'https://example.com/pdf2.pdf'
),
(
    'حصة الفيزياء المتقدمة - الكهرباء',
    'شرح الدوائر الكهربائية والمقاومات',
    75,
    1,
    '2',
    'https://example.com/video3.mp4',
    'https://example.com/pdf3.pdf'
)
ON CONFLICT DO NOTHING;

-- ربط الحصص الجديدة بالاشتراكات
INSERT INTO public.subscription_lessons (subscription_id, lesson_id)
SELECT s.id, l.id 
FROM public.subscriptions s
JOIN public.lessons l ON s.grade = l.grade
WHERE NOT EXISTS (
    SELECT 1 FROM public.subscription_lessons sl 
    WHERE sl.subscription_id = s.id AND sl.lesson_id = l.id
)
ON CONFLICT DO NOTHING;

-- إضافة فهرس لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_subscription_lessons_subscription_id 
ON public.subscription_lessons(subscription_id);

CREATE INDEX IF NOT EXISTS idx_subscription_lessons_lesson_id 
ON public.subscription_lessons(lesson_id);
