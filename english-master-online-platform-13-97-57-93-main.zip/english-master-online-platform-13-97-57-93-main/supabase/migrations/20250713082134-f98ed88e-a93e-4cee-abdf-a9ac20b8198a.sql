-- إنشاء storage buckets الجديدة فقط (تجاهل المكررة)
INSERT INTO storage.buckets (id, name, public) 
SELECT 'homework-videos', 'homework-videos', true
WHERE NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'homework-videos');

INSERT INTO storage.buckets (id, name, public) 
SELECT 'solution-files', 'solution-files', true
WHERE NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'solution-files');

-- إنشاء policies للوصول للملفات
CREATE POLICY "Allow public access to lesson videos" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'lesson-videos');

CREATE POLICY "Allow teachers to upload lesson videos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'lesson-videos');

CREATE POLICY "Allow teachers to update lesson videos" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'lesson-videos');

CREATE POLICY "Allow public access to lesson files" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'lesson-files');

CREATE POLICY "Allow teachers to upload lesson files" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'lesson-files');

CREATE POLICY "Allow teachers to update lesson files" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'lesson-files');

CREATE POLICY "Allow public access to lesson images" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'lesson-images');

CREATE POLICY "Allow teachers to upload lesson images" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'lesson-images');

CREATE POLICY "Allow teachers to update lesson images" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'lesson-images');

CREATE POLICY "Allow public access to homework videos" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'homework-videos');

CREATE POLICY "Allow teachers to upload homework videos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'homework-videos');

CREATE POLICY "Allow teachers to update homework videos" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'homework-videos');

CREATE POLICY "Allow public access to solution files" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'solution-files');

CREATE POLICY "Allow teachers to upload solution files" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'solution-files');

CREATE POLICY "Allow teachers to update solution files" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'solution-files');