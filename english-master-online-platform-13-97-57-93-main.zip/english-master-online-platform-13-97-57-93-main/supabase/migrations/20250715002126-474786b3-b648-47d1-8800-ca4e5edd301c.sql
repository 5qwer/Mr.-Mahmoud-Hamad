-- إصلاح سياسات جدول activity_logs
DROP POLICY IF EXISTS "System can create activity logs" ON public.activity_logs;

-- إنشاء سياسة جديدة تسمح بالإدراج بدون شروط معقدة
CREATE POLICY "Allow activity logs creation" ON public.activity_logs 
FOR INSERT 
WITH CHECK (true);

-- تحديث سياسة العرض لتكون أكثر مرونة
DROP POLICY IF EXISTS "Users can view their activity logs" ON public.activity_logs;

CREATE POLICY "Allow viewing activity logs" ON public.activity_logs 
FOR SELECT 
USING (true);

-- إصلاح سياسات الاشتراكات لضمان ظهورها للجميع حسب الصف
DROP POLICY IF EXISTS "Students can view all subscriptions" ON public.subscriptions_users;
DROP POLICY IF EXISTS "Users can view all subscriptions" ON public.user_subscriptions;

-- إنشاء سياسات جديدة للاشتراكات تسمح للجميع بالعرض
CREATE POLICY "Everyone can view subscriptions" ON public.subscriptions_users 
FOR SELECT 
USING (true);

CREATE POLICY "Everyone can view user subscriptions" ON public.user_subscriptions 
FOR SELECT 
USING (true);

-- التأكد من أن جدول subscriptions يسمح بالعرض للجميع
DROP POLICY IF EXISTS "Anyone can view subscriptions" ON public.subscriptions;

CREATE POLICY "Public can view all subscriptions" ON public.subscriptions 
FOR SELECT 
USING (true);

-- إصلاح سياسات جدول الدروس
DROP POLICY IF EXISTS "Anyone can view lessons" ON public.lessons;

CREATE POLICY "Public can view all lessons" ON public.lessons 
FOR SELECT 
USING (true);