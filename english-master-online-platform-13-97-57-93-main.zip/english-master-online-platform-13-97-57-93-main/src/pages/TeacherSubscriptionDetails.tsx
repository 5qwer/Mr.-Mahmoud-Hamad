
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Calendar, BookOpen, Moon, Sun, Edit, Plus, Play, FileText } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';
import { supabaseDataManager } from '@/utils/supabaseDataManager';

interface Subscription {
  id: number;
  title: string;
  description: string;
  price: number;
  duration: string;
  coverImage: string;
  lessons: any[];
  grade: string;
  createdAt: string;
}

const TeacherSubscriptionDetails = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { subscriptionId } = useParams();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    loadSubscriptionDetails();
  }, [subscriptionId]);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
  };

  const loadSubscriptionDetails = async () => {
    if (!subscriptionId) {
      toast.error('معرف الاشتراك غير صحيح');
      navigate('/teacher/subscriptions');
      return;
    }

    setLoading(true);
    try {
      console.log('تحميل تفاصيل الاشتراك:', subscriptionId);
      const subscriptionData = await supabaseDataManager.getSubscriptionById(parseInt(subscriptionId));
      
      if (subscriptionData) {
        setSubscription(subscriptionData);
        console.log('تم تحميل بيانات الاشتراك:', subscriptionData);
      } else {
        toast.error('الاشتراك غير موجود');
        navigate('/teacher/subscriptions');
      }
    } catch (error) {
      console.error('خطأ في تحميل تفاصيل الاشتراك:', error);
      toast.error('حدث خطأ في تحميل تفاصيل الاشتراك');
      navigate('/teacher/subscriptions');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${
        isDarkMode 
          ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
          : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
      }`}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">جاري تحميل تفاصيل الاشتراك...</p>
        </div>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${
        isDarkMode 
          ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
          : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
      }`}>
        <Card className="p-8 text-center">
          <p className="text-muted-foreground text-xl">الاشتراك غير موجود</p>
          <Button 
            onClick={() => navigate('/teacher/subscriptions')} 
            className="mt-4"
          >
            العودة للاشتراكات
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 animate-fade-in">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/teacher/subscriptions')}
            className="rounded-full ml-4 hover-lift"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold text-primary mr-4">📋 تفاصيل الاشتراك</h1>
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className="rounded-full hover-lift"
        >
          {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      <div className="container mx-auto px-4 py-8 space-y-6">
        {/* معلومات الاشتراك */}
        <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm animate-slide-in`}>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <div className="aspect-video bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg relative mb-4">
                {subscription.coverImage ? (
                  <img 
                    src={subscription.coverImage} 
                    alt={subscription.title}
                    className="w-full h-full object-cover rounded-lg"
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <BookOpen className="w-16 h-16 text-white/80" />
                  </div>
                )}
                <div className="absolute top-2 right-2">
                  <Badge className="bg-blue-500 text-white">
                    {subscription.grade === '1' ? 'الأول الثانوي' : 
                     subscription.grade === '2' ? 'الثاني الثانوي' : 'الثالث الثانوي'}
                  </Badge>
                </div>
              </div>
            </div>
            
            <div>
              <h1 className="text-3xl font-bold mb-4">{subscription.title}</h1>
              <p className="text-muted-foreground text-lg mb-6">{subscription.description}</p>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 ml-3 text-blue-500" />
                  <span className="font-semibold">المدة: {subscription.duration} يوم</span>
                </div>
                
                <div className="flex items-center">
                  <BookOpen className="w-5 h-5 ml-3 text-green-500" />
                  <span className="font-semibold">عدد الحصص: {subscription.lessons?.length || 0}</span>
                </div>
                
                <div className="text-3xl font-bold text-green-600">
                  {subscription.price} جنيه
                </div>
              </div>
              
              <div className="flex gap-4 mt-6">
                <Button 
                  onClick={() => navigate(`/teacher/upload-lesson?subscription=${subscription.id}`)}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  <Plus className="w-4 h-4 ml-2" />
                  إضافة حصة جديدة
                </Button>
                
                <Button 
                  variant="outline"
                  onClick={() => navigate('/teacher/subscriptions')}
                >
                  <Edit className="w-4 h-4 ml-2" />
                  تعديل الاشتراك
                </Button>
              </div>
            </div>
          </div>
        </Card>

        {/* قائمة الحصص */}
        <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm animate-slide-in`}>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">حصص الاشتراك</h2>
            <Button 
              onClick={() => navigate(`/teacher/upload-lesson?subscription=${subscription.id}`)}
              className="bg-green-600 hover:bg-green-700"
            >
              <Plus className="w-4 h-4 ml-2" />
              إضافة حصة جديدة
            </Button>
          </div>

          {subscription.lessons && subscription.lessons.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {subscription.lessons
                .sort((a, b) => (a.order_number || 0) - (b.order_number || 0))
                .map((lesson, index) => (
                <Card 
                  key={lesson.id} 
                  className={`p-4 ${isDarkMode ? 'bg-gray-700/50' : 'bg-gray-50'} hover-lift animate-scale-in`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge className="bg-blue-500 text-white text-xs">
                          الحصة {lesson.order_number || index + 1}
                        </Badge>
                      </div>
                      <h4 className="font-bold text-lg">{lesson.title}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-2">{lesson.description}</p>
                    </div>
                    
                    <div className="flex gap-1">
                      {lesson.video_url && <Play className="w-4 h-4 text-green-500" />}
                      {lesson.pdf_url && <FileText className="w-4 h-4 text-blue-500" />}
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center mt-4">
                    <span className="text-sm text-muted-foreground">
                      الترتيب: {lesson.order_number || index + 1}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      أسئلة: {lesson.questions?.length || 0}
                    </span>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground text-xl mb-4">لا توجد حصص في هذا الاشتراك</p>
              <Button 
                onClick={() => navigate(`/teacher/upload-lesson?subscription=${subscription.id}`)}
                className="bg-green-600 hover:bg-green-700"
              >
                إضافة أول حصة
              </Button>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

export default TeacherSubscriptionDetails;
