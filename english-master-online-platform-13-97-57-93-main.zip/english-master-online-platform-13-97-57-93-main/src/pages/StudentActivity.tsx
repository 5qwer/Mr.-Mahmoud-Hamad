
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Activity, Trophy, BookOpen, CreditCard, Award, Target, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { dataManager } from '@/utils/dataManager';

const StudentActivity = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [activityLog, setActivityLog] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    setCurrentStudent(student);

    // Load activity log and stats
    const log = dataManager.getActivityLog(student.id.toString());
    const studentStats = dataManager.getStudentStats(student.id.toString());
    
    setActivityLog(log);
    setStats(studentStats);
  }, [navigate]);

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'lesson_watched':
        return <BookOpen className="w-5 h-5 text-blue-500" />;
      case 'exam_passed':
        return <Trophy className="w-5 h-5 text-green-500" />;
      case 'wallet_charged':
        return <CreditCard className="w-5 h-5 text-purple-500" />;
      case 'lesson_purchased':
        return <Award className="w-5 h-5 text-orange-500" />;
      case 'subscription_purchased':
        return <Target className="w-5 h-5 text-indigo-500" />;
      case 'book_purchased':
        return <BookOpen className="w-5 h-5 text-pink-500" />;
      default:
        return <Activity className="w-5 h-5 text-gray-500" />;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`} style={{
      backgroundImage: localStorage.getItem('appBackgroundImage') ? `url(${localStorage.getItem('appBackgroundImage')})` : undefined,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed'
    }}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/student/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">📑 سجل النشاط</h1>
        
        {/* Teacher Image */}
        <div className="mr-4">
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-blue-400 shadow-lg">
            <img 
              src="/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png" 
              alt="Mr. Mahmoud Hamad" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Statistics Overview */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card className="p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-blue-500" />
              <h3 className="font-bold text-sm">التقدم</h3>
              <p className="text-2xl font-bold text-blue-600">{stats.progressPercentage}%</p>
              <p className="text-xs text-muted-foreground">{stats.completedLessons}/{stats.totalLessons} حصة</p>
            </Card>

            <Card className="p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm text-center">
              <Trophy className="w-8 h-8 mx-auto mb-2 text-green-500" />
              <h3 className="font-bold text-sm">متوسط الدرجات</h3>
              <p className="text-2xl font-bold text-green-600">{stats.averageScore}%</p>
              <p className="text-xs text-muted-foreground">{stats.totalExamsTaken} امتحان</p>
            </Card>

            <Card className="p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm text-center">
              <Award className="w-8 h-8 mx-auto mb-2 text-purple-500" />
              <h3 className="font-bold text-sm">النقاط</h3>
              <p className="text-2xl font-bold text-purple-600">{stats.totalPoints}</p>
              <p className="text-xs text-muted-foreground">المستوى {stats.level}</p>
            </Card>

            <Card className="p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm text-center">
              <CreditCard className="w-8 h-8 mx-auto mb-2 text-orange-500" />
              <h3 className="font-bold text-sm">المحفظة</h3>
              <p className="text-2xl font-bold text-orange-600">{stats.walletBalance}</p>
              <p className="text-xs text-muted-foreground">جنيه</p>
            </Card>
          </div>
        )}

        {/* Level Progress */}
        {stats && (
          <Card className="p-4 mb-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold">تقدم المستوى</h3>
              <span className="text-sm text-muted-foreground">المستوى {stats.level}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
              <div 
                className="bg-gradient-to-r from-purple-500 to-blue-500 h-3 rounded-full transition-all duration-300"
                style={{ 
                  width: `${Math.max(5, ((stats.totalPoints % 100) / 100) * 100)}%` 
                }}
              ></div>
            </div>
            <p className="text-sm text-muted-foreground">
              {stats.nextLevelPoints} نقطة للمستوى التالي
            </p>
          </Card>
        )}

        {/* Activity Log */}
        <Card className="p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
          <h3 className="font-bold mb-4 flex items-center">
            <Activity className="w-5 h-5 mr-2" />
            سجل الأنشطة
          </h3>
          
          {activityLog.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Activity className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>لا توجد أنشطة بعد</p>
              <p className="text-sm">ابدأ بمشاهدة الحصص وحل الامتحانات</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {activityLog.map((activity) => (
                <div 
                  key={activity.id}
                  className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600"
                >
                  <div className="flex-shrink-0 mt-0.5">
                    {getActivityIcon(activity.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {activity.description}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {formatDate(activity.timestamp)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Exam Results Summary */}
        {currentStudent?.examResults && currentStudent.examResults.length > 0 && (
          <Card className="p-4 mt-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <h3 className="font-bold mb-4 flex items-center">
              <Trophy className="w-5 h-5 mr-2" />
              نتائج الامتحانات الأخيرة
            </h3>
            
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {currentStudent.examResults.slice(0, 10).map((result: any, index: number) => (
                <div 
                  key={index}
                  className="flex items-center justify-between p-2 rounded border border-gray-200 dark:border-gray-600"
                >
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${result.passed ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className="text-sm">حصة رقم {result.lessonId}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`text-sm font-bold ${result.passed ? 'text-green-600' : 'text-red-600'}`}>
                      {result.percentage}%
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {result.score}/{result.totalQuestions}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default StudentActivity;
