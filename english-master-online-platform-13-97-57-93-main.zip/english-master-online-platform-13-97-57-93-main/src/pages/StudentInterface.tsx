import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, LogIn, UserPlus, Sun, Moon, Sparkles, Star, Heart, Award, Zap, Globe, Crown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const StudentInterface = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const isDark = savedTheme === 'dark';
    setIsDarkMode(isDark);
    document.documentElement.classList.toggle('dark', isDark);

    // التحقق من وجود جلسة طالب نشطة
    const currentStudent = localStorage.getItem('currentStudent');
    if (currentStudent) {
      try {
        JSON.parse(currentStudent);
        console.log('تم العثور على جلسة طالب نشطة، إعادة توجيه للوحة التحكم');
        navigate('/student/dashboard');
      } catch (error) {
        console.error('خطأ في قراءة بيانات الطالب:', error);
        localStorage.removeItem('currentStudent');
      }
    }
  }, [navigate]);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', newTheme);
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Enhanced Premium Background */}
      <div className="absolute inset-0">
        {/* Animated gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-purple-900 via-indigo-800 to-cyan-900 animate-gradient-shift">
          {/* Floating premium elements */}
          <div className="absolute inset-0">
            {[...Array(30)].map((_, i) => (
              <div
                key={i}
                className={`absolute animate-float ${
                  i % 8 === 0 ? 'text-6xl' : 
                  i % 8 === 1 ? 'text-5xl' :
                  i % 8 === 2 ? 'text-4xl' :
                  'w-4 h-4 bg-white/30 rounded-full modern-shadow'
                }`}
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 4}s`,
                  animationDuration: `${3 + Math.random() * 4}s`,
                }}
              >
                {i % 8 === 0 && '⭐'}
                {i % 8 === 1 && '💎'}
                {i % 8 === 2 && '🏆'}
              </div>
            ))}
          </div>

          {/* Premium floating icons */}
          <div className="absolute top-20 left-12 text-yellow-300/50 animate-bounce-gentle transform rotate-12">
            <Crown size={80} className="text-glow" />
          </div>
          <div className="absolute top-32 right-20 text-blue-300/50 animate-pulse-custom transform -rotate-12">
            <Globe size={90} className="text-glow" />
          </div>
          <div className="absolute bottom-40 left-20 text-green-300/40 animate-float transform rotate-45">
            <Award size={70} className="text-glow" />
          </div>
          <div className="absolute top-1/2 right-32 text-purple-300/40 animate-spin-slow">
            <Zap size={60} className="text-glow" />
          </div>
        </div>
      </div>

      {/* Enhanced Header */}
      <div className="relative z-20 flex justify-between items-center p-8">
        <div className="flex items-center animate-slide-up">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/')}
            className="rounded-full ml-4 bg-white/20 border-white/40 text-white hover:bg-white/30 backdrop-blur-xl hover:scale-110 transition-all duration-300 modern-shadow-lg"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          <div className="mr-4">
            <h1 className="text-5xl font-black bg-gradient-to-r from-white via-yellow-200 to-white bg-clip-text text-transparent text-glow">
              🌟 منصة عالمية متطورة
            </h1>
            <p className="text-2xl text-white/90 font-bold mt-2 animate-pulse-custom">للتعليم الرقمي المتميز</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="text-white text-xl font-bold bg-gradient-to-r from-yellow-400/30 to-orange-400/30 px-6 py-3 rounded-full backdrop-blur-xl border-2 border-white/30 modern-shadow-lg animate-glow">
            <Star className="inline w-6 h-6 mr-2" />
            الأفضل عالمياً
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            className="rounded-full bg-white/20 border-white/40 text-white hover:bg-white/30 backdrop-blur-xl hover:scale-110 transition-all duration-300 modern-shadow-lg"
          >
            {isDarkMode ? <Sun className="h-6 w-6" /> : <Moon className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Enhanced Main Content */}
      <div className="relative z-20 container mx-auto px-8 py-8">
        <div className="max-w-lg mx-auto">
          {/* Premium interface card */}
          <div className="bg-gradient-to-br from-white/95 via-blue-50/95 to-purple-50/95 dark:from-gray-900/95 dark:via-blue-900/95 dark:to-purple-900/95 backdrop-blur-2xl rounded-3xl p-2 border-4 border-white/40 modern-shadow-lg animate-rise-from-ground card-hover-effect">
            {/* Enhanced header */}
            <div className="bg-gradient-to-r from-blue-600/90 to-purple-600/90 rounded-t-3xl p-6 flex items-center justify-between border-b-2 border-white/30">
              <div className="flex items-center space-x-4">
                <div className="w-4 h-4 bg-green-400 rounded-full animate-pulse-custom modern-shadow"></div>
                <div className="w-4 h-4 bg-yellow-400 rounded-full animate-pulse-custom modern-shadow" style={{animationDelay: '0.3s'}}></div>
                <div className="w-4 h-4 bg-red-400 rounded-full animate-pulse-custom modern-shadow" style={{animationDelay: '0.6s'}}></div>
              </div>
              <h2 className="text-white font-black text-xl text-glow">🎓 بوابة الطالب المتميز</h2>
              <Heart className="w-6 h-6 text-pink-300 animate-pulse-custom" />
            </div>

            {/* Welcome section */}
            <div className="p-8 text-center border-b-2 border-gray-200/20">
              <div className="relative mb-6">
                <div className="absolute -inset-4 bg-gradient-to-r from-blue-400/30 to-purple-400/30 rounded-full blur-lg animate-pulse-custom"></div>
                <Sparkles className="relative w-20 h-20 mx-auto text-blue-500 animate-spin-slow text-glow" />
              </div>
              <h3 className="text-3xl font-black text-gray-800 dark:text-white mb-3 animate-fade-in gradient-text">
                أهلاً وسهلاً بك
              </h3>
              <p className="text-xl text-gray-600 dark:text-gray-300 font-semibold animate-fade-in" style={{animationDelay: '0.2s'}}>
                في منصة التعليم العالمية المتطورة
              </p>
              <div className="mt-4 flex justify-center space-x-2">
                <Star className="w-6 h-6 text-yellow-400 animate-pulse-custom" />
                <Star className="w-6 h-6 text-yellow-400 animate-pulse-custom" style={{animationDelay: '0.2s'}} />
                <Star className="w-6 h-6 text-yellow-400 animate-pulse-custom" style={{animationDelay: '0.4s'}} />
                <Star className="w-6 h-6 text-yellow-400 animate-pulse-custom" style={{animationDelay: '0.6s'}} />
                <Star className="w-6 h-6 text-yellow-400 animate-pulse-custom" style={{animationDelay: '0.8s'}} />
              </div>
            </div>

            {/* Enhanced Options */}
            <div className="p-8 space-y-6">
              {/* Login Option */}
              <Card 
                className="group p-6 bg-gradient-to-r from-blue-500/90 to-blue-600/90 border-3 border-blue-300/50 hover:from-blue-400/90 hover:to-blue-500/90 transition-all duration-300 cursor-pointer card-hover-effect backdrop-blur-sm animate-slide-in-right modern-shadow-lg"
                onClick={() => navigate('/student/login')}
                style={{animationDelay: '0.3s'}}
              >
                <div className="flex items-center space-x-5 text-white">
                  <div className="bg-blue-300/40 p-4 rounded-2xl group-hover:scale-110 transition-transform duration-300 group-hover:bg-blue-200/50 modern-shadow">
                    <LogIn className="w-8 h-8" />
                  </div>
                  <div className="flex-1 text-right">
                    <h3 className="text-2xl font-black mb-2 text-glow">🔐 تسجيل الدخول</h3>
                    <p className="text-blue-100 text-lg font-medium">للطلاب المسجلين مسبقاً</p>
                  </div>
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Sparkles className="w-6 h-6 text-yellow-300 animate-spin-slow" />
                  </div>
                </div>
              </Card>

              {/* Register Option */}
              <Card 
                className="group p-6 bg-gradient-to-r from-green-500/90 to-emerald-600/90 border-3 border-green-300/50 hover:from-green-400/90 hover:to-emerald-500/90 transition-all duration-300 cursor-pointer card-hover-effect backdrop-blur-sm animate-slide-in-right modern-shadow-lg"
                onClick={() => navigate('/student/register')}
                style={{animationDelay: '0.5s'}}
              >
                <div className="flex items-center space-x-5 text-white">
                  <div className="bg-green-300/40 p-4 rounded-2xl group-hover:scale-110 transition-transform duration-300 group-hover:bg-green-200/50 modern-shadow">
                    <UserPlus className="w-8 h-8" />
                  </div>
                  <div className="flex-1 text-right">
                    <h3 className="text-2xl font-black mb-2 text-glow">📝 إنشاء حساب جديد</h3>
                    <p className="text-green-100 text-lg font-medium">انضم إلى المنصة العالمية</p>
                  </div>
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Crown className="w-6 h-6 text-yellow-300 animate-bounce-gentle" />
                  </div>
                </div>
              </Card>
            </div>
          </div>

          {/* Enhanced Teacher Section */}
          <div className="mt-10 text-center animate-fade-in" style={{animationDelay: '0.7s'}}>
            <div className="bg-gradient-to-br from-white/90 via-yellow-50/90 to-orange-50/90 dark:from-gray-800/90 dark:via-yellow-900/90 dark:to-orange-900/90 backdrop-blur-2xl rounded-3xl p-8 border-3 border-yellow-300/40 modern-shadow-lg card-hover-effect">
              {/* Teacher circular image with enhanced frame */}
              <div className="relative w-32 h-32 mx-auto mb-6 animate-pulse-custom">
                <div className="absolute -inset-6 bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 rounded-full blur-lg animate-spin-slow"></div>
                <div className="absolute -inset-3 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 rounded-full animate-pulse-custom"></div>
                <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-2xl modern-shadow-lg">
                  <img 
                    src="/lovable-uploads/dfec8824-a3a7-417b-b7ed-fa90a3b92a6c.png" 
                    alt="مستر محمود حمد" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              
              <h2 className="text-4xl font-black bg-gradient-to-r from-gray-800 via-blue-600 to-purple-600 bg-clip-text text-transparent mb-3 text-glow">
                مستر محمود حمد
              </h2>
              
              <div className="flex items-center justify-center space-x-3 text-gray-700 dark:text-gray-200 mb-6">
                <div className="bg-gradient-to-r from-green-400 to-blue-400 text-white px-4 py-2 rounded-full font-bold text-lg modern-shadow">
                  📞 01050744978
                </div>
              </div>
              
              <p className="text-xl text-gray-600 dark:text-gray-300 font-bold mb-4">
                🌟 مدرس أول اللغة الإنجليزية
              </p>
              
              <div className="flex justify-center space-x-2 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-8 h-8 text-yellow-400 fill-current animate-pulse-custom" style={{animationDelay: `${i * 0.2}s`}} />
                ))}
              </div>
              
              <p className="text-lg text-gray-600 dark:text-gray-300 font-semibold gradient-text">
                ✨ ابدأ رحلتك التعليمية المتميزة معنا اليوم
              </p>
            </div>
          </div>

          {/* Links Section */}
          <div className="mt-10 animate-fade-in" style={{animationDelay: '0.9s'}}>
            <div className="text-center mb-6">
              <p className="text-2xl font-bold text-white mb-4 text-glow">
                📱 اسحب لأسفل للمزيد من الخدمات
              </p>
              <div className="animate-bounce-gentle">
                <ArrowLeft className="w-8 h-8 mx-auto text-white/70 transform rotate-90" />
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-white/20 via-blue-50/20 to-purple-50/20 backdrop-blur-2xl rounded-3xl p-8 border-2 border-white/30 modern-shadow-lg">
              <h3 className="text-3xl font-black mb-8 text-center text-white text-glow">
                🔗 روابط مهمة وخدمات متميزة
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-white/20 rounded-2xl p-6 border-2 border-white/30 hover:bg-white/30 transition-all duration-300 cursor-pointer card-hover-effect modern-shadow">
                  <h4 className="text-2xl font-bold mb-4 text-cyan-300 text-glow">📞 التواصل المباشر</h4>
                  <p className="text-white/90 text-lg font-medium">تواصل مع المدرس عبر الواتساب</p>
                </div>
                <div className="bg-white/20 rounded-2xl p-6 border-2 border-white/30 hover:bg-white/30 transition-all duration-300 cursor-pointer card-hover-effect modern-shadow">
                  <h4 className="text-2xl font-bold mb-4 text-blue-300 text-glow">📚 مكتبة الموارد</h4>
                  <p className="text-white/90 text-lg font-medium">موارد تعليمية شاملة</p>
                </div>
                <div className="bg-white/20 rounded-2xl p-6 border-2 border-white/30 hover:bg-white/30 transition-all duration-300 cursor-pointer card-hover-effect modern-shadow">
                  <h4 className="text-2xl font-bold mb-4 text-purple-300 text-glow">🎥 قناة اليوتيوب</h4>
                  <p className="text-white/90 text-lg font-medium">دروس مجانية متميزة</p>
                </div>
                <div className="bg-white/20 rounded-2xl p-6 border-2 border-white/30 hover:bg-white/30 transition-all duration-300 cursor-pointer card-hover-effect modern-shadow">
                  <h4 className="text-2xl font-bold mb-4 text-green-300 text-glow">💬 مجتمع التليجرام</h4>
                  <p className="text-white/90 text-lg font-medium">انضم لمجتمع الطلاب</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Footer */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20">
        <div className="text-5xl font-black bg-gradient-to-r from-white via-yellow-200 to-white bg-clip-text text-transparent animate-pulse-custom text-glow">
          🌟 منصة عالمية متطورة
        </div>
      </div>
    </div>
  );
};

export default StudentInterface;
