
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Eye, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const TeacherPaymentTransfers = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [confirmedTransfers, setConfirmedTransfers] = useState<any[]>([]);
  const [pendingTransfers, setPendingTransfers] = useState<any[]>([]);
  const [totalConfirmedAmount, setTotalConfirmedAmount] = useState(0);
  const [totalPendingAmount, setTotalPendingAmount] = useState(0);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    loadTransfers();
    
    // تحديث البيانات كل 30 ثانية
    const interval = setInterval(loadTransfers, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadTransfers = async () => {
    setLoading(true);
    
    try {
      console.log('🔄 بدء تحميل البيانات من Supabase...');
      
      // تحميل الطلاب أولاً مع استخدام select لضمان الحصول على البيانات
      const { data: studentsData, error: studentsError } = await supabase
        .from('students')
        .select('id, full_name, student_number, grade, wallet_balance')
        .order('created_at', { ascending: false });

      if (studentsError) {
        console.error('❌ خطأ في تحميل بيانات الطلاب:', studentsError);
        toast.error('فشل في تحميل بيانات الطلاب');
      } else {
        console.log('✅ تم تحميل بيانات الطلاب بنجاح:', studentsData?.length || 0, 'طالب');
      }

      // تحميل طلبات المحفظة المؤكدة مع join للطلاب
      const { data: confirmedData, error: confirmedError } = await supabase
        .from('wallet_requests')
        .select(`
          *,
          students!inner(
            id,
            full_name,
            student_number,
            grade
          )
        `)
        .eq('status', 'approved')
        .order('reviewed_at', { ascending: false });

      if (confirmedError) {
        console.error('❌ خطأ في تحميل العمليات المؤكدة:', confirmedError);
        toast.error('فشل في تحميل العمليات المؤكدة');
        setConfirmedTransfers([]);
        setTotalConfirmedAmount(0);
      } else {
        console.log('✅ تم تحميل العمليات المؤكدة:', confirmedData?.length || 0, 'عملية');
        
        // معالجة البيانات المؤكدة
        const confirmedWithStudents = (confirmedData || []).map(transfer => ({
          ...transfer,
          studentName: transfer.students?.full_name || 'طالب غير محدد',
          studentNumber: transfer.students?.student_number || '',
          studentGrade: transfer.students?.grade || '',
          confirmedAt: transfer.reviewed_at || transfer.created_at,
          confirmedBy: transfer.reviewed_by || 'الدعم الفني',
          transferNumber: transfer.transfer_number || transfer.transfer_id || 'غير محدد'
        }));
        
        setConfirmedTransfers(confirmedWithStudents);
        
        // حساب إجمالي المبلغ المؤكد
        const confirmedTotal = confirmedWithStudents.reduce((sum, transfer) => sum + Number(transfer.amount || 0), 0);
        setTotalConfirmedAmount(confirmedTotal);
        
        console.log('💰 العمليات المؤكدة:', confirmedWithStudents.length, 'بإجمالي:', confirmedTotal, 'جنيه');
      }

      // تحميل طلبات المحفظة المعلقة مع join للطلاب
      const { data: pendingData, error: pendingError } = await supabase
        .from('wallet_requests')
        .select(`
          *,
          students!inner(
            id,
            full_name,
            student_number,
            grade
          )
        `)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (pendingError) {
        console.error('❌ خطأ في تحميل العمليات المعلقة:', pendingError);
        toast.error('فشل في تحميل العمليات المعلقة');
        setPendingTransfers([]);
        setTotalPendingAmount(0);
      } else {
        console.log('✅ تم تحميل العمليات المعلقة:', pendingData?.length || 0, 'عملية');
        
        // معالجة البيانات المعلقة
        const pendingWithStudents = (pendingData || []).map(transfer => ({
          ...transfer,
          studentName: transfer.students?.full_name || 'طالب غير محدد',
          studentNumber: transfer.students?.student_number || '',
          studentGrade: transfer.students?.grade || '',
          createdAt: transfer.created_at,
          paymentMethod: transfer.payment_method || 'غير محدد',
          transferNumber: transfer.transfer_number || transfer.transfer_id || 'غير محدد',
          transferImage: transfer.transfer_image
        }));
        
        setPendingTransfers(pendingWithStudents);
        
        // حساب إجمالي المبلغ المعلق
        const pendingTotal = pendingWithStudents.reduce((sum, transfer) => sum + Number(transfer.amount || 0), 0);
        setTotalPendingAmount(pendingTotal);
        
        console.log('⏳ العمليات المعلقة:', pendingWithStudents.length, 'بإجمالي:', pendingTotal, 'جنيه');
      }

      console.log('🎉 انتهى تحميل جميع البيانات بنجاح');
      
      // عرض رسالة نجاح أو معلومات حسب البيانات المتوفرة
      const totalConfirmed = confirmedData?.length || 0;
      const totalPending = pendingData?.length || 0;
      
      if (totalConfirmed === 0 && totalPending === 0) {
        toast.info('لا توجد عمليات تحويل حالياً');
      } else {
        toast.success(`تم تحديث البيانات بنجاح - ${totalConfirmed} مؤكدة، ${totalPending} معلقة`);
      }

    } catch (error) {
      console.error('💥 خطأ في تحميل البيانات:', error);
      toast.error('حدث خطأ أثناء تحميل البيانات');
      
      // تصفير البيانات في حالة الخطأ
      setConfirmedTransfers([]);
      setPendingTransfers([]);
      setTotalConfirmedAmount(0);
      setTotalPendingAmount(0);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    console.log('🔄 إعادة تحميل البيانات يدوياً...');
    toast.info('جاري تحديث البيانات...');
    loadTransfers();
  };

  return (
    <div className={`min-h-screen transition-all duration-500 transform-gpu ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="flex items-center p-4 animate-fade-in">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/teacher/dashboard')}
          className="rounded-full ml-4 hover-scale"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">💸 عرض عمليات التحويل</h1>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          disabled={loading}
          className="mr-auto hover-scale"
        >
          <RefreshCw className={`h-4 w-4 ml-2 ${loading ? 'animate-spin' : ''}`} />
          تحديث
        </Button>
      </div>

      <div className="container mx-auto px-4 py-8 space-y-6">
        {/* Enhanced Summary Cards */}
        <div className="grid md:grid-cols-4 gap-6 animate-fade-in">
          <Card className="p-6 hover-scale">
            <div className="text-center">
              <h2 className="text-lg font-bold text-primary mb-2">إجمالي المبلغ</h2>
              <p className="text-2xl font-bold text-green-600">
                {totalConfirmedAmount.toLocaleString()} جنيه
              </p>
              <p className="text-muted-foreground">
                {confirmedTransfers.length} عملية مؤكدة
              </p>
            </div>
          </Card>
          
          <Card className="p-6 hover-scale">
            <div className="text-center">
              <h2 className="text-lg font-bold text-primary mb-2">معلق</h2>
              <p className="text-2xl font-bold text-orange-600">
                {totalPendingAmount.toLocaleString()} جنيه
              </p>
              <p className="text-muted-foreground">
                {pendingTransfers.length} عملية معلقة
              </p>
            </div>
          </Card>
          
          <Card className="p-6 hover-scale">
            <div className="text-center">
              <h2 className="text-lg font-bold text-primary mb-2">العمليات</h2>
              <p className="text-2xl font-bold text-blue-600">
                {pendingTransfers.length}
              </p>
              <p className="text-muted-foreground">
                بإجمالي {totalPendingAmount.toLocaleString()} جنيه
              </p>
            </div>
          </Card>
          
          <Card className="p-6 hover-scale">
            <div className="text-center">
              <h2 className="text-lg font-bold text-primary mb-2">إجمالي العام</h2>
              <p className="text-2xl font-bold text-purple-600">
                {(totalConfirmedAmount + totalPendingAmount).toLocaleString()} جنيه
              </p>
              <p className="text-muted-foreground">
                {confirmedTransfers.length + pendingTransfers.length} عملية
              </p>
            </div>
          </Card>
        </div>

        {/* Loading State */}
        {loading && (
          <Card className="p-8 animate-fade-in">
            <div className="text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
              <p className="text-muted-foreground">جاري تحميل البيانات من Supabase...</p>
            </div>
          </Card>
        )}

        {/* No Data State */}
        {!loading && confirmedTransfers.length === 0 && pendingTransfers.length === 0 && (
          <Card className="p-8 animate-fade-in">
            <div className="text-center">
              <p className="text-lg text-muted-foreground mb-4">لا توجد عمليات تحويل حالياً</p>
              <p className="text-sm text-muted-foreground mb-4">البيانات محفوظة على Supabase وتظهر لجميع الأجهزة</p>
              <Button onClick={handleRefresh} variant="outline">
                <RefreshCw className="h-4 w-4 ml-2" />
                إعادة التحميل
              </Button>
            </div>
          </Card>
        )}

        {/* Pending Transfers */}
        {!loading && pendingTransfers.length > 0 && (
          <Card className="p-6 animate-fade-in">
            <h2 className="text-lg font-bold mb-4 text-orange-600">🕒 العمليات المعلقة</h2>
            <div className="space-y-4">
              {pendingTransfers.map((transfer, index) => (
                <div key={transfer.id || index} className="p-4 border border-orange-200 rounded-lg bg-orange-50">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="grid md:grid-cols-3 gap-4">
                        <div>
                          <h3 className="font-bold">{transfer.studentName}</h3>
                          <p className="text-sm text-muted-foreground">
                            {transfer.studentNumber && `رقم: ${transfer.studentNumber}`}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {transfer.studentGrade && `الصف: ${transfer.studentGrade}`}
                          </p>
                        </div>
                        <div>
                          <p className="font-semibold text-orange-600">{transfer.amount} جنيه</p>
                          <p className="text-sm text-muted-foreground">المبلغ</p>
                        </div>
                        <div>
                          <p className="text-sm">{transfer.paymentMethod}</p>
                          <p className="text-sm text-muted-foreground">وسيلة الدفع</p>
                        </div>
                      </div>
                      
                      {transfer.transferNumber && (
                        <div className="mt-2">
                          <p className="text-sm">{transfer.transferNumber}</p>
                          <p className="text-xs text-muted-foreground">رقم التحويل</p>
                        </div>
                      )}
                      
                      {transfer.message && (
                        <div className="mt-2">
                          <p className="text-sm italic">{transfer.message}</p>
                          <p className="text-xs text-muted-foreground">رسالة الطالب</p>
                        </div>
                      )}
                      
                      <div className="mt-2">
                        <p className="text-sm">{new Date(transfer.createdAt).toLocaleString('ar-EG')}</p>
                        <p className="text-xs text-muted-foreground">تاريخ الطلب</p>
                      </div>
                    </div>
                    
                    <div className="flex flex-col items-center space-y-2">
                      <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                        قيد المراجعة
                      </Badge>
                      
                      {transfer.transferImage && (
                        <Button size="sm" variant="outline" className="hover-scale">
                          <Eye className="w-4 h-4 ml-1" />
                          عرض الصورة
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Confirmed Transfers */}
        {!loading && confirmedTransfers.length > 0 && (
          <Card className="p-6 animate-fade-in">
            <h2 className="text-lg font-bold mb-4 text-green-600">✅ التحويلات المؤكدة</h2>
            <div className="space-y-4">
              {confirmedTransfers.map((transfer, index) => (
                <div key={transfer.id || index} className="p-4 border border-green-200 rounded-lg bg-green-50 hover-scale">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="grid md:grid-cols-4 gap-4">
                        <div>
                          <h3 className="font-bold">{transfer.studentName}</h3>
                          <p className="text-sm text-muted-foreground">
                            {transfer.studentNumber && `رقم: ${transfer.studentNumber}`}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {transfer.studentGrade && `الصف: ${transfer.studentGrade}`}
                          </p>
                        </div>
                        <div>
                          <p className="font-semibold text-green-600">{transfer.amount} جنيه</p>
                          <p className="text-sm text-muted-foreground">المبلغ</p>
                        </div>
                        <div>
                          <p className="text-sm">{transfer.payment_method}</p>
                          <p className="text-sm text-muted-foreground">وسيلة الدفع</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-blue-600">
                            {transfer.confirmedBy}
                          </p>
                          <p className="text-sm text-muted-foreground">أكد بواسطة</p>
                        </div>
                      </div>
                      
                      <div className="mt-3 grid md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm">{transfer.transferNumber}</p>
                          <p className="text-xs text-muted-foreground">رقم التحويل</p>
                        </div>
                        <div>
                          <p className="text-sm">{new Date(transfer.confirmedAt).toLocaleString('ar-EG')}</p>
                          <p className="text-xs text-muted-foreground">تاريخ التأكيد</p>
                        </div>
                      </div>

                      {transfer.message && (
                        <div className="mt-2">
                          <p className="text-sm italic">{transfer.message}</p>
                          <p className="text-xs text-muted-foreground">رسالة الطالب</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex flex-col items-center space-y-2">
                      <Badge variant="default" className="bg-green-100 text-green-800">
                        مؤكد
                      </Badge>
                      
                      {transfer.transfer_image && (
                        <Button size="sm" variant="outline" className="hover-scale">
                          <Eye className="w-4 h-4 ml-1" />
                          عرض الصورة
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Data Source Info */}
        {!loading && (
          <Card className="p-4 animate-fade-in">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                📊 البيانات محفوظة على قاعدة بيانات Supabase وتظهر لجميع الأجهزة في الوقت الفعلي
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                آخر تحديث: {new Date().toLocaleString('ar-EG')}
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default TeacherPaymentTransfers;
