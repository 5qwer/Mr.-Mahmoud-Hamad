
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Search, Ban, CheckCircle, User, Phone, Calendar, GraduationCap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const TeacherBlockStudents = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [students, setStudents] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('all');
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [blockReason, setBlockReason] = useState('');
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [actionType, setActionType] = useState<'block' | 'unblock'>('block');
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    loadStudents();
  }, []);

  const loadStudents = async () => {
    try {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في تحميل الطلاب:', error);
        toast.error('فشل في تحميل قائمة الطلاب');
        return;
      }

      console.log('Loaded students from Supabase:', data);
      setStudents(data || []);
    } catch (error) {
      console.error('خطأ عام في تحميل الطلاب:', error);
      toast.error('حدث خطأ في تحميل الطلاب');
    }
  };

  const filteredStudents = students.filter(student => {
    const matchesSearch = student.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (student.student_number && student.student_number.includes(searchTerm));
    const matchesGrade = selectedGrade === 'all' || student.grade === selectedGrade;
    return matchesSearch && matchesGrade;
  });

  const handleBlockAction = (student: any, action: 'block' | 'unblock') => {
    setSelectedStudent(student);
    setActionType(action);
    setShowBlockModal(true);
    setBlockReason('');
  };

  const confirmBlockAction = async () => {
    if (!selectedStudent) return;

    if (actionType === 'block' && !blockReason.trim()) {
      toast.error('يرجى إدخال سبب الحظر');
      return;
    }

    try {
      const { data, error } = await supabase.rpc('toggle_student_block', {
        p_student_id: selectedStudent.id,
        p_action: actionType,
        p_reason: actionType === 'block' ? blockReason.trim() : undefined,
        p_blocked_by: 'المعلم'
      });

      if (error) {
        console.error('خطأ في عملية الحظر:', error);
        toast.error('فشل في تنفيذ العملية');
        return;
      }

      console.log('نتيجة عملية الحظر:', data);
      
      if (data && (data as any).success) {
        loadStudents();
        toast.success(actionType === 'block' ? 'تم حظر الطالب بنجاح' : 'تم رفع الحظر عن الطالب بنجاح');
      } else {
        toast.error((data as any)?.message || 'فشل في تنفيذ العملية');
      }
    } catch (error) {
      console.error('خطأ عام في عملية الحظر:', error);
      toast.error('حدث خطأ في تنفيذ العملية');
    }

    setShowBlockModal(false);
    setSelectedStudent(null);
    setBlockReason('');
  };

  const getGradeLabel = (grade: string) => {
    switch (grade) {
      case 'first': return 'الأول الثانوي العام';
      case 'second': return 'الثاني الثانوي العام';
      case 'third': return 'الثالث الثانوي العام';
      case '1': return 'الأول الثانوي العام';
      case '2': return 'الثاني الثانوي العام';
      case '3': return 'الثالث الثانوي العام';
      default: return grade;
    }
  };

  // Statistics by grade
  const gradeStats = {
    first: filteredStudents.filter(s => s.grade === 'first' || s.grade === '1').length,
    second: filteredStudents.filter(s => s.grade === 'second' || s.grade === '2').length,
    third: filteredStudents.filter(s => s.grade === 'third' || s.grade === '3').length,
    total: filteredStudents.length
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/teacher/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">🚫 حظر الطلاب</h1>
        
        {/* Teacher Image */}
        <div className="mr-4">
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-blue-400 shadow-lg">
            <img 
              src="/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png" 
              alt="Mr. Mahmoud Hamad" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Students Statistics */}
        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <Card className="p-4 text-center">
            <h3 className="font-bold text-blue-600">إجمالي الطلاب</h3>
            <p className="text-2xl font-bold">{gradeStats.total}</p>
          </Card>
          <Card className="p-4 text-center">
            <h3 className="font-bold text-green-600">الأول الثانوي</h3>
            <p className="text-2xl font-bold">{gradeStats.first}</p>
          </Card>
          <Card className="p-4 text-center">
            <h3 className="font-bold text-yellow-600">الثاني الثانوي</h3>
            <p className="text-2xl font-bold">{gradeStats.second}</p>
          </Card>
          <Card className="p-4 text-center">
            <h3 className="font-bold text-red-600">الثالث الثانوي</h3>
            <p className="text-2xl font-bold">{gradeStats.third}</p>
          </Card>
        </div>

        {/* Search and Filter */}
        <Card className="p-6 mb-6">
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="search">البحث بالاسم أو رقم الطالب</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="ابحث عن طالب..."
                  className="text-right pr-4 pl-10"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>الصف الدراسي</Label>
              <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                <SelectTrigger>
                  <SelectValue placeholder="اختر الصف" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الصفوف</SelectItem>
                  <SelectItem value="first">الأول الثانوي العام</SelectItem>
                  <SelectItem value="second">الثاني الثانوي العام</SelectItem>
                  <SelectItem value="third">الثالث الثانوي العام</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">نتائج البحث</p>
                <p className="text-2xl font-bold text-blue-600">{filteredStudents.length}</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Students List */}
        <Card className="p-6">
          <h2 className="text-lg font-bold mb-4">قائمة الطلاب</h2>
          
          {filteredStudents.length === 0 ? (
            <div className="text-center py-8">
              <User className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <p className="text-muted-foreground">لا توجد طلاب مطابقين للبحث</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredStudents.map((student) => (
                <div 
                  key={student.id} 
                  className={`flex items-center justify-between p-4 border rounded-lg transition-all duration-200 hover:shadow-md ${
                    student.is_blocked ? 'border-red-200 bg-red-50' : 'border-gray-200'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      student.is_blocked ? 'bg-red-100' : 'bg-blue-100'
                    }`}>
                      <User className={`w-6 h-6 ${student.is_blocked ? 'text-red-600' : 'text-blue-600'}`} />
                    </div>
                    
                    <div>
                      <h3 className="font-bold flex items-center">
                        {student.full_name}
                        {student.is_blocked && (
                          <Ban className="w-4 h-4 ml-2 text-red-500" />
                        )}
                      </h3>
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <span className="flex items-center">
                          <User className="w-3 h-3 ml-1" />
                          {student.student_number || 'غير محدد'}
                        </span>
                        <span className="flex items-center">
                          <Phone className="w-3 h-3 ml-1" />
                          {student.parent_number || 'غير محدد'}
                        </span>
                        <span className="flex items-center">
                          <GraduationCap className="w-3 h-3 ml-1" />
                          {getGradeLabel(student.grade)}
                        </span>
                        <span className="flex items-center">
                          <Calendar className="w-3 h-3 ml-1" />
                          {new Date(student.created_at).toLocaleDateString('ar-EG')}
                        </span>
                      </div>
                      {student.is_blocked && student.block_reason && (
                        <div className="mt-2">
                          <p className="text-sm text-red-600">
                            <strong>سبب الحظر:</strong> {student.block_reason}
                          </p>
                          {student.blocked_at && (
                            <p className="text-xs text-red-500">
                              تاريخ الحظر: {new Date(student.blocked_at).toLocaleString('ar-EG')}
                            </p>
                          )}
                        </div>
                      )}
                      <div className="text-xs text-muted-foreground mt-1">
                        رصيد المحفظة: {student.wallet_balance || 0} جنيه
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {student.is_blocked ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleBlockAction(student, 'unblock')}
                        className="text-green-600 border-green-600 hover:bg-green-50"
                      >
                        <CheckCircle className="w-4 h-4 ml-1" />
                        رفع الحظر
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleBlockAction(student, 'block')}
                      >
                        <Ban className="w-4 h-4 ml-1" />
                        حظر
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Block/Unblock Modal */}
        {showBlockModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <Card className="p-6 max-w-md w-full mx-4">
              <h3 className="text-lg font-bold mb-4">
                {actionType === 'block' ? 'حظر الطالب' : 'رفع الحظر'}
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                هل أنت متأكد من {actionType === 'block' ? 'حظر' : 'رفع الحظر عن'} الطالب: 
                <strong className="mr-1">{selectedStudent?.full_name}</strong>؟
              </p>
              
              {actionType === 'block' && (
                <div className="space-y-2 mb-4">
                  <Label htmlFor="blockReason">سبب الحظر *</Label>
                  <Textarea
                    id="blockReason"
                    value={blockReason}
                    onChange={(e) => setBlockReason(e.target.value)}
                    placeholder="اكتب سبب حظر الطالب بوضوح..."
                    className="text-right"
                    rows={3}
                  />
                  <p className="text-xs text-muted-foreground">
                    سيتم إرسال هذا السبب للطالب في إشعار
                  </p>
                </div>
              )}
              
              <div className="flex space-x-2">
                <Button 
                  onClick={confirmBlockAction}
                  variant={actionType === 'block' ? 'destructive' : 'default'}
                  className="flex-1"
                >
                  تأكيد {actionType === 'block' ? 'الحظر' : 'رفع الحظر'}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setShowBlockModal(false)}
                  className="flex-1"
                >
                  إلغاء
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeacherBlockStudents;
