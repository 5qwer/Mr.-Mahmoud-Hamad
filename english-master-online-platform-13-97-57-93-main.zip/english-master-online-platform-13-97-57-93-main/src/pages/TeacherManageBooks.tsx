
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Plus, Trash2, Edit3, Save, X, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const TeacherManageBooks = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [books, setBooks] = useState<any[]>([]);
  const [filteredBooks, setFilteredBooks] = useState<any[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingBook, setEditingBook] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [gradeFilter, setGradeFilter] = useState('all');
  const [bookData, setBookData] = useState({
    title: '',
    description: '',
    price: '',
    coverImage: '',
    grade: '1',
    pickupLocation: '',
    category: 'unlimited',
    duration: '',
    subject: 'عام'
  });
  const [showConfirmDelete, setShowConfirmDelete] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    loadBooks();
  }, []);

  useEffect(() => {
    filterBooks();
  }, [books, searchTerm, gradeFilter]);

  const loadBooks = async () => {
    try {
      const { data, error } = await supabase
        .from('available_books')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في تحميل الكتب:', error);
        toast.error('فشل في تحميل الكتب');
        return;
      }

      console.log('تحميل الكتب من Supabase:', data);
      setBooks(data || []);
    } catch (error) {
      console.error('خطأ في تحميل الكتب:', error);
      toast.error('فشل في تحميل الكتب');
      setBooks([]);
    }
  };

  const filterBooks = () => {
    let filtered = books;
    
    if (searchTerm) {
      filtered = filtered.filter(book => 
        book.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (gradeFilter !== 'all') {
      filtered = filtered.filter(book => book.grade === gradeFilter);
    }
    
    setFilteredBooks(filtered);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast.error('حجم الصورة كبير جداً. يجب أن يكون أقل من 5 ميجابايت');
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setBookData(prev => ({...prev, coverImage: result}));
        toast.success('تم رفع صورة الكتاب بنجاح');
      };
      reader.readAsDataURL(file);
    }
  };

  const validateBookData = () => {
    if (!bookData.title.trim()) {
      toast.error('يرجى إدخال عنوان الكتاب');
      return false;
    }
    if (!bookData.description.trim()) {
      toast.error('يرجى إدخال وصف الكتاب');
      return false;
    }
    if (!bookData.price || parseFloat(bookData.price) <= 0) {
      toast.error('يرجى إدخال سعر صحيح للكتاب');
      return false;
    }
    if (!bookData.pickupLocation.trim()) {
      toast.error('يرجى إدخال مكان الاستلام');
      return false;
    }
    if (bookData.category === 'limited' && (!bookData.duration || parseInt(bookData.duration) <= 0)) {
      toast.error('يرجى إدخال مدة صحيحة للاستعارة');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateBookData()) {
      return;
    }

    try {
      const bookDataToSave = {
        title: bookData.title.trim(),
        description: bookData.description.trim(),
        price: parseFloat(bookData.price),
        cover_image: bookData.coverImage || null,
        grade: bookData.grade,
        subject: bookData.subject,
        pickup_location: bookData.pickupLocation.trim(),
        category: bookData.category,
        duration: bookData.category === 'limited' ? parseInt(bookData.duration) : null,
      };

      if (editingBook) {
        const { error } = await supabase
          .from('available_books')
          .update(bookDataToSave)
          .eq('id', editingBook.id);

        if (error) {
          console.error('خطأ في تحديث الكتاب:', error);
          toast.error('فشل في تحديث الكتاب');
          return;
        }

        console.log('تم تحديث الكتاب بنجاح');
        toast.success('تم تحديث الكتاب بنجاح');
      } else {
        const { error } = await supabase
          .from('available_books')
          .insert([bookDataToSave]);

        if (error) {
          console.error('خطأ في إضافة الكتاب:', error);
          toast.error('فشل في إضافة الكتاب');
          return;
        }

        console.log('تم إضافة الكتاب بنجاح');
        toast.success('تم إضافة الكتاب بنجاح');
      }

      // إعادة تحميل الكتب
      await loadBooks();
      
      // إعادة تعيين النموذج
      resetForm();
    } catch (error) {
      console.error('خطأ في حفظ الكتاب:', error);
      toast.error('فشل في حفظ الكتاب');
    }
  };

  const handleEdit = (book: any) => {
    console.log('تحرير الكتاب:', book);
    setEditingBook(book);
    setBookData({
      title: book.title || '',
      description: book.description || '',
      price: book.price?.toString() || '',
      coverImage: book.cover_image || '',
      grade: book.grade || '1',
      subject: book.subject || 'عام',
      pickupLocation: book.pickup_location || '',
      category: book.category || 'unlimited',
      duration: book.duration?.toString() || ''
    });
    setShowAddForm(true);
  };

  const handleDelete = (book: any) => {
    setShowConfirmDelete(book);
  };

  const confirmDelete = async () => {
    if (showConfirmDelete) {
      try {
        const { error } = await supabase
          .from('available_books')
          .delete()
          .eq('id', showConfirmDelete.id);

        if (error) {
          console.error('خطأ في حذف الكتاب:', error);
          toast.error('فشل في حذف الكتاب');
          return;
        }

        console.log('حذف الكتاب:', showConfirmDelete.id);
        toast.success('تم حذف الكتاب بنجاح');
        
        // إعادة تحميل الكتب
        await loadBooks();
        setShowConfirmDelete(null);
      } catch (error) {
        console.error('خطأ في حذف الكتاب:', error);
        toast.error('فشل في حذف الكتاب');
      }
    }
  };

  const resetForm = () => {
    setBookData({
      title: '',
      description: '',
      price: '',
      coverImage: '',
      grade: '1',
      subject: 'عام',
      pickupLocation: '',
      category: 'unlimited',
      duration: ''
    });
    setShowAddForm(false);
    setEditingBook(null);
  };

  const getGradeLabel = (grade: string) => {
    switch (grade) {
      case '1': return 'الأول الثانوي';
      case '2': return 'الثاني الثانوي';
      case '3': return 'الثالث الثانوي';
      default: return grade;
    }
  };

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900' 
        : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
    }`}>
      <div className="flex items-center justify-between p-6">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/teacher/dashboard')}
            className={`rounded-xl ml-4 transition-all duration-300 hover:scale-110 border-2 ${
              isDarkMode 
                ? 'border-purple-400 hover:border-purple-300 hover:bg-purple-900/50' 
                : 'border-indigo-300 hover:border-indigo-400 hover:bg-indigo-50'
            }`}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className={`text-2xl font-bold ${
            isDarkMode ? 'text-white' : 'text-slate-800'
          }`}>
            📚 إدارة الكتب
          </h1>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* Add Book Button */}
        <div className="mb-8">
          <Button 
            onClick={() => setShowAddForm(true)} 
            disabled={showAddForm}
            className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 hover:scale-105 shadow-lg ${
              isDarkMode 
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500' 
                : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500'
            }`}
          >
            <Plus className="w-5 h-5 ml-2" />
            إضافة كتاب جديد
          </Button>
          {showAddForm && (
            <Button 
              variant="outline" 
              onClick={resetForm}
              className={`mr-4 px-6 py-3 rounded-xl font-semibold transition-all duration-300 hover:scale-105 border-2 ${
                isDarkMode 
                  ? 'border-red-400 hover:border-red-300 hover:bg-red-900/30 text-red-300' 
                  : 'border-red-400 hover:border-red-500 hover:bg-red-50 text-red-600'
              }`}
            >
              <X className="w-5 h-5 ml-2" />
              إلغاء
            </Button>
          )}
        </div>

        {/* Add/Edit Book Form */}
        {showAddForm && (
          <Card className={`p-8 mb-8 shadow-2xl border-0 transition-all duration-500 ${
            isDarkMode 
              ? 'bg-gradient-to-br from-slate-800/95 to-purple-900/95 backdrop-blur-lg' 
              : 'bg-gradient-to-br from-white/95 to-indigo-50/95 backdrop-blur-lg'
          }`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold">
                {editingBook ? 'تعديل الكتاب' : 'إضافة كتاب جديد'}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان الكتاب *</Label>
                  <Input
                    id="title"
                    value={bookData.title}
                    onChange={(e) => setBookData(prev => ({...prev, title: e.target.value}))}
                    placeholder="أدخل عنوان الكتاب"
                    className="text-right"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="price">السعر (جنيه) *</Label>
                  <Input
                    id="price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={bookData.price}
                    onChange={(e) => setBookData(prev => ({...prev, price: e.target.value}))}
                    placeholder="0"
                    className="text-right"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">وصف الكتاب *</Label>
                <Textarea
                  id="description"
                  value={bookData.description}
                  onChange={(e) => setBookData(prev => ({...prev, description: e.target.value}))}
                  placeholder="أدخل وصف الكتاب"
                  className="text-right"
                  rows={3}
                  required
                />
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="grade">الصف الدراسي</Label>
                  <select
                    id="grade"
                    value={bookData.grade}
                    onChange={(e) => setBookData(prev => ({...prev, grade: e.target.value}))}
                    className="w-full p-2 border rounded-md text-right bg-white"
                  >
                    <option value="1">الصف الأول الثانوي</option>
                    <option value="2">الصف الثاني الثانوي</option>
                    <option value="3">الصف الثالث الثانوي</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subject">المادة</Label>
                  <Input
                    id="subject"
                    value={bookData.subject}
                    onChange={(e) => setBookData(prev => ({...prev, subject: e.target.value}))}
                    placeholder="أدخل المادة"
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pickupLocation">مكان الاستلام *</Label>
                  <Input
                    id="pickupLocation"
                    value={bookData.pickupLocation}
                    onChange={(e) => setBookData(prev => ({...prev, pickupLocation: e.target.value}))}
                    placeholder="أدخل مكان الاستلام"
                    className="text-right"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">الفئة</Label>
                  <select
                    id="category"
                    value={bookData.category}
                    onChange={(e) => setBookData(prev => ({...prev, category: e.target.value}))}
                    className="w-full p-2 border rounded-md text-right bg-white"
                  >
                    <option value="unlimited">غير محدودة</option>
                    <option value="limited">محدودة بالمدة</option>
                  </select>
                </div>
                {bookData.category === 'limited' && (
                  <div className="space-y-2">
                    <Label htmlFor="duration">المدة (بالأيام) *</Label>
                    <Input
                      id="duration"
                      type="number"
                      min="1"
                      value={bookData.duration}
                      onChange={(e) => setBookData(prev => ({...prev, duration: e.target.value}))}
                      placeholder="عدد الأيام"
                      className="text-right"
                      required={bookData.category === 'limited'}
                    />
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="coverImage">صورة الكتاب</Label>
                <Input
                  id="coverImage"
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="text-right"
                />
                {bookData.coverImage && (
                  <p className="text-sm text-green-600">✅ تم رفع الصورة بنجاح</p>
                )}
              </div>

              <div className="flex gap-4">
                <Button 
                  type="submit" 
                  className="flex-1 hover:scale-105 transition-transform"
                >
                  <Save className="w-4 h-4 ml-2" />
                  {editingBook ? 'تحديث الكتاب' : 'إضافة الكتاب'}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={resetForm}
                  className="flex-1"
                >
                  <X className="w-4 h-4 ml-2" />
                  إلغاء
                </Button>
              </div>
            </form>
          </Card>
        )}

        {/* Search and Filter Section */}
        <Card className={`p-6 mb-8 shadow-xl border-0 transition-all duration-300 ${
          isDarkMode 
            ? 'bg-gradient-to-r from-slate-800/90 to-purple-800/90 backdrop-blur-lg' 
            : 'bg-gradient-to-r from-white/90 to-indigo-50/90 backdrop-blur-lg'
        }`}>
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="البحث عن اسم الكتاب..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="text-right pr-4 pl-10"
              />
            </div>
            <div className="flex gap-2 items-center">
              <Label htmlFor="gradeFilter">المرحلة:</Label>
              <select
                id="gradeFilter"
                value={gradeFilter}
                onChange={(e) => setGradeFilter(e.target.value)}
                className="p-2 border rounded-md text-right bg-white"
              >
                <option value="all">جميع المراحل</option>
                <option value="1">الأول الثانوي</option>
                <option value="2">الثاني الثانوي</option>
                <option value="3">الثالث الثانوي</option>
              </select>
            </div>
          </div>
        </Card>

        {/* Books List */}
        <Card className={`p-8 shadow-2xl border-0 transition-all duration-500 ${
          isDarkMode 
            ? 'bg-gradient-to-br from-slate-800/95 to-purple-900/95 backdrop-blur-lg' 
            : 'bg-gradient-to-br from-white/95 to-indigo-50/95 backdrop-blur-lg'
        }`}>
          <h2 className="text-lg font-bold mb-4">الكتب المتاحة ({filteredBooks.length})</h2>
          
          {filteredBooks.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                {searchTerm || gradeFilter !== 'all' ? 'لا توجد كتب تطابق البحث' : 'لا توجد كتب متاحة حالياً'}
              </p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredBooks.map((book) => (
                <Card key={book.id} className="p-4 bg-white hover:shadow-lg transition-shadow">
                  {book.cover_image && (
                    <img
                      src={book.cover_image}
                      alt={book.title}
                      className="w-full h-48 object-cover rounded-lg mb-4"
                    />
                  )}
                  
                  <div className="space-y-2">
                    <h3 className="font-bold text-lg">{book.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {book.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-green-600">
                        {book.price} جنيه
                      </span>
                      <span className="text-sm text-muted-foreground">
                        {getGradeLabel(book.grade)}
                      </span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <p><strong>المادة:</strong> {book.subject}</p>
                      <p><strong>مكان الاستلام:</strong> {book.pickup_location}</p>
                      <p><strong>الفئة:</strong> {book.category === 'unlimited' ? 'غير محدودة' : `محدودة (${book.duration} يوم)`}</p>
                    </div>
                  </div>

                  <div className="flex justify-between mt-4 gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(book)}
                      className="flex-1 hover:scale-105 transition-transform"
                    >
                      <Edit3 className="w-4 h-4 ml-1" />
                      تعديل
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(book)}
                      className="flex-1 hover:scale-105 transition-transform"
                    >
                      <Trash2 className="w-4 h-4 ml-1" />
                      حذف
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Delete Confirmation Modal */}
      {showConfirmDelete && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="p-6 max-w-md w-full bg-white">
            <h3 className="text-lg font-bold mb-4 text-center">تأكيد الحذف</h3>
            <p className="text-center mb-6">
              هل أنت متأكد من حذف كتاب "{showConfirmDelete.title}"؟
            </p>
            <div className="flex gap-4">
              <Button
                variant="destructive"
                onClick={confirmDelete}
                className="flex-1"
              >
                تأكيد الحذف
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowConfirmDelete(null)}
                className="flex-1"
              >
                إلغاء
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default TeacherManageBooks;
