
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Plus, Trash2, CreditCard } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const TeacherPaymentMethods = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [paymentMethods, setPaymentMethods] = useState<any[]>([]);
  const [newMethod, setNewMethod] = useState({
    name: '',
    number: ''
  });
  const [adminPassword, setAdminPassword] = useState('');
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [actionType, setActionType] = useState<'add' | 'delete'>('add');
  const [selectedMethodId, setSelectedMethodId] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const ADMIN_PASSWORD = 'HHDV/58HR';

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    loadPaymentMethods();
  }, []);

  const loadPaymentMethods = async () => {
    try {
      console.log('Loading payment methods...');
      const { data, error } = await supabase
        .from('payment_methods')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في جلب وسائل الدفع:', error);
        toast.error('حدث خطأ في تحميل وسائل الدفع');
        return;
      }

      console.log('Loaded payment methods:', data);
      setPaymentMethods(data || []);
    } catch (error) {
      console.error('خطأ في تحميل وسائل الدفع:', error);
      toast.error('حدث خطأ في تحميل وسائل الدفع');
    }
  };

  const handleAddMethod = () => {
    if (!newMethod.name.trim() || !newMethod.number.trim()) {
      toast.error('يرجى ملء جميع الحقول');
      return;
    }

    setActionType('add');
    setShowPasswordModal(true);
  };

  const handleDeleteMethod = (methodId: number) => {
    setSelectedMethodId(methodId);
    setActionType('delete');
    setShowPasswordModal(true);
  };

  const handlePasswordConfirm = async () => {
    if (adminPassword.trim() !== ADMIN_PASSWORD) {
      toast.error('كلمة المرور غير صحيحة');
      return;
    }

    setIsLoading(true);

    try {
      if (actionType === 'add') {
        console.log('Adding payment method:', newMethod);
        const { data, error } = await supabase
          .from('payment_methods')
          .insert([{
            name: newMethod.name.trim(),
            number: newMethod.number.trim()
          }])
          .select();

        if (error) {
          console.error('خطأ في إضافة وسيلة الدفع:', error);
          toast.error('حدث خطأ في إضافة وسيلة الدفع');
          return;
        }

        console.log('Added payment method:', data);
        toast.success('تم إضافة وسيلة الدفع بنجاح');
        setNewMethod({ name: '', number: '' });
        
      } else if (actionType === 'delete' && selectedMethodId) {
        console.log('Deleting payment method:', selectedMethodId);
        const { error } = await supabase
          .from('payment_methods')
          .delete()
          .eq('id', selectedMethodId);

        if (error) {
          console.error('خطأ في حذف وسيلة الدفع:', error);
          toast.error('حدث خطأ في حذف وسيلة الدفع');
          return;
        }

        console.log('Deleted payment method:', selectedMethodId);
        toast.success('تم حذف وسيلة الدفع بنجاح');
      }

      await loadPaymentMethods();
    } catch (error) {
      console.error('Error in payment method operation:', error);
      toast.error('حدث خطأ في العملية');
    } finally {
      setIsLoading(false);
      setShowPasswordModal(false);
      setAdminPassword('');
      setSelectedMethodId(null);
    }
  };

  const closeModal = () => {
    setShowPasswordModal(false);
    setAdminPassword('');
    setSelectedMethodId(null);
    setIsLoading(false);
  };

  return (
    <div className={`min-h-screen transition-all duration-200 ease-out ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="flex items-center p-4 animate-fade-in">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/teacher/dashboard')}
          className="rounded-full ml-4 transition-all duration-150 hover:scale-105"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">💳 إدارة وسائل الدفع</h1>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Add New Payment Method */}
        <Card className="p-6 mb-6 transition-all duration-200 hover:shadow-lg animate-scale-in">
          <h2 className="text-lg font-bold mb-4">إضافة وسيلة دفع جديدة</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">اسم وسيلة الدفع</Label>
              <Input
                id="name"
                value={newMethod.name}
                onChange={(e) => setNewMethod({...newMethod, name: e.target.value})}
                placeholder="مثال: فودافون كاش"
                className="text-right transition-all duration-150 focus:scale-[1.02]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="number">رقم الحساب</Label>
              <Input
                id="number"
                value={newMethod.number}
                onChange={(e) => setNewMethod({...newMethod, number: e.target.value})}
                placeholder="أدخل رقم الحساب"
                className="text-right transition-all duration-150 focus:scale-[1.02]"
              />
            </div>
            <div className="flex items-end">
              <Button 
                onClick={handleAddMethod} 
                className="w-full transition-all duration-150 hover:scale-105"
                disabled={isLoading}
              >
                <Plus className="w-4 h-4 ml-2" />
                {isLoading && actionType === 'add' ? 'جاري الإضافة...' : 'إضافة'}
              </Button>
            </div>
          </div>
        </Card>

        {/* Current Payment Methods */}
        <Card className="p-6 transition-all duration-200 hover:shadow-lg animate-scale-in">
          <h2 className="text-lg font-bold mb-4">وسائل الدفع الحالية</h2>
          
          {paymentMethods.length === 0 ? (
            <div className="text-center py-8 animate-fade-in">
              <CreditCard className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <p className="text-muted-foreground">لا توجد وسائل دفع مضافة حالياً</p>
              <p className="text-sm text-muted-foreground mt-2">
                أضف وسائل الدفع ليتمكن الطلاب من شحن محافظهم
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {paymentMethods.map((method, index) => (
                <div 
                  key={method.id} 
                  className="flex items-center justify-between p-4 border rounded-lg transition-all duration-200 hover:shadow-md hover:scale-[1.01] animate-fade-in"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="flex items-center space-x-4">
                    <CreditCard className="w-8 h-8 text-blue-500" />
                    <div>
                      <h3 className="font-bold">{method.name}</h3>
                      <p className="text-sm text-muted-foreground">{method.number}</p>
                      <p className="text-xs text-muted-foreground">
                        تاريخ الإضافة: {new Date(method.created_at).toLocaleDateString('ar-EG')}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDeleteMethod(method.id)}
                      className="transition-all duration-150 hover:scale-105"
                      disabled={isLoading}
                    >
                      <Trash2 className="w-4 h-4" />
                      {isLoading && actionType === 'delete' && selectedMethodId === method.id ? 'جاري الحذف...' : 'حذف'}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Password Modal */}
        {showPasswordModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 animate-fade-in">
            <Card className="p-6 max-w-md w-full mx-4 animate-scale-in">
              <h3 className="text-lg font-bold mb-4">تأكيد العملية</h3>
              <p className="text-sm text-muted-foreground mb-4">
                يرجى إدخال كلمة المرور لتأكيد {actionType === 'add' ? 'الإضافة' : 'الحذف'}
              </p>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="password">كلمة المرور</Label>
                  <Input
                    id="password"
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="أدخل كلمة المرور"
                    className="text-center transition-all duration-150 focus:scale-[1.02]"
                    onKeyPress={(e) => e.key === 'Enter' && handlePasswordConfirm()}
                  />
                </div>
                
                <div className="flex space-x-2">
                  <Button 
                    onClick={handlePasswordConfirm} 
                    className="flex-1 transition-all duration-150 hover:scale-105"
                    disabled={isLoading}
                  >
                    {isLoading ? 'جاري المعالجة...' : 'تأكيد'}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={closeModal}
                    className="flex-1 transition-all duration-150 hover:scale-105"
                    disabled={isLoading}
                  >
                    إلغاء
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeacherPaymentMethods;
