
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Send, Image, Mic, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const TeacherStudentMessages = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [messages, setMessages] = useState<any[]>([]);
  const [selectedMessage, setSelectedMessage] = useState<any>(null);
  const [replyText, setReplyText] = useState('');
  const [replyImage, setReplyImage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    // Load student messages
    const studentMessages = JSON.parse(localStorage.getItem('studentMessages') || '[]');
    setMessages(studentMessages);
  }, []);

  const handleReply = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!replyText && !replyImage) {
      toast.error('يرجى كتابة رد أو إرفاق صورة');
      return;
    }

    const reply = {
      id: Date.now(),
      messageId: selectedMessage.id,
      from: 'teacher',
      text: replyText,
      image: replyImage,
      timestamp: new Date().toISOString()
    };

    // Add reply to the message
    const updatedMessages = messages.map(msg => 
      msg.id === selectedMessage.id 
        ? { ...msg, replies: [...(msg.replies || []), reply], status: 'replied' }
        : msg
    );
    
    setMessages(updatedMessages);
    localStorage.setItem('studentMessages', JSON.stringify(updatedMessages));
    
    // Also save to student's inbox
    const studentReplies = JSON.parse(localStorage.getItem('teacherReplies') || '[]');
    studentReplies.push(reply);
    localStorage.setItem('teacherReplies', JSON.stringify(studentReplies));
    
    setReplyText('');
    setReplyImage('');
    setSelectedMessage({...selectedMessage, replies: [...(selectedMessage.replies || []), reply], status: 'replied'});
    toast.success('تم إرسال الرد بنجاح');
  };

  const getStudentInfo = (studentName: string) => {
    const students = JSON.parse(localStorage.getItem('students') || '[]');
    return students.find((s: any) => s.fullName === studentName) || {};
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/teacher/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">💬 رسائل الطلاب</h1>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-6">
          {/* Messages List */}
          <Card className="p-6">
            <h2 className="text-lg font-bold mb-4">الرسائل الواردة</h2>
            
            {messages.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">لا توجد رسائل من الطلاب</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`p-3 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                      selectedMessage?.id === message.id ? 'border-blue-500 bg-blue-50' : ''
                    }`}
                    onClick={() => setSelectedMessage(message)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">{message.studentName}</h3>
                      <Badge variant={message.status === 'replied' ? 'default' : 'secondary'}>
                        {message.status === 'replied' ? 'تم الرد' : 'جديد'}
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-1">
                      {message.subject || 'سؤال عام'}
                    </p>
                    
                    <p className="text-sm line-clamp-2">
                      {message.text}
                    </p>
                    
                    <p className="text-xs text-muted-foreground mt-2">
                      {new Date(message.timestamp).toLocaleString('ar-EG')}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </Card>

          {/* Message Details & Reply */}
          <Card className="p-6">
            {selectedMessage ? (
              <div className="space-y-4">
                {/* Student Info */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center mb-3">
                    <User className="w-5 h-5 ml-2" />
                    <h3 className="font-bold">بيانات الطالب</h3>
                  </div>
                  
                  {(() => {
                    const studentInfo = getStudentInfo(selectedMessage.studentName);
                    return (
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <span className="font-semibold">الاسم: </span>
                          {selectedMessage.studentName}
                        </div>
                        <div>
                          <span className="font-semibold">الصف: </span>
                          {studentInfo.grade ? `الصف ${studentInfo.grade}` : 'غير محدد'}
                        </div>
                        <div>
                          <span className="font-semibold">رقم الطالب: </span>
                          {studentInfo.studentNumber || 'غير محدد'}
                        </div>
                        <div>
                          <span className="font-semibold">رقم ولي الأمر: </span>
                          {studentInfo.parentNumber || 'غير محدد'}
                        </div>
                      </div>
                    );
                  })()}
                </div>

                {/* Original Message */}
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">الرسالة الأصلية:</h4>
                  <p className="text-sm mb-2">{selectedMessage.text}</p>
                  
                  {selectedMessage.image && (
                    <div className="mt-2">
                      <img
                        src={selectedMessage.image}
                        alt="صورة مرفقة"
                        className="max-w-full h-32 object-cover rounded"
                      />
                    </div>
                  )}
                  
                  <p className="text-xs text-muted-foreground mt-2">
                    {new Date(selectedMessage.timestamp).toLocaleString('ar-EG')}
                  </p>
                </div>

                {/* Previous Replies */}
                {selectedMessage.replies && selectedMessage.replies.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-semibold">الردود السابقة:</h4>
                    {selectedMessage.replies.map((reply: any) => (
                      <div key={reply.id} className="p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm">{reply.text}</p>
                        {reply.image && (
                          <img
                            src={reply.image}
                            alt="صورة الرد"
                            className="max-w-full h-24 object-cover rounded mt-2"
                          />
                        )}
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(reply.timestamp).toLocaleString('ar-EG')}
                        </p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Reply Form */}
                <form onSubmit={handleReply} className="space-y-3">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold">الرد:</label>
                    <Textarea
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder="اكتب ردك هنا..."
                      className="text-right"
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-semibold">صورة (اختياري):</label>
                    <Input
                      type="url"
                      value={replyImage}
                      onChange={(e) => setReplyImage(e.target.value)}
                      placeholder="رابط الصورة"
                      className="text-right"
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button type="submit" className="flex-1">
                      <Send className="w-4 h-4 ml-2" />
                      إرسال الرد
                    </Button>
                    
                    <Button type="button" variant="outline">
                      <Image className="w-4 h-4" />
                    </Button>
                    
                    <Button type="button" variant="outline">
                      <Mic className="w-4 h-4" />
                    </Button>
                  </div>
                </form>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">اختر رسالة لعرض التفاصيل والرد عليها</p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TeacherStudentMessages;
