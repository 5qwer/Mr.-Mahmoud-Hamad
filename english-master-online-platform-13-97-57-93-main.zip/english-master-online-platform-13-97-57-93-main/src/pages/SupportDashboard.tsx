
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, LogOut, MessageSquare, Users, Activity, Bell, BookOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const SupportDashboard = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentSupport, setCurrentSupport] = useState<any>(null);
  const [onlineTime, setOnlineTime] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    // Load current support session
    const supportData = localStorage.getItem('currentSupport');
    if (!supportData) {
      navigate('/support/login');
      return;
    }
    
    try {
      const support = JSON.parse(supportData);
      setCurrentSupport(support);
      
      // Calculate online time
      const loginTime = new Date(support.loginTime);
      const updateTime = () => {
        const now = new Date();
        const diff = now.getTime() - loginTime.getTime();
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        setOnlineTime(`${hours}:${minutes.toString().padStart(2, '0')}`);
      };
      
      updateTime();
      const interval = setInterval(updateTime, 60000); // Update every minute
      
      return () => clearInterval(interval);
    } catch (error) {
      console.error('خطأ في تحليل بيانات الدعم:', error);
      navigate('/support/login');
    }
  }, [navigate]);

  const handleLogout = async () => {
    if (!currentSupport) return;
    
    try {
      // Update logout time in database
      const { error } = await supabase
        .from('support_team')
        .update({ 
          online: false, 
          last_logout: new Date().toISOString() 
        })
        .eq('id', currentSupport.id);

      if (error) {
        console.error('خطأ في تسجيل الخروج:', error);
        toast.error('حدث خطأ في تسجيل الخروج');
      } else {
        console.log('تم تسجيل الخروج بنجاح');
        toast.success('تم تسجيل الخروج بنجاح');
      }
      
      // Clear local storage and redirect
      localStorage.removeItem('currentSupport');
      navigate('/');
    } catch (error) {
      console.error('خطأ عام في تسجيل الخروج:', error);
      toast.error('حدث خطأ غير متوقع');
      
      // Still clear local storage and redirect even if database update failed
      localStorage.removeItem('currentSupport');
      navigate('/');
    }
  };

  if (!currentSupport) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-4">جاري التحميل...</h2>
          <p className="text-muted-foreground">يرجى الانتظار</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
    }`}>
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 text-4xl animate-float">🧑‍🔧</div>
        <div className="absolute top-20 right-20 text-3xl animate-float" style={{animationDelay: '0.5s'}}>💬</div>
        <div className="absolute bottom-20 left-20 text-3xl animate-float" style={{animationDelay: '1s'}}>⭐</div>
        <div className="absolute bottom-10 right-10 text-4xl animate-float" style={{animationDelay: '1.5s'}}>🛠️</div>
        <div className="absolute top-1/2 left-1/4 text-2xl animate-float" style={{animationDelay: '2s'}}>💡</div>
        <div className="absolute top-1/3 right-1/3 text-2xl animate-float" style={{animationDelay: '2.5s'}}>✨</div>
      </div>
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/')}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">🧑‍🔧 لوحة الدعم الفني</h1>
        </div>
        
        <Button 
          variant="destructive" 
          onClick={handleLogout}
          className="flex items-center gap-2"
        >
          <LogOut className="h-4 w-4" />
          تسجيل الخروج
        </Button>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Card */}
        <Card className="beautiful-card pulse-glow relative overflow-hidden mb-6">
          <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 to-blue-500/10"></div>
          <div className="relative p-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="text-6xl ml-6 animate-float">🧑‍🔧</div>
                <div>
                  <h2 className="text-3xl font-bold gradient-text mb-3">مرحباً {currentSupport.name}</h2>
                  <div className="flex items-center gap-4">
                    <Badge variant="default" className="bg-gradient-to-r from-green-500 to-green-600 animate-pulse">
                      🟢 متصل الآن
                    </Badge>
                    <span className="text-sm text-muted-foreground font-medium">
                      وقت الاتصال: {onlineTime}
                    </span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground mb-1">وقت الدخول</p>
                <p className="font-medium text-lg">
                  {new Date(currentSupport.loginTime).toLocaleString('ar-EG')}
                </p>
                <div className="flex justify-center gap-2 mt-2">
                  <span className="text-lg animate-float">⭐</span>
                  <span className="text-lg animate-float" style={{animationDelay: '0.5s'}}>✨</span>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <Card className="beautiful-card hover-lift cursor-pointer animate-3d relative overflow-hidden group shadow-blue-500/30" 
                onClick={() => navigate('/support/messages')}>
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-blue-700 opacity-5 group-hover:opacity-10 transition-opacity"></div>
            <div className="absolute top-2 right-2 text-4xl opacity-10 group-hover:opacity-20 transition-opacity animate-float">💬</div>
            <div className="relative p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-blue-700 ml-4 animate-3d shadow-lg group-hover:scale-110 transition-transform">
                  <MessageSquare className="h-8 w-8 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold text-lg gradient-text">الرسائل</h3>
                    <span className="text-xl animate-float">📨</span>
                  </div>
                  <p className="text-sm text-muted-foreground">محادثات الطلاب</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="beautiful-card hover-lift cursor-pointer animate-3d relative overflow-hidden group shadow-green-500/30"
                onClick={() => navigate('/support/payments')}>
            <div className="absolute inset-0 bg-gradient-to-br from-green-500 to-green-700 opacity-5 group-hover:opacity-10 transition-opacity"></div>
            <div className="absolute top-2 right-2 text-4xl opacity-10 group-hover:opacity-20 transition-opacity animate-float">💰</div>
            <div className="relative p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-xl bg-gradient-to-br from-green-500 to-green-700 ml-4 animate-3d shadow-lg group-hover:scale-110 transition-transform">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold text-lg gradient-text">المدفوعات</h3>
                    <span className="text-xl animate-float">💳</span>
                  </div>
                  <p className="text-sm text-muted-foreground">طلبات الشحن</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="beautiful-card hover-lift cursor-pointer animate-3d relative overflow-hidden group shadow-orange-500/30"
                onClick={() => navigate('/support/block-students')}>
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500 to-orange-700 opacity-5 group-hover:opacity-10 transition-opacity"></div>
            <div className="absolute top-2 right-2 text-4xl opacity-10 group-hover:opacity-20 transition-opacity animate-float">🚫</div>
            <div className="relative p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-xl bg-gradient-to-br from-orange-500 to-orange-700 ml-4 animate-3d shadow-lg group-hover:scale-110 transition-transform">
                  <Activity className="h-8 w-8 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold text-lg gradient-text">حظر الطلاب</h3>
                    <span className="text-xl animate-float">⛔</span>
                  </div>
                  <p className="text-sm text-muted-foreground">إدارة الحسابات</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="beautiful-card hover-lift cursor-pointer animate-3d relative overflow-hidden group shadow-purple-500/30"
                onClick={() => navigate('/support/rewards')}>
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-purple-700 opacity-5 group-hover:opacity-10 transition-opacity"></div>
            <div className="absolute top-2 right-2 text-4xl opacity-10 group-hover:opacity-20 transition-opacity animate-float">🎁</div>
            <div className="relative p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500 to-purple-700 ml-4 animate-3d shadow-lg group-hover:scale-110 transition-transform">
                  <Bell className="h-8 w-8 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold text-lg gradient-text">المكافآت</h3>
                    <span className="text-xl animate-float">🏆</span>
                  </div>
                  <p className="text-sm text-muted-foreground">نقاط الطلاب</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="beautiful-card hover-lift cursor-pointer animate-3d relative overflow-hidden group shadow-emerald-500/30"
                onClick={() => navigate('/support/book-reservations')}>
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500 to-emerald-700 opacity-5 group-hover:opacity-10 transition-opacity"></div>
            <div className="absolute top-2 right-2 text-4xl opacity-10 group-hover:opacity-20 transition-opacity animate-float">📚</div>
            <div className="relative p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 ml-4 animate-3d shadow-lg group-hover:scale-110 transition-transform">
                  <BookOpen className="h-8 w-8 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold text-lg gradient-text">حجز الكتب</h3>
                    <span className="text-xl animate-float">📖</span>
                  </div>
                  <p className="text-sm text-muted-foreground">حجوزات الطلاب</p>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Statistics Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="beautiful-card animate-3d relative overflow-hidden shadow-blue-500/20">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-cyan-500/5"></div>
            <div className="absolute top-2 right-2 text-4xl opacity-10 animate-float">📊</div>
            <div className="relative p-6">
              <div className="flex items-center gap-2 mb-4">
                <h3 className="font-bold text-lg gradient-text">📊 إحصائيات اليوم</h3>
                <span className="text-xl animate-float">📈</span>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-2 rounded-lg bg-blue-50/50">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    📨 الرسائل المستلمة
                  </span>
                  <span className="font-bold text-blue-600">0</span>
                </div>
                <div className="flex justify-between items-center p-2 rounded-lg bg-green-50/50">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    📤 الرسائل المرسلة
                  </span>
                  <span className="font-bold text-green-600">0</span>
                </div>
                <div className="flex justify-between items-center p-2 rounded-lg bg-purple-50/50">
                  <span className="text-sm text-muted-foreground flex items-center gap-2">
                    💰 طلبات الشحن
                  </span>
                  <span className="font-bold text-purple-600">0</span>
                </div>
              </div>
            </div>
          </Card>

          <Card className="beautiful-card animate-3d relative overflow-hidden shadow-green-500/20">
            <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-emerald-500/5"></div>
            <div className="absolute top-2 right-2 text-4xl opacity-10 animate-float">⏰</div>
            <div className="relative p-6">
              <div className="flex items-center gap-2 mb-4">
                <h3 className="font-bold text-lg gradient-text">⏰ معلومات الجلسة</h3>
                <span className="text-xl animate-float">🕐</span>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-2 rounded-lg bg-green-50/50">
                  <span className="text-sm text-muted-foreground">🕐 وقت الدخول</span>
                  <span className="font-medium text-sm">
                    {new Date(currentSupport.loginTime).toLocaleTimeString('ar-EG')}
                  </span>
                </div>
                <div className="flex justify-between items-center p-2 rounded-lg bg-blue-50/50">
                  <span className="text-sm text-muted-foreground">⏱️ المدة المتصلة</span>
                  <span className="font-bold text-blue-600">{onlineTime}</span>
                </div>
                <div className="flex justify-between items-center p-2 rounded-lg bg-green-50/50">
                  <span className="text-sm text-muted-foreground">🔆 الحالة</span>
                  <Badge variant="default" className="bg-gradient-to-r from-green-500 to-green-600 text-xs animate-pulse">
                    متصل ✨
                  </Badge>
                </div>
              </div>
            </div>
          </Card>

          <Card className="beautiful-card animate-3d relative overflow-hidden shadow-purple-500/20">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-pink-500/5"></div>
            <div className="absolute top-2 right-2 text-4xl opacity-10 animate-float">🎯</div>
            <div className="relative p-6">
              <div className="flex items-center gap-2 mb-4">
                <h3 className="font-bold text-lg gradient-text">🎯 المهام السريعة</h3>
                <span className="text-xl animate-float">⚡</span>
              </div>
              <div className="space-y-3">
                <Button variant="outline" size="sm" className="w-full justify-start hover-lift beautiful-button"
                        onClick={() => navigate('/support/messages')}>
                  📨 تحقق من الرسائل الجديدة
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start hover-lift beautiful-button"
                        onClick={() => navigate('/support/payments')}>
                  💰 مراجعة طلبات الشحن
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start hover-lift beautiful-button"
                        onClick={() => navigate('/support/block-students')}>
                  👥 إدارة حسابات الطلاب
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SupportDashboard;
