
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Save, Eye, EyeOff } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const TeacherChangeProfile = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [formData, setFormData] = useState({
    currentName: '',
    currentCode: '',
    currentPhone: '',
    newName: '',
    newCode: '',
    newPhone: ''
  });
  const [showCurrentCode, setShowCurrentCode] = useState(false);
  const [showNewCode, setShowNewCode] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    // تحميل البيانات الحالية للمعلم
    const currentTeacher = JSON.parse(localStorage.getItem('currentTeacher') || 'null');
    const teacherData = JSON.parse(localStorage.getItem('teacherData') || '{"name":"Mahmoud","code":"HHDV/58HR","phone":"01050747978"}');
    
    console.log('البيانات المحملة:', { currentTeacher, teacherData });
    
    setFormData(prev => ({
      ...prev,
      newName: teacherData.name,
      newCode: teacherData.code,
      newPhone: teacherData.phone
    }));
  }, []);

  const handleVerifyCurrentData = () => {
    const teacherData = JSON.parse(localStorage.getItem('teacherData') || '{"name":"Mahmoud","code":"HHDV/58HR","phone":"01050747978"}');
    
    console.log('التحقق من البيانات:');
    console.log('المدخلة:', formData);
    console.log('المطلوبة:', teacherData);
    
    if (formData.currentName.trim() === teacherData.name && 
        formData.currentCode.trim() === teacherData.code && 
        formData.currentPhone.trim() === teacherData.phone) {
      setIsVerified(true);
      toast.success('تم التحقق من البيانات بنجاح');
    } else {
      toast.error('البيانات المدخلة غير صحيحة');
      console.log('فشل التحقق:', {
        nameMatch: formData.currentName.trim() === teacherData.name,
        codeMatch: formData.currentCode.trim() === teacherData.code,
        phoneMatch: formData.currentPhone.trim() === teacherData.phone
      });
    }
  };

  const handleSaveChanges = () => {
    if (!formData.newName || !formData.newCode || !formData.newPhone) {
      toast.error('يرجى ملء جميع الحقول الجديدة');
      return;
    }

    // تحديث بيانات المعلم في localStorage
    const newTeacherData = {
      name: formData.newName.trim(),
      code: formData.newCode.trim(),
      phone: formData.newPhone.trim()
    };
    
    localStorage.setItem('teacherData', JSON.stringify(newTeacherData));
    
    // تحديث بيانات الجلسة الحالية
    const currentTeacher = JSON.parse(localStorage.getItem('currentTeacher') || 'null');
    if (currentTeacher) {
      currentTeacher.name = newTeacherData.name;
      localStorage.setItem('currentTeacher', JSON.stringify(currentTeacher));
    }
    
    console.log('تم تحديث البيانات إلى:', newTeacherData);
    
    toast.success('تم تحديث البيانات بنجاح');
    
    // إعادة تعيين النموذج
    setFormData({
      currentName: '',
      currentCode: '',
      currentPhone: '',
      newName: formData.newName,
      newCode: formData.newCode,
      newPhone: formData.newPhone
    });
    setIsVerified(false);
    
    // العودة للوحة التحكم بعد 2 ثانية
    setTimeout(() => {
      navigate('/teacher/dashboard');
    }, 2000);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/teacher/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">🔄 تغيير بيانات الدخول</h1>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* التحقق من البيانات الحالية */}
          {!isVerified && (
            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4 text-center">التحقق من البيانات الحالية</h2>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentName">الاسم الحالي</Label>
                  <Input
                    id="currentName"
                    value={formData.currentName}
                    onChange={(e) => setFormData({...formData, currentName: e.target.value})}
                    placeholder="أدخل الاسم الحالي"
                    className="text-right"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currentCode">كود الدخول الحالي</Label>
                  <div className="relative">
                    <Input
                      id="currentCode"
                      type={showCurrentCode ? "text" : "password"}
                      value={formData.currentCode}
                      onChange={(e) => setFormData({...formData, currentCode: e.target.value})}
                      placeholder="أدخل كود الدخول الحالي"
                      className="text-right pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute left-2 top-1/2 transform -translate-y-1/2"
                      onClick={() => setShowCurrentCode(!showCurrentCode)}
                    >
                      {showCurrentCode ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currentPhone">رقم الهاتف الحالي</Label>
                  <Input
                    id="currentPhone"
                    value={formData.currentPhone}
                    onChange={(e) => setFormData({...formData, currentPhone: e.target.value})}
                    placeholder="أدخل رقم الهاتف الحالي"
                    className="text-right"
                  />
                </div>

                <Button onClick={handleVerifyCurrentData} className="w-full">
                  التحقق من البيانات
                </Button>
              </div>
            </Card>
          )}

          {/* البيانات الجديدة */}
          {isVerified && (
            <Card className="p-6">
              <h2 className="text-lg font-bold mb-4 text-center text-green-600">✅ تم التحقق - أدخل البيانات الجديدة</h2>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="newName">الاسم الجديد</Label>
                  <Input
                    id="newName"
                    value={formData.newName}
                    onChange={(e) => setFormData({...formData, newName: e.target.value})}
                    placeholder="أدخل الاسم الجديد"
                    className="text-right"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="newCode">كود الدخول الجديد</Label>
                  <div className="relative">
                    <Input
                      id="newCode"
                      type={showNewCode ? "text" : "password"}
                      value={formData.newCode}
                      onChange={(e) => setFormData({...formData, newCode: e.target.value})}
                      placeholder="أدخل كود الدخول الجديد"
                      className="text-right pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute left-2 top-1/2 transform -translate-y-1/2"
                      onClick={() => setShowNewCode(!showNewCode)}
                    >
                      {showNewCode ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="newPhone">رقم الهاتف الجديد</Label>
                  <Input
                    id="newPhone"
                    value={formData.newPhone}
                    onChange={(e) => setFormData({...formData, newPhone: e.target.value})}
                    placeholder="أدخل رقم الهاتف الجديد"
                    className="text-right"
                  />
                </div>

                <div className="flex gap-4">
                  <Button onClick={handleSaveChanges} className="flex-1">
                    <Save className="w-4 h-4 ml-2" />
                    حفظ التغييرات
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setIsVerified(false)}
                    className="flex-1"
                  >
                    إلغاء
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {/* تعليمات */}
          <Card className="p-6 bg-blue-50">
            <h3 className="font-bold mb-2">📋 تعليمات هامة:</h3>
            <ul className="text-sm space-y-1">
              <li>• يجب إدخال البيانات الحالية بدقة للتحقق من الهوية</li>
              <li>• احرص على حفظ البيانات الجديدة في مكان آمن</li>
              <li>• سيتم تحديث بيانات الجلسة الحالية تلقائياً</li>
              <li>• استخدم البيانات الجديدة في تسجيل الدخول القادم</li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TeacherChangeProfile;
