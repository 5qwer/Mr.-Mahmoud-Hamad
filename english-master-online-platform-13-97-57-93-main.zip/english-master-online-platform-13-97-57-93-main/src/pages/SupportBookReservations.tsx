import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Search, BookOpen, User, Users, Calendar, Phone, GraduationCap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface BookReservation {
  id: string;
  book_title: string;
  book_grade: string;
  book_subject: string;
  book_price: number;
  pickup_location: string;
  student_id: string;
  student_name: string;
  student_grade: string;
  status: string;
  created_at: string;
  notes?: string;
}

const SupportBookReservations = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [selectedGrade, setSelectedGrade] = useState('');
  const [availableBooks, setAvailableBooks] = useState<any[]>([]);
  const [selectedBook, setSelectedBook] = useState<any>(null);
  const [reservations, setReservations] = useState<BookReservation[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchPerformed, setSearchPerformed] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    // Check if support is logged in
    const supportData = localStorage.getItem('currentSupport');
    if (!supportData) {
      navigate('/support/login');
      return;
    }
  }, [navigate]);

  const loadBooksForGrade = async (grade: string) => {
    if (!grade) return;
    
    setLoading(true);
    try {
      console.log('جاري تحميل الكتب للصف:', grade);
      
      const { data, error } = await supabase
        .from('available_books')
        .select('*')
        .eq('grade', grade)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في تحميل الكتب:', error);
        toast.error('حدث خطأ في تحميل الكتب');
        return;
      }

      console.log('الكتب المحملة:', data);
      setAvailableBooks(data || []);
      setSearchPerformed(true);
      
      if (!data || data.length === 0) {
        toast.info('لا توجد كتب متاحة لهذا الصف');
      } else {
        toast.success(`تم العثور على ${data.length} كتاب`);
      }
    } catch (error) {
      console.error('خطأ في تحميل الكتب:', error);
      toast.error('حدث خطأ غير متوقع');
    } finally {
      setLoading(false);
    }
  };

  const loadReservationsForBook = async (bookTitle: string) => {
    setLoading(true);
    try {
      console.log('البحث عن الحجوزات للكتاب:', bookTitle);
      
      const { data, error } = await supabase
        .from('book_reservations')
        .select('*')
        .eq('book_title', bookTitle)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في البحث:', error);
        toast.error('حدث خطأ في البحث');
        return;
      }

      console.log('نتائج البحث:', data);
      setReservations(data || []);
      
      if (!data || data.length === 0) {
        toast.info('لم يتم العثور على حجوزات لهذا الكتاب');
      } else {
        toast.success(`تم العثور على ${data.length} حجز`);
      }
    } catch (error) {
      console.error('خطأ في البحث:', error);
      toast.error('حدث خطأ غير متوقع');
    } finally {
      setLoading(false);
    }
  };

  const handleGradeSelect = (grade: string) => {
    setSelectedGrade(grade);
    setSelectedBook(null);
    setReservations([]);
    loadBooksForGrade(grade);
  };

  const handleBookSelect = (book: any) => {
    setSelectedBook(book);
    loadReservationsForBook(book.title);
  };

  const handleClearSearch = () => {
    setSelectedGrade('');
    setAvailableBooks([]);
    setSelectedBook(null);
    setReservations([]);
    setSearchPerformed(false);
  };


  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">⏳ في الانتظار</Badge>;
      case 'approved':
        return <Badge variant="default" className="bg-green-100 text-green-800">✅ موافق عليه</Badge>;
      case 'rejected':
        return <Badge variant="destructive">❌ مرفوض</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
    }`}>
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 text-4xl animate-float">📚</div>
        <div className="absolute top-20 right-20 text-3xl animate-float" style={{animationDelay: '0.5s'}}>🎓</div>
        <div className="absolute bottom-20 left-20 text-3xl animate-float" style={{animationDelay: '1s'}}>📖</div>
        <div className="absolute bottom-10 right-10 text-4xl animate-float" style={{animationDelay: '1.5s'}}>👨‍🎓</div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/support/dashboard')}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">📚 حجوزات الكتب</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Search Section */}
        <Card className="beautiful-card mb-8">
          <div className="p-6">
            <div className="flex items-center gap-2 mb-6">
              <Search className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold gradient-text">البحث عن حجوزات الكتب</h2>
              <span className="text-2xl animate-float">🔍</span>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <div className="space-y-2">
                <Label htmlFor="grade">الصف الدراسي</Label>
                <Select value={selectedGrade} onValueChange={handleGradeSelect}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر الصف..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">🥇 الأول الثانوي</SelectItem>
                    <SelectItem value="2">🥈 الثاني الثانوي</SelectItem>
                    <SelectItem value="3">🥉 الثالث الثانوي</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-end">
                {searchPerformed && (
                  <Button 
                    variant="outline" 
                    onClick={handleClearSearch}
                    className="hover-lift w-full"
                  >
                    مسح البحث
                  </Button>
                )}
              </div>
            </div>
          </div>
        </Card>

        {/* Available Books Section */}
        {availableBooks.length > 0 && (
          <Card className="beautiful-card mb-8">
            <div className="p-6">
              <div className="flex items-center gap-2 mb-6">
                <BookOpen className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-bold gradient-text">
                  الكتب المتاحة للصف {selectedGrade === '1' ? 'الأول' : selectedGrade === '2' ? 'الثاني' : 'الثالث'} الثانوي
                </h3>
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  📚 {availableBooks.length} كتاب
                </Badge>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {availableBooks.map((book) => (
                  <Card 
                    key={book.id} 
                    className={`hover-lift animate-3d border-2 cursor-pointer transition-all ${
                      selectedBook?.id === book.id 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                    onClick={() => handleBookSelect(book)}
                  >
                    <div className="p-4">
                      <div className="text-center mb-3">
                        {book.cover_image ? (
                          <img
                            src={book.cover_image}
                            alt={book.title}
                            className="w-20 h-28 object-cover rounded-lg mx-auto mb-2"
                          />
                        ) : (
                          <div className="w-20 h-28 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg mx-auto mb-2 flex items-center justify-center">
                            <BookOpen className="w-8 h-8 text-blue-500" />
                          </div>
                        )}
                        <h4 className="font-bold text-lg">{book.title}</h4>
                        <p className="text-sm text-blue-600">{book.subject}</p>
                        <p className="text-xs text-green-600 font-bold">{book.price} جنيه</p>
                      </div>
                      
                      <div className="text-xs text-gray-500 text-center">
                        <p>📍 {book.pickup_location}</p>
                        <p>📅 {new Date(book.created_at).toLocaleDateString('ar-EG')}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </Card>
        )}

        {/* Reservations Results Section */}
        {selectedBook && (
          <Card className="beautiful-card">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <Users className="h-6 w-6 text-primary" />
                  <h3 className="text-xl font-bold gradient-text">
                    الطلاب الحاجزين لكتاب: {selectedBook.title}
                  </h3>
                  <span className="text-xl animate-float">👥</span>
                </div>
                {reservations.length > 0 && (
                  <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                    📊 {reservations.length} حجز
                  </Badge>
                )}
              </div>

              {reservations.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4 animate-float">📭</div>
                  <h3 className="text-xl font-bold text-muted-foreground mb-2">
                    لا توجد حجوزات
                  </h3>
                  <p className="text-muted-foreground">
                    لم يتم العثور على أي حجوزات لكتاب "{selectedBook.title}"
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {reservations.map((reservation) => (
                    <Card key={reservation.id} className="hover-lift animate-3d border-l-4 border-l-blue-500">
                      <div className="p-6">
                        <div className="grid md:grid-cols-2 gap-6">
                          {/* Student Info */}
                          <div className="space-y-4">
                            <div className="flex items-center gap-2 mb-3">
                              <User className="h-5 w-5 text-blue-500" />
                              <h4 className="font-bold text-lg text-primary">بيانات الطالب</h4>
                              <span className="text-lg animate-float">👨‍🎓</span>
                            </div>
                            
                            <div className="space-y-2">
                              <div className="flex items-center gap-3 p-2 rounded-lg bg-blue-50/50">
                                <span className="text-sm text-muted-foreground min-w-0 flex-shrink-0">👤 الاسم:</span>
                                <span className="font-medium">{reservation.student_name}</span>
                              </div>
                              
                              <div className="flex items-center gap-3 p-2 rounded-lg bg-green-50/50">
                                <span className="text-sm text-muted-foreground min-w-0 flex-shrink-0">🎓 الصف:</span>
                                <span className="font-medium">{reservation.student_grade}</span>
                              </div>
                              
                              <div className="flex items-center gap-3 p-2 rounded-lg bg-yellow-50/50">
                                <span className="text-sm text-muted-foreground min-w-0 flex-shrink-0">📅 تاريخ الحجز:</span>
                                <span className="font-medium text-sm">{formatDate(reservation.created_at)}</span>
                              </div>
                            </div>
                          </div>
                          
                          {/* Book Info */}
                          <div className="space-y-4">
                            <div className="flex items-center gap-2 mb-3">
                              <BookOpen className="h-5 w-5 text-green-500" />
                              <h4 className="font-bold text-lg text-primary">بيانات الكتاب</h4>
                              <span className="text-lg animate-float">📚</span>
                            </div>
                            
                            <div className="space-y-2">
                              <div className="flex items-center gap-3 p-2 rounded-lg bg-green-50/50">
                                <span className="text-sm text-muted-foreground min-w-0 flex-shrink-0">📖 العنوان:</span>
                                <span className="font-medium">{reservation.book_title}</span>
                              </div>
                              
                              <div className="flex items-center gap-3 p-2 rounded-lg bg-blue-50/50">
                                <span className="text-sm text-muted-foreground min-w-0 flex-shrink-0">📚 المادة:</span>
                                <span className="font-medium">{reservation.book_subject}</span>
                              </div>
                              
                              <div className="flex items-center gap-3 p-2 rounded-lg bg-purple-50/50">
                                <span className="text-sm text-muted-foreground min-w-0 flex-shrink-0">💰 السعر:</span>
                                <span className="font-bold text-green-600">{reservation.book_price} جنيه</span>
                              </div>
                              
                              <div className="flex items-center gap-3 p-2 rounded-lg bg-orange-50/50">
                                <span className="text-sm text-muted-foreground min-w-0 flex-shrink-0">📍 موقع الاستلام:</span>
                                <span className="font-medium">{reservation.pickup_location}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {/* Status */}
                        <div className="mt-6 pt-4 border-t border-border">
                          <div className="flex items-center gap-3 mb-4">
                            <span className="text-sm text-muted-foreground">الحالة:</span>
                            {getStatusBadge(reservation.status)}
                          </div>
                          
                          {reservation.notes && (
                            <div className="mt-3 p-3 bg-gray-50/50 rounded-lg">
                              <span className="text-sm text-muted-foreground block mb-1">📝 ملاحظات:</span>
                              <p className="text-sm">{reservation.notes}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </Card>
        )}

        {/* No grade selected message */}
        {!selectedGrade && (
          <Card className="beautiful-card">
            <div className="p-12 text-center">
              <div className="text-6xl mb-4 animate-float">🎓</div>
              <h3 className="text-xl font-bold text-muted-foreground mb-2">
                اختر الصف الدراسي
              </h3>
              <p className="text-muted-foreground">
                قم بتحديد الصف الدراسي أولاً لعرض الكتب المتاحة
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default SupportBookReservations;