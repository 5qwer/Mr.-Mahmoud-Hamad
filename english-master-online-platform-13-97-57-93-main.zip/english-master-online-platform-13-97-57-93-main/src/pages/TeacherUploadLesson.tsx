import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Upload, FileText, Video, Moon, Sun, HelpCircle, Plus, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { Progress } from '@/components/ui/progress';
import { supabaseDataManager } from '@/utils/supabaseDataManager';
import { useErrorHandler } from '@/hooks/useErrorHandler';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
}

const TeacherUploadLesson = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentTeacher, setCurrentTeacher] = useState<any>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [targetSubscriptionId, setTargetSubscriptionId] = useState<number | null>(null);
  const [targetSubscriptionTitle, setTargetSubscriptionTitle] = useState<string>('');
  const { showError, ErrorToasts } = useErrorHandler();
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    grade: '',
    coverImage: null as File | null,
    explanationVideo: null as File | null,
    explanationFile: null as File | null,
    homework: '',
    homeworkVideo: null as File | null,
    homeworkSolution: null as File | null
  });

  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const teacher = JSON.parse(localStorage.getItem('currentTeacher') || 'null');
    if (!teacher) {
      navigate('/teacher');
      return;
    }
    setCurrentTeacher(teacher);
    
    // التحقق من معاملات URL لمعرفة الاشتراك المستهدف
    const urlParams = new URLSearchParams(window.location.search);
    const subscriptionId = urlParams.get('subscription');
    const grade = urlParams.get('grade');
    
    if (subscriptionId) {
      const parsedSubscriptionId = parseInt(subscriptionId);
      setTargetSubscriptionId(parsedSubscriptionId);
      
      // تحديد الصف مباشرة من معاملات URL إذا كان متوفراً
      if (grade) {
        setFormData(prev => ({ ...prev, grade: grade }));
      }
      
      loadSubscriptionTitle(parsedSubscriptionId);
    }
  }, [navigate]);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
  };

  const loadSubscriptionTitle = async (subscriptionId: number) => {
    try {
      const subscription = await supabaseDataManager.getSubscriptionById(subscriptionId);
      if (subscription) {
        setTargetSubscriptionTitle(subscription.title);
        // تحديد الصف من بيانات الاشتراك إذا لم يكن محدد مسبقاً
        if (subscription.grade && !formData.grade) {
          setFormData(prev => ({ ...prev, grade: subscription.grade }));
        }
      }
    } catch (error) {
      console.error('خطأ في تحميل بيانات الاشتراك:', error);
    }
  };

  const handleFileChange = (field: string, file: File | null) => {
    setFormData(prev => ({
      ...prev,
      [field]: file
    }));
  };

  const addQuestion = () => {
    const newQuestion: Question = {
      id: Date.now(),
      question: '',
      options: ['', '', '', ''],
      correctAnswer: 0
    };
    setQuestions([...questions, newQuestion]);
  };

  const updateQuestion = (id: number, field: string, value: any) => {
    setQuestions(questions.map(q => 
      q.id === id ? { ...q, [field]: value } : q
    ));
  };

  const updateQuestionOption = (questionId: number, optionIndex: number, value: string) => {
    setQuestions(questions.map(q => 
      q.id === questionId 
        ? { ...q, options: q.options.map((opt, idx) => idx === optionIndex ? value : opt) }
        : q
    ));
  };

  const removeQuestion = (id: number) => {
    setQuestions(questions.filter(q => q.id !== id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // التحقق من العنوان فقط
    if (!formData.title.trim()) {
      showError('خطأ في البيانات', 'يرجى إدخال عنوان الحصة');
      return;
    }

    // التحقق من الصف - إما من النموذج أو من الاشتراك المحدد
    const gradeToUse = formData.grade || (targetSubscriptionId ? 'auto' : '');
    if (!gradeToUse) {
      showError('خطأ في البيانات', 'يرجى اختيار الصف الدراسي أو التأكد من ربط الحصة بالاشتراك');
      return;
    }

    // التحقق من صحة الأسئلة فقط إذا تم إضافة أسئلة
    for (const question of questions) {
      if (question.question.trim() && question.options.some(opt => !opt.trim())) {
        showError('خطأ في الأسئلة', 'إذا أضفت سؤال، يرجى إدخال جميع خيارات الإجابة');
        return;
      }
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      // محاكاة تقدم الرفع
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + Math.random() * 15;
        });
      }, 200);

      // تحديد الصف النهائي للحصة
      let finalGrade = formData.grade;
      
      // إذا كان مربوط بالاشتراك ولم يكن الصف محدد، احصل عليه من الاشتراك
      if (targetSubscriptionId && !finalGrade) {
        const subscription = await supabaseDataManager.getSubscriptionById(targetSubscriptionId);
        if (subscription && subscription.grade) {
          finalGrade = subscription.grade;
        } else {
          throw new Error('لم يتم العثور على بيانات صف الاشتراك. يرجى المحاولة مرة أخرى.');
        }
      }

      // التأكد من أن الصف محدد
      if (!finalGrade) {
        throw new Error('يرجى تحديد الصف الدراسي');
      }

      // إنشاء بيانات الحصة مع ترتيب صحيح
      const orderNumber = targetSubscriptionId ? await getNextOrderNumber(targetSubscriptionId) : 1;
      
      const lessonData = {
        title: formData.title.trim(),
        description: formData.description.trim() || null,
        grade: finalGrade,
        price: 0,
        order_number: orderNumber,
        homework: formData.homework.trim() || null
      };

      // تحضير ملفات الرفع
      const files = {
        coverImage: formData.coverImage,
        explanationVideo: formData.explanationVideo,
        explanationFile: formData.explanationFile,
        homeworkVideo: formData.homeworkVideo,
        homeworkSolution: formData.homeworkSolution
      };

      // إنشاء الحصة في Supabase مع رفع الملفات
      console.log('إنشاء الحصة مع رفع الملفات:', lessonData);
      const newLesson = await supabaseDataManager.createLesson(lessonData, files);
      
      if (!newLesson) {
        throw new Error('فشل في إنشاء الحصة. يرجى المحاولة مرة أخرى.');
      }
      
      setUploadProgress(95);

      // إضافة الحصة للاشتراك إذا كان محدد
      if (targetSubscriptionId && newLesson) {
        console.log('ربط الحصة بالاشتراك:', { subscriptionId: targetSubscriptionId, lessonId: newLesson.id });
        await supabaseDataManager.addLessonToSubscription(targetSubscriptionId, newLesson.id);
        toast.success(`✅ تم إضافة الحصة "${formData.title}" إلى اشتراك "${targetSubscriptionTitle}" بنجاح!`);
      } else {
        toast.success('✅ تم إنشاء الحصة ورفع الملفات بنجاح!');
      }

      setUploadProgress(100);

      // إعادة تعيين النموذج
      setFormData({
        title: '',
        description: '',
        grade: targetSubscriptionId ? finalGrade : '', // الاحتفاظ بالصف إذا كان مربوط بالاشتراك
        coverImage: null,
        explanationVideo: null,
        explanationFile: null,
        homework: '',
        homeworkVideo: null,
        homeworkSolution: null
      });

      setQuestions([]);

      // العودة لصفحة الاشتراك إذا كان قادم منها
      if (targetSubscriptionId) {
        setTimeout(() => {
          navigate(`/teacher/subscription-details/${targetSubscriptionId}`);
        }, 1500);
      }

    } catch (error: any) {
      console.error('خطأ في رفع الحصة:', error);
      
      // عرض رسالة خطأ مفصلة
      const errorTitle = 'خطأ في رفع الحصة';
      let errorMessage = '';
      
      if (error.message) {
        errorMessage = error.message;
      } else if (error.error) {
        errorMessage = error.error;
      } else if (typeof error === 'string') {
        errorMessage = error;
      } else {
        errorMessage = 'حدث خطأ غير متوقع أثناء رفع الحصة. يرجى التحقق من الاتصال بالإنترنت والمحاولة مرة أخرى.';
      }
      
      // إضافة تفاصيل تقنية إذا كانت متوفرة
      if (error.status) {
        errorMessage += `\n\nرمز الخطأ: ${error.status}`;
      }
      
      if (error.details) {
        errorMessage += `\nالتفاصيل: ${error.details}`;
      }

      showError(errorTitle, errorMessage);
    } finally {
      setIsUploading(false);
      setTimeout(() => setUploadProgress(0), 2000);
    }
  };

  const getNextOrderNumber = async (subscriptionId: number) => {
    try {
      const subscription = await supabaseDataManager.getSubscriptionById(subscriptionId);
      return (subscription?.lessons?.length || 0) + 1;
    } catch (error) {
      console.error('خطأ في الحصول على رقم الترتيب:', error);
      return 1;
    }
  };

  return (
    <>
      <ErrorToasts />
      <div className={`min-h-screen transition-all duration-500 ${
        isDarkMode 
          ? 'bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900' 
          : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
      }`}>
        {/* Header */}
        <div className="flex items-center justify-between p-6 animate-fade-in">
          <div className="flex items-center">
            <Button
              variant="outline"
              size="icon"
              onClick={() => targetSubscriptionId ? navigate(`/teacher/subscription-details/${targetSubscriptionId}`) : navigate('/teacher/dashboard')}
              className={`rounded-xl ml-4 transition-all duration-300 hover:scale-110 border-2 ${
                isDarkMode 
                  ? 'border-purple-400 hover:border-purple-300 hover:bg-purple-900/50' 
                  : 'border-indigo-300 hover:border-indigo-400 hover:bg-indigo-50'
              }`}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="mr-4">
              <h1 className={`text-2xl font-bold mb-1 ${
                isDarkMode ? 'text-white' : 'text-slate-800'
              }`}>
                📥 {targetSubscriptionId ? 'إضافة حصة جديدة' : 'رفع حصة مدفوعة'}
              </h1>
              {targetSubscriptionId && (
                <p className={`text-sm ${
                  isDarkMode ? 'text-purple-300' : 'text-indigo-600'
                }`}>
                  الاشتراك: {targetSubscriptionTitle}
                </p>
              )}
            </div>
          </div>
          
          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            className={`rounded-xl transition-all duration-300 hover:scale-110 border-2 ${
              isDarkMode 
                ? 'border-yellow-400 hover:border-yellow-300 hover:bg-yellow-900/30' 
                : 'border-orange-300 hover:border-orange-400 hover:bg-orange-50'
            }`}
          >
            {isDarkMode ? <Sun className="h-5 w-5 text-yellow-400" /> : <Moon className="h-5 w-5 text-orange-500" />}
          </Button>
        </div>

        <div className="container mx-auto px-6 py-8">
          <Card className={`p-8 shadow-2xl border-0 transition-all duration-500 hover:shadow-3xl ${
            isDarkMode 
              ? 'bg-gradient-to-br from-slate-800/95 to-purple-900/95 backdrop-blur-lg' 
              : 'bg-gradient-to-br from-white/95 to-indigo-50/95 backdrop-blur-lg'
          }`}>
            {targetSubscriptionId && (
              <div className="mb-6 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200">
                <div className="flex items-center gap-2">
                  <Badge className="bg-green-500 text-white">مربوط بالاشتراك</Badge>
                  <span className="font-semibold">{targetSubscriptionTitle}</span>
                </div>
                <p className="text-sm text-green-600 mt-1">
                  سيتم إضافة الحصة تلقائياً إلى هذا الاشتراك بمجرد الحفظ
                </p>
                {formData.grade && (
                  <p className="text-sm text-green-600 mt-1">
                    ✅ الصف الدراسي: {formData.grade === '1' ? 'الأول الثانوي' : formData.grade === '2' ? 'الثاني الثانوي' : 'الثالث الثانوي'}
                  </p>
                )}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Information */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="title" className="text-lg font-semibold">عنوان الحصة *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    placeholder="أدخل عنوان الحصة"
                    className="text-lg"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="grade" className="text-lg font-semibold">
                    الصف الدراسي {targetSubscriptionId ? '' : '*'}
                  </Label>
                  <Select 
                    value={formData.grade} 
                    onValueChange={(value) => setFormData({...formData, grade: value})} 
                    required={!targetSubscriptionId}
                    disabled={!!targetSubscriptionId}
                  >
                    <SelectTrigger className="text-lg">
                      <SelectValue placeholder={targetSubscriptionId ? "سيتم تحديده من الاشتراك" : "اختر الصف"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">الأول الثانوي</SelectItem>
                      <SelectItem value="2">الثاني الثانوي</SelectItem>
                      <SelectItem value="3">الثالث الثانوي</SelectItem>
                    </SelectContent>
                  </Select>
                  {targetSubscriptionId && formData.grade && (
                    <p className="text-sm text-green-600 mt-1">
                      ✅ تم تحديد الصف تلقائياً من الاشتراك المحدد
                    </p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="coverImage" className="text-lg font-semibold">صورة الحصة</Label>
                <Input
                  id="coverImage"
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileChange('coverImage', e.target.files?.[0] || null)}
                  className="text-lg"
                />
                {formData.coverImage && (
                  <p className="text-sm text-green-600">
                    ✅ تم اختيار: {formData.coverImage.name}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-lg font-semibold">وصف الحصة</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="اكتب وصف مفصل للحصة (اختياري)"
                  rows={4}
                  className="text-lg"
                />
              </div>

              {/* Explanation Section */}
              <Card className="p-4 bg-blue-50 dark:bg-blue-900/20">
                <h3 className="font-bold text-xl mb-4 flex items-center text-blue-600">
                  <Video className="w-6 h-6 ml-2" />
                  مواد الشرح (اختيارية)
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="explanationVideo" className="text-lg font-semibold">فيديو الشرح</Label>
                    <Input
                      id="explanationVideo"
                      type="file"
                      accept="video/*"
                      onChange={(e) => handleFileChange('explanationVideo', e.target.files?.[0] || null)}
                      className="text-lg"
                    />
                    {formData.explanationVideo && (
                      <p className="text-sm text-blue-600">
                        ✅ تم اختيار: {formData.explanationVideo.name} - حجم الملف: {(formData.explanationVideo.size / (1024 * 1024)).toFixed(2)} MB
                      </p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="explanationFile" className="text-lg font-semibold">ملف الشرح (PDF/Word/PowerPoint)</Label>
                    <Input
                      id="explanationFile"
                      type="file"
                      accept=".pdf,.doc,.docx,.ppt,.pptx"
                      onChange={(e) => handleFileChange('explanationFile', e.target.files?.[0] || null)}
                      className="text-lg"
                    />
                    {formData.explanationFile && (
                      <p className="text-sm text-blue-600">
                        ✅ تم اختيار: {formData.explanationFile.name}
                      </p>
                    )}
                  </div>
                </div>
              </Card>

              {/* Homework Section */}
              <Card className="p-4 bg-orange-50 dark:bg-orange-900/20">
                <h3 className="font-bold text-xl mb-4 flex items-center text-orange-600">
                  <FileText className="w-6 h-6 ml-2" />
                  الواجب (اختياري)
                </h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="homework" className="text-lg font-semibold">نص الواجب</Label>
                    <Textarea
                      id="homework"
                      value={formData.homework}
                      onChange={(e) => setFormData({...formData, homework: e.target.value})}
                      placeholder="اكتب تعليمات الواجب والمطلوب من الطلاب (اختياري)"
                      rows={3}
                      className="text-lg"
                    />
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="homeworkVideo" className="text-lg font-semibold">فيديو الواجب</Label>
                      <Input
                        id="homeworkVideo"
                        type="file"
                        accept="video/*"
                        onChange={(e) => handleFileChange('homeworkVideo', e.target.files?.[0] || null)}
                        className="text-lg"
                      />
                      {formData.homeworkVideo && (
                        <p className="text-sm text-orange-600">
                          ✅ تم اختيار: {formData.homeworkVideo.name}
                        </p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="homeworkSolution" className="text-lg font-semibold">ملف حل الواجب</Label>
                      <Input
                        id="homeworkSolution"
                        type="file"
                        accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                        onChange={(e) => handleFileChange('homeworkSolution', e.target.files?.[0] || null)}
                        className="text-lg"
                      />
                      {formData.homeworkSolution && (
                        <p className="text-sm text-orange-600">
                          ✅ تم اختيار: {formData.homeworkSolution.name}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </Card>

              {/* Questions Section */}
              <Card className="p-4 bg-purple-50 dark:bg-purple-900/20">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold text-xl flex items-center text-purple-600">
                    <HelpCircle className="w-6 h-6 ml-2" />
                    أسئلة الحصة (اختيارية)
                  </h3>
                  <Button 
                    type="button" 
                    onClick={addQuestion}
                    variant="outline"
                    size="sm"
                  >
                    <Plus className="w-4 h-4 ml-2" />
                    إضافة سؤال
                  </Button>
                </div>

                {questions.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <HelpCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>لم يتم إضافة أسئلة بعد</p>
                    <p className="text-sm">يمكنك إضافة أسئلة اختيارية للحصة</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {questions.map((question, index) => (
                      <Card key={question.id} className="p-4 bg-gray-50">
                        <div className="flex justify-between items-center mb-3">
                          <h4 className="font-semibold">السؤال {index + 1}</h4>
                          <Button
                            type="button"
                            onClick={() => removeQuestion(question.id)}
                            variant="destructive"
                            size="sm"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>

                        <div className="space-y-3">
                          <div className="space-y-2">
                            <Label>نص السؤال</Label>
                            <Input
                              placeholder="اكتب السؤال هنا"
                              value={question.question}
                              onChange={(e) => updateQuestion(question.id, 'question', e.target.value)}
                              className="text-right"
                            />
                          </div>

                          <div className="space-y-2">
                            <Label>خيارات الإجابة</Label>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                              {question.options.map((option, optionIndex) => (
                                <div key={optionIndex} className="flex items-center space-x-2">
                                  <input
                                    type="radio"
                                    name={`correct-${question.id}`}
                                    checked={question.correctAnswer === optionIndex}
                                    onChange={() => updateQuestion(question.id, 'correctAnswer', optionIndex)}
                                    className="ml-2"
                                  />
                                  <Input
                                    placeholder={`الخيار ${optionIndex + 1}`}
                                    value={option}
                                    onChange={(e) => updateQuestionOption(question.id, optionIndex, e.target.value)}
                                    className="text-right flex-1"
                                  />
                                  <span className="text-sm text-muted-foreground">
                                    {optionIndex === question.correctAnswer ? '✅' : ''}
                                  </span>
                                </div>
                              ))}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              اختر الإجابة الصحيحة بالنقر على الدائرة بجانب الخيار
                            </p>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </Card>

              {/* Upload Progress */}
              {isUploading && (
                <Card className="p-4 bg-green-50 dark:bg-green-900/20">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>جاري رفع الحصة...</span>
                      <span>{Math.round(uploadProgress)}%</span>
                    </div>
                    <Progress value={uploadProgress} className="w-full" />
                  </div>
                </Card>
              )}

              <Button 
                type="submit" 
                className="w-full py-4 text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 hover-lift" 
                disabled={isUploading}
              >
                {isUploading ? (
                  <>
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white ml-2"></div>
                    جاري الرفع...
                  </>
                ) : (
                  <>
                    <Upload className="w-6 h-6 ml-2" />
                    {targetSubscriptionId ? 'إضافة الحصة للاشتراك' : 'رفع الحصة'}
                  </>
                )}
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </>
  );
};

export default TeacherUploadLesson;
