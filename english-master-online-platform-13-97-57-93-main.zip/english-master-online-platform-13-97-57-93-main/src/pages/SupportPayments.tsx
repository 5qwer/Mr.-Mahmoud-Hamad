import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, CheckCircle, XCircle, Eye, Search, CreditCard, User, Clock, Image as ImageIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const SupportPayments = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [walletRequests, setWalletRequests] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [showModal, setShowModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [actionType, setActionType] = useState<'approve' | 'reject'>('approve');
  const [showImageModal, setShowImageModal] = useState(false);
  const [selectedImage, setSelectedImage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    loadWalletRequests();
  }, []);

  const loadWalletRequests = async () => {
    try {
      console.log('Loading wallet requests from Supabase...');
      
      const { data: requests, error } = await supabase
        .from('wallet_requests')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في جلب طلبات المحفظة:', error);
        toast.error('حدث خطأ في تحميل طلبات المحفظة');
        return;
      }

      if (!requests || requests.length === 0) {
        setWalletRequests([]);
        return;
      }

      const requestsWithStudents = await Promise.all(
        requests.map(async (request) => {
          const { data: student } = await supabase
            .from('students')
            .select('full_name, parent_number, wallet_balance')
            .eq('id', request.user_id)
            .single();

          return {
            ...request,
            students: student
          };
        })
      );

      console.log('Wallet requests loaded:', requestsWithStudents);
      setWalletRequests(requestsWithStudents || []);
    } catch (error) {
      console.error('خطأ في تحميل طلبات المحفظة:', error);
      toast.error('حدث خطأ في تحميل طلبات المحفظة');
    }
  };

  const filteredRequests = walletRequests.filter(request =>
    request.students?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    request.transfer_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    request.payment_method?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAction = (request: any, action: 'approve' | 'reject') => {
    setSelectedRequest(request);
    setActionType(action);
    setShowModal(true);
    setRejectReason('');
  };

  const confirmAction = async () => {
    if (!selectedRequest) return;

    if (actionType === 'reject' && !rejectReason.trim()) {
      toast.error('يرجى إدخال سبب الرفض');
      return;
    }

    try {
      console.log('بدء تأكيد العملية:', actionType, 'للطلب:', selectedRequest.id);

      if (actionType === 'approve') {
        console.log('استدعاء edge function لتأكيد العملية...');
        console.log('البيانات المرسلة:', {
          request_id: selectedRequest.id,
          student_id: selectedRequest.user_id,
          amount_to_add: selectedRequest.amount,
          payment_method: selectedRequest.payment_method,
          transfer_number: selectedRequest.transfer_number
        });
        
        const { data, error } = await supabase.functions.invoke('process-wallet-approval', {
          body: {
            request_id: selectedRequest.id,
            student_id: selectedRequest.user_id,
            amount_to_add: Number(selectedRequest.amount),
            payment_method: selectedRequest.payment_method,
            transfer_number: selectedRequest.transfer_number
          }
        });

        console.log('Edge function response:', { data, error });

        if (error) {
          console.error('خطأ في edge function:', error);
          toast.error(`فشل في معالجة العملية: ${error.message || 'خطأ في الاتصال بالخادم'}`);
          return;
        }

        if (!data) {
          console.error('Edge function returned no data');
          toast.error('لم يتم إرجاع بيانات من الخادم');
          return;
        }

        if (!data.success) {
          console.error('Edge function returned unsuccessful result:', data);
          toast.error(`فشل في معالجة العملية: ${data.error || 'العملية لم تكتمل بنجاح'}`);
          return;
        }

        console.log('تم تأكيد العملية بنجاح عبر edge function:', data);
        
        // عرض رسالة النجاح بالرصيد الجديد من النتيجة
        toast.success(`تم تأكيد عملية الدفع بنجاح! تم إضافة ${data.amount_added} جنيه للمحفظة. الرصيد الجديد: ${data.new_balance} جنيه ✅`);

      } else {
        // Handle rejection
        const { error: updateError } = await supabase
          .from('wallet_requests')
          .update({
            status: 'rejected',
            reviewed_at: new Date().toISOString(),
            reviewed_by: 'الدعم الفني',
            reject_reason: rejectReason.trim()
          })
          .eq('id', selectedRequest.id);

        if (updateError) {
          console.error('خطأ في تحديث طلب المحفظة:', updateError);
          toast.error('حدث خطأ في تحديث الطلب');
          return;
        }

        toast.success('تم رفض عملية الدفع');
      }

      // إعادة تحميل الطلبات لإظهار التحديثات
      await loadWalletRequests();
      
    } catch (error) {
      console.error('خطأ في العملية:', error);
      toast.error(`حدث خطأ في العملية: ${(error as Error).message}`);
    }

    setShowModal(false);
    setSelectedRequest(null);
    setRejectReason('');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">في الانتظار</Badge>;
      case 'approved':
        return <Badge variant="outline" className="bg-green-100 text-green-800">مؤكد</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="bg-red-100 text-red-800">مرفوض</Badge>;
      default:
        return <Badge variant="outline">غير محدد</Badge>;
    }
  };

  const viewImage = (imageUrl: string) => {
    setSelectedImage(imageUrl);
    setShowImageModal(true);
  };

  const pendingRequests = filteredRequests.filter(r => r.status === 'pending');
  const processedRequests = filteredRequests.filter(r => r.status !== 'pending');

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-cyan-900 to-teal-900' 
        : 'bg-gradient-to-br from-cyan-50 via-white to-teal-50'
    }`}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/support/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">💳 إدارة عمليات الدفع</h1>
        
        <div className="mr-4">
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-blue-400 shadow-lg">
            <img 
              src="/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png" 
              alt="Mr. Mahmoud Hamad" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Card className="p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Search className="w-5 h-5 text-gray-500" />
            <h2 className="text-lg font-bold">البحث في العمليات</h2>
          </div>
          
          <Input
            placeholder="ابحث بالاسم أو رقم التحويل أو وسيلة الدفع..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="text-right"
          />
        </Card>

        <Card className="p-6 mb-6">
          <div className="flex items-center gap-2 mb-6">
            <Clock className="w-5 h-5 text-orange-500" />
            <h3 className="text-lg font-bold">الطلبات المعلقة</h3>
            <Badge variant="outline" className="mr-auto">
              {pendingRequests.length}
            </Badge>
          </div>
          
          {pendingRequests.length === 0 ? (
            <div className="text-center py-8">
              <CreditCard className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <p className="text-muted-foreground">لا توجد طلبات معلقة</p>
            </div>
          ) : (
            <div className="space-y-4">
              {pendingRequests.map((request) => (
                <div key={request.id} className="border rounded-lg p-4 bg-yellow-50">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <User className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="font-bold">{request.students?.full_name || 'غير محدد'}</h4>
                          <p className="text-sm text-muted-foreground">
                            {request.students?.parent_number} • {new Date(request.created_at).toLocaleDateString('ar-EG')}
                          </p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="font-semibold">المبلغ:</span>
                          <p className="text-green-600 font-bold">{request.amount} جنيه</p>
                        </div>
                        <div>
                          <span className="font-semibold">وسيلة الدفع:</span>
                          <p>{request.payment_method}</p>
                        </div>
                        <div>
                          <span className="font-semibold">رقم التحويل:</span>
                          <p>{request.transfer_number}</p>
                        </div>
                        <div>
                          <span className="font-semibold">وقت التحويل:</span>
                          <p>{new Date(request.transfer_time).toLocaleString('ar-EG')}</p>
                        </div>
                      </div>
                      
                      {request.message && (
                        <div className="mt-2">
                          <span className="font-semibold">رسالة الطالب:</span>
                          <p className="text-sm text-gray-600 mt-1">{request.message}</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex flex-col gap-2 mr-4">
                      {getStatusBadge(request.status)}
                      {request.transfer_image && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => viewImage(request.transfer_image)}
                        >
                          <ImageIcon className="w-4 h-4 ml-1" />
                          عرض الإيصال
                        </Button>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex gap-2 pt-4 border-t">
                    <Button
                      onClick={() => handleAction(request, 'approve')}
                      className="bg-green-600 hover:bg-green-700"
                      size="sm"
                    >
                      <CheckCircle className="w-4 h-4 ml-1" />
                      تأكيد الدفع
                    </Button>
                    <Button
                      onClick={() => handleAction(request, 'reject')}
                      variant="destructive"
                      size="sm"
                    >
                      <XCircle className="w-4 h-4 ml-1" />
                      رفض الدفع
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <CreditCard className="w-5 h-5 text-blue-500" />
            <h3 className="text-lg font-bold">العمليات المعالجة</h3>
            <Badge variant="outline" className="mr-auto">
              {processedRequests.length}
            </Badge>
          </div>
          
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {processedRequests.map((request) => (
              <div key={request.id} className={`border rounded-lg p-4 ${
                request.status === 'approved' ? 'bg-green-50' : 'bg-red-50'
              }`}>
                <div className="flex justify-between items-center">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="font-bold">{request.students?.full_name || 'غير محدد'}</h4>
                      <span className="text-sm text-muted-foreground">
                        {request.amount} جنيه
                      </span>
                      {getStatusBadge(request.status)}
                      {request.transfer_image && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => viewImage(request.transfer_image)}
                        >
                          <ImageIcon className="w-3 h-3 ml-1" />
                          الإيصال
                        </Button>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {new Date(request.reviewed_at).toLocaleString('ar-EG')} • {request.reviewed_by}
                    </p>
                    {request.reject_reason && (
                      <p className="text-sm text-red-600 mt-1">
                        سبب الرفض: {request.reject_reason}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <Card className="p-6 max-w-md w-full mx-4">
              <h3 className="text-lg font-bold mb-4">
                {actionType === 'approve' ? 'تأكيد عملية الدفع' : 'رفض عملية الدفع'}
              </h3>
              
              <div className="mb-4">
                <p className="text-sm text-muted-foreground mb-2">
                  الطالب: <strong>{selectedRequest?.students?.full_name || 'غير محدد'}</strong>
                </p>
                <p className="text-sm text-muted-foreground mb-2">
                  المبلغ: <strong>{selectedRequest?.amount} جنيه</strong>
                </p>
                <p className="text-sm text-muted-foreground mb-2">
                  الرصيد الحالي: <strong>{selectedRequest?.students?.wallet_balance || 0} جنيه</strong>
                </p>
                {actionType === 'approve' && (
                  <p className="text-sm text-green-600 font-semibold">
                    الرصيد بعد الإضافة: {(selectedRequest?.students?.wallet_balance || 0) + (selectedRequest?.amount || 0)} جنيه
                  </p>
                )}
                <p className="text-sm text-muted-foreground">
                  رقم التحويل: <strong>{selectedRequest?.transfer_number}</strong>
                </p>
              </div>
              
              {actionType === 'reject' && (
                <div className="space-y-2 mb-4">
                  <Label htmlFor="rejectReason">سبب الرفض *</Label>
                  <Textarea
                    id="rejectReason"
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                    placeholder="اكتب سبب رفض عملية الدفع..."
                    className="text-right"
                  />
                </div>
              )}
              
              <div className="flex space-x-2">
                <Button 
                  onClick={confirmAction}
                  variant={actionType === 'approve' ? 'default' : 'destructive'}
                  className="flex-1"
                >
                  تأكيد {actionType === 'approve' ? 'القبول' : 'الرفض'}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setShowModal(false)}
                  className="flex-1"
                >
                  إلغاء
                </Button>
              </div>
            </Card>
          </div>
        )}

        {showImageModal && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
            <div className="relative max-w-4xl max-h-[90vh] overflow-auto">
              <Button
                onClick={() => setShowImageModal(false)}
                className="absolute top-4 right-4 z-10"
                variant="secondary"
              >
                ✕
              </Button>
              <img
                src={selectedImage}
                alt="إيصال التحويل"
                className="max-w-full max-h-full object-contain"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SupportPayments;
