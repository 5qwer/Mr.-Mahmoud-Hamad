
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Book, Search, Eye, Moon, Sun, CheckCircle, User, MapPin, Calendar, Printer } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const StudentBooks = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [books, setBooks] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [reservedBooks, setReservedBooks] = useState<Set<string>>(new Set());
  const [showReceipt, setShowReceipt] = useState(false);
  const [selectedReservation, setSelectedReservation] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student');
      return;
    }
    setCurrentStudent(student);
    
    loadBooks();
    loadReservedBooks(student.id);
  }, [navigate]);

  const loadBooks = async () => {
    try {
      const { data, error } = await supabase
        .from('available_books')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في تحميل الكتب:', error);
        toast.error('فشل في تحميل الكتب');
        return;
      }

      console.log('جميع الكتب المحملة من Supabase:', data);
      setBooks(data || []);
    } catch (error) {
      console.error('خطأ في تحميل الكتب:', error);
      toast.error('فشل في تحميل الكتب');
      setBooks([]);
    }
  };

  const loadReservedBooks = async (studentId: string) => {
    try {
      const { data, error } = await supabase
        .from('book_reservations')
        .select('*')
        .eq('student_id', studentId);

      if (error) {
        console.error('خطأ في تحميل الحجوزات:', error);
        return;
      }

      const reservedBookTitles = new Set(data?.map((reservation: any) => reservation.book_title) || []);
      setReservedBooks(reservedBookTitles);
    } catch (error) {
      console.error('خطأ في تحميل الحجوزات:', error);
    }
  };

  const normalizeGrade = (grade: string): string => {
    if (!grade) return '1';
    const gradeStr = grade.toString().toLowerCase();
    if (gradeStr === 'first' || gradeStr === '1' || gradeStr === 'الأول') return '1';
    if (gradeStr === 'second' || gradeStr === '2' || gradeStr === 'الثاني') return '2';
    if (gradeStr === 'third' || gradeStr === '3' || gradeStr === 'الثالث') return '3';
    return gradeStr;
  };

  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         book.subject.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (!currentStudent) {
      console.log('لا يوجد طالب محدد، عرض جميع الكتب');
      return matchesSearch;
    }
    
    const studentGrade = normalizeGrade(currentStudent.grade || '1');
    const bookGrade = normalizeGrade(book.grade || '1');
    const matchesGrade = bookGrade === studentGrade || book.grade === 'all';
    
    console.log('تصفية الكتب:', {
      bookTitle: book.title,
      bookGrade: bookGrade,
      studentGrade: studentGrade,
      matchesGrade: matchesGrade,
      matchesSearch: matchesSearch
    });
    
    return matchesSearch && matchesGrade;
  });

  console.log('الكتب المصفاة:', filteredBooks);
  console.log('الطالب الحالي:', currentStudent);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
  };

  const handleView = (book: any) => {
    if (book.file_url) {
      window.open(book.file_url, '_blank');
    } else {
      toast.error('الملف غير متوفر للعرض');
    }
  };

  const handleViewReceipt = async (book: any) => {
    try {
      const { data, error } = await supabase
        .from('book_reservations')
        .select('*')
        .eq('student_id', currentStudent.id)
        .eq('book_title', book.title)
        .single();

      if (error) {
        console.error('خطأ في تحميل بيانات الحجز:', error);
        toast.error('فشل في تحميل بيانات الحجز');
        return;
      }

      setSelectedReservation({ ...data, book });
      setShowReceipt(true);
    } catch (error) {
      console.error('خطأ في تحميل بيانات الحجز:', error);
      toast.error('فشل في تحميل بيانات الحجز');
    }
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  const getGradeLabel = (grade: string) => {
    const normalizedGrade = normalizeGrade(grade);
    switch (normalizedGrade) {
      case '1': return 'الأول الثانوي';
      case '2': return 'الثاني الثانوي';
      case '3': return 'الثالث الثانوي';
      case 'all': return 'جميع الصفوف';
      default: return grade;
    }
  };

  const isBookReserved = (bookTitle: string) => {
    return reservedBooks.has(bookTitle);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/student/dashboard')}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">📚 مكتبة الكتب</h1>
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className="rounded-full"
        >
          {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Search Section */}
        <Card className="p-6 mb-8">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="ابحث عن كتاب أو مادة..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="text-right pr-4 pl-10"
              />
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground">المتاح</p>
              <p className="text-2xl font-bold text-blue-600">{filteredBooks.length}</p>
            </div>
          </div>
          
          {currentStudent && (
            <div className="mt-4 p-3 bg-blue-50 rounded-lg text-sm">
              <p><span className="font-medium">الصف الدراسي:</span> {getGradeLabel(currentStudent.grade)}</p>
              <p><span className="font-medium">إجمالي الكتب:</span> {books.length}</p>
              <p><span className="font-medium">الكتب المتاحة لصفك:</span> {filteredBooks.length}</p>
            </div>
          )}
        </Card>

        {/* Books Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBooks.map((book) => (
            <Card key={book.id} className="p-6 hover:shadow-lg transition-shadow">
              <div className="text-center mb-4">
                {book.cover_image ? (
                  <img
                    src={book.cover_image}
                    alt={book.title}
                    className="w-32 h-40 object-cover rounded-lg mx-auto mb-4"
                  />
                ) : (
                  <div className="w-32 h-40 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg mx-auto mb-4 flex items-center justify-center">
                    <Book className="w-16 h-16 text-blue-500" />
                  </div>
                )}
                
                <h3 className="font-bold text-lg mb-2">{book.title}</h3>
                <p className="text-sm text-muted-foreground mb-1">{book.subject}</p>
                <p className="text-xs text-blue-600">{getGradeLabel(book.grade)}</p>
              </div>
              
              {book.description && (
                <p className="text-sm text-gray-600 mb-4 text-center">{book.description}</p>
              )}
              
              <div className="text-center text-xs text-muted-foreground mb-4">
                <p>تاريخ الإضافة: {new Date(book.created_at).toLocaleDateString('ar-EG')}</p>
                <p>السعر: {book.price} جنيه</p>
                <p>مكان الاستلام: {book.pickup_location}</p>
              </div>
              
              <div className="flex gap-2">
                <Button
                  onClick={() => handleView(book)}
                  variant="outline"
                  className="flex-1"
                  disabled={!book.file_url}
                >
                  <Eye className="w-4 h-4 ml-1" />
                  عرض
                </Button>
                
                {isBookReserved(book.title) ? (
                  <div className="flex gap-2 flex-1">
                    <Button
                      onClick={() => handleViewReceipt(book)}
                      variant="outline"
                      className="flex-1 text-blue-600 border-blue-600 hover:bg-blue-50"
                    >
                      <Eye className="w-4 h-4 ml-1" />
                      عرض الإيصال
                    </Button>
                    <Button
                      disabled
                      className="flex-1 bg-green-500 hover:bg-green-600"
                    >
                      <CheckCircle className="w-4 h-4 ml-1" />
                      تم الحجز
                    </Button>
                  </div>
                ) : (
                  <Button
                    onClick={() => navigate(`/student/book-details/${book.id}`)}
                    className="flex-1 bg-green-500 hover:bg-green-600"
                  >
                    📚 حجز الآن
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>
        
        {filteredBooks.length === 0 && (
          <Card className="p-12 text-center">
            <Book className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-bold mb-2">لا توجد كتب متاحة</h3>
            <p className="text-muted-foreground">
              {searchTerm ? `لا توجد نتائج للبحث "${searchTerm}"` : 'لم يتم رفع أي كتب لصفك الدراسي بعد'}
            </p>
            {currentStudent && (
              <div className="mt-4 text-sm text-gray-500">
                <p>صفك الدراسي: {getGradeLabel(currentStudent.grade)}</p>
                <p>إجمالي الكتب في النظام: {books.length}</p>
              </div>
            )}
          </Card>
        )}
      </div>

      {/* Receipt Modal */}
      {showReceipt && selectedReservation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto p-8 bg-white shadow-2xl print:shadow-none print:max-w-none print:w-full print:max-h-none print:overflow-visible">
            {/* Header */}
            <div className="text-center mb-8 relative print:mb-6">
              <div className="absolute top-0 right-0 opacity-30 print:opacity-50">
                <img 
                  src="/lovable-uploads/d210bf9c-1ff3-4adc-aed6-1016a16dd585.png" 
                  alt="ختم الأستاذ محمود حامد" 
                  className="w-32 h-32 object-contain"
                />
              </div>
              <h1 className="text-3xl font-bold text-blue-600 mb-2">إيصال حجز كتاب</h1>
              <p className="text-lg text-gray-600">الأستاذ محمود حامد - مدرس اللغة الإنجليزية</p>
              <div className="w-full h-1 bg-gradient-to-r from-blue-500 to-green-500 mt-4"></div>
            </div>

            {/* Receipt Details */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {/* Student Info */}
              <div className="space-y-3">
                <h3 className="font-bold text-lg text-blue-600 flex items-center">
                  <User className="w-5 h-5 ml-2" />
                  بيانات الطالب
                </h3>
                <div className="bg-blue-50 p-4 rounded-lg space-y-2">
                  <p><span className="font-medium">الاسم:</span> {selectedReservation.student_name}</p>
                  <p><span className="font-medium">الصف:</span> {getGradeLabel(selectedReservation.student_grade)}</p>
                  <p><span className="font-medium">رقم الطالب:</span> {currentStudent.student_number}</p>
                  <p><span className="font-medium">رقم ولي الأمر:</span> {currentStudent.parent_number}</p>
                </div>
              </div>

              {/* Reservation Info */}
              <div className="space-y-3">
                <h3 className="font-bold text-lg text-blue-600 flex items-center">
                  <Calendar className="w-5 h-5 ml-2" />
                  تفاصيل الحجز
                </h3>
                <div className="bg-green-50 p-4 rounded-lg space-y-2">
                  <p><span className="font-medium">رقم الإيصال:</span> {selectedReservation.id.slice(-8)}</p>
                  <p><span className="font-medium">تاريخ الحجز:</span> {new Date(selectedReservation.created_at).toLocaleDateString('ar-EG')}</p>
                  <p><span className="font-medium">وقت الحجز:</span> {new Date(selectedReservation.created_at).toLocaleTimeString('ar-EG')}</p>
                  <p><span className="font-medium">تاريخ الاستلام المتوقع:</span> {new Date(new Date(selectedReservation.created_at).getTime() + 24 * 60 * 60 * 1000).toLocaleDateString('ar-EG')}</p>
                </div>
              </div>
            </div>

            {/* Book Details */}
            <div className="mb-8">
              <h3 className="font-bold text-lg text-blue-600 mb-4">تفاصيل الكتاب</h3>
              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-start gap-4">
                  {selectedReservation.book.cover_image ? (
                    <img
                      src={selectedReservation.book.cover_image}
                      alt={selectedReservation.book_title}
                      className="w-24 h-32 object-cover rounded-lg"
                    />
                  ) : (
                    <div className="w-24 h-32 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Book className="w-8 h-8 text-blue-500" />
                    </div>
                  )}
                  <div className="flex-1">
                    <h4 className="font-bold text-xl mb-2">{selectedReservation.book_title}</h4>
                    <p className="text-gray-600 mb-1">{selectedReservation.book_subject}</p>
                    <p className="text-sm text-gray-500 mb-3">{getGradeLabel(selectedReservation.book_grade)}</p>
                    <div className="text-right">
                      <span className="text-2xl font-bold text-green-600">{selectedReservation.book_price} جنيه</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Pickup Location */}
            <div className="mb-8">
              <h3 className="font-bold text-lg text-blue-600 flex items-center mb-4">
                <MapPin className="w-5 h-5 ml-2" />
                مكان الاستلام
              </h3>
              <div className="bg-yellow-50 p-4 rounded-lg">
                <p className="font-medium mb-2">{selectedReservation.pickup_location}</p>
                <p className="text-sm text-gray-600 mb-1">أوقات الاستلام: يومياً من 9 صباحاً إلى 5 مساءً</p>
                <p className="text-sm font-medium text-red-600">⚠️ يرجى إحضار هذا الإيصال والهوية الطلابية عند الاستلام</p>
              </div>
            </div>

            {/* Footer */}
            <div className="text-center border-t pt-6">
              <div className="flex justify-center items-center mb-4">
                <img 
                  src="/lovable-uploads/d210bf9c-1ff3-4adc-aed6-1016a16dd585.png" 
                  alt="ختم الأستاذ محمود حامد" 
                  className="w-20 h-20 object-contain"
                />
              </div>
              <p className="text-sm text-gray-500">هذا الإيصال صادر إلكترونياً ولا يحتاج لتوقيع</p>
              <p className="text-xs text-gray-400 mt-2">
                للاستفسارات: تواصل مع الدعم الفني من خلال التطبيق
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 mt-6 print:hidden">
              <Button
                onClick={handlePrintReceipt}
                variant="outline"
                className="flex-1"
              >
                <Printer className="w-4 h-4 ml-2" />
                طباعة
              </Button>
              <Button
                onClick={() => setShowReceipt(false)}
                className="flex-1"
              >
                إغلاق
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default StudentBooks;
