
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Send, ImagePlus, Volume2, MessageSquare } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface Message {
  id: string;
  from: 'student' | 'support';
  message: string;
  date: string;
  hasImage: boolean;
  image: string;
  supportName?: string;
  support_reply?: string;
  status?: string;
}

const StudentSupport = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [message, setMessage] = useState('');
  const [messageImage, setMessageImage] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    setCurrentStudent(student);

    // إذا كان الطالب محظور، توجيه لصفحة الحظر
    if (student.is_blocked || student.isBlocked) {
      navigate('/student/blocked', { 
        state: { 
          student: student,
          blockReason: student.block_reason || student.blockReason || 'غير محدد',
          blockedAt: student.blocked_at || student.blockedAt
        }
      });
      return;
    }

    loadMessages(student.id);

    // التحقق من وجود رسالة تلقائية مرسلة من صفحة الحظر
    const state = location.state;
    if (state && state.autoMessageSent) {
      toast.success('تم إرسال معلوماتك للدعم الفني، انتظر الرد');
    }
  }, [navigate, location.state]);

  const loadMessages = async (studentId: string) => {
    try {
      setLoading(true);
      console.log('تحميل رسائل الطالب من Supabase:', studentId);
      
      const { data, error } = await supabase
        .from('support_messages_new')
        .select('*')
        .eq('student_id', studentId)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('خطأ في تحميل الرسائل:', error);
        toast.error('فشل في تحميل الرسائل');
        return;
      }

      console.log('الرسائل المحملة من Supabase:', data);
      
      const formattedMessages: Message[] = [];
      
      data?.forEach(msg => {
        // رسالة الطالب
        formattedMessages.push({
          id: msg.id + '_student',
          from: 'student',
          message: msg.message,
          date: msg.created_at,
          hasImage: !!msg.image_url,
          image: msg.image_url || '',
          supportName: ''
        });

        // رد الدعم إذا كان موجوداً
        if (msg.support_reply) {
          formattedMessages.push({
            id: msg.id + '_support',
            from: 'support',
            message: msg.support_reply,
            date: msg.replied_at || msg.created_at,
            hasImage: false,
            image: '',
            supportName: msg.support_name || 'الدعم الفني'
          });
        }
      });
      
      setMessages(formattedMessages);
      console.log('الرسائل المنسقة:', formattedMessages);
    } catch (error) {
      console.error('خطأ عام في تحميل الرسائل:', error);
      toast.error('حدث خطأ في تحميل الرسائل');
    } finally {
      setLoading(false);
    }
  };

  const uploadImage = async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${currentStudent.id}_${Date.now()}.${fileExt}`;
      
      const { data, error } = await supabase.storage
        .from('transfer-receipts')
        .upload(fileName, file);

      if (error) {
        console.error('خطأ في رفع الصورة:', error);
        return null;
      }

      const { data: urlData } = supabase.storage
        .from('transfer-receipts')
        .getPublicUrl(fileName);

      return urlData.publicUrl;
    } catch (error) {
      console.error('خطأ عام في رفع الصورة:', error);
      return null;
    }
  };

  const handleSendMessage = async () => {
    if (!currentStudent) return;
    
    if (!message.trim() && !messageImage) {
      toast.error('يرجى كتابة رسالة أو رفع صورة');
      return;
    }

    try {
      console.log('إرسال رسالة جديدة إلى Supabase:', { message: message.trim(), hasImage: !!messageImage });

      let imageUrl = null;
      if (messageImage) {
        // تحويل base64 إلى ملف
        const response = await fetch(messageImage);
        const blob = await response.blob();
        const file = new File([blob], 'support_image.jpg', { type: 'image/jpeg' });
        imageUrl = await uploadImage(file);
      }

      const { data, error } = await supabase
        .from('support_messages_new')
        .insert([{
          student_id: currentStudent.id,
          student_name: currentStudent.full_name,
          message: message.trim(),
          image_url: imageUrl,
          status: 'pending'
        }])
        .select()
        .single();

      if (error) {
        console.error('خطأ في إرسال الرسالة:', error);
        toast.error('فشل في إرسال الرسالة');
        return;
      }

      console.log('تم إرسال الرسالة بنجاح:', data);
      playMessageSound();
      
      setMessage('');
      setMessageImage('');
      
      toast.success('تم إرسال الرسالة بنجاح');
      
      // إعادة تحميل الرسائل
      loadMessages(currentStudent.id);
      
    } catch (error) {
      console.error('خطأ عام في إرسال الرسالة:', error);
      toast.error('حدث خطأ في إرسال الرسالة');
    }
  };

  const playMessageSound = () => {
    try {
      const audio = new Audio('data:audio/wav;base64,UklGRlIAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACbmZqbmZmZmZqbmZmZmZqbmZmZmZqbmZmZmZqbmZmZmZqbmZmZmZqbmZg==');
      audio.play().catch(() => {
        console.log('تشغيل صوت بديل');
      });
    } catch (error) {
      console.log('تعذر تشغيل الصوت:', error);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setMessageImage(reader.result as string);
        console.log('تم تحميل الصورة');
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`} style={{
      backgroundImage: localStorage.getItem('appBackgroundImage') ? `url(${localStorage.getItem('appBackgroundImage')})` : undefined,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed'
    }}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/student/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">💬 الدعم الفني</h1>
        
        {/* Support Image */}
        <div className="mr-4">
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-blue-400 shadow-lg">
            <img 
              src="/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png" 
              alt="Mr. Mahmoud Hamad" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
        
        <Button 
          onClick={() => currentStudent && loadMessages(currentStudent.id)} 
          variant="outline" 
          size="sm"
          className="mr-2"
        >
          تحديث الرسائل
        </Button>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Chat Messages */}
        <Card className="mb-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
          <div className="p-4 space-y-4 max-h-96 overflow-y-auto">
            {loading ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">جاري تحميل الرسائل...</p>
              </div>
            ) : messages.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>لا توجد رسائل بعد</p>
                <p className="text-sm">ابدأ محادثة مع فريق الدعم</p>
              </div>
            ) : (
              messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.from === 'student' ? 'justify-start' : 'justify-end'}`}>
                  <div className="flex flex-col">
                    {msg.from === 'support' && (
                      <div className="text-xs text-gray-500 dark:text-gray-400 mb-1">
                        {msg.supportName || 'الدعم الفني'}
                      </div>
                    )}
                    <div className={`rounded-xl p-3 max-w-xs break-words ${
                      msg.from === 'student' 
                        ? 'bg-blue-100 dark:bg-blue-900 text-right' 
                        : 'bg-gray-200 dark:bg-gray-700 text-left'
                    }`}>
                      {msg.hasImage && (
                        <img src={msg.image} alt="Message" className="max-w-full h-auto rounded-md mb-2" />
                      )}
                      {msg.message && <div className="mb-1">{msg.message}</div>}
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        {new Date(msg.date).toLocaleTimeString('ar-EG', { 
                          hour: '2-digit', 
                          minute: '2-digit',
                          day: 'numeric',
                          month: 'short'
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Send Message */}
        <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
          <div className="p-4">
            <div className="flex items-end space-x-3">
              <div className="flex-1">
                <Textarea
                  placeholder="اكتب رسالتك هنا..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="resize-none border-none focus-visible:ring-0 shadow-none dark:bg-gray-700 text-right min-h-[60px]"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                />
                {messageImage && (
                  <div className="mt-2 relative">
                    <img src={messageImage} alt="Uploaded" className="max-w-full h-32 rounded-md" />
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute top-1 right-1"
                      onClick={() => setMessageImage('')}
                    >
                      ×
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="flex flex-col space-y-2">
                <label htmlFor="image-upload" className="cursor-pointer">
                  <div className="p-2 bg-blue-500 hover:bg-blue-600 text-white rounded-full transition-colors duration-200">
                    <ImagePlus className="w-5 h-5" />
                  </div>
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                />
                
                <Button 
                  onClick={handleSendMessage} 
                  className="rounded-full"
                  size="icon"
                  disabled={!message.trim() && !messageImage}
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default StudentSupport;
