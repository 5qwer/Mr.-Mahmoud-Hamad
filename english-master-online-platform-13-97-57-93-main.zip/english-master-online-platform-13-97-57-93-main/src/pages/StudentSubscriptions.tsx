
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Calendar, BookOpen, Moon, Sun, Search, Eye } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabaseDataManager } from '@/utils/supabaseDataManager';

interface Subscription {
  id: number;
  title: string;
  description: string;
  price: number;
  duration: string;
  coverImage: string;
  lessons: any[];
  isPurchased: boolean;
  expiryDate?: string;
  grade: string;
}

const StudentSubscriptions = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [backgroundImage, setBackgroundImage] = useState('');
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [studentSubscriptions, setStudentSubscriptions] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const isDark = savedTheme === 'dark';
    setIsDarkMode(isDark);
    document.documentElement.classList.toggle('dark', isDark);
    
    const savedBackground = localStorage.getItem('appBackgroundImage');
    if (savedBackground) {
      setBackgroundImage(savedBackground);
    }
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    console.log('Current student from localStorage:', student);
    
    if (!student) {
      navigate('/student/login');
      return;
    }
    
    setCurrentStudent(student);
    loadSubscriptions(student);
    loadStudentSubscriptions(student);
  }, [navigate]);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', newTheme);
  };

  const loadSubscriptions = async (student: any) => {
    if (!student) return;
    
    setLoading(true);
    console.log('Loading subscriptions for student:', student);
    
    try {
      const availableSubscriptions = await supabaseDataManager.getSubscriptionsByGrade(student.grade);
      console.log('Subscriptions loaded from Supabase:', availableSubscriptions);
      setSubscriptions(availableSubscriptions);
      
      if (availableSubscriptions.length === 0) {
        console.log('No subscriptions found for grade:', student.grade);
        toast.info('لا توجد اشتراكات متاحة لصفك الدراسي حالياً');
      }
    } catch (error) {
      console.error('Error loading subscriptions:', error);
      toast.error('فشل في تحميل الاشتراكات');
    } finally {
      setLoading(false);
    }
  };

  const loadStudentSubscriptions = async (student: any) => {
    if (!student) return;
    
    try {
      const purchasedSubs = await supabaseDataManager.getStudentSubscriptions(student.id);
      console.log('Student subscriptions:', purchasedSubs);
      setStudentSubscriptions(purchasedSubs);
    } catch (error) {
      console.error('Error loading student subscriptions:', error);
    }
  };

  const filteredSubscriptions = subscriptions.filter(subscription => {
    const isPurchased = studentSubscriptions.some(sub => sub.id === subscription.id);
    const matchesSearch = (subscription.title?.toLowerCase() || '').includes(searchQuery.toLowerCase()) ||
                         (subscription.description?.toLowerCase() || '').includes(searchQuery.toLowerCase());
    
    return matchesSearch && { ...subscription, isPurchased };
  }).map(subscription => ({
    ...subscription,
    isPurchased: studentSubscriptions.some(sub => sub.id === subscription.id)
  }));

  const handlePurchaseSubscription = async (subscription: Subscription) => {
    if (!currentStudent || loading) return;
    
    // الحصول على الرصيد الحالي من Supabase
    const updatedStudent = await supabaseDataManager.getStudentById(currentStudent.id);
    if (!updatedStudent) {
      toast.error('فشل في الحصول على بيانات الطالب');
      return;
    }
    
    const currentBalance = updatedStudent.wallet_balance || 0;
    const afterPayment = currentBalance - subscription.price;
    
    // عرض رسالة تأكيد الدفع
    const confirmPayment = window.confirm(`
🛒 تأكيد الاشتراك 

📋 الاشتراك: ${subscription.title}
💰 المبلغ المطلوب: ${subscription.price} جنيه
💳 رصيدك الحالي: ${currentBalance} جنيه
📊 الرصيد بعد الدفع: ${afterPayment} جنيه

${afterPayment < 0 ? '⚠️ رصيدك غير كافي!' : '✅ سيتم خصم المبلغ من محفظتك'}

هل تريد المتابعة؟
    `);
    
    if (!confirmPayment) {
      toast.info('تم إلغاء عملية الشراء');
      return;
    }
    
    setLoading(true);
    console.log('Purchasing subscription:', subscription.id, 'for student:', currentStudent.id);
    
    try {
      if (currentBalance < subscription.price) {
        toast.error('رصيد المحفظة غير كافي. يرجى شحن المحفظة أولاً');
        return;
      }

      // شراء الاشتراك مع خصم المبلغ من Supabase
      const success = await supabaseDataManager.purchaseSubscription(
        currentStudent.id,
        subscription.id
      );
      
      if (!success) {
        toast.error('فشل في شراء الاشتراك');
        return;
      }
      
      // تحديث بيانات الطالب المحلية من Supabase
      const latestStudent = await supabaseDataManager.getStudentById(currentStudent.id);
      if (latestStudent) {
        localStorage.setItem('currentStudent', JSON.stringify(latestStudent));
        setCurrentStudent(latestStudent);
      }
      
      // إعادة تحميل اشتراكات الطالب
      await loadStudentSubscriptions(latestStudent || currentStudent);
      
      await supabaseDataManager.addActivityLog(
        currentStudent.id.toString(),
        'subscription_purchased',
        `تم شراء الاشتراك: ${subscription.title}`
      );
      
      toast.success(`✅ تم شراء الاشتراك بنجاح! تم خصم ${subscription.price} جنيه من محفظتك`);
      console.log('Subscription purchased successfully');
    } catch (error) {
      console.error('Error purchasing subscription:', error);
      toast.error('فشل في شراء الاشتراك');
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (subscription: Subscription) => {
    const isPurchased = studentSubscriptions.some(sub => sub.id === subscription.id);
    if (isPurchased) {
      navigate(`/student/subscription-details/${subscription.id}`);
    } else {
      toast.error('يجب شراء الاشتراك أولاً للوصول إلى التفاصيل');
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}
      style={{
        backgroundImage: backgroundImage ? `url(${backgroundImage})` : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="flex justify-between items-center p-4 animate-fade-in">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/student/dashboard')}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">🧾 الاشتراكات</h1>
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className="rounded-full"
        >
          {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      <div className="container mx-auto px-4 py-8 space-y-6">
        {currentStudent && (
          <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm animate-slide-in`}>
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-bold text-xl">مرحباً {currentStudent.fullName}</h3>
                <p className="text-muted-foreground text-lg">
                  الصف: {currentStudent.grade === '1' ? 'الأول الثانوي العام' : 
                         currentStudent.grade === '2' ? 'الثاني الثانوي العام' : 'الثالث الثانوي العام'}
                </p>
              </div>
              <div className="text-center">
                <p className="text-base text-muted-foreground">رصيد المحفظة</p>
                <p className="text-3xl font-bold text-green-600">{currentStudent.wallet_balance || 0} جنيه</p>
              </div>
            </div>
          </Card>
        )}

        <Card className={`p-4 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm animate-slide-in`}>
          <div className="space-y-2">
            <Label className="text-base font-semibold">البحث في الاشتراكات</Label>
            <div className="relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                placeholder="ابحث عن اشتراك..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="text-right pr-12 text-base"
              />
            </div>
          </div>
        </Card>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">جاري تحميل الاشتراكات...</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {filteredSubscriptions.map((subscription, index) => (
              <Card 
                key={subscription.id} 
                className={`overflow-hidden hover:shadow-xl transition-all duration-500 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm animate-scale-in`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="aspect-video bg-gradient-to-r from-blue-500 to-purple-600 relative">
                  {subscription.coverImage ? (
                    <img 
                      src={subscription.coverImage} 
                      alt={subscription.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center text-white">
                        <BookOpen className="w-16 h-16 mx-auto mb-2" />
                        <h3 className="text-xl font-bold">{subscription.title}</h3>
                      </div>
                    </div>
                  )}
                  <div className="absolute top-2 right-2">
                    {subscription.isPurchased ? (
                      <Badge className="bg-green-500 text-base">نشط</Badge>
                    ) : (
                      <Badge variant="secondary" className="text-base">غير مشترك</Badge>
                    )}
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-3">{subscription.title}</h3>
                  <p className="text-muted-foreground mb-4 text-base leading-relaxed">{subscription.description}</p>
                  
                  <div className="space-y-3 mb-4 text-base">
                    <div className="flex items-center">
                      <Calendar className="w-5 h-5 ml-3 text-blue-500" />
                      <span className="font-semibold">المدة: {subscription.duration} يوم</span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <h4 className="font-bold text-lg mb-3">محتويات الاشتراك:</h4>
                    <div className="space-y-2">
                      <div className="flex items-center text-base">
                        <BookOpen className="w-4 h-4 ml-3 text-blue-500" />
                        <span>عدد الحصص: {subscription.lessons?.length || 0}</span>
                      </div>
                      <div className="flex items-center text-base">
                        <BookOpen className="w-4 h-4 ml-3 text-green-500" />
                        <span>حصص تفاعلية مع امتحانات</span>
                      </div>
                      <div className="flex items-center text-base">
                        <BookOpen className="w-4 h-4 ml-3 text-purple-500" />
                        <span>ملفات PDF وحلول الواجبات</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-2xl font-bold text-green-600">{subscription.price} جنيه</span>
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                    {subscription.isPurchased ? (
                      <>
                        <Button 
                          onClick={() => handleViewDetails(subscription)}
                          className="bg-blue-600 hover:bg-blue-700 text-base font-semibold"
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          عرض التفاصيل والحصص
                        </Button>
                        <Badge variant="outline" className="text-center py-2 text-base">
                          مشترك بالفعل ✓
                        </Badge>
                      </>
                    ) : (
                      <Button 
                        onClick={() => handlePurchaseSubscription(subscription)} 
                        className="bg-blue-600 hover:bg-blue-700 text-base font-semibold"
                        disabled={loading}
                      >
                        {loading ? 'جاري الاشتراك...' : 'اشترك الآن'}
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {filteredSubscriptions.length === 0 && !loading && (
          <div className="text-center py-12 animate-fade-in">
            <Card className={`p-8 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
              <p className="text-muted-foreground text-xl">
                {searchQuery ? 
                  `لا توجد اشتراكات تحتوي على "${searchQuery}"` : 
                  'لا توجد اشتراكات متاحة لصفك الدراسي حالياً'
                }
              </p>
              <p className="text-base mt-2">تواصل مع المعلم لإضافة المزيد من الاشتراكات</p>
            </Card>
          </div>
        )}

        {/* عرض الاشتراكات المشتراة */}
        {studentSubscriptions.length > 0 && (
          <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm animate-slide-in`}>
            <h2 className="text-2xl font-bold mb-6">📚 اشتراكاتي</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {studentSubscriptions.map((subscription, index) => (
                <Card 
                  key={subscription.id} 
                  className={`overflow-hidden ${isDarkMode ? 'bg-gray-700/50' : 'bg-white'} border-green-200`}
                >
                  <div className="aspect-video bg-gradient-to-r from-green-500 to-blue-600 relative">
                    {subscription.coverImage ? (
                      <img 
                        src={subscription.coverImage} 
                        alt={subscription.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <BookOpen className="w-16 h-16 text-white/80" />
                      </div>
                    )}
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-green-500">نشط</Badge>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <h3 className="font-bold text-lg mb-2">{subscription.title}</h3>
                    <p className="text-muted-foreground text-sm mb-3">{subscription.description}</p>
                    
                    <div className="space-y-2 mb-4 text-sm">
                      <div className="flex justify-between">
                        <span>عدد الحصص:</span>
                        <span className="font-bold">{subscription.lessons?.length || 0}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>تاريخ الشراء:</span>
                        <span className="font-bold text-green-600">
                          {new Date(subscription.purchasedAt).toLocaleDateString('ar-EG')}
                        </span>
                      </div>
                    </div>
                    
                    <Button 
                      onClick={() => navigate(`/student/subscription-details/${subscription.id}`)}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      عرض الحصص
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default StudentSubscriptions;
