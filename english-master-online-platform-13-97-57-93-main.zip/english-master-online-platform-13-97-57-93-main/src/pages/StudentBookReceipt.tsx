
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, CheckCircle, Calendar, MapPin, User, Phone, Printer } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { dataManager } from '@/utils/dataManager';

const StudentBookReceipt = () => {
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [book, setBook] = useState<any>(null);
  const [receiptData, setReceiptData] = useState<any>(null);
  const navigate = useNavigate();
  const { bookId } = useParams();

  useEffect(() => {
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    setCurrentStudent(student);
    
    // Load book details
    const allBooks = dataManager.getBooks();
    const foundBook = allBooks.find(b => b.id === bookId);
    if (!foundBook) {
      navigate('/student/books');
      return;
    }
    setBook(foundBook);
    
    // إنشاء بيانات الإيصال
    const now = new Date();
    const receipt = {
      receiptNumber: `REC-${Date.now()}`,
      bookingDate: now.toLocaleDateString('ar-EG'),
      bookingTime: now.toLocaleTimeString('ar-EG'),
      deliveryDate: new Date(now.getTime() + 24 * 60 * 60 * 1000).toLocaleDateString('ar-EG'), // غداً
      amount: 50
    };
    setReceiptData(receipt);
  }, [bookId, navigate]);

  const handlePrint = () => {
    window.print();
  };

  if (!book || !currentStudent || !receiptData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <CheckCircle className="w-16 h-16 mx-auto mb-4 animate-pulse text-green-500" />
          <p className="text-lg">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      <div className="flex items-center justify-between p-4 print:hidden">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/student/dashboard')}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">🎉 تم حجز الكتاب بنجاح</h1>
        </div>
        <Button onClick={handlePrint} variant="outline" className="flex items-center">
          <Printer className="w-4 h-4 ml-2" />
          طباعة
        </Button>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* إيصال الحجز */}
        <Card className="max-w-2xl mx-auto p-8 bg-white shadow-2xl">
          {/* الختم والشعار */}
          <div className="text-center mb-8 relative">
            <div className="absolute top-0 right-0 opacity-30">
              <img 
                src="/lovable-uploads/d210bf9c-1ff3-4adc-aed6-1016a16dd585.png" 
                alt="ختم الأستاذ محمود حامد" 
                className="w-32 h-32 object-contain"
              />
            </div>
            <h1 className="text-3xl font-bold text-blue-600 mb-2">إيصال حجز كتاب</h1>
            <p className="text-lg text-gray-600">الأستاذ محمود حامد - مدرس اللغة الإنجليزية</p>
            <div className="w-full h-1 bg-gradient-to-r from-blue-500 to-green-500 mt-4"></div>
          </div>

          {/* معلومات الإيصال */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="space-y-3">
              <h3 className="font-bold text-lg text-blue-600 flex items-center">
                <User className="w-5 h-5 ml-2" />
                بيانات الطالب
              </h3>
              <div className="bg-blue-50 p-4 rounded-lg space-y-2">
                <p><span className="font-medium">الاسم:</span> {currentStudent.fullName}</p>
                <p><span className="font-medium">الرقم الطلابي:</span> {currentStudent.studentNumber}</p>
                <p><span className="font-medium">رقم ولي الأمر:</span> {currentStudent.parentNumber}</p>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-bold text-lg text-blue-600 flex items-center">
                <Calendar className="w-5 h-5 ml-2" />
                تفاصيل الحجز
              </h3>
              <div className="bg-green-50 p-4 rounded-lg space-y-2">
                <p><span className="font-medium">رقم الإيصال:</span> {receiptData.receiptNumber}</p>
                <p><span className="font-medium">تاريخ الحجز:</span> {receiptData.bookingDate}</p>
                <p><span className="font-medium">وقت الحجز:</span> {receiptData.bookingTime}</p>
                <p><span className="font-medium">تاريخ الاستلام المتوقع:</span> {receiptData.deliveryDate}</p>
              </div>
            </div>
          </div>

          {/* تفاصيل الكتاب */}
          <div className="mb-8">
            <h3 className="font-bold text-lg text-blue-600 mb-4">تفاصيل الكتاب</h3>
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-start gap-4">
                {book.coverImage ? (
                  <img
                    src={book.coverImage}
                    alt={book.title}
                    className="w-24 h-32 object-cover rounded-lg"
                  />
                ) : (
                  <div className="w-24 h-32 bg-blue-100 rounded-lg flex items-center justify-center">
                    <CheckCircle className="w-8 h-8 text-blue-500" />
                  </div>
                )}
                <div className="flex-1">
                  <h4 className="font-bold text-xl mb-2">{book.title}</h4>
                  <p className="text-gray-600 mb-1">{book.subject}</p>
                  <p className="text-sm text-gray-500 mb-3">
                    {book.grade === '1' ? 'الأول الثانوي' : 
                     book.grade === '2' ? 'الثاني الثانوي' : 
                     book.grade === '3' ? 'الثالث الثانوي' : book.grade}
                  </p>
                  <div className="text-right">
                    <span className="text-2xl font-bold text-green-600">{receiptData.amount} جنيه</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* مكان الاستلام */}
          <div className="mb-8">
            <h3 className="font-bold text-lg text-blue-600 flex items-center mb-4">
              <MapPin className="w-5 h-5 ml-2" />
              مكان الاستلام
            </h3>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <p className="font-medium mb-2">مكتب الأستاذ محمود حامد</p>
              <p className="text-sm text-gray-600 mb-1">شارع الجامعة، مبنى التعليم، الدور الثاني</p>
              <p className="text-sm text-gray-600 mb-1">أوقات الاستلام: يومياً من 9 صباحاً إلى 5 مساءً</p>
              <p className="text-sm font-medium text-red-600">⚠️ يرجى إحضار هذا الإيصال والهوية الطلابية عند الاستلام</p>
            </div>
          </div>

          {/* الختم النهائي */}
          <div className="text-center border-t pt-6">
            <div className="flex justify-center items-center mb-4">
              <img 
                src="/lovable-uploads/d210bf9c-1ff3-4adc-aed6-1016a16dd585.png" 
                alt="ختم الأستاذ محمود حامد" 
                className="w-20 h-20 object-contain"
              />
            </div>
            <p className="text-sm text-gray-500">هذا الإيصال صادر إلكترونياً ولا يحتاج لتوقيع</p>
            <p className="text-xs text-gray-400 mt-2">
              للاستفسارات: تواصل مع الدعم الفني من خلال التطبيق
            </p>
          </div>
        </Card>

        {/* أزرار العمليات */}
        <div className="max-w-2xl mx-auto mt-6 print:hidden">
          <div className="flex gap-4">
            <Button
              onClick={() => navigate('/student/dashboard')}
              className="flex-1"
            >
              العودة للوحة التحكم
            </Button>
            <Button
              onClick={() => navigate('/student/books')}
              variant="outline"
              className="flex-1"
            >
              تصفح المزيد من الكتب
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentBookReceipt;
