import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Book, MapPin, User, Phone, CreditCard } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { supabaseDataManager } from '@/utils/supabaseDataManager';

const StudentBookDetails = () => {
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [book, setBook] = useState<any>(null);
  const [showPaymentConfirm, setShowPaymentConfirm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(false);
  const navigate = useNavigate();
  const { bookId } = useParams();

  useEffect(() => {
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    setCurrentStudent(student);
    
    loadBookDetails();
  }, [bookId, navigate]);

  const loadBookDetails = async () => {
    try {
      const { data, error } = await supabase
        .from('available_books')
        .select('*')
        .eq('id', bookId)
        .single();

      if (error) {
        console.error('خطأ في تحميل تفاصيل الكتاب:', error);
        toast.error('الكتاب غير موجود');
        navigate('/student/books');
        return;
      }

      setBook(data);
      setLoading(false);
    } catch (error) {
      console.error('خطأ في تحميل الكتاب:', error);
      toast.error('فشل في تحميل تفاصيل الكتاب');
      navigate('/student/books');
    }
  };


  const handlePayment = async () => {
    if (!currentStudent || !book || purchasing) return;
    
    setPurchasing(true);
    
    try {
      // التحقق من البيانات المطلوبة قبل المتابعة
      if (!currentStudent.id || !currentStudent.full_name) {
        toast.error('خطأ في بيانات الطالب، يرجى تسجيل الدخول مرة أخرى');
        setPurchasing(false);
        return;
      }

      console.log('بيانات الطالب للحجز:', {
        student_id: currentStudent.id,
        student_name: currentStudent.full_name,
        student_grade: currentStudent.grade
      });

      // الحصول على الرصيد الحالي من Supabase
      const updatedStudent = await supabaseDataManager.getStudentById(currentStudent.id);
      if (!updatedStudent) {
        toast.error('فشل في الحصول على بيانات الطالب');
        setPurchasing(false);
        return;
      }
      
      const currentBalance = updatedStudent.wallet_balance || 0;
      const bookPrice = book.price;
      
      if (currentBalance < bookPrice) {
        toast.error('رصيد المحفظة غير كافي');
        setPurchasing(false);
        return;
      }

      // إنشاء طلب حجز الكتاب أولاً قبل خصم المبلغ
      const { data: reservationData, error: reservationError } = await supabase
        .from('book_reservations')
        .insert([{
          student_id: currentStudent.id,
          student_name: currentStudent.full_name, // استخدام full_name بدلاً من fullName
          student_grade: currentStudent.grade || '1',
          book_title: book.title,
          book_subject: book.subject || 'عام',
          book_grade: book.grade,
          book_price: book.price,
          pickup_location: book.pickup_location,
          status: 'pending'
        }])
        .select()
        .single();

      if (reservationError) {
        console.error('خطأ في إنشاء طلب الحجز:', reservationError);
        toast.error('فشل في إنشاء طلب الحجز');
        setPurchasing(false);
        return;
      }

      console.log('تم إنشاء طلب الحجز بنجاح:', reservationData);
      
      // خصم المبلغ من رصيد الطالب بعد نجاح إنشاء الطلب
      const success = await supabaseDataManager.deductStudentBalance(
        currentStudent.id,
        bookPrice,
        `حجز كتاب: ${book.title}`
      );
      
      if (!success) {
        // إذا فشل خصم المبلغ، نحذف طلب الحجز
        await supabase
          .from('book_reservations')
          .delete()
          .eq('id', reservationData.id);
        
        toast.error('فشل في خصم المبلغ من الرصيد');
        setPurchasing(false);
        return;
      }
      
      // تحديث بيانات الطالب المحلية من Supabase
      const latestStudent = await supabaseDataManager.getStudentById(currentStudent.id);
      if (latestStudent) {
        localStorage.setItem('currentStudent', JSON.stringify(latestStudent));
        setCurrentStudent(latestStudent);
      }
      
      // إضافة سجل النشاط
      await supabaseDataManager.addActivityLog(currentStudent.id, 'book_purchase', `تم حجز كتاب: ${book.title}`);
      
      // إرسال إشعار
      await supabaseDataManager.addNotification(
        currentStudent.id, 
        'book_purchase', 
        `تم حجز كتاب "${book.title}" بنجاح. سيتم التواصل معك قريباً لتحديد موعد الاستلام.`
      );
      
      toast.success('تم حجز الكتاب بنجاح! 🎉');
      toast.success('تم إرسال طلب الحجز للدعم الفني');
      
      // العودة إلى صفحة الكتب مع إعادة تحميل الحالة
      navigate('/student/books', { replace: true });
      
    } catch (error) {
      console.error('Error during book purchase:', error);
      toast.error('حدث خطأ أثناء حجز الكتاب');
    } finally {
      setPurchasing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Book className="w-16 h-16 mx-auto mb-4 animate-pulse text-blue-500" />
          <p className="text-lg">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Book className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <p className="text-lg">الكتاب غير موجود</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/student/books')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">📖 تفاصيل الكتاب</h1>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-2xl mx-auto p-6">
          {/* صورة الكتاب والمعلومات الأساسية */}
          <div className="text-center mb-6">
            {book.cover_image ? (
              <img
                src={book.cover_image}
                alt={book.title}
                className="w-48 h-64 object-cover rounded-lg mx-auto mb-4 shadow-lg"
              />
            ) : (
              <div className="w-48 h-64 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg mx-auto mb-4 flex items-center justify-center shadow-lg">
                <Book className="w-24 h-24 text-blue-500" />
              </div>
            )}
            
            <h2 className="text-2xl font-bold mb-2">{book.title}</h2>
            <p className="text-lg text-blue-600 mb-2">{book.subject}</p>
            <p className="text-sm text-muted-foreground">
              {book.grade === '1' ? 'الأول الثانوي' : 
               book.grade === '2' ? 'الثاني الثانوي' : 
               book.grade === '3' ? 'الثالث الثانوي' : book.grade}
            </p>
          </div>

          {/* وصف الكتاب */}
          {book.description && (
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <h3 className="font-bold mb-2">وصف الكتاب</h3>
              <p className="text-gray-700">{book.description}</p>
            </div>
          )}

          {/* بيانات الطالب */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <h3 className="font-bold mb-3 flex items-center">
              <User className="w-5 h-5 ml-2" />
              بيانات الطالب
            </h3>
            <div className="space-y-2 text-sm">
              <p><span className="font-medium">الرقم الطلابي:</span> {currentStudent?.student_number}</p>
              <p><span className="font-medium">اسم الطالب:</span> {currentStudent?.full_name}</p>
              <p><span className="font-medium">رقم ولي الأمر:</span> {currentStudent?.parent_number}</p>
            </div>
          </div>

          {/* تفاصيل الاستلام */}
          <div className="bg-blue-50 rounded-lg p-4 mb-6">
            <h3 className="font-bold mb-3 flex items-center">
              <MapPin className="w-5 h-5 ml-2" />
              تفاصيل الاستلام
            </h3>
            <div className="space-y-2 text-sm">
              <p><span className="font-medium">المكان:</span> {book.pickup_location}</p>
              <p><span className="font-medium">الفئة:</span> {book.category === 'unlimited' ? 'غير محدودة' : `محدودة (${book.duration} يوم)`}</p>
              <p><span className="font-medium">ملاحظة:</span> يرجى إحضار الهوية الطلابية عند الاستلام</p>
            </div>
          </div>

          {/* السعر والدفع */}
          <div className="bg-green-50 rounded-lg p-4 mb-6">
            <div className="flex justify-between items-center mb-4">
              <span className="text-lg font-bold">سعر الكتاب:</span>
              <span className="text-2xl font-bold text-green-600">{book.price} جنيه</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span>رصيد المحفظة الحالي:</span>
              <span className={`font-bold ${(currentStudent?.wallet_balance || 0) >= book.price ? 'text-green-600' : 'text-red-600'}`}>
                {currentStudent?.wallet_balance || 0} جنيه
              </span>
            </div>
          </div>


          {/* أزرار العمليات */}
          <div className="space-y-3">
            {(currentStudent?.wallet_balance || 0) >= book.price ? (
              <Button
                onClick={() => setShowPaymentConfirm(true)}
                className="w-full bg-green-500 hover:bg-green-600 text-lg py-3"
                disabled={purchasing}
              >
                <CreditCard className="w-5 h-5 ml-2" />
                {purchasing ? 'جاري الحجز...' : 'حجز الكتاب الآن'}
              </Button>
            ) : (
              <div className="text-center">
                <p className="text-red-600 mb-3">رصيد المحفظة غير كافي</p>
                <Button
                  onClick={() => navigate('/student/wallet')}
                  variant="outline"
                  className="w-full"
                >
                  شحن المحفظة
                </Button>
              </div>
            )}
          </div>
        </Card>

        {/* نافذة تأكيد الدفع */}
        {showPaymentConfirm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <Card className="max-w-md mx-4 p-6">
              <h3 className="text-xl font-bold mb-4 text-center">تأكيد حجز الكتاب</h3>
              <div className="space-y-3 mb-6">
                <p><span className="font-medium">الكتاب:</span> {book.title}</p>
                <p><span className="font-medium">السعر:</span> {book.price} جنيه</p>
                <p><span className="font-medium">سيتم خصم:</span> {book.price} جنيه من محفظتك</p>
                <p><span className="font-medium">الرصيد بعد الخصم:</span> {(currentStudent?.wallet_balance || 0) - book.price} جنيه</p>
              </div>
              <div className="flex gap-3">
                <Button
                  onClick={handlePayment}
                  className="flex-1 bg-green-500 hover:bg-green-600"
                  disabled={purchasing}
                >
                  {purchasing ? 'جاري التأكيد...' : 'تأكيد الحجز'}
                </Button>
                <Button
                  onClick={() => setShowPaymentConfirm(false)}
                  variant="outline"
                  className="flex-1"
                  disabled={purchasing}
                >
                  إلغاء
                </Button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentBookDetails;
