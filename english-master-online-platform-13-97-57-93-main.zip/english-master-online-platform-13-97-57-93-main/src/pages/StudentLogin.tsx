
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { playWelcomeSound } from '@/utils/welcomeSound';
import { supabaseDataManager } from '@/utils/supabaseDataManager';

const StudentLogin = () => {
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      console.log('محاولة تسجيل دخول الطالب:', { fullName, password });
      
      const student = await supabaseDataManager.authenticateStudent(fullName.trim(), password.trim());
      
      if (!student) {
        console.log('بيانات الدخول غير صحيحة');
        toast.error('بيانات الدخول غير صحيحة');
        return;
      }

      console.log('تم العثور على الطالب:', student);

      if (student.isBlocked) {
        // عرض شاشة الحظر مع إمكانية التواصل مع الدعم
        navigate('/student/blocked', { 
          state: { 
            student: student,
            blockReason: student.blockReason || 'غير محدد',
            blockedAt: student.blocked_at || student.blockedAt
          }
        });
        return;
      }

      // إنشاء جلسة جديدة للطالب
      const sessionResult = await supabaseDataManager.createStudentSession(student.id);
      if (!sessionResult.success) {
        toast.error('فشل في إنشاء جلسة تسجيل الدخول');
        return;
      }

      localStorage.setItem('currentStudent', JSON.stringify(student));
      
      try {
        playWelcomeSound();
      } catch (error) {
        console.log('تعذر تشغيل صوت الترحيب:', error);
      }
      
      await supabaseDataManager.addActivityLog(student.id, 'login', 'تسجيل دخول الطالب');
      
      toast.success(`🎉 أهلاً وسهلاً ${student.fullName}! أذكر الله`);
      navigate('/student/dashboard');
    } catch (error: any) {
      console.error('خطأ في تسجيل الدخول:', error);
      if (error.message) {
        toast.error(error.message);
      } else {
        toast.error('حدث خطأ في تسجيل الدخول');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // إضافة تحديث نشاط الجلسة عند التفاعل مع الصفحة - المدة صفر ثانية  
  const handlePageActivity = () => {
    const sessionToken = localStorage.getItem('student_session_token');
    if (sessionToken) {
      // إنهاء الجلسة فوراً (مدة زمنية صفر ثانية)
      supabaseDataManager.endStudentSession();
    }
  };

  // إضافة listener لتحديث نشاط الجلسة
  useState(() => {
    const events = ['click', 'keypress', 'scroll', 'mousemove'];
    events.forEach(event => {
      document.addEventListener(event, handlePageActivity);
    });

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, handlePageActivity);
      });
    };
  });

  // إنهاء الجلسة عند إغلاق النافذة أو الخروج
  useState(() => {
    const handleBeforeUnload = () => {
      supabaseDataManager.endStudentSession();
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  });

  return (
    <div className="min-h-screen page-transition relative overflow-hidden bg-gradient-to-br from-indigo-900 via-blue-800 via-purple-900 via-pink-800 to-orange-900 dark:from-gray-900 dark:via-blue-900 dark:to-purple-900 flex items-center justify-center p-4">
      {/* Enhanced Magical Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 left-10 w-96 h-96 bg-gradient-to-r from-cyan-400/30 to-blue-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float"></div>
        <div className="absolute top-1/2 right-10 w-80 h-80 bg-gradient-to-r from-purple-400/30 to-pink-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-10 left-1/3 w-72 h-72 bg-gradient-to-r from-yellow-400/30 to-orange-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/4 left-1/2 w-64 h-64 bg-gradient-to-r from-emerald-400/30 to-teal-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float" style={{animationDelay: '0.5s'}}></div>
        
        {/* Floating Academic Icons */}
        <div className="absolute top-20 left-20 text-6xl text-yellow-300/40 animate-bounce transform rotate-12">📚</div>
        <div className="absolute top-32 right-32 text-5xl text-blue-300/40 animate-pulse transform -rotate-12">🎓</div>
        <div className="absolute bottom-40 left-16 text-4xl text-green-300/35 animate-float transform rotate-45">⭐</div>
        <div className="absolute top-1/2 right-20 text-5xl text-purple-300/30 animate-float">✨</div>
        <div className="absolute bottom-20 right-1/4 text-4xl text-pink-300/35 animate-bounce">🌟</div>
      </div>

      <form 
        onSubmit={handleLogin} 
        className="relative z-10 beautiful-card p-12 w-full max-w-lg animate-fade-in hover-lift pulse-glow"
        style={{
          background: 'linear-gradient(145deg, rgba(255,255,255,0.15), rgba(255,255,255,0.05))',
          backdropFilter: 'blur(30px)',
          border: '2px solid rgba(255,255,255,0.3)',
          boxShadow: '0 25px 50px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.3)'
        }}
      >
        <div className="text-center mb-10">
          <div className="relative mb-6">
            <div className="absolute -inset-3 bg-gradient-to-r from-cyan-500 via-blue-500 via-purple-500 to-pink-500 rounded-full blur-lg opacity-75 animate-pulse"></div>
            <div className="relative w-24 h-24 mx-auto bg-gradient-to-r from-cyan-500 via-blue-500 via-purple-500 to-pink-500 rounded-full flex items-center justify-center animate-float shadow-2xl">
              <span className="text-5xl">🎓</span>
            </div>
          </div>
          <h2 className="text-4xl font-bold gradient-text mb-4 animate-fade-in">
            🌟 تسجيل دخول الطالب المتميز 🌟
          </h2>
          <p className="text-white/80 text-xl font-medium animate-fade-in" style={{animationDelay: '0.2s'}}>
            ✨ مرحباً بك في رحلة التعلم الممتعة ✨
          </p>
        </div>
        
        <div className="mb-8 animate-fade-in" style={{animationDelay: '0.1s'}}>
          <Label htmlFor="fullName" className="block mb-3 text-right font-bold text-white text-lg flex items-center justify-end gap-2">
            <span>👤 الاسم الرباعي الكريم</span>
          </Label>
          <div className="relative">
            <Input
              id="fullName"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="أدخل اسمك الرباعي المبارك"
              required
              className="text-right py-4 px-6 text-lg rounded-2xl border-3 border-cyan-300/50 focus:border-cyan-400 beautiful-card animate-3d bg-white/10 backdrop-blur-sm text-white placeholder-white/60 shadow-xl"
              disabled={isLoading}
              style={{
                background: 'linear-gradient(145deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))',
                backdropFilter: 'blur(10px)'
              }}
            />
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-cyan-300 text-xl">👨‍🎓</div>
          </div>
        </div>

        <div className="mb-10 animate-fade-in" style={{animationDelay: '0.2s'}}>
          <Label htmlFor="password" className="block mb-3 text-right font-bold text-white text-lg flex items-center justify-end gap-2">
            <span>🔐 كلمة المرور السرية</span>
          </Label>
          <div className="relative">
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="أدخل كلمة المرور المقدسة"
              required
              className="text-right py-4 px-6 text-lg rounded-2xl border-3 border-purple-300/50 focus:border-purple-400 beautiful-card animate-3d bg-white/10 backdrop-blur-sm text-white placeholder-white/60 shadow-xl"
              disabled={isLoading}
              style={{
                background: 'linear-gradient(145deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))',
                backdropFilter: 'blur(10px)'
              }}
            />
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-purple-300 text-xl">🗝️</div>
          </div>
        </div>

        <Button 
          type="submit" 
          className="w-full py-5 text-xl font-bold bg-gradient-to-r from-cyan-500 via-blue-500 via-purple-500 to-pink-500 hover:from-cyan-600 hover:via-blue-600 hover:via-purple-600 hover:to-pink-600 shadow-2xl hover:shadow-3xl transform hover:scale-105 hover-lift animate-3d rounded-2xl border-2 border-white/30" 
          disabled={isLoading}
          style={{
            background: 'linear-gradient(135deg, #06b6d4, #3b82f6, #8b5cf6, #ec4899)',
            boxShadow: '0 20px 40px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.3)'
          }}
        >
          {isLoading ? (
            <>
              <div className="animate-spin rounded-full h-6 w-6 border-b-3 border-white mr-3"></div>
              ⏳ جاري الدخول إلى عالم المعرفة...
            </>
          ) : (
            <>
              <span className="mr-3 text-2xl">🚀</span>
              دخول القلعة التعليمية
              <span className="ml-3 text-2xl">✨</span>
            </>
          )}
        </Button>

        <div className="mt-10 p-8 beautiful-card animate-fade-in hover-lift rounded-2xl" style={{animationDelay: '0.4s', background: 'linear-gradient(145deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))', backdropFilter: 'blur(15px)'}}>
          <h3 className="font-bold text-yellow-300 mb-4 text-center text-xl flex items-center justify-center gap-2">
            <span>🎯</span>
            بيانات تجريبية للاستكشاف
            <span>🎯</span>
          </h3>
          <div className="text-sm text-white/90 space-y-3">
            <div className="p-3 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-xl border border-cyan-300/30">
              <p className="flex items-center gap-2"><span>👤</span> الاسم: أحمد محمد علي</p>
              <p className="flex items-center gap-2"><span>🔑</span> كلمة المرور: 123456</p>
            </div>
            <div className="p-3 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl border border-purple-300/30">
              <p className="flex items-center gap-2"><span>👤</span> الاسم: فاطمة سعد محمود</p>
              <p className="flex items-center gap-2"><span>🔑</span> كلمة المرور: 789012</p>
            </div>
            <div className="p-3 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 rounded-xl border border-emerald-300/30">
              <p className="flex items-center gap-2"><span>👤</span> الاسم: محمد أحمد حسن</p>
              <p className="flex items-center gap-2"><span>🔑</span> كلمة المرور: 456789</p>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default StudentLogin;
