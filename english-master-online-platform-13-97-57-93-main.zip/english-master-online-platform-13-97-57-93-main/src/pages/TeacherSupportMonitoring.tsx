
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ArrowLeft, UserPlus, UserX, Eye, Activity, MessageCircle, Send } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface SupportMember {
  id: string;
  name: string;
  code: string;
  online: boolean;
  last_login: string | null;
  last_logout: string | null;
  created_at: string;
}

interface SupportMessage {
  id: string;
  student_id: string;
  student_name: string;
  message: string;
  image_url: string | null;
  support_reply: string | null;
  support_name: string | null;
  status: string;
  created_at: string;
  replied_at: string | null;
  updated_at: string;
}

const TeacherSupportMonitoring = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [supportList, setSupportList] = useState<SupportMember[]>([]);
  const [supportMessages, setSupportMessages] = useState<SupportMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [messagesLoading, setMessagesLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState<SupportMessage | null>(null);
  const [replyText, setReplyText] = useState('');
  const [newSupport, setNewSupport] = useState({
    name: '',
    code: ''
  });
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    loadSupportMembers();
    loadSupportMessages();
  }, []);

  const loadSupportMembers = async () => {
    try {
      const { data, error } = await supabase
        .from('support_team')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في جلب أعضاء الدعم:', error);
        toast.error('فشل في تحميل قائمة الدعم');
        return;
      }

      setSupportList(data || []);
    } catch (error) {
      console.error('خطأ عام في تحميل الدعم:', error);
      toast.error('حدث خطأ في تحميل البيانات');
    } finally {
      setLoading(false);
    }
  };

  const loadSupportMessages = async () => {
    try {
      setMessagesLoading(true);
      const { data, error } = await supabase
        .from('support_messages_new')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في جلب رسائل الدعم:', error);
        toast.error('فشل في تحميل الرسائل');
        return;
      }

      setSupportMessages(data || []);
    } catch (error) {
      console.error('خطأ عام في تحميل الرسائل:', error);
      toast.error('حدث خطأ في تحميل الرسائل');
    } finally {
      setMessagesLoading(false);
    }
  };

  const handleAddSupport = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newSupport.name || !newSupport.code) {
      toast.error('يرجى ملء جميع الحقول');
      return;
    }

    try {
      const { error } = await supabase
        .from('support_team')
        .insert([{
          name: newSupport.name.trim(),
          code: newSupport.code.trim(),
          online: false
        }]);

      if (error) {
        console.error('خطأ في إضافة عضو الدعم:', error);
        if (error.code === '23505') {
          toast.error('يوجد عضو دعم بنفس الكود بالفعل');
        } else {
          toast.error('فشل في إضافة عضو الدعم');
        }
        return;
      }

      setNewSupport({ name: '', code: '' });
      toast.success('تم إضافة عضو الدعم بنجاح');
      loadSupportMembers();
    } catch (error) {
      console.error('خطأ عام في إضافة الدعم:', error);
      toast.error('حدث خطأ غير متوقع');
    }
  };

  const handleRemoveSupport = async (supportId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا العضو؟')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('support_team')
        .delete()
        .eq('id', supportId);

      if (error) {
        console.error('خطأ في حذف عضو الدعم:', error);
        toast.error('فشل في حذف عضو الدعم');
        return;
      }

      toast.success('تم حذف عضو الدعم');
      loadSupportMembers();
    } catch (error) {
      console.error('خطأ عام في حذف الدعم:', error);
      toast.error('حدث خطأ في الحذف');
    }
  };

  const handleToggleStatus = async (supportId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('support_team')
        .update({ online: !currentStatus })
        .eq('id', supportId);

      if (error) {
        console.error('خطأ في تحديث حالة الدعم:', error);
        toast.error('فشل في تحديث الحالة');
        return;
      }

      toast.success('تم تحديث حالة عضو الدعم');
      loadSupportMembers();
    } catch (error) {
      console.error('خطأ عام في تحديث الحالة:', error);
      toast.error('حدث خطأ في التحديث');
    }
  };

  const handleReplyToMessage = async () => {
    if (!selectedMessage || !replyText.trim()) {
      toast.error('يرجى كتابة رد');
      return;
    }

    try {
      const { error } = await supabase
        .from('support_messages_new')
        .update({
          support_reply: replyText.trim(),
          support_name: 'الأستاذ محمود حامد',
          status: 'replied',
          replied_at: new Date().toISOString()
        })
        .eq('id', selectedMessage.id);

      if (error) {
        console.error('خطأ في الرد على الرسالة:', error);
        toast.error('فشل في إرسال الرد');
        return;
      }

      toast.success('تم إرسال الرد بنجاح');
      setReplyText('');
      setSelectedMessage(null);
      loadSupportMessages();
    } catch (error) {
      console.error('خطأ عام في الرد:', error);
      toast.error('حدث خطأ في الرد');
    }
  };

  const formatDateTime = (dateString: string | null) => {
    if (!dateString) return 'لم يسجل بعد';
    return new Date(dateString).toLocaleString('ar-EG', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="destructive">في الانتظار</Badge>;
      case 'replied':
        return <Badge variant="default" className="bg-green-500">تم الرد</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/teacher/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">👀 مراقبة الدعم الفني</h1>
      </div>

      <div className="container mx-auto px-4 py-8 space-y-6">
        {/* Add New Support */}
        <Card className="p-6">
          <h2 className="text-lg font-bold mb-4 flex items-center">
            <UserPlus className="w-5 h-5 ml-2" />
            إضافة عضو دعم جديد
          </h2>
          <form onSubmit={handleAddSupport} className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">الاسم الثلاثي</Label>
              <Input
                id="name"
                value={newSupport.name}
                onChange={(e) => setNewSupport({...newSupport, name: e.target.value})}
                placeholder="أدخل الاسم الثلاثي"
                className="text-right"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="code">كود الدخول</Label>
              <Input
                id="code"
                type="password"
                value={newSupport.code}
                onChange={(e) => setNewSupport({...newSupport, code: e.target.value})}
                placeholder="أدخل كود الدخول"
                className="text-right"
              />
            </div>
            <div className="flex items-end">
              <Button type="submit" className="w-full">
                <UserPlus className="w-4 h-4 ml-2" />
                إضافة عضو الدعم
              </Button>
            </div>
          </form>
        </Card>

        {/* Support Team Overview */}
        <Card className="p-6">
          <h2 className="text-lg font-bold mb-4 flex items-center">
            <Activity className="w-5 h-5 ml-2" />
            فريق الدعم الفني
            <Badge variant="secondary" className="mr-2">
              {supportList.length} عضو
            </Badge>
            <Badge variant="default" className="mr-2 bg-green-500">
              {supportList.filter(s => s.online).length} متصل
            </Badge>
          </h2>
          
          {loading ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">جاري التحميل...</p>
            </div>
          ) : supportList.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">لا يوجد أعضاء دعم فني حالياً</p>
              <p className="text-sm text-muted-foreground mt-2">استخدم النموذج أعلاه لإضافة عضو جديد</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">الاسم</TableHead>
                  <TableHead className="text-right">الكود</TableHead>
                  <TableHead className="text-right">الحالة</TableHead>
                  <TableHead className="text-right">آخر دخول</TableHead>
                  <TableHead className="text-right">آخر خروج</TableHead>
                  <TableHead className="text-right">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {supportList.map((support) => (
                  <TableRow key={support.id}>
                    <TableCell className="font-medium">{support.name}</TableCell>
                    <TableCell>
                      <span className="font-mono text-sm bg-gray-100 px-2 py-1 rounded">
                        {support.code.substring(0, 3)}***
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant={support.online ? 'default' : 'outline'} 
                             className={support.online ? 'bg-green-500 hover:bg-green-600' : ''}>
                        {support.online ? '🟢 متصل' : '🔴 غير متصل'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      {formatDateTime(support.last_login)}
                    </TableCell>
                    <TableCell className="text-sm">
                      {formatDateTime(support.last_logout)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleToggleStatus(support.id, support.online)}
                          title={support.online ? 'قطع الاتصال' : 'تفعيل الاتصال'}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleRemoveSupport(support.id)}
                          title="حذف عضو الدعم"
                        >
                          <UserX className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Card>

        {/* Support Messages */}
        <Card className="p-6">
          <h2 className="text-lg font-bold mb-4 flex items-center">
            <MessageCircle className="w-5 h-5 ml-2" />
            رسائل الدعم الفني
            <Badge variant="secondary" className="mr-2">
              {supportMessages.length} رسالة
            </Badge>
            <Badge variant="destructive" className="mr-2">
              {supportMessages.filter(m => m.status === 'pending').length} في الانتظار
            </Badge>
          </h2>

          {messagesLoading ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">جاري تحميل الرسائل...</p>
            </div>
          ) : supportMessages.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">لا توجد رسائل دعم فني</p>
            </div>
          ) : (
            <div className="space-y-4">
              {supportMessages.map((message) => (
                <Card key={message.id} className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-semibold">{message.student_name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {formatDateTime(message.created_at)}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusBadge(message.status)}
                      {message.status === 'pending' && (
                        <Button
                          size="sm"
                          onClick={() => setSelectedMessage(message)}
                          variant="outline"
                        >
                          رد
                        </Button>
                      )}
                    </div>
                  </div>
                  
                  <div className="mb-2">
                    <p className="text-sm">{message.message}</p>
                    {message.image_url && (
                      <img 
                        src={message.image_url} 
                        alt="مرفق الرسالة"
                        className="mt-2 max-w-xs rounded border"
                      />
                    )}
                  </div>

                  {message.support_reply && (
                    <div className="mt-3 p-3 bg-blue-50 rounded border-r-4 border-blue-500">
                      <p className="text-sm font-medium text-blue-900">
                        رد {message.support_name}:
                      </p>
                      <p className="text-sm text-blue-800">{message.support_reply}</p>
                      <p className="text-xs text-blue-600 mt-1">
                        {formatDateTime(message.replied_at)}
                      </p>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </Card>

        {/* Reply Modal */}
        {selectedMessage && (
          <Card className="p-6">
            <h3 className="text-lg font-bold mb-4">الرد على رسالة {selectedMessage.student_name}</h3>
            <div className="mb-4 p-3 bg-gray-50 rounded">
              <p className="text-sm font-medium">الرسالة الأصلية:</p>
              <p className="text-sm">{selectedMessage.message}</p>
              {selectedMessage.image_url && (
                <img 
                  src={selectedMessage.image_url} 
                  alt="مرفق الرسالة"
                  className="mt-2 max-w-xs rounded border"
                />
              )}
            </div>
            
            <div className="space-y-4">
              <Textarea
                placeholder="اكتب ردك هنا..."
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                className="min-h-[100px]"
              />
              
              <div className="flex items-center space-x-2">
                <Button onClick={handleReplyToMessage} className="mr-2">
                  <Send className="w-4 h-4 ml-2" />
                  إرسال الرد
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSelectedMessage(null);
                    setReplyText('');
                  }}
                >
                  إلغاء
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default TeacherSupportMonitoring;
