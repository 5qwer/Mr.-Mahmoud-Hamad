
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Calendar, BookOpen, Moon, Sun, Search, Package, Eye, Edit, Trash2, Upload, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabaseDataManager } from '@/utils/supabaseDataManager';

interface Subscription {
  id: number;
  title: string;
  description: string;
  price: number;
  duration: string;
  coverImage: string;
  lessons: any[];
  isPurchased: boolean;
  expiryDate?: string;
  grade: string;
}

interface Lesson {
  id: number;
  title: string;
  description: string;
  grade: string;
}

const TeacherSubscriptions = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentTeacher, setCurrentTeacher] = useState<any>(null);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('all');
  const [isCreating, setIsCreating] = useState(false);
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [selectedSubscription, setSelectedSubscription] = useState<Subscription | null>(null);
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [selectedLessons, setSelectedLessons] = useState<number[]>([]);
  const [newSubscription, setNewSubscription] = useState({
    title: '',
    description: '',
    price: '',
    duration: '',
    grade: ''
  });
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const teacher = JSON.parse(localStorage.getItem('currentTeacher') || 'null');
    if (!teacher) {
      navigate('/teacher');
      return;
    }
    setCurrentTeacher(teacher);
    loadSubscriptions();
    loadLessons();
  }, [navigate]);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
  };

  const loadSubscriptions = async () => {
    try {
      console.log('بدء تحميل الاشتراكات...');
      const data = await supabaseDataManager.getAllSubscriptions();
      console.log('تم تحميل الاشتراكات:', data);
      setSubscriptions(data);
    } catch (error) {
      console.error('خطأ في تحميل الاشتراكات:', error);
      toast.error('حدث خطأ في تحميل الاشتراكات');
    }
  };

  const loadLessons = async () => {
    try {
      console.log('بدء تحميل الحصص...');
      const data = await supabaseDataManager.getAllLessons();
      console.log('تم تحميل الحصص:', data);
      setLessons(data);
    } catch (error) {
      console.error('خطأ في تحميل الحصص:', error);
      toast.error('حدث خطأ في تحميل الحصص');
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewSubscription(prev => ({ ...prev, [name]: value }));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      console.log('تم اختيار الصورة:', file.name);
      setSelectedImageFile(file);
      
      // إنشاء معاينة للصورة
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    if (!newSubscription.title.trim()) {
      toast.error('يرجى إدخال عنوان الاشتراك');
      return false;
    }
    
    if (!newSubscription.description.trim()) {
      toast.error('يرجى إدخال وصف الاشتراك');
      return false;
    }
    
    if (!newSubscription.price || parseFloat(newSubscription.price) <= 0) {
      toast.error('يرجى إدخال سعر صحيح');
      return false;
    }
    
    if (!newSubscription.duration || parseInt(newSubscription.duration) <= 0) {
      toast.error('يرجى إدخال مدة صحيحة بالأيام');
      return false;
    }
    
    if (!newSubscription.grade) {
      toast.error('يرجى اختيار الصف الدراسي');
      return false;
    }

    if (!selectedImageFile) {
      toast.error('يرجى اختيار صورة الغلاف');
      return false;
    }

    // التحقق من نوع وحجم الصورة
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif'];
    if (!allowedTypes.includes(selectedImageFile.type)) {
      toast.error('نوع الصورة غير مدعوم. يرجى اختيار صورة بصيغة JPG أو PNG أو WEBP');
      return false;
    }

    if (selectedImageFile.size > 5242880) { // 5MB
      toast.error('حجم الصورة كبير جداً. يرجى اختيار صورة أقل من 5 ميجابايت');
      return false;
    }

    return true;
  };

  const handleCreateSubscription = async () => {
    console.log('بدء إنشاء الاشتراك...');
    
    if (!validateForm()) {
      return;
    }

    setIsCreating(true);
    try {
      console.log('بيانات الاشتراك:', {
        title: newSubscription.title,
        description: newSubscription.description,
        price: parseFloat(newSubscription.price),
        duration: newSubscription.duration,
        grade: newSubscription.grade
      });

      console.log('تفاصيل الصورة:', {
        name: selectedImageFile?.name,
        type: selectedImageFile?.type,
        size: selectedImageFile?.size
      });

      const result = await supabaseDataManager.createSubscription({
        title: newSubscription.title,
        description: newSubscription.description,
        price: parseFloat(newSubscription.price),
        duration: newSubscription.duration,
        grade: newSubscription.grade
      }, selectedImageFile!);

      console.log('نتيجة إنشاء الاشتراك:', result);

      // إعادة تعيين النموذج
      setNewSubscription({
        title: '',
        description: '',
        price: '',
        duration: '',
        grade: ''
      });
      setSelectedImageFile(null);
      setImagePreview('');
      
      toast.success('✅ تم إنشاء الاشتراك بنجاح!');
      
      // إعادة تحميل الاشتراكات
      await loadSubscriptions();
    } catch (error: any) {
      console.error('خطأ مفصل في إنشاء الاشتراك:', error);
      toast.error(error.message || 'حدث خطأ في إنشاء الاشتراك');
    } finally {
      setIsCreating(false);
    }
  };

  const handleDeleteSubscription = async (subscriptionId: number) => {
    if (!confirm('هل أنت متأكد من حذف هذا الاشتراك؟')) {
      return;
    }
    
    try {
      console.log('بدء حذف الاشتراك:', subscriptionId);
      
      // محاولة حذف الاشتراك
      await supabaseDataManager.deleteSubscription(subscriptionId);
      
      // إذا وصلنا هنا، فقد تم الحذف بنجاح
      toast.success('تم حذف الاشتراك بنجاح');
      
      // إعادة تحميل قائمة الاشتراكات للتأكد من الحذف
      await loadSubscriptions();
      
    } catch (error: any) {
      console.error('خطأ في حذف الاشتراك:', error);
      
      // عرض رسالة خطأ واضحة للمستخدم
      const errorMessage = error.message || 'حدث خطأ في حذف الاشتراك';
      toast.error(errorMessage);
    }
  };

  const handleLinkLessons = async () => {
    if (!selectedSubscription || selectedLessons.length === 0) {
      toast.error('يرجى اختيار حصص للربط');
      return;
    }

    try {
      console.log('بدء ربط الحصص:', { subscriptionId: selectedSubscription.id, lessonIds: selectedLessons });
      
      for (const lessonId of selectedLessons) {
        await supabaseDataManager.addLessonToSubscription(selectedSubscription.id, lessonId);
      }
      
      toast.success('تم ربط الحصص بالاشتراك بنجاح');
      setShowLinkModal(false);
      setSelectedLessons([]);
      setSelectedSubscription(null);
      await loadSubscriptions();
    } catch (error: any) {
      console.error('خطأ في ربط الحصص:', error);
      toast.error(error.message || 'حدث خطأ في ربط الحصص');
    }
  };

  // فلترة الاشتراكات حسب البحث والصف
  const filteredSubscriptions = subscriptions.filter(subscription => {
    const matchesSearch = (subscription.title?.toLowerCase() || '').includes(searchQuery.toLowerCase()) ||
                         (subscription.description?.toLowerCase() || '').includes(searchQuery.toLowerCase());
    const matchesGrade = selectedGrade === 'all' || subscription.grade === selectedGrade;
    return matchesSearch && matchesGrade;
  });

  // فلترة الحصص المتاحة للربط حسب الصف المحدد
  const getAvailableLessonsForGrade = (grade: string) => {
    return lessons.filter(lesson => lesson.grade === grade);
  };

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900' 
        : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between p-6 animate-fade-in">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/teacher/dashboard')}
            className={`rounded-xl ml-4 transition-all duration-300 hover:scale-110 border-2 ${
              isDarkMode 
                ? 'border-purple-400 hover:border-purple-300 hover:bg-purple-900/50' 
                : 'border-indigo-300 hover:border-indigo-400 hover:bg-indigo-50'
            }`}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className={`text-2xl font-bold ${
            isDarkMode ? 'text-white' : 'text-slate-800'
          }`}>
            📦 إدارة الاشتراكات
          </h1>
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className={`rounded-xl transition-all duration-300 hover:scale-110 border-2 ${
            isDarkMode 
              ? 'border-yellow-400 hover:border-yellow-300 hover:bg-yellow-900/30' 
              : 'border-orange-300 hover:border-orange-400 hover:bg-orange-50'
          }`}
        >
          {isDarkMode ? <Sun className="h-5 w-5 text-yellow-400" /> : <Moon className="h-5 w-5 text-orange-500" />}
        </Button>
      </div>

      <div className="container mx-auto px-6 py-8">
        <Tabs defaultValue="create" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="create" className="text-lg font-semibold">
              <Package className="w-5 h-5 ml-2" />
              إنشاء اشتراك جديد
            </TabsTrigger>
            <TabsTrigger value="manage" className="text-lg font-semibold">
              <Eye className="w-5 h-5 ml-2" />
              إدارة الاشتراكات الحالية
            </TabsTrigger>
          </TabsList>

          {/* Create Tab */}
          <TabsContent value="create">
            <Card className={`p-8 shadow-2xl border-0 transition-all duration-500 hover:shadow-3xl ${
              isDarkMode 
                ? 'bg-gradient-to-br from-slate-800/95 to-purple-900/95 backdrop-blur-lg' 
                : 'bg-gradient-to-br from-white/95 to-indigo-50/95 backdrop-blur-lg'
            }`}>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleCreateSubscription();
                }}
                className="space-y-6"
              >
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="title" className="text-lg font-semibold">عنوان الاشتراك *</Label>
                    <Input
                      id="title"
                      name="title"
                      value={newSubscription.title}
                      onChange={handleInputChange}
                      placeholder="أدخل عنوان الاشتراك"
                      className="text-lg"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="grade" className="text-lg font-semibold">الصف الدراسي *</Label>
                    <Select onValueChange={(value) => setNewSubscription({...newSubscription, grade: value})} required>
                      <SelectTrigger className="text-lg">
                        <SelectValue placeholder="اختر الصف" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">الأول الثانوي</SelectItem>
                        <SelectItem value="2">الثاني الثانوي</SelectItem>
                        <SelectItem value="3">الثالث الثانوي</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description" className="text-lg font-semibold">وصف الاشتراك *</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={newSubscription.description}
                    onChange={handleInputChange}
                    placeholder="اكتب وصفاً للاشتراك"
                    rows={3}
                    className="text-lg"
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="price" className="text-lg font-semibold">سعر الاشتراك (جنيه) *</Label>
                    <Input
                      id="price"
                      name="price"
                      type="number"
                      min="0"
                      step="0.01"
                      value={newSubscription.price}
                      onChange={handleInputChange}
                      placeholder="أدخل السعر"
                      className="text-lg"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="duration" className="text-lg font-semibold">مدة الاشتراك (أيام) *</Label>
                    <Input
                      id="duration"
                      name="duration"
                      type="number"
                      min="1"
                      value={newSubscription.duration}
                      onChange={handleInputChange}
                      placeholder="أدخل المدة بالأيام"
                      className="text-lg"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="coverImage" className="text-lg font-semibold">صورة الغلاف *</Label>
                  <Input
                    id="coverImage"
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="text-lg"
                    required
                  />
                  {imagePreview && (
                    <div className="mt-4">
                      <p className="text-sm text-green-600 mb-2">✅ معاينة الصورة:</p>
                      <img 
                        src={imagePreview} 
                        alt="معاينة صورة الغلاف" 
                        className="max-w-xs h-32 object-cover rounded-lg border shadow-sm"
                      />
                    </div>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full py-4 text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 hover-lift"
                  disabled={isCreating}
                >
                  {isCreating ? (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      جاري الإنشاء...
                    </div>
                  ) : (
                    'إنشاء الاشتراك'
                  )}
                </Button>
              </form>
            </Card>
          </TabsContent>

          {/* Manage Tab */}
          <TabsContent value="manage">
            <Card className={`p-8 shadow-2xl border-0 transition-all duration-500 ${
              isDarkMode 
                ? 'bg-gradient-to-br from-slate-800/95 to-purple-900/95 backdrop-blur-lg' 
                : 'bg-gradient-to-br from-white/95 to-indigo-50/95 backdrop-blur-lg'
            }`}>
              {/* Search and Filter */}
              <div className="grid md:grid-cols-3 gap-4 mb-4">
                <div className="space-y-2">
                  <Label className="text-lg font-semibold">البحث في الاشتراكات</Label>
                  <div className="relative">
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
                    <Input
                      placeholder="ابحث عن اشتراك..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="text-right pr-12 text-lg"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-lg font-semibold">فلترة حسب الصف</Label>
                  <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                    <SelectTrigger className="text-lg">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">جميع الصفوف</SelectItem>
                      <SelectItem value="1">الأول الثانوي</SelectItem>
                      <SelectItem value="2">الثاني الثانوي</SelectItem>
                      <SelectItem value="3">الثالث الثانوي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-end">
                  <Badge className="bg-blue-500 text-white">
                    إجمالي الاشتراكات: {filteredSubscriptions.length}
                  </Badge>
                </div>
              </div>

              {/* Subscriptions Grid */}
              <div className="grid md:grid-cols-2 gap-6">
                {filteredSubscriptions.map((subscription, index) => (
                  <Card 
                    key={subscription.id} 
                    className={`overflow-hidden hover-lift animate-scale-in ${isDarkMode ? 'bg-gray-700/50' : 'bg-white'}`}
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div className="aspect-video bg-gradient-to-r from-blue-500 to-purple-600 relative">
                      {subscription.coverImage ? (
                        <img 
                          src={subscription.coverImage} 
                          alt={subscription.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Package className="w-16 h-16 text-white/80" />
                        </div>
                      )}
                      <div className="absolute top-2 right-2">
                        <Badge className="bg-blue-500 text-white">
                          {subscription.grade === '1' ? 'الأول الثانوي' : 
                           subscription.grade === '2' ? 'الثاني الثانوي' : 'الثالث الثانوي'}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="p-6">
                      <h3 className="font-bold text-lg mb-2 line-clamp-1">{subscription.title}</h3>
                      <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{subscription.description}</p>

                      <div className="flex items-center justify-between mb-4">
                        <span className="text-xl font-bold text-green-600">{subscription.price} جنيه</span>
                        <span className="text-sm text-muted-foreground">{subscription.duration} يوم</span>
                      </div>

                      <div className="flex flex-wrap gap-2 mb-4">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="flex-1"
                          onClick={() => navigate(`/teacher/subscription-details/${subscription.id}`)}
                        >
                          <Eye className="w-4 h-4 ml-1" />
                          عرض التفاصيل
                        </Button>
                        <Button 
                          size="sm" 
                          variant="secondary"
                          onClick={() => {
                            setSelectedSubscription(subscription);
                            setShowLinkModal(true);
                          }}
                        >
                          <Plus className="w-4 h-4 ml-1" />
                          ربط حصص
                        </Button>
                        <Button 
                          size="sm" 
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => navigate(`/teacher/upload-lesson?subscription=${subscription.id}&grade=${subscription.grade}`)}
                        >
                          <Plus className="w-4 h-4 ml-1" />
                          إضافة حصة جديدة
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive" 
                          onClick={() => handleDeleteSubscription(subscription.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="text-sm text-muted-foreground">
                        عدد الحصص: {subscription.lessons?.length || 0}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {filteredSubscriptions.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground text-xl">
                    {searchQuery || selectedGrade !== 'all' ? 'لا توجد اشتراكات تطابق البحث' : 'لا توجد اشتراكات بعد'}
                  </p>
                </div>
              )}
            </Card>
          </TabsContent>
        </Tabs>

        {/* Link Lessons Modal */}
        {showLinkModal && selectedSubscription && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <Card className={`p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">ربط حصص بالاشتراك: {selectedSubscription.title}</h2>
                <Button variant="outline" onClick={() => setShowLinkModal(false)}>
                  إغلاق
                </Button>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-4">
                  <Badge className="bg-blue-500 text-white">
                    {selectedSubscription.grade === '1' ? 'الأول الثانوي' : 
                     selectedSubscription.grade === '2' ? 'الثاني الثانوي' : 'الثالث الثانوي'}
                  </Badge>
                  <span className="text-sm text-muted-foreground">الحصص المتاحة لهذا الصف</span>
                </div>

                <Label className="text-lg font-semibold">اختر الحصص للربط:</Label>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {getAvailableLessonsForGrade(selectedSubscription.grade).map((lesson) => (
                    <div key={lesson.id} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`lesson-${lesson.id}`}
                        checked={selectedLessons.includes(lesson.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedLessons([...selectedLessons, lesson.id]);
                          } else {
                            setSelectedLessons(selectedLessons.filter(id => id !== lesson.id));
                          }
                        }}
                        className="ml-2"
                      />
                      <label htmlFor={`lesson-${lesson.id}`} className="flex-1 cursor-pointer">
                        <div className="p-2 border rounded hover:bg-gray-50">
                          <h4 className="font-semibold">{lesson.title}</h4>
                          <p className="text-sm text-muted-foreground">{lesson.description}</p>
                        </div>
                      </label>
                    </div>
                  ))}
                </div>

                {getAvailableLessonsForGrade(selectedSubscription.grade).length === 0 && (
                  <div className="text-center py-8">
                    <BookOpen className="w-12 h-12 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-muted-foreground">لا توجد حصص متاحة لهذا الصف</p>
                    <Button 
                      className="mt-4"
                      onClick={() => {
                        setShowLinkModal(false);
                        navigate(`/teacher/upload-lesson?subscription=${selectedSubscription.id}&grade=${selectedSubscription.grade}`);
                      }}
                    >
                      إضافة حصة جديدة
                    </Button>
                  </div>
                )}

                <div className="flex gap-4">
                  <Button 
                    onClick={handleLinkLessons} 
                    className="flex-1"
                    disabled={selectedLessons.length === 0}
                  >
                    ربط الحصص المحددة ({selectedLessons.length})
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setShowLinkModal(false)}
                  >
                    إلغاء
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeacherSubscriptions;
