
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Plus, Trash2, Edit3, Save, X, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const TeacherManageLinks = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [links, setLinks] = useState<any[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingLink, setEditingLink] = useState<any>(null);
  const [linkData, setLinkData] = useState({
    name: '',
    url: '',
    description: '',
    targetGrade: 'all'
  });
  const [showConfirmDelete, setShowConfirmDelete] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    loadLinks();
  }, []);

  const loadLinks = () => {
    try {
      const savedLinks = JSON.parse(localStorage.getItem('teacherLinks') || '[]');
      console.log('تحميل الروابط:', savedLinks);
      setLinks(savedLinks);
    } catch (error) {
      console.error('خطأ في تحميل الروابط:', error);
      setLinks([]);
    }
  };

  const validateLinkData = () => {
    if (!linkData.name.trim()) {
      toast.error('يرجى إدخال اسم الرابط');
      return false;
    }
    if (!linkData.url.trim()) {
      toast.error('يرجى إدخال الرابط');
      return false;
    }
    if (!linkData.description.trim()) {
      toast.error('يرجى إدخال وصف الرابط');
      return false;
    }
    
    // Validate URL format
    try {
      new URL(linkData.url);
    } catch {
      toast.error('يرجى إدخال رابط صحيح');
      return false;
    }
    
    return true;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateLinkData()) {
      return;
    }

    try {
      const link = {
        id: editingLink ? editingLink.id : Date.now(),
        name: linkData.name.trim(),
        url: linkData.url.trim(),
        description: linkData.description.trim(),
        targetGrade: linkData.targetGrade,
        createdAt: editingLink ? editingLink.createdAt : new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      let updatedLinks;
      if (editingLink) {
        updatedLinks = links.map(l => l.id === editingLink.id ? link : l);
        console.log('تحديث الرابط:', link);
        toast.success('تم تحديث الرابط بنجاح');
      } else {
        updatedLinks = [...links, link];
        console.log('إضافة رابط جديد:', link);
        toast.success('تم إضافة الرابط بنجاح');
      }

      setLinks(updatedLinks);
      localStorage.setItem('teacherLinks', JSON.stringify(updatedLinks));
      
      // Reset form
      resetForm();
    } catch (error) {
      console.error('خطأ في حفظ الرابط:', error);
      toast.error('فشل في حفظ الرابط');
    }
  };

  const handleEdit = (link: any) => {
    console.log('تحرير الرابط:', link);
    setEditingLink(link);
    setLinkData({
      name: link.name || '',
      url: link.url || '',
      description: link.description || '',
      targetGrade: link.targetGrade || 'all'
    });
    setShowAddForm(true);
  };

  const handleDelete = (link: any) => {
    setShowConfirmDelete(link);
  };

  const confirmDelete = () => {
    if (showConfirmDelete) {
      try {
        const updatedLinks = links.filter(l => l.id !== showConfirmDelete.id);
        setLinks(updatedLinks);
        localStorage.setItem('teacherLinks', JSON.stringify(updatedLinks));
        console.log('حذف الرابط:', showConfirmDelete.id);
        toast.success('تم حذف الرابط بنجاح');
        setShowConfirmDelete(null);
      } catch (error) {
        console.error('خطأ في حذف الرابط:', error);
        toast.error('فشل في حذف الرابط');
      }
    }
  };

  const resetForm = () => {
    setLinkData({
      name: '',
      url: '',
      description: '',
      targetGrade: 'all'
    });
    setShowAddForm(false);
    setEditingLink(null);
  };

  const getGradeLabel = (grade: string) => {
    switch (grade) {
      case 'first': return 'الأول الثانوي';
      case 'second': return 'الثاني الثانوي';
      case 'third': return 'الثالث الثانوي';
      case 'all': return 'جميع المراحل';
      default: return grade;
    }
  };

  const openLink = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/teacher/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">🔗 إدارة الروابط</h1>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Add Link Button */}
        <div className="mb-6">
          <Button 
            onClick={() => setShowAddForm(true)} 
            disabled={showAddForm}
            className="hover:scale-105 transition-transform"
          >
            <Plus className="w-4 h-4 ml-2" />
            إضافة رابط جديد
          </Button>
          {showAddForm && (
            <Button 
              variant="outline" 
              onClick={resetForm}
              className="mr-4"
            >
              <X className="w-4 h-4 ml-2" />
              إلغاء
            </Button>
          )}
        </div>

        {/* Add/Edit Link Form */}
        {showAddForm && (
          <Card className="p-6 mb-6 bg-white/90 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold">
                {editingLink ? 'تعديل الرابط' : 'إضافة رابط جديد'}
              </h2>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">اسم الرابط *</Label>
                  <Input
                    id="name"
                    value={linkData.name}
                    onChange={(e) => setLinkData(prev => ({...prev, name: e.target.value}))}
                    placeholder="أدخل اسم الرابط"
                    className="text-right"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="url">الرابط *</Label>
                  <Input
                    id="url"
                    type="url"
                    value={linkData.url}
                    onChange={(e) => setLinkData(prev => ({...prev, url: e.target.value}))}
                    placeholder="https://example.com"
                    className="text-right"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">وصف الرابط *</Label>
                <Textarea
                  id="description"
                  value={linkData.description}
                  onChange={(e) => setLinkData(prev => ({...prev, description: e.target.value}))}
                  placeholder="أدخل وصف الرابط"
                  className="text-right"
                  rows={3}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="targetGrade">المرحلة المستهدفة</Label>
                <select
                  id="targetGrade"
                  value={linkData.targetGrade}
                  onChange={(e) => setLinkData(prev => ({...prev, targetGrade: e.target.value}))}
                  className="w-full p-2 border rounded-md text-right bg-white"
                >
                  <option value="all">جميع المراحل</option>
                  <option value="first">الصف الأول الثانوي</option>
                  <option value="second">الصف الثاني الثانوي</option>
                  <option value="third">الصف الثالث الثانوي</option>
                </select>
              </div>

              <div className="flex gap-4">
                <Button 
                  type="submit" 
                  className="flex-1 hover:scale-105 transition-transform"
                >
                  <Save className="w-4 h-4 ml-2" />
                  {editingLink ? 'تحديث الرابط' : 'إضافة الرابط'}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={resetForm}
                  className="flex-1"
                >
                  <X className="w-4 h-4 ml-2" />
                  إلغاء
                </Button>
              </div>
            </form>
          </Card>
        )}

        {/* Links List */}
        <Card className="p-6 bg-white/90 backdrop-blur-sm">
          <h2 className="text-lg font-bold mb-4">الروابط المتاحة ({links.length})</h2>
          
          {links.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">لا توجد روابط متاحة حالياً</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {links.map((link) => (
                <Card key={link.id} className="p-4 bg-white hover:shadow-lg transition-shadow">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <h3 className="font-bold text-lg">{link.name}</h3>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => openLink(link.url)}
                        className="p-1"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    </div>
                    
                    <p className="text-sm text-muted-foreground">
                      {link.description}
                    </p>
                    
                    <div className="text-xs text-blue-600">
                      المرحلة: {getGradeLabel(link.targetGrade)}
                    </div>
                    
                    <div className="text-xs text-muted-foreground">
                      تاريخ الإضافة: {new Date(link.createdAt).toLocaleDateString('ar-EG')}
                    </div>
                  </div>

                  <div className="flex justify-between mt-4 gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(link)}
                      className="flex-1 hover:scale-105 transition-transform"
                    >
                      <Edit3 className="w-4 h-4 ml-1" />
                      تعديل
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(link)}
                      className="flex-1 hover:scale-105 transition-transform"
                    >
                      <Trash2 className="w-4 h-4 ml-1" />
                      حذف
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* Delete Confirmation Modal */}
      {showConfirmDelete && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="p-6 max-w-md w-full bg-white">
            <h3 className="text-lg font-bold mb-4 text-center">تأكيد الحذف</h3>
            <p className="text-center mb-6">
              هل أنت متأكد من حذف الرابط "{showConfirmDelete.name}"؟
            </p>
            <div className="flex gap-4">
              <Button
                variant="destructive"
                onClick={confirmDelete}
                className="flex-1"
              >
                تأكيد الحذف
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowConfirmDelete(null)}
                className="flex-1"
              >
                إلغاء
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default TeacherManageLinks;
