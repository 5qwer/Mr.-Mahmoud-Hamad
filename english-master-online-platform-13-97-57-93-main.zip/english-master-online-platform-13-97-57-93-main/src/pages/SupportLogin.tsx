
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, UserCheck, Eye, EyeOff, Moon, Sun } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const SupportLogin = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    code: ''
  });
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    document.documentElement.classList.toggle('dark', savedTheme === 'dark');

    // Apply background image if exists
    const backgroundImage = localStorage.getItem('appBackgroundImage');
    if (backgroundImage) {
      document.body.style.backgroundImage = `url(${backgroundImage})`;
      document.body.style.backgroundSize = 'cover';
      document.body.style.backgroundPosition = 'center';
      document.body.style.backgroundAttachment = 'fixed';
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', newTheme);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('تجربة تسجيل دخول الدعم بالبيانات:', formData);
    
    if (!formData.name || !formData.code) {
      toast.error('يرجى ملء جميع الحقول');
      return;
    }

    try {
      // استخدام الدالة الجديدة للمصادقة
      const { data, error } = await supabase.rpc('authenticate_support_team', {
        support_name: formData.name.trim(),
        support_code: formData.code.trim()
      });

      if (error) {
        console.error('خطأ في المصادقة:', error);
        toast.error('حدث خطأ في تسجيل الدخول');
        return;
      }

      if (!data || data.length === 0) {
        console.log('خطأ في تسجيل الدخول - البيانات غير صحيحة');
        toast.error('بيانات الدخول غير صحيحة. يرجى التواصل مع المعلم');
        return;
      }

      const supportMember = data[0];
      console.log('عضو الدعم الموجود:', supportMember);

      // Save current support session
      const supportData = {
        id: supportMember.id,
        name: supportMember.name,
        code: formData.code,
        loginTime: new Date().toISOString()
      };
      
      localStorage.setItem('currentSupport', JSON.stringify(supportData));
      console.log('تم حفظ جلسة الدعم:', supportData);
      
      // Play success sound
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApBnb/QUG4eIAAAAQ==');
      audio.play().catch(() => {});
      
      toast.success('تم تسجيل الدخول بنجاح');
      navigate('/support/dashboard');
    } catch (error: any) {
      console.error('خطأ عام في تسجيل الدخول:', error);
      toast.error('حدث خطأ في تسجيل الدخول. يرجى المحاولة لاحقاً');
    }
  };

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-slate-900 via-cyan-900 to-emerald-900' 
        : 'bg-gradient-to-br from-orange-50 via-pink-50 to-yellow-50'
    }`} style={{
      backgroundImage: localStorage.getItem('appBackgroundImage') ? `url(${localStorage.getItem('appBackgroundImage')})` : undefined,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed'
    }}>
      {/* Hidden Text - "دخول" at the top */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-10">
        <div className="text-6xl font-bold bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 bg-clip-text text-transparent animate-pulse opacity-20 hover:opacity-80 transition-opacity duration-500 transform rotate-12 font-serif drop-shadow-lg">
          دخول
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between p-4 animate-fade-in relative z-20">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/')}
            className="rounded-full ml-4 hover:scale-110 transition-transform duration-300 border-2 border-orange-300 hover:border-orange-500"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent mr-4 animate-pulse">🧑‍🔧 دعم فني</h1>
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className="rounded-full hover:scale-110 transition-transform duration-300 border-2 border-orange-300 hover:border-orange-500"
        >
          {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 relative z-20">
        <Card className="max-w-md mx-auto p-8 animate-scale-in shadow-2xl hover:shadow-3xl transition-all duration-500 border-4 border-gradient-to-r from-cyan-400 to-emerald-500 backdrop-blur-sm bg-white/85 dark:bg-gray-800/85 rounded-3xl">
          <div className="text-center mb-8">
            <div className="relative">
              <UserCheck className="w-20 h-20 mx-auto mb-4 text-cyan-500 animate-bounce drop-shadow-lg" />
              <div className="absolute inset-0 w-20 h-20 mx-auto rounded-full bg-gradient-to-r from-cyan-200 to-emerald-200 opacity-30 animate-ping"></div>
            </div>
            <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 bg-clip-text text-transparent drop-shadow-sm">
              تسجيل دخول الدعم الفني
            </h2>
            <p className="text-muted-foreground animate-fade-in font-medium">
              أدخل بيانات الدخول الخاصة بك
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2 transform hover:scale-105 transition-transform duration-300">
              <Label htmlFor="name" className="text-lg font-semibold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">الاسم الثلاثي</Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="أدخل الاسم الثلاثي"
                className="text-center text-lg py-3 border-3 border-cyan-200 focus:border-cyan-500 transition-all duration-300 rounded-2xl shadow-lg focus:shadow-xl"
                autoComplete="off"
              />
            </div>

            <div className="space-y-2 transform hover:scale-105 transition-transform duration-300">
              <Label htmlFor="code" className="text-lg font-semibold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">الكود</Label>
              <div className="relative">
                <Input
                  id="code"
                  type={showPassword ? "text" : "password"}
                  value={formData.code}
                  onChange={(e) => setFormData({...formData, code: e.target.value})}
                  placeholder="أدخل الكود"
                  className="text-center text-lg py-3 border-3 border-cyan-200 focus:border-cyan-500 transition-all duration-300 rounded-2xl pr-12 shadow-lg focus:shadow-xl"
                  autoComplete="off"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute left-2 top-1/2 transform -translate-y-1/2 hover:bg-gradient-to-r hover:from-cyan-100 hover:to-emerald-100 rounded-full"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full py-4 text-lg font-bold bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-600 hover:from-cyan-600 hover:via-teal-600 hover:to-emerald-700 transform hover:scale-105 transition-all duration-300 rounded-2xl shadow-xl hover:shadow-2xl text-white"
            >
              🚀 تسجيل الدخول
            </Button>
          </form>

          <div className="mt-8 p-6 bg-gradient-to-r from-orange-50 via-yellow-50 to-red-50 dark:from-cyan-900/30 dark:via-teal-900/30 dark:to-emerald-900/30 rounded-2xl text-center animate-pulse border-2 border-gradient-to-r from-orange-200 to-yellow-200">
            <div className="flex items-center justify-center space-x-2 text-orange-700 dark:text-cyan-300">
              <span className="text-2xl">🔐</span>
              <p className="font-semibold">منطقة محمية</p>
            </div>
            <p className="text-sm text-orange-600 dark:text-cyan-400 mt-2 font-medium">
              للدخول يجب أن يكون لديك صلاحية من المعلم
            </p>
          </div>
        </Card>
      </div>

      {/* Hidden Text - "دعم" at the bottom */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <div className="text-5xl font-bold bg-gradient-to-r from-emerald-400 via-cyan-500 to-teal-600 bg-clip-text text-transparent animate-bounce opacity-30 hover:opacity-90 transition-opacity duration-500 transform -rotate-6 font-mono shadow-2xl drop-shadow-lg">
          دعم
        </div>
      </div>

      {/* Hidden Text - "مدرس" in the corner */}
      <div className="absolute top-1/2 right-8 transform -translate-y-1/2 z-10">
        <div className="text-4xl font-bold bg-gradient-to-r from-yellow-400 via-orange-500 to-red-600 bg-clip-text text-transparent animate-float opacity-25 hover:opacity-85 transition-opacity duration-500 transform rotate-45 font-sans drop-shadow-lg">
          مدرس
        </div>
      </div>
    </div>
  );
};

export default SupportLogin;
