import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  BookOpen, 
  CreditCard, 
  MessageSquare, 
  Bell, 
  LogOut, 
  Sun, 
  Moon,
  Activity,
  Gift,
  Users,
  Trophy,
  Target,
  Wallet,
  Book,
  Play,
  Star,
  RefreshCw
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabaseDataManager } from '@/utils/supabaseDataManager';
import { playWelcomeSound } from '@/utils/welcomeSound';
import { errorCorrection } from '@/utils/errorCorrection';
import { supabase } from '@/integrations/supabase/client';

const StudentDashboard = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [stats, setStats] = useState<any>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const navigate = useNavigate();

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', newTheme);
  };

  const refreshStudentData = async (studentId: string) => {
    setIsRefreshing(true);
    try {
      console.log('تحديث بيانات الطالب من قاعدة البيانات...');
      
      const { data: studentData, error } = await supabase
        .from('students')
        .select('*')
        .eq('id', studentId)
        .single();

      if (error) {
        console.error('خطأ في تحميل بيانات الطالب:', error);
        return null;
      }

      console.log('بيانات الطالب المحدثة:', studentData);
      return studentData;
    } catch (error) {
      console.error('خطأ في تحديث بيانات الطالب:', error);
      return null;
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const isDark = savedTheme === 'dark';
    setIsDarkMode(isDark);
    document.documentElement.classList.toggle('dark', isDark);
    
    // Apply background image if exists
    const backgroundImage = localStorage.getItem('appBackgroundImage');
    if (backgroundImage) {
      document.body.style.backgroundImage = `url(${backgroundImage})`;
      document.body.style.backgroundSize = 'cover';
      document.body.style.backgroundPosition = 'center';
      document.body.style.backgroundAttachment = 'fixed';
    }
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }

    // Check if student is blocked
    if (student.isBlocked) {
      toast.error(`حسابك محظور: ${student.blockReason || 'لم يتم تحديد السبب'}`);
      localStorage.removeItem('currentStudent');
      navigate('/student/login');
      return;
    }

    setCurrentStudent(student);
    
    // تحديث البيانات من قاعدة البيانات
    const loadLatestData = async () => {
      const latestData = await refreshStudentData(student.id);
      if (latestData) {
        const updatedStudent = {
          ...student,
          walletBalance: latestData.wallet_balance,
          points: latestData.points,
          completedLessons: latestData.completed_lessons,
          totalLessons: latestData.total_lessons,
          lastLogin: new Date().toISOString()
        };
        
        localStorage.setItem('currentStudent', JSON.stringify(updatedStudent));
        setCurrentStudent(updatedStudent);
        console.log('تم تحديث بيانات الطالب:', updatedStudent);
      }
    };

    loadLatestData();
    
    // Update last login using Supabase
    supabaseDataManager.updateStudent(student.id, {
      updated_at: new Date().toISOString()
    });

    // Play welcome sound
    playWelcomeSound();

    // Load stats using Supabase
    const loadStats = async () => {
      const studentStats = await supabaseDataManager.getStudentStats(student.id);
      setStats(studentStats);
    };
    loadStats();

    // Load unread notifications count from general messages
    const loadNotifications = async () => {
      try {
        const { data, error } = await supabase
          .from('general_messages')
          .select('*')
          .order('created_at', { ascending: false });
        
        if (error) {
          console.error('Error loading notifications:', error);
          return;
        }
        
        // Filter notifications for current student
        const userNotifications = (data || []).filter((notif) => {
          // If target_all is true, show to all students
          if (notif.target_all) return true;
          // If specific grades are targeted, check if user's grade matches
          if (notif.target_grades && notif.target_grades.length > 0) {
            const userGrade = student.grade?.toString() || '1';
            return notif.target_grades.includes(userGrade);
          }
          return false;
        });
        
        // Count unread notifications
        const readNotifs = JSON.parse(localStorage.getItem(`readNotifications_${student.id}`) || '[]');
        const readNotificationsSet = new Set(readNotifs);
        const unread = userNotifications.filter((n) => !readNotificationsSet.has(n.id)).length;
        setUnreadNotifications(unread);
      } catch (error) {
        console.error('Error loading notifications:', error);
      }
    };
    loadNotifications();

    // Add daily login points (once per day)
    const today = new Date().toDateString();
    const lastLoginDate = student.lastLogin ? new Date(student.lastLogin).toDateString() : '';
    
    if (lastLoginDate !== today) {
      const pointsAwarded = 1;
      const studentWithPoints = {
        ...student,
        points: (student.points || 0) + pointsAwarded,
        totalPoints: (student.totalPoints || 0) + pointsAwarded,
        streakDays: lastLoginDate === new Date(Date.now() - 86400000).toDateString() 
          ? (student.streakDays || 0) + 1 
          : 1
      };
      
      // Update in Supabase
      supabaseDataManager.updateStudent(student.id, {
        points: studentWithPoints.points,
        updated_at: new Date().toISOString()
      });
      
      localStorage.setItem('currentStudent', JSON.stringify(studentWithPoints));
      
      supabaseDataManager.addActivityLog(student.id, 'daily_login', `تسجيل دخول يومي - حصلت على ${pointsAwarded} نقطة`);
      
      toast.success(`🎉 مرحباً ${student.fullName}! حصلت على نقطة تسجيل الدخول اليومي`);
    }

    // Initialize error correction system
    errorCorrection.initialize();

    // إعداد تحديث تلقائي كل 30 ثانية
    const intervalId = setInterval(async () => {
      if (student.id) {
        const latestData = await refreshStudentData(student.id);
        if (latestData) {
          const currentStudent = JSON.parse(localStorage.getItem('currentStudent') || '{}');
          const updatedStudent = {
            ...currentStudent,
            walletBalance: latestData.wallet_balance,
            points: latestData.points,
            completedLessons: latestData.completed_lessons,
            totalLessons: latestData.total_lessons
          };
          localStorage.setItem('currentStudent', JSON.stringify(updatedStudent));
          setCurrentStudent(updatedStudent);
        }
      }
    }, 30000); // كل 30 ثانية

    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('currentStudent');
    toast.success('تم تسجيل الخروج بنجاح');
    navigate('/');
  };

  const handleManualRefresh = async () => {
    if (currentStudent?.id) {
      const latestData = await refreshStudentData(currentStudent.id);
      if (latestData) {
        const updatedStudent = {
          ...currentStudent,
          walletBalance: latestData.wallet_balance,
          points: latestData.points,
          completedLessons: latestData.completed_lessons,
          totalLessons: latestData.total_lessons
        };
        localStorage.setItem('currentStudent', JSON.stringify(updatedStudent));
        setCurrentStudent(updatedStudent);
        toast.success('تم تحديث البيانات بنجاح! 💰');
      }
    }
  };

  const dashboardOptions = [
    {
      id: 'paid-lessons',
      title: '💡 الحصص المدفوعة',
      description: 'شاهد الحصص واجتز الامتحانات',
      icon: <Play className="w-8 h-8" />,
      color: 'from-blue-500 to-blue-600',
      route: '/student/paid-lessons',
      badge: stats?.completedLessons || 0,
      bgImage: '🎬',
      emoji: '🎯'
    },
    {
      id: 'subscriptions',
      title: '🧾 الاشتراكات',
      description: 'الاشتراكات الشهرية والباقات',
      icon: <Target className="w-8 h-8" />,
      color: 'from-purple-500 to-purple-600',
      route: '/student/subscriptions',
      badge: currentStudent?.subscriptions?.filter((s: any) => s.active).length || 0,
      bgImage: '📋',
      emoji: '🎪'
    },
    {
      id: 'books',
      title: '📚 الكتب',
      description: 'اطلب الكتب الدراسية',
      icon: <Book className="w-8 h-8" />,
      color: 'from-orange-500 to-orange-600',
      route: '/student/books',
      badge: null,
      bgImage: '📖',
      emoji: '🔖'
    },
    {
      id: 'support',
      title: '🛠️ الدعم الفني',
      description: 'تواصل مع فريق الدعم',
      icon: <MessageSquare className="w-8 h-8" />,
      color: 'from-green-500 to-green-600',
      route: '/student/support',
      badge: null,
      bgImage: '💬',
      emoji: '🤝'
    },
    {
      id: 'wallet',
      title: '💳 المحفظة',
      description: 'شحن الرصيد وإدارة المدفوعات',
      icon: <Wallet className="w-8 h-8" />,
      color: 'from-indigo-500 to-indigo-600',
      route: '/student/wallet',
      badge: currentStudent?.walletBalance || 0,
      bgImage: '💰',
      emoji: '💎'
    },
    {
      id: 'activity',
      title: '📑 سجل النشاط',
      description: 'تتبع تقدمك والإنجازات',
      icon: <Activity className="w-8 h-8" />,
      color: 'from-teal-500 to-teal-600',
      route: '/student/activity',
      badge: null,
      bgImage: '📊',
      emoji: '📈'
    },
    {
      id: 'notifications',
      title: '🛎️ الإشعارات',
      description: 'الرسائل والتحديثات',
      icon: <Bell className="w-8 h-8" />,
      color: 'from-red-500 to-red-600',
      route: '/student/notifications',
      badge: unreadNotifications > 0 ? unreadNotifications : null,
      bgImage: '🔔',
      emoji: '📢'
    },
    {
      id: 'rewards',
      title: '🎁 المكافآت',
      description: 'استبدل النقاط بمكافآت',
      icon: <Gift className="w-8 h-8" />,
      color: 'from-yellow-500 to-yellow-600',
      route: '/student/rewards',
      badge: currentStudent?.points || 0,
      bgImage: '🏆',
      emoji: '🎊'
    }
  ];

  return (
    <div className={`min-h-screen page-transition relative overflow-hidden ${
      isDarkMode 
        ? 'bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900' 
        : 'bg-gradient-to-br from-pink-50 via-blue-50 to-purple-50'
    }`}>
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-20 w-64 h-64 bg-blue-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-float"></div>
        <div className="absolute bottom-20 right-20 w-64 h-64 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-float" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-float" style={{animationDelay: '1s'}}></div>
      </div>

      {/* Header */}
      <div className="relative z-20 flex items-center justify-between p-4 beautiful-card border-b border-white/20">
        <div className="flex items-center animate-fade-in">
          <div className="relative w-16 h-16 rounded-full overflow-hidden border-4 border-gradient-to-r from-blue-500 to-purple-500 shadow-2xl ml-4 hover-lift animate-float">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full blur opacity-75 animate-pulse"></div>
            <img 
              src="/lovable-uploads/3c3ffc84-907d-4398-9e67-feb37028560f.png" 
              alt="Teacher" 
              className="relative w-full h-full object-cover rounded-full"
            />
          </div>
          <div>
            <h1 className="text-2xl font-bold gradient-text animate-fade-in">
              🌟 مرحباً، {currentStudent?.fullName || 'الطالب المتميز'} 🌟
            </h1>
            <p className="text-lg text-purple-200 font-semibold animate-fade-in" style={{animationDelay: '0.2s'}}>
              🎓 {currentStudent?.grade === 'first' && 'الأول الثانوي'}
              {currentStudent?.grade === 'second' && 'الثاني الثانوي'}
              {currentStudent?.grade === 'third' && 'الثالث الثانوي'} 📚
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2 animate-fade-in" style={{animationDelay: '0.3s'}}>
          {/* جرس الإشعارات مع العدد */}
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/student/notifications')}
            className="rounded-full beautiful-card hover-lift animate-3d relative"
          >
            <Bell className="h-5 w-5 text-blue-600" />
            {unreadNotifications > 0 && (
              <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
                {unreadNotifications > 9 ? '9+' : unreadNotifications}
              </div>
            )}
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="rounded-full beautiful-card hover-lift animate-3d"
          >
            <RefreshCw className={`h-5 w-5 text-green-600 ${isRefreshing ? 'animate-spin' : ''}`} />
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            className="rounded-full beautiful-card hover-lift animate-3d"
          >
            {isDarkMode ? <Sun className="h-5 w-5 text-yellow-400" /> : <Moon className="h-5 w-5 text-purple-600" />}
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            onClick={handleLogout}
            className="rounded-full beautiful-card hover-lift animate-3d text-red-400 hover:text-red-300"
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Student Stats Overview */}
      {stats && (
        <div className="relative z-10 px-4 mb-6 animate-fade-in" style={{animationDelay: '0.4s'}}>
          <Card className="p-6 beautiful-card hover-lift pulse-glow">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <div className="animate-3d hover-lift">
                <div className="w-12 h-12 mx-auto mb-2 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center animate-float">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <p className="text-sm font-semibold text-yellow-600">🏆 المستوى</p>
                <p className="font-bold text-2xl gradient-text">{stats.level}</p>
              </div>
              <div className="animate-3d hover-lift">
                <div className="w-12 h-12 mx-auto mb-2 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full flex items-center justify-center animate-float" style={{animationDelay: '0.5s'}}>
                  <Star className="w-6 h-6 text-white" />
                </div>
                <p className="text-sm font-semibold text-purple-600">⭐ النقاط</p>
                <p className="font-bold text-2xl gradient-text">{currentStudent?.points || 0}</p>
              </div>
              <div className="animate-3d hover-lift">
                <div className="w-12 h-12 mx-auto mb-2 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full flex items-center justify-center animate-float" style={{animationDelay: '1s'}}>
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <p className="text-sm font-semibold text-blue-600">📚 الحصص المكتملة</p>
                <p className="font-bold text-2xl gradient-text">{stats.completedLessons}</p>
              </div>
              <div className="animate-3d hover-lift">
                <div className="w-12 h-12 mx-auto mb-2 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center animate-float" style={{animationDelay: '1.5s'}}>
                  <CreditCard className="w-6 h-6 text-white" />
                </div>
                <p className="text-sm font-semibold text-green-600">💳 الرصيد</p>
                <p className="font-bold text-2xl gradient-text">{currentStudent?.walletBalance || 0}</p>
              </div>
            </div>
            
            {/* Progress Bar */}
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">التقدم العام</span>
                <span className="text-sm text-muted-foreground">{stats.progressPercentage}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${stats.progressPercentage}%` }}
                ></div>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Dashboard Options Grid */}
      <div className="relative z-10 container mx-auto px-4 py-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {dashboardOptions.map((option, index) => (
            <Card 
              key={option.id}
              className="group p-6 beautiful-card cursor-pointer hover-lift animate-3d animate-fade-in pulse-glow"
              onClick={() => navigate(option.route)}
              style={{animationDelay: `${index * 0.1}s`}}
            >
              <div className="relative overflow-hidden rounded-xl mb-4">
                <div className={`w-full h-40 bg-gradient-to-r ${option.color} rounded-xl flex items-center justify-center relative group-hover:scale-110 transition-all duration-300`}>
                  {/* Background Pattern */}
                  <div className="absolute inset-0 opacity-20">
                    <div className="text-6xl absolute top-2 right-2">{option.bgImage}</div>
                    <div className="text-4xl absolute bottom-2 left-2">{option.emoji}</div>
                  </div>
                  
                  {/* Main Icon */}
                  <div className="text-white z-10 animate-float">
                    {option.icon}
                  </div>
                  
                  {/* Sparkle Effect */}
                  <div className="absolute top-4 left-4 text-white/60 animate-pulse">✨</div>
                  <div className="absolute bottom-4 right-4 text-white/60 animate-pulse" style={{animationDelay: '1s'}}>⭐</div>
                </div>
              </div>
              
              <div className="text-center">
                <h3 className="font-bold text-xl mb-3 gradient-text group-hover:scale-105 transition-transform duration-300">
                  {option.title}
                </h3>
                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                  {option.description}
                </p>
                
                {option.badge !== null && (
                  <Badge 
                    variant={option.id === 'notifications' && option.badge > 0 ? 'destructive' : 'secondary'}
                    className="text-sm px-3 py-1 animate-bounce"
                  >
                    {option.badge}
                  </Badge>
                )}
              </div>
            </Card>
          ))}
        </div>

        {/* Quick Stats */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6 animate-fade-in" style={{animationDelay: '0.8s'}}>
          <Card className="p-6 beautiful-card text-center hover-lift animate-3d pulse-glow">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center animate-float">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-bold text-lg gradient-text mb-2">📊 معدل النجاح</h3>
            <p className="text-3xl font-bold text-blue-600">{stats?.averageScore || 0}%</p>
            <div className="text-4xl mt-2">🎯</div>
          </Card>
          
          <Card className="p-6 beautiful-card text-center hover-lift animate-3d pulse-glow">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center animate-float" style={{animationDelay: '0.5s'}}>
              <Trophy className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-bold text-lg gradient-text mb-2">🏆 الامتحانات المجتازة</h3>
            <p className="text-3xl font-bold text-yellow-600">
              {currentStudent?.examResults?.filter((e: any) => e.passed).length || 0}
            </p>
            <div className="text-4xl mt-2">🥇</div>
          </Card>
          
          <Card className="p-6 beautiful-card text-center hover-lift animate-3d pulse-glow">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center animate-float" style={{animationDelay: '1s'}}>
              <Target className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-bold text-lg gradient-text mb-2">🔥 أيام الإنجاز</h3>
            <p className="text-3xl font-bold text-purple-600">{currentStudent?.streakDays || 0}</p>
            <div className="text-4xl mt-2">⚡</div>
          </Card>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground">
            تطبيق مستر محمود حمد - مدرس أول لغة إنجليزية
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            📞 للتواصل: 01050747978
          </p>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
