
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Bell, BellOff, MessageSquare, CreditCard, BookOpen, Gift, AlertCircle, CheckCircle, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import NotificationSystem from '@/components/NotificationSystem';

const StudentNotifications = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    setCurrentStudent(student);
  }, [navigate]);

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`} style={{
      backgroundImage: localStorage.getItem('appBackgroundImage') ? `url(${localStorage.getItem('appBackgroundImage')})` : undefined,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed'
    }}>
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/student/dashboard')}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="mr-4">
            <h1 className="text-xl font-bold text-primary flex items-center">
              🛎️ الإشعارات والرسائل العامة
            </h1>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {currentStudent && (
          <NotificationSystem 
            currentUser={currentStudent} 
            userType="student" 
          />
        )}

        {/* Quick Actions */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Button
            variant="outline"
            className="p-4 h-auto flex flex-col items-center space-y-2"
            onClick={() => navigate('/student/support')}
          >
            <MessageSquare className="w-6 h-6" />
            <span className="text-xs">الدعم الفني</span>
          </Button>
          
          <Button
            variant="outline"
            className="p-4 h-auto flex flex-col items-center space-y-2"
            onClick={() => navigate('/student/wallet')}
          >
            <CreditCard className="w-6 h-6" />
            <span className="text-xs">المحفظة</span>
          </Button>
          
          <Button
            variant="outline"
            className="p-4 h-auto flex flex-col items-center space-y-2"
            onClick={() => navigate('/student/paid-lessons')}
          >
            <BookOpen className="w-6 h-6" />
            <span className="text-xs">الحصص</span>
          </Button>
          
          <Button
            variant="outline"
            className="p-4 h-auto flex flex-col items-center space-y-2"
            onClick={() => navigate('/student/rewards')}
          >
            <Gift className="w-6 h-6" />
            <span className="text-xs">المكافآت</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default StudentNotifications;
