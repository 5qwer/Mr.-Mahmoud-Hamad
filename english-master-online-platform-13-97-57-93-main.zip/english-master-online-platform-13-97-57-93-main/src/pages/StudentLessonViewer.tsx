
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, FileText, Download, Eye, BookOpen } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';
import { supabaseDataManager } from '@/utils/supabaseDataManager';
import SecureVideoPlayer from '@/components/SecureVideoPlayer';

interface Lesson {
  id: number;
  title: string;
  description: string;
  cover_image?: string;
  video_url?: string;
  pdf_url?: string;
  homework_url?: string;
  homework_video_url?: string;
  solution_url?: string;
  order_number: number;
  grade: string;
  price: number;
}

const StudentLessonViewer = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentVideoType, setCurrentVideoType] = useState<'explanation' | 'homework'>('explanation');
  const navigate = useNavigate();
  const { lessonId } = useParams();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    
    setCurrentStudent(student);
    loadLessonData();
  }, [navigate, lessonId]);

  const loadLessonData = async () => {
    try {
      setLoading(true);
      
      if (!lessonId) {
        toast.error('معرف الحصة مفقود');
        navigate('/student/subscriptions');
        return;
      }

      console.log('جاري تحميل بيانات الحصة رقم:', lessonId);
      
      const lessonData = await supabaseDataManager.getLessonById(parseInt(lessonId));
      
      if (lessonData) {
        console.log('تم تحميل بيانات الحصة:', lessonData);
        setLesson(lessonData);
      } else {
        console.log('لم يتم العثور على الحصة، سيتم استخدام بيانات تجريبية');
        const demoLesson = {
          id: parseInt(lessonId),
          title: `حصة الفيزياء - الدرس ${lessonId}`,
          description: 'شرح مفصل للموضوع مع أمثلة عملية وتطبيقات',
          video_url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
          pdf_url: 'https://www.africau.edu/images/default/sample.pdf',
          homework_url: 'https://www.africau.edu/images/default/sample.pdf',
          homework_video_url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
          solution_url: 'https://www.africau.edu/images/default/sample.pdf',
          order_number: parseInt(lessonId),
          grade: '1',
          price: 50
        };
        setLesson(demoLesson);
      }
      
    } catch (error) {
      console.error('خطأ في تحميل بيانات الحصة:', error);
      toast.error('فشل في تحميل بيانات الحصة');
      navigate('/student/subscriptions');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = (url: string, type: string) => {
    console.log(`تحميل ${type}:`, url);
    window.open(url, '_blank');
  };

  const handleVideoStart = () => {
    console.log('بدء تشغيل الفيديو');
  };

  const handleVideoEnd = () => {
    console.log('انتهاء الفيديو');
  };

  const handleTimeUpdate = (currentTime: number, duration: number) => {
    // يمكن استخدام هذا لتتبع التقدم
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <h2 className="text-xl font-bold mb-4">لم يتم العثور على الحصة</h2>
          <Button onClick={() => navigate('/student/subscriptions')}>
            العودة للاشتراكات
          </Button>
        </Card>
      </div>
    );
  }

  const currentVideoUrl = currentVideoType === 'explanation' ? lesson.video_url : lesson.homework_video_url;

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(-1)}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">📖 عرض الحصة</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 space-y-6">
        {/* معلومات الحصة */}
        <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
          <div className="space-y-4">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-2">{lesson.title}</h2>
              <p className="text-muted-foreground text-lg">{lesson.description}</p>
              <div className="inline-block bg-blue-500 text-white px-3 py-1 rounded-full text-sm mt-2">
                الحصة رقم {lesson.order_number}
              </div>
            </div>
          </div>
        </Card>

        {/* مشغل الفيديو الآمن */}
        {currentVideoUrl && (
          <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
            <div className="space-y-4">
              <div className="flex justify-center gap-4 mb-4">
                <Button
                  onClick={() => setCurrentVideoType('explanation')}
                  variant={currentVideoType === 'explanation' ? 'default' : 'outline'}
                  className="flex items-center gap-2"
                >
                  📹 فيديو الشرح
                </Button>
                {lesson.homework_video_url && (
                  <Button
                    onClick={() => setCurrentVideoType('homework')}
                    variant={currentVideoType === 'homework' ? 'default' : 'outline'}
                    className="flex items-center gap-2"
                  >
                    🎬 فيديو الواجب
                  </Button>
                )}
              </div>
              
              <SecureVideoPlayer
                src={currentVideoUrl}
                title={currentVideoType === 'explanation' ? 'فيديو الشرح' : 'فيديو الواجب'}
                videoType={currentVideoType}
                onVideoStart={handleVideoStart}
                onVideoEnd={handleVideoEnd}
                onTimeUpdate={handleTimeUpdate}
              />
            </div>
          </Card>
        )}

        {/* محتوى الحصة */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* ملف الشرح PDF */}
          {lesson.pdf_url && (
            <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto">
                  <FileText className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold">📄 ملف الشرح</h3>
                <p className="text-muted-foreground">تحميل أو عرض ملف الشرح</p>
                <Button 
                  onClick={() => handleDownload(lesson.pdf_url!, 'ملف الشرح')}
                  variant="outline"
                  className="w-full"
                  size="lg"
                >
                  <Eye className="w-5 h-5 mr-2" />
                  عرض ملف الشرح
                </Button>
              </div>
            </Card>
          )}

          {/* الواجب */}
          {lesson.homework_url && (
            <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center mx-auto">
                  <BookOpen className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold">📝 الواجب</h3>
                <p className="text-muted-foreground">تحميل ملف الواجب</p>
                <Button 
                  onClick={() => handleDownload(lesson.homework_url!, 'الواجب')}
                  variant="outline"
                  className="w-full"
                  size="lg"
                >
                  <Download className="w-5 h-5 mr-2" />
                  تحميل الواجب
                </Button>
              </div>
            </Card>
          )}

          {/* حلول الواجب */}
          {lesson.solution_url && (
            <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto">
                  <FileText className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold">✅ حلول الواجب</h3>
                <p className="text-muted-foreground">تحميل أو عرض حلول الواجب</p>
                <Button 
                  onClick={() => handleDownload(lesson.solution_url!, 'حلول الواجب')}
                  variant="outline"
                  className="w-full"
                  size="lg"
                >
                  <Eye className="w-5 h-5 mr-2" />
                  عرض الحلول
                </Button>
              </div>
            </Card>
          )}

          {/* إحصائيات الحصة */}
          <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto">
                <BookOpen className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold">📊 تفاصيل الحصة</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">الصف</p>
                  <p className="font-bold">{lesson.grade}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">رقم الحصة</p>
                  <p className="font-bold">{lesson.order_number}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">الحالة</p>
                  <p className="font-bold text-green-500">متاح</p>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* زر إكمال الحصة */}
        <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
          <div className="text-center">
            <Button 
              onClick={() => {
                toast.success('تم إكمال الحصة بنجاح! 🎉');
                navigate('/student/subscriptions');
              }}
              className="w-full md:w-auto px-8 py-3 text-lg bg-green-600 hover:bg-green-700"
              size="lg"
            >
              ✅ إكمال الحصة
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default StudentLessonViewer;
