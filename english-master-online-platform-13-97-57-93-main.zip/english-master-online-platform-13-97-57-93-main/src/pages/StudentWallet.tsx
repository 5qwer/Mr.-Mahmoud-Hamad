
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, CreditCard, Upload, Volume2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const StudentWallet = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [amount, setAmount] = useState('');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('');
  const [methodNumber, setMethodNumber] = useState('');
  const [transferTime, setTransferTime] = useState('');
  const [message, setMessage] = useState('');
  const [transferImage, setTransferImage] = useState<File | null>(null);
  const [transferImagePreview, setTransferImagePreview] = useState<string>('');
  const [paymentMethods, setPaymentMethods] = useState<any[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  // Function to play payment success sound
  const playPaymentSound = () => {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApBnb/QUG4eIAabjfrFhC0FJHXH8d2QQAkUXrTp66hVFAlBnb/QUG4eIAabjfrFhC0FJHXH8d2QQAkUXrTp66hVFAlBnb/QUG4eIAabjfrFhC0F');
    audio.play().catch(() => {
      // Fallback sound effect using Web Audio API
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(600, audioContext.currentTime + 0.1);
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    });
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    // Apply background image if exists
    const backgroundImage = localStorage.getItem('appBackgroundImage');
    if (backgroundImage) {
      document.body.style.backgroundImage = `url(${backgroundImage})`;
      document.body.style.backgroundSize = 'cover';
      document.body.style.backgroundPosition = 'center';
      document.body.style.backgroundAttachment = 'fixed';
    }
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    setCurrentStudent(student);

    // Load payment methods from Supabase
    loadPaymentMethods();
  }, [navigate]);

  const loadPaymentMethods = async () => {
    try {
      console.log('Loading payment methods for student...');
      const { data, error } = await supabase
        .from('payment_methods')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في جلب وسائل الدفع:', error);
        toast.error('حدث خطأ في تحميل وسائل الدفع');
        return;
      }

      console.log('Payment methods loaded:', data);
      setPaymentMethods(data || []);
    } catch (error) {
      console.error('خطأ في تحميل وسائل الدفع:', error);
      toast.error('حدث خطأ في تحميل وسائل الدفع');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setTransferImage(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        setTransferImagePreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const uploadImageToSupabase = async (file: File): Promise<string | null> => {
    try {
      const filePath = `transfers/${Date.now()}_${file.name}`;
      console.log('Uploading image to:', filePath);
      
      const { data, error } = await supabase.storage
        .from('transfer-receipts')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) {
        console.error('Error uploading image:', error);
        return null;
      }

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('transfer-receipts')
        .getPublicUrl(filePath);

      console.log('Image uploaded successfully:', urlData.publicUrl);
      return urlData.publicUrl;
    } catch (error) {
      console.error('Error in uploadImageToSupabase:', error);
      return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('Starting form submission...');
    console.log('Form data:', {
      amount,
      selectedPaymentMethod,
      methodNumber,
      transferTime,
      message,
      transferImage: !!transferImage,
      currentStudent: currentStudent?.id
    });
    
    if (!amount || !selectedPaymentMethod || !methodNumber || !transferTime || !transferImage) {
      toast.error('يرجى ملء جميع الحقول المطلوبة ورفع صورة الإيصال');
      return;
    }

    if (!currentStudent?.id) {
      toast.error('لم يتم العثور على بيانات الطالب');
      return;
    }

    setIsSubmitting(true);

    try {
      console.log('Starting wallet request submission...');
      
      // Upload image first
      console.log('Uploading image...');
      const imageUrl = await uploadImageToSupabase(transferImage);
      if (!imageUrl) {
        toast.error('فشل في رفع صورة الإيصال');
        setIsSubmitting(false);
        return;
      }
      console.log('Image uploaded successfully:', imageUrl);

      // Create unique identifier to avoid conflicts
      const uniqueTransferId = `WR_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const transferTimeISO = new Date(transferTime).toISOString();

      const walletRequestData = {
        user_id: currentStudent.id,
        amount: parseFloat(amount),
        payment_method: selectedPaymentMethod,
        transfer_id: uniqueTransferId,
        transfer_number: methodNumber,
        transfer_time: transferTimeISO,
        transfer_image: imageUrl,
        message: message || null,
        status: 'pending'
      };

      console.log('Creating wallet request with data:', walletRequestData);

      // Create wallet request in Supabase
      const { data, error } = await supabase
        .from('wallet_requests')
        .insert(walletRequestData)
        .select()
        .single();

      console.log('Supabase response:', { data, error });

      if (error) {
        console.error('خطأ في إنشاء طلب الشحن:', error);
        toast.error('حدث خطأ في إرسال طلب الشحن: ' + error.message);
        setIsSubmitting(false);
        return;
      }

      console.log('Wallet request created successfully:', data);
      
      // Play success sound
      playPaymentSound();
      
      toast.success('🎵 تم إرسال طلب الشحن بنجاح! في انتظار موافقة الدعم الفني');
      
      // Reset form
      setAmount('');
      setSelectedPaymentMethod('');
      setMethodNumber('');
      setTransferTime('');
      setMessage('');
      setTransferImage(null);
      setTransferImagePreview('');
      
    } catch (error) {
      console.error('خطأ في إرسال طلب الشحن:', error);
      toast.error('حدث خطأ في إرسال طلب الشحن: ' + (error as Error).message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Get selected payment method details
  const selectedMethodDetails = paymentMethods.find(method => method.name === selectedPaymentMethod);

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`} style={{
      backgroundImage: localStorage.getItem('appBackgroundImage') ? `url(${localStorage.getItem('appBackgroundImage')})` : undefined,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed'
    }}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/student/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">💳 المحفظة</h1>
      </div>

      <div className="container mx-auto px-4 py-8">
        {currentStudent && (
          <div className="mb-6">
            <Card className="p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-bold">الرصيد الحالي</h3>
                  <p className="text-2xl font-bold text-green-600">{currentStudent.walletBalance || 0} جنيه</p>
                </div>
                <CreditCard className="w-12 h-12 text-blue-500" />
              </div>
            </Card>
          </div>
        )}

        <Card className="max-w-md mx-auto p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
          <div className="text-center mb-6">
            <div className="flex items-center justify-center mb-4">
              <CreditCard className="w-16 h-16 text-green-500 mr-2" />
              <Volume2 className="w-8 h-8 text-blue-500" />
            </div>
            <h2 className="text-2xl font-bold text-primary mb-2">شحن المحفظة</h2>
            <p className="text-muted-foreground">اختر وسيلة الدفع وأدخل بيانات التحويل</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="amount">المبلغ المطلوب *</Label>
              <Input
                id="amount"
                type="number"
                min="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="أدخل المبلغ بالجنيه"
                className="text-right"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="payment-method">وسيلة الدفع *</Label>
              <Select value={selectedPaymentMethod} onValueChange={setSelectedPaymentMethod} required>
                <SelectTrigger className="text-right">
                  <SelectValue placeholder="اختر وسيلة الدفع" />
                </SelectTrigger>
                <SelectContent>
                  {paymentMethods.map((method) => (
                    <SelectItem key={method.id} value={method.name}>
                      <div className="flex justify-between items-center w-full">
                        <span>{method.name}</span>
                        <span className="text-muted-foreground text-sm mr-2">{method.number}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              {selectedMethodDetails && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    <strong>رقم الحساب:</strong> {selectedMethodDetails.number}
                  </p>
                  <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                    قم بالتحويل إلى هذا الرقم ثم أدخل رقم العملية أدناه
                  </p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="method-number">رقم التحويل *</Label>
              <Input
                id="method-number"
                type="text"
                value={methodNumber}
                onChange={(e) => setMethodNumber(e.target.value)}
                placeholder="أدخل رقم التحويل أو المرجع"
                className="text-right"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="transfer-time">وقت التحويل *</Label>
              <Input
                id="transfer-time"
                type="datetime-local"
                value={transferTime}
                onChange={(e) => setTransferTime(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="message">رسالة إضافية (اختيارية)</Label>
              <Textarea
                id="message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="أضف أي ملاحظات إضافية"
                className="text-right"
              />
            </div>

            <div className="space-y-2">
              <Label>صورة إيصال التحويل *</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                  required
                />
                <label htmlFor="image-upload" className="cursor-pointer">
                  {transferImagePreview ? (
                    <img src={transferImagePreview} alt="معاינة الإيصال" className="max-w-full h-32 mx-auto rounded" />
                  ) : (
                    <>
                      <Upload className="w-8 h-8 mx-auto mb-2 text-gray-500" />
                      <p className="text-sm text-gray-500">اضغط لرفع صورة إيصال التحويل</p>
                    </>
                  )}
                </label>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-green-500 hover:bg-green-600"
              disabled={isSubmitting || !selectedPaymentMethod}
            >
              {isSubmitting ? '🔄 جاري الإرسال...' : '🎵 إرسال طلب الشحن'}
            </Button>
          </form>
        </Card>

        {/* Payment Methods Display */}
        {paymentMethods.length > 0 && (
          <Card className="max-w-md mx-auto mt-6 p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <h3 className="font-bold mb-3 text-center">وسائل الدفع المتاحة</h3>
            <div className="space-y-2">
              {paymentMethods.map((method) => (
                <div key={method.id} className="flex justify-between items-center p-2 border rounded">
                  <span className="font-semibold">{method.name}</span>
                  <span className="text-muted-foreground">{method.number}</span>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default StudentWallet;
