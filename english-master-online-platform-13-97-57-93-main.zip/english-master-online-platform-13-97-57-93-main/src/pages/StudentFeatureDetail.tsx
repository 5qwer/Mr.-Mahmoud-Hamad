
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Play, FileText, Download, MessageSquare, BookOpen, DollarSign, Sun, Moon } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';

const StudentFeatureDetail = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const { featureId } = useParams();
  const navigate = useNavigate();

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', newTheme);
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    
    // Apply background image if exists
    const backgroundImage = localStorage.getItem('appBackgroundImage');
    if (backgroundImage) {
      document.body.style.backgroundImage = `url(${backgroundImage})`;
      document.body.style.backgroundSize = 'cover';
      document.body.style.backgroundPosition = 'center';
      document.body.style.backgroundAttachment = 'fixed';
    }
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    setCurrentStudent(student);
  }, [navigate]);

  const getFeatureDetails = () => {
    switch (featureId) {
      case 'paid-lessons':
        return {
          title: '💡 الحصص المدفوعة',
          description: 'مجموعة متنوعة من الحصص التعليمية عالية الجودة',
          features: [
            '🎥 فيديوهات شرح تفصيلية',
            '📄 ملفات PDF للمراجعة',
            '📝 واجبات وتمارين',
            '✅ حلول نموذجية',
            '🧪 امتحانات تفاعلية',
            '❓ إمكانية السؤال للمعلم'
          ],
          buttonText: 'تصفح الحصص',
          buttonAction: () => navigate('/student/paid-lessons')
        };
      case 'subscriptions':
        return {
          title: '🧾 الاشتراكات',
          description: 'اشتراكات شهرية شاملة لجميع المواد',
          features: [
            '📚 حصص متعددة في اشتراك واحد',
            '💰 توفير في التكلفة',
            '🔄 تحديث مستمر للمحتوى',
            '⏰ صالح لمدة شهر كامل',
            '📊 متابعة التقدم',
            '🎯 محتوى مخصص حسب الصف'
          ],
          buttonText: 'عرض الاشتراكات',
          buttonAction: () => navigate('/student/subscriptions')
        };
      case 'books':
        return {
          title: '📚 الكتب',
          description: 'مجموعة من الكتب الدراسية والمراجع',
          features: [
            '📖 كتب منهجية معتمدة',
            '📍 توصيل للمنزل',
            '💳دفع آمن ومضمون',
            '📞 خدمة عملاء متميزة',
            '🚚 شحن سريع',
            '💯 ضمان الجودة'
          ],
          buttonText: 'تصفح الكتب',
          buttonAction: () => navigate('/student/books')
        };
      case 'support':
        return {
          title: '🛠️ الدعم الفني',
          description: 'خدمة دعم فني متاحة على مدار الساعة',
          features: [
            '💬 دردشة مباشرة',
            '📷 إرسال الصور',
            '⚡ رد سريع',
            '👥 فريق متخصص',
            '📱 متاح 24/7',
            '🔧 حل جميع المشاكل التقنية'
          ],
          buttonText: 'تواصل مع الدعم',
          buttonAction: () => navigate('/student/support')
        };
      case 'wallet':
        return {
          title: '💳 المحفظة',
          description: 'إدارة رصيدك وعمليات الدفع بسهولة',
          features: [
            '💰 شحن الرصيد بسهولة',
            '📊 متابعة المعاملات',
            '🔒 أمان عالي',
            '💳 وسائل دفع متعددة',
            '📱 فودافون كاش وأورانج موني',
            '✅ تأكيد فوري'
          ],
          buttonText: 'إدارة المحفظة',
          buttonAction: () => navigate('/student/wallet')
        };
      case 'activity':
        return {
          title: '📑 سجل النشاط',
          description: 'تتبع تقدمك الأكاديمي ونشاطك',
          features: [
            '📈 إحصائيات التقدم',
            '🏆 الدرجات والتقييمات',
            '📅 سجل الحضور',
            '⏱️ وقت المذاكرة',
            '🎯 الأهداف المحققة',
            '📊 تقارير مفصلة'
          ],
          buttonText: 'عرض السجل',
          buttonAction: () => navigate('/student/activity')
        };
      case 'notifications':
        return {
          title: '🛎️ الإشعارات',
          description: 'كن على اطلاع بآخر التحديثات والأخبار',
          features: [
            '📢 إشعارات فورية',
            '📚 تحديثات الحصص',
            '💰 تأكيدات الدفع',
            '📝 رسائل المعلم',
            '🔔 تذكيرات مهمة',
            '⚡ إشعارات الدعم'
          ],
          buttonText: 'عرض الإشعارات',
          buttonAction: () => navigate('/student/notifications')
        };
      case 'rewards':
        return {
          title: '🎁 المكافآت',
          description: 'احصل على مكافآت مقابل تميزك الأكاديمي',
          features: [
            '⭐ نقاط على الامتحانات',
            '🎁 حصص مجانية',
            '🏆 شهادات تقدير',
            '💎 مكافآت خاصة',
            '🔥 تحديات يومية',
            '🎯 أهداف وإنجازات'
          ],
          buttonText: 'عرض المكافآت',
          buttonAction: () => navigate('/student/rewards')
        };
      default:
        return {
          title: '🔍 الميزة غير موجودة',
          description: 'عذراً، هذه الميزة غير متاحة حالياً',
          features: [],
          buttonText: 'العودة للوحة التحكم',
          buttonAction: () => navigate('/student/dashboard')
        };
    }
  };

  const feature = getFeatureDetails();

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`} style={{
      backgroundImage: localStorage.getItem('appBackgroundImage') ? `url(${localStorage.getItem('appBackgroundImage')})` : undefined,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed'
    }}>
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/student/dashboard')}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">{feature.title}</h1>
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className="rounded-full hover:scale-110 transition-transform duration-300"
        >
          {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      <div className="container mx-auto px-4 py-8">
        {currentStudent && (
          <div className="mb-6">
            <Card className="p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-bold">مرحباً {currentStudent.fullName}</h3>
                  <p className="text-muted-foreground">رصيد المحفظة: {currentStudent.walletBalance || 0} جنيه</p>
                </div>
                <Badge className="bg-blue-100 text-blue-800">نشط</Badge>
              </div>
            </Card>
          </div>
        )}

        <div className="max-w-4xl mx-auto">
          <Card className="p-8 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
            <div className="text-center mb-8">
              <div className="text-6xl mb-4">
                {featureId === 'paid-lessons' && '💡'}
                {featureId === 'subscriptions' && '🧾'}
                {featureId === 'books' && '📚'}
                {featureId === 'support' && '🛠️'}
                {featureId === 'wallet' && '💳'}
                {featureId === 'activity' && '📑'}
                {featureId === 'notifications' && '🛎️'}
                {featureId === 'rewards' && '🎁'}
              </div>
              <h2 className="text-3xl font-bold text-primary mb-4">{feature.title}</h2>
              <p className="text-xl text-muted-foreground">{feature.description}</p>
            </div>

            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {feature.features.map((featureItem, index) => (
                <div key={index} className="flex items-center space-x-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <div className="text-2xl">{featureItem.split(' ')[0]}</div>
                  <span className="font-medium">{featureItem.substring(featureItem.indexOf(' ') + 1)}</span>
                </div>
              ))}
            </div>

            <div className="text-center">
              <Button
                size="lg"
                onClick={feature.buttonAction}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 text-lg"
              >
                {feature.buttonText}
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default StudentFeatureDetail;
