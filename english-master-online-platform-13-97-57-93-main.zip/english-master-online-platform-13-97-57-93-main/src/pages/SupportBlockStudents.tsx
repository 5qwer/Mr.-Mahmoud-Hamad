import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Search, Shield, ShieldX, User, AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const SupportBlockStudents = () => {
  const [students, setStudents] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('all');
  
  const navigate = useNavigate();

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = async () => {
    try {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في تحميل الطلاب:', error);
        toast.error('فشل في تحميل قائمة الطلاب');
        return;
      }

      setStudents(data || []);
    } catch (error) {
      console.error('خطأ عام في تحميل الطلاب:', error);
      toast.error('حدث خطأ في تحميل الطلاب');
    }
  };


  const filteredStudents = students.filter(student => {
    const matchesSearch = student.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (student.email && student.email.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesGrade = selectedGrade === 'all' || student.grade === selectedGrade;
    return matchesSearch && matchesGrade;
  });

  const blockStudent = async (studentId: string, studentName: string) => {
    const reason = prompt(`سبب حظر الطالب "${studentName}":`);
    if (!reason || !reason.trim()) return;

    if (confirm(`هل أنت متأكد من حظر الطالب "${studentName}"؟\nالسبب: ${reason}`)) {
      try {
        const { data, error } = await supabase.rpc('toggle_student_block', {
          p_student_id: studentId,
          p_action: 'block',
          p_reason: reason.trim(),
          p_blocked_by: 'الدعم الفني'
        });

        if (error) {
          console.error('خطأ في حظر الطالب:', error);
          toast.error('فشل في حظر الطالب');
          return;
        }

        console.log('نتيجة حظر الطالب:', data);
        
        if (data && (data as any).success) {
          toast.success(`تم حظر الطالب "${studentName}" بنجاح`);
          loadStudents(); // إعادة تحميل القائمة
        } else {
          toast.error((data as any)?.message || 'فشل في حظر الطالب');
        }
      } catch (error) {
        console.error('خطأ عام في حظر الطالب:', error);
        toast.error('حدث خطأ في حظر الطالب');
      }
    }
  };

  const unblockStudent = async (studentId: string, studentName: string) => {
    if (confirm(`هل أنت متأكد من إلغاء حظر الطالب "${studentName}"؟`)) {
      try {
        const { data, error } = await supabase.rpc('toggle_student_block', {
          p_student_id: studentId,
          p_action: 'unblock',
          p_blocked_by: 'الدعم الفني'
        });

        if (error) {
          console.error('خطأ في إلغاء حظر الطالب:', error);
          toast.error('فشل في إلغاء حظر الطالب');
          return;
        }

        console.log('نتيجة إلغاء حظر الطالب:', data);
        
        if (data && (data as any).success) {
          toast.success(`تم إلغاء حظر الطالب "${studentName}" بنجاح`);
          loadStudents(); // إعادة تحميل القائمة
        } else {
          toast.error((data as any)?.message || 'فشل في إلغاء حظر الطالب');
        }
      } catch (error) {
        console.error('خطأ عام في إلغاء حظر الطالب:', error);
        toast.error('حدث خطأ في إلغاء حظر الطالب');
      }
    }
  };

  const isBlocked = (student: any) => student.is_blocked;

  const getGradeLabel = (grade: string) => {
    switch (grade) {
      case 'first': return 'الأول الثانوي العام';
      case 'second': return 'الثاني الثانوي العام';
      case 'third': return 'الثالث الثانوي العام';
      case '1': return 'الأول الثانوي العام';
      case '2': return 'الثاني الثانوي العام';
      case '3': return 'الثالث الثانوي العام';
      default: return grade;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-orange-50">
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/support/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">🚫 إدارة حظر الطلاب</h1>
        
        {/* Teacher Image */}
        <div className="mr-4">
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-blue-400 shadow-lg">
            <img 
              src="/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png" 
              alt="Mr. Mahmoud Hamad" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Search Section */}
        <Card className="p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Search className="w-5 h-5 text-gray-500" />
            <h2 className="text-lg font-bold">البحث عن الطلاب</h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            <Input
              placeholder="ابحث بالاسم أو الإيميل..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="text-right"
            />
            
            <Select value={selectedGrade} onValueChange={setSelectedGrade}>
              <SelectTrigger>
                <SelectValue placeholder="اختر الصف الدراسي" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الصفوف</SelectItem>
                <SelectItem value="first">الأول الثانوي العام</SelectItem>
                <SelectItem value="second">الثاني الثانوي العام</SelectItem>
                <SelectItem value="third">الثالث الثانوي العام</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </Card>

        {/* Students List */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <User className="w-5 h-5 text-blue-500" />
            <h3 className="text-lg font-bold">قائمة الطلاب</h3>
            <Badge variant="outline" className="mr-auto">
              المجموع: {filteredStudents.length}
            </Badge>
          </div>
          
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {filteredStudents.map((student) => (
              <div 
                key={student.id}
                className={`p-4 border rounded-lg transition-colors ${
                  isBlocked(student) 
                    ? 'bg-red-50 border-red-200' 
                    : 'bg-gray-50 hover:bg-gray-100'
                }`}
              >
                <div className="flex justify-between items-center">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className={`p-2 rounded-full ${
                        isBlocked(student) ? 'bg-red-100' : 'bg-blue-100'
                      }`}>
                        {isBlocked(student) ? 
                          <ShieldX className="w-4 h-4 text-red-600" /> : 
                          <Shield className="w-4 h-4 text-blue-600" />
                        }
                      </div>
                      <div>
                        <h4 className="font-bold text-lg">{student.full_name}</h4>
                        <p className="text-sm text-muted-foreground">{student.email || 'لا يوجد إيميل'}</p>
                        {isBlocked(student) && student.block_reason && (
                          <p className="text-sm text-red-600 mt-1">
                            السبب: {student.block_reason}
                          </p>
                        )}
                        {isBlocked(student) && student.blocked_at && (
                          <p className="text-xs text-red-500">
                            تاريخ الحظر: {new Date(student.blocked_at).toLocaleString('ar-EG')}
                          </p>
                        )}
                      </div>
                      {isBlocked(student) && (
                        <Badge variant="destructive" className="mr-2">
                          محظور
                        </Badge>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                      <span className="text-green-600">
                        الصف: {getGradeLabel(student.grade)}
                      </span>
                      <span className="text-blue-600">النقاط: {student.points || 0}</span>
                      <span className="text-purple-600">الرصيد: {student.wallet_balance || 0} جنيه</span>
                      <span className="text-orange-600">
                        التسجيل: {new Date(student.created_at || Date.now()).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex flex-col gap-2">
                    {isBlocked(student) ? (
                      <Button
                        onClick={() => unblockStudent(student.id, student.full_name)}
                        className="bg-green-600 hover:bg-green-700"
                        size="sm"
                      >
                        <Shield className="w-4 h-4 ml-2" />
                        إلغاء الحظر
                      </Button>
                    ) : (
                      <Button
                        onClick={() => blockStudent(student.id, student.full_name)}
                        variant="destructive"
                        size="sm"
                      >
                        <ShieldX className="w-4 h-4 ml-2" />
                        حظر الطالب
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {filteredStudents.length === 0 && (
              <div className="text-center py-12">
                <User className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <p className="text-muted-foreground text-lg">
                  {searchQuery || selectedGrade !== 'all' ? 'لا توجد نتائج للبحث' : 'لا توجد طلاب مسجلين'}
                </p>
              </div>
            )}
          </div>
        </Card>

        {/* Block Statistics */}
        <div className="mt-8 grid md:grid-cols-2 gap-6">
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <AlertTriangle className="w-6 h-6 text-yellow-500" />
              <h3 className="text-lg font-bold">إحصائيات الحظر</h3>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>إجمالي الطلاب:</span>
                <span className="font-bold">{students.length}</span>
              </div>
              <div className="flex justify-between">
                <span>الطلاب المحظورين:</span>
                <span className="font-bold text-red-600">{students.filter(s => s.is_blocked).length}</span>
              </div>
              <div className="flex justify-between">
                <span>الطلاب النشطين:</span>
                <span className="font-bold text-green-600">{students.filter(s => !s.is_blocked).length}</span>
              </div>
            </div>
          </Card>
          
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <Shield className="w-6 h-6 text-blue-500" />
              <h3 className="text-lg font-bold">آخر عمليات الحظر</h3>
            </div>
            
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {JSON.parse(localStorage.getItem('blockLogs') || '[]').slice(0, 5).map((log: any) => (
                <div key={log.id} className="p-2 bg-gray-50 rounded text-sm">
                  <p className="font-semibold">{log.studentName}</p>
                  <p className="text-muted-foreground">
                    {log.action === 'block' ? 'تم الحظر' : 'تم إلغاء الحظر'} - {new Date(log.timestamp).toLocaleString('ar-EG')}
                  </p>
                </div>
              ))}
              
              {JSON.parse(localStorage.getItem('blockLogs') || '[]').length === 0 && (
                <p className="text-muted-foreground text-center py-4">لا توجد عمليات حظر مسجلة</p>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SupportBlockStudents;
