
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Play, FileText, Download, Calendar, BookOpen, Clock } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';
import { supabaseDataManager } from '@/utils/supabaseDataManager';

interface Lesson {
  id: number;
  title: string;
  description: string;
  cover_image?: string;
  video_url?: string;
  pdf_url?: string;
  homework_url?: string;
  homework_video_url?: string;
  solution_url?: string;
  order_number: number;
}

interface Subscription {
  id: number;
  title: string;
  description: string;
  price: number;
  duration_days: number;
  coverImage?: string;
  lessons: Lesson[];
  expiresAt?: string;
  purchasedAt: string;
}

const StudentSubscriptionDetails = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { subscriptionId } = useParams();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    
    setCurrentStudent(student);
    loadSubscriptionDetails(student);
  }, [navigate, subscriptionId]);

  // إعادة تحميل البيانات عند التركيز على الصفحة
  useEffect(() => {
    const handleFocus = () => {
      if (currentStudent) {
        loadSubscriptionDetails(currentStudent);
      }
    };

    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, [currentStudent]);

  const loadSubscriptionDetails = async (student: any) => {
    if (!subscriptionId) return;
    
    try {
      setLoading(true);
      
      console.log('جاري تحميل تفاصيل الاشتراك للطالب:', student.id);
      
      // الحصول على اشتراكات الطالب
      const studentSubscriptions = await supabaseDataManager.getStudentSubscriptions(student.id);
      console.log('اشتراكات الطالب المسترجعة:', studentSubscriptions);
      
      // البحث عن الاشتراك المحدد
      const targetSubscription = studentSubscriptions.find(
        sub => sub.id === parseInt(subscriptionId)
      );
      
      if (!targetSubscription) {
        console.log('لم يتم العثور على الاشتراك المطلوب');
        toast.error('لم يتم العثور على الاشتراك أو أنك لم تشتريه');
        navigate('/student/subscriptions');
        return;
      }
      
      console.log('تم العثور على الاشتراك:', targetSubscription);
      console.log('حصص الاشتراك:', targetSubscription.lessons);
      
      // إضافة expiresAt إذا كانت مفقودة
      const subscriptionWithExpiry = {
        ...targetSubscription,
        expiresAt: targetSubscription.expiresAt || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      };
      
      setSubscription(subscriptionWithExpiry);
      
      if (!targetSubscription.lessons || targetSubscription.lessons.length === 0) {
        console.log('تحذير: لا توجد حصص مرتبطة بهذا الاشتراك');
      }
      
    } catch (error) {
      console.error('Error loading subscription details:', error);
      toast.error('فشل في تحميل تفاصيل الاشتراك');
    } finally {
      setLoading(false);
    }
  };

  const handleLessonClick = (lesson: Lesson) => {
    // حفظ معرف الحصة في localStorage للوصول إليه في صفحة عرض الحصة
    localStorage.setItem('currentLesson', JSON.stringify(lesson));
    navigate(`/student/lesson/${lesson.id}`);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getDaysRemaining = (expiresAt: string) => {
    const now = new Date();
    const expiry = new Date(expiresAt);
    const diffTime = expiry.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8">
          <p className="text-center text-muted-foreground">لم يتم العثور على الاشتراك</p>
        </Card>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/student/subscriptions')}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">📚 تفاصيل الاشتراك</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 space-y-6">
        {/* معلومات الاشتراك */}
        <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
          <div className="flex flex-col md:flex-row gap-6">
            <div className="md:w-1/3">
              {subscription.coverImage ? (
                <img 
                  src={subscription.coverImage} 
                  alt={subscription.title}
                  className="w-full h-48 object-cover rounded-lg"
                />
              ) : (
                <div className="w-full h-48 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-16 h-16 text-white" />
                </div>
              )}
            </div>
            
            <div className="md:w-2/3 space-y-4">
              <div>
                <h2 className="text-2xl font-bold mb-2">{subscription.title}</h2>
                <p className="text-muted-foreground text-lg">{subscription.description}</p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <BookOpen className="w-6 h-6 mx-auto mb-2 text-blue-500" />
                  <p className="text-sm text-muted-foreground">عدد الحصص</p>
                  <p className="font-bold text-lg">{subscription.lessons?.length || 0}</p>
                </div>
                
                <div className="text-center">
                  <Calendar className="w-6 h-6 mx-auto mb-2 text-green-500" />
                  <p className="text-sm text-muted-foreground">تاريخ الشراء</p>
                  <p className="font-bold text-sm">{formatDate(subscription.purchasedAt)}</p>
                </div>
                
                <div className="text-center">
                  <Clock className="w-6 h-6 mx-auto mb-2 text-orange-500" />
                  <p className="text-sm text-muted-foreground">ينتهي في</p>
                  <p className="font-bold text-sm">{subscription.expiresAt ? formatDate(subscription.expiresAt) : 'غير محدد'}</p>
                </div>
                
                <div className="text-center">
                  <div className="w-6 h-6 mx-auto mb-2">
                    <Badge className={`${subscription.expiresAt && getDaysRemaining(subscription.expiresAt) > 7 ? 'bg-green-500' : 'bg-orange-500'}`}>
                      {subscription.expiresAt ? getDaysRemaining(subscription.expiresAt) : 30} يوم
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">متبقي</p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* قائمة الحصص */}
        <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
          <h3 className="text-xl font-bold mb-6">📋 حصص الاشتراك</h3>
          
          {subscription.lessons && subscription.lessons.length > 0 ? (
            <div className="space-y-4">
              {subscription.lessons
                .sort((a, b) => (a.order_number || 0) - (b.order_number || 0))
                .map((lesson, index) => (
                  <Card 
                    key={lesson.id}
                    className={`p-4 hover:shadow-md transition-all cursor-pointer ${
                      isDarkMode ? 'bg-gray-700/50 hover:bg-gray-700' : 'bg-white hover:bg-gray-50'
                    }`}
                    onClick={() => handleLessonClick(lesson)}
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                          {lesson.order_number || index + 1}
                        </div>
                      </div>
                      
                      <div className="flex-1">
                        <h4 className="font-bold text-lg mb-1">{lesson.title}</h4>
                        <p className="text-muted-foreground text-sm mb-2">{lesson.description}</p>
                        
                        <div className="flex gap-4 text-xs">
                          {lesson.video_url && (
                            <div className="flex items-center gap-1 text-blue-500">
                              <Play className="w-3 h-3" />
                              <span>فيديو</span>
                            </div>
                          )}
                          {lesson.pdf_url && (
                            <div className="flex items-center gap-1 text-red-500">
                              <FileText className="w-3 h-3" />
                              <span>PDF</span>
                            </div>
                          )}
                          {lesson.homework_url && (
                            <div className="flex items-center gap-1 text-orange-500">
                              <Download className="w-3 h-3" />
                              <span>واجب</span>
                            </div>
                          )}
                          {lesson.solution_url && (
                            <div className="flex items-center gap-1 text-green-500">
                              <FileText className="w-3 h-3" />
                              <span>حلول</span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex-shrink-0">
                        <Button size="sm" variant="outline">
                          <Play className="w-4 h-4 mr-2" />
                          مشاهدة
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 mx-auto mb-4 text-muted-foreground/50" />
              <p className="text-muted-foreground text-lg">لا توجد حصص مرتبطة بهذا الاشتراك بعد</p>
              <p className="text-sm text-muted-foreground mt-2">تواصل مع المعلم لإضافة الحصص</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

export default StudentSubscriptionDetails;
