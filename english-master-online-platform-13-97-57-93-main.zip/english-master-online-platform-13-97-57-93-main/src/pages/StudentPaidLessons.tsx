import { useState, useEffect, useCallback } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Play, FileText, Download, MessageSquare, Lock, Unlock, RefreshCw, Video, BookOpen, Send } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { dataManager } from '@/utils/dataManager';
import { Textarea } from '@/components/ui/textarea';

interface Lesson {
  id: number;
  title: string;
  description: string;
  price: number;
  coverImage: string;
  videoUrl?: string;
  explanationVideo?: string;
  homeworkVideoUrl?: string;
  pdfUrl?: string;
  explanationFile?: string;
  homeworkUrl?: string;
  homework?: string;
  solutionUrl?: string;
  homeworkSolution?: string;
  isPurchased: boolean;
  isCompleted: boolean;
  grade: string;
  order: number;
}

const StudentPaidLessons = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [showContent, setShowContent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [questionText, setQuestionText] = useState('');
  const [sendingQuestion, setSendingQuestion] = useState(false);
  const navigate = useNavigate();

  const loadLessons = useCallback(() => {
    if (!currentStudent) return;
    
    setLoading(true);
    console.log('Loading lessons for student:', currentStudent);
    
    try {
      // Get all lessons and filter by student's grade
      const allLessons = JSON.parse(localStorage.getItem('lessons') || '[]');
      console.log('All lessons from localStorage:', allLessons);
      
      // Normalize grade for comparison
      const studentGrade = currentStudent.grade?.toString() || '1';
      const normalizedStudentGrade = studentGrade === 'first' ? '1' : 
                                   studentGrade === 'second' ? '2' : 
                                   studentGrade === 'third' ? '3' : studentGrade;
      
      console.log('Student grade:', normalizedStudentGrade);
      
      // Filter lessons by grade
      const studentLessons = allLessons.filter((lesson: any) => {
        const lessonGrade = lesson.grade?.toString() || '1';
        const normalizedLessonGrade = lessonGrade === 'first' ? '1' : 
                                    lessonGrade === 'second' ? '2' : 
                                    lessonGrade === 'third' ? '3' : lessonGrade;
        
        console.log('Comparing lesson grade:', normalizedLessonGrade, 'with student grade:', normalizedStudentGrade);
        return normalizedLessonGrade === normalizedStudentGrade;
      });
      
      console.log('Filtered lessons for student grade:', studentLessons);
      
      // Update purchase status based on student data
      const studentPurchasedLessons = currentStudent.purchasedLessons || [];
      console.log('Student purchased lessons:', studentPurchasedLessons);
      
      const updatedLessons = studentLessons.map((lesson: any) => ({
        ...lesson,
        // Map different video field names
        videoUrl: lesson.videoUrl || lesson.explanationVideo,
        pdfUrl: lesson.pdfUrl || lesson.explanationFile,
        homeworkUrl: lesson.homeworkUrl || lesson.homework,
        solutionUrl: lesson.solutionUrl || lesson.homeworkSolution,
        isPurchased: studentPurchasedLessons.includes(lesson.id.toString()) || 
                    lesson.isPurchased || 
                    true // All subscription lessons are free for subscribed users
      }));
      
      console.log('Updated lessons with purchase status:', updatedLessons);
      setLessons(updatedLessons);
      
      if (updatedLessons.length === 0) {
        console.log('No lessons found for grade:', normalizedStudentGrade);
        toast.info('لا توجد حصص متاحة لصفك الدراسي حالياً');
      }
    } catch (error) {
      console.error('Error loading lessons:', error);
      toast.error('فشل في تحميل الحصص');
    } finally {
      setLoading(false);
    }
  }, [currentStudent]);

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    console.log('Current student from localStorage:', student);
    
    if (!student) {
      navigate('/student/login');
      return;
    }
    
    setCurrentStudent(student);
  }, [navigate]);

  useEffect(() => {
    if (currentStudent) {
      loadLessons();
    }
  }, [currentStudent, loadLessons]);

  const handlePurchaseLesson = useCallback((lesson: Lesson) => {
    if (!currentStudent || loading) return;
    
    setLoading(true);
    console.log('Purchasing lesson:', lesson.id, 'for student:', currentStudent.id);
    
    try {
      const currentBalance = currentStudent.walletBalance || 0;
      console.log('Current balance:', currentBalance);
      
      // All subscription lessons are free for subscribed users

      // Update student data
      const updatedPurchasedLessons = [...(currentStudent.purchasedLessons || []), lesson.id.toString()];
      const updatedStudent = {
        ...currentStudent,
        purchasedLessons: updatedPurchasedLessons
      };
      
      // Save to localStorage
      localStorage.setItem('currentStudent', JSON.stringify(updatedStudent));
      
      // Update students array
      const students = JSON.parse(localStorage.getItem('students') || '[]');
      const updatedStudents = students.map((s: any) => 
        s.id === currentStudent.id ? updatedStudent : s
      );
      localStorage.setItem('students', JSON.stringify(updatedStudents));
      
      // Update lesson state
      const updatedLessons = lessons.map(l => 
        l.id === lesson.id ? { ...l, isPurchased: true } : l
      );
      
      setCurrentStudent(updatedStudent);
      setLessons(updatedLessons);
      
      // Add activity log
      dataManager.addActivityLog(
        currentStudent.id.toString(),
        'lesson_purchased',
        `تم شراء الحصة: ${lesson.title}`
      );
      
      toast.success(`✅ تم الوصول للحصة بنجاح!`);
      console.log('Lesson purchased successfully');
    } catch (error) {
      console.error('Error purchasing lesson:', error);
      toast.error('فشل في شراء الحصة');
    } finally {
      setLoading(false);
    }
  }, [currentStudent, lessons, loading]);

  const handleViewLesson = useCallback((lesson: Lesson) => {
    if (!lesson.isPurchased) {
      toast.error('يجب شراء الحصة أولاً');
      return;
    }
    console.log('Viewing lesson content:', lesson);
    setSelectedLesson(lesson);
    setShowContent(true);
  }, []);

  const handleSendQuestion = useCallback(async () => {
    if (!selectedLesson || !currentStudent || !questionText.trim()) {
      toast.error('يرجى كتابة السؤال أولاً');
      return;
    }
    
    setSendingQuestion(true);
    
    try {
      const message = {
        id: Date.now(),
        studentId: currentStudent.id,
        studentName: currentStudent.fullName,
        lessonId: selectedLesson.id,
        lessonTitle: selectedLesson.title,
        message: questionText.trim(),
        image: null,
        timestamp: new Date().toISOString(),
        replied: false
      };
      
      const messages = JSON.parse(localStorage.getItem('teacherMessages') || '[]');
      messages.unshift(message);
      localStorage.setItem('teacherMessages', JSON.stringify(messages));
      
      // Add activity log
      dataManager.addActivityLog(
        currentStudent.id.toString(),
        'question_sent',
        `تم إرسال سؤال للمعلم حول: ${selectedLesson.title}`
      );
      
      setQuestionText('');
      toast.success('تم إرسال السؤال للمعلم بنجاح');
      console.log('Question sent to teacher:', message);
    } catch (error) {
      console.error('Error sending question:', error);
      toast.error('فشل في إرسال السؤال');
    } finally {
      setSendingQuestion(false);
    }
  }, [selectedLesson, currentStudent, questionText]);

  const handleDownloadFile = (url: string, filename: string) => {
    if (!url) {
      toast.error('الملف غير متوفر');
      return;
    }
    
    try {
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success('تم بدء تحميل الملف');
    } catch (error) {
      console.error('Error downloading file:', error);
      toast.error('فشل في تحميل الملف');
    }
  };

  const handleStartExam = () => {
    if (!selectedLesson) return;
    
    // Add activity log
    dataManager.addActivityLog(
      currentStudent.id.toString(),
      'exam_started',
      `بدء امتحان: ${selectedLesson.title}`
    );
    
    toast.success('تم بدء الامتحان');
    // Here you would navigate to exam page or open exam modal
  };

  if (showContent && selectedLesson) {
    return (
      <div className={`min-h-screen transition-all duration-700 ${
        isDarkMode 
          ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
          : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
      }`}>
        <div className="flex items-center p-4 animate-fade-in">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setShowContent(false)}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">{selectedLesson.title}</h1>
        </div>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* فيديو الشرح */}
            {(selectedLesson.videoUrl || selectedLesson.explanationVideo) && (
              <Card className="p-6 animate-fade-in">
                <h3 className="text-lg font-bold mb-4 flex items-center">
                  <Video className="w-6 h-6 ml-2 text-blue-500" />
                  🎥 فيديو الشرح
                </h3>
                <div className="aspect-video bg-black rounded-lg overflow-hidden">
                  {(selectedLesson.videoUrl || selectedLesson.explanationVideo) ? (
                    <video 
                      controls 
                      className="w-full h-full"
                      poster={selectedLesson.coverImage}
                      onError={(e) => {
                        console.error('Video loading error:', e);
                        toast.error('خطأ في تحميل الفيديو');
                      }}
                    >
                      <source src={selectedLesson.videoUrl || selectedLesson.explanationVideo} type="video/mp4" />
                      <source src={selectedLesson.videoUrl || selectedLesson.explanationVideo} type="video/webm" />
                      <source src={selectedLesson.videoUrl || selectedLesson.explanationVideo} type="video/ogg" />
                      المتصفح لا يدعم تشغيل الفيديو
                    </video>
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-white">
                      <div className="text-center">
                        <Video className="w-16 h-16 mx-auto mb-4 opacity-50" />
                        <p>الفيديو غير متوفر</p>
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            )}

            {/* فيديو الواجب */}
            {selectedLesson.homeworkVideoUrl && (
              <Card className="p-6 animate-fade-in">
                <h3 className="text-lg font-bold mb-4 flex items-center">
                  <Video className="w-6 h-6 ml-2 text-green-500" />
                  📝 فيديو الواجب
                </h3>
                <div className="aspect-video bg-black rounded-lg overflow-hidden">
                  <video 
                    controls 
                    className="w-full h-full"
                    onError={(e) => {
                      console.error('Homework video loading error:', e);
                      toast.error('خطأ في تحميل فيديو الواجب');
                    }}
                  >
                    <source src={selectedLesson.homeworkVideoUrl} type="video/mp4" />
                    <source src={selectedLesson.homeworkVideoUrl} type="video/webm" />
                    <source src={selectedLesson.homeworkVideoUrl} type="video/ogg" />
                    المتصفح لا يدعم تشغيل الفيديو
                  </video>
                </div>
              </Card>
            )}

            {/* الملفات */}
            <div className="grid md:grid-cols-3 gap-4 animate-fade-in">
              {(selectedLesson.pdfUrl || selectedLesson.explanationFile) && (
                <Card className="p-4">
                  <div className="text-center">
                    <FileText className="w-12 h-12 mx-auto mb-2 text-blue-500" />
                    <h4 className="font-bold mb-2">ملف الشرح</h4>
                    <Button 
                      size="sm" 
                      className="w-full"
                      onClick={() => handleDownloadFile(
                        selectedLesson.pdfUrl || selectedLesson.explanationFile!, 
                        `${selectedLesson.title}_شرح.pdf`
                      )}
                    >
                      <Download className="w-4 h-4 ml-2" />
                      تحميل PDF
                    </Button>
                  </div>
                </Card>
              )}
              
              {(selectedLesson.homeworkUrl && selectedLesson.homeworkUrl !== selectedLesson.homework) && (
                <Card className="p-4">
                  <div className="text-center">
                    <FileText className="w-12 h-12 mx-auto mb-2 text-green-500" />
                    <h4 className="font-bold mb-2">ملف الواجب</h4>
                    <Button 
                      size="sm" 
                      className="w-full"
                      onClick={() => handleDownloadFile(selectedLesson.homeworkUrl!, `${selectedLesson.title}_واجب.pdf`)}
                    >
                      <Download className="w-4 h-4 ml-2" />
                      تحميل الواجب
                    </Button>
                  </div>
                </Card>
              )}
              
              {(selectedLesson.solutionUrl || selectedLesson.homeworkSolution) && (
                <Card className="p-4">
                  <div className="text-center">
                    <FileText className="w-12 h-12 mx-auto mb-2 text-purple-500" />
                    <h4 className="font-bold mb-2">حل الواجب</h4>
                    <Button 
                      size="sm" 
                      className="w-full"
                      onClick={() => handleDownloadFile(
                        selectedLesson.solutionUrl || selectedLesson.homeworkSolution!, 
                        `${selectedLesson.title}_حل.pdf`
                      )}
                    >
                      <Download className="w-4 h-4 ml-2" />
                      تحميل الحل
                    </Button>
                  </div>
                </Card>
              )}
            </div>

            {/* عرض الواجب النصي */}
            {selectedLesson.homework && (
              <Card className="p-6 animate-fade-in">
                <h3 className="text-lg font-bold mb-4 flex items-center">
                  <BookOpen className="w-6 h-6 ml-2 text-orange-500" />
                  📋 الواجب
                </h3>
                <div className="bg-orange-50 dark:bg-orange-900/20 p-4 rounded-lg">
                  <p className="text-lg leading-relaxed whitespace-pre-wrap">{selectedLesson.homework}</p>
                </div>
              </Card>
            )}

            {/* إرسال سؤال للمعلم */}
            <Card className="p-6 animate-fade-in">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <MessageSquare className="w-6 h-6 ml-2 text-blue-500" />
                💬 إرسال سؤال للمعلم
              </h3>
              <div className="space-y-4">
                <Textarea
                  placeholder="اكتب سؤالك هنا..."
                  value={questionText}
                  onChange={(e) => setQuestionText(e.target.value)}
                  className="min-h-[100px] resize-none"
                  maxLength={500}
                />
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">
                    {questionText.length}/500 حرف
                  </span>
                  <Button 
                    onClick={handleSendQuestion}
                    disabled={!questionText.trim() || sendingQuestion}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {sendingQuestion ? (
                      <>
                        <RefreshCw className="w-4 h-4 ml-2 animate-spin" />
                        جاري الإرسال...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 ml-2" />
                        إرسال السؤال
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </Card>

            {/* الإجراءات */}
            <div className="flex gap-4 animate-fade-in">
              <Button 
                onClick={handleStartExam}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                ابدأ الامتحان
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-all duration-700 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="flex items-center p-4 animate-fade-in">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/student/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">💡 الحصص المدفوعة</h1>
        <Button
          variant="outline"
          size="sm"
          onClick={loadLessons}
          disabled={loading}
          className="mr-auto"
        >
          <RefreshCw className={`h-4 w-4 ml-2 ${loading ? 'animate-spin' : ''}`} />
          تحديث
        </Button>
      </div>

      <div className="container mx-auto px-4 py-8">
        {currentStudent && (
          <div className="mb-6 animate-fade-in">
            <Card className="p-4 bg-white/90 backdrop-blur-sm">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-bold text-lg">مرحباً {currentStudent.fullName}</h3>
                  <p className="text-muted-foreground">
                    الصف: {currentStudent.grade === '1' || currentStudent.grade === 'first' ? 'الأول الثانوي العام' : 
                           currentStudent.grade === '2' || currentStudent.grade === 'second' ? 'الثاني الثانوي العام' : 
                           currentStudent.grade === '3' || currentStudent.grade === 'third' ? 'الثالث الثانوي العام' : 'غير محدد'}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">رصيد المحفظة</p>
                  <p className="text-2xl font-bold text-green-600">{currentStudent.walletBalance || 0} جنيه</p>
                </div>
              </div>
            </Card>
          </div>
        )}

        {loading ? (
          <div className="text-center py-12">
            <RefreshCw className="w-12 h-12 animate-spin mx-auto mb-4 text-primary" />
            <p className="text-muted-foreground">جاري تحميل الحصص...</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {lessons.map((lesson, index) => (
              <Card 
                key={lesson.id} 
                className="overflow-hidden hover:shadow-xl transition-all duration-500 bg-white/90 backdrop-blur-sm animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="aspect-video bg-gradient-to-r from-blue-500 to-purple-600 relative">
                  {lesson.coverImage ? (
                    <img
                      src={lesson.coverImage}
                      alt={lesson.title}
                      className="w-full h-full object-cover"
                      loading="lazy"
                      onError={(e) => {
                        console.error('Cover image loading error:', e);
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-white">
                      <Play className="w-16 h-16" />
                    </div>
                  )}
                  <div className="absolute top-2 right-2">
                    {lesson.isPurchased ? (
                      <Badge className="bg-green-500">
                        <Unlock className="w-3 h-3 ml-1" />
                        مشتراة
                      </Badge>
                    ) : (
                      <Badge variant="secondary">
                        <Lock className="w-3 h-3 ml-1" />
                        غير مشتراة
                      </Badge>
                    )}
                  </div>
                  <div className="absolute top-2 left-2">
                    <Badge className="bg-green-500">متاح للمشتركين</Badge>
                  </div>
                </div>
                
                <div className="p-4">
                  <h3 className="font-bold mb-2 text-lg">{lesson.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{lesson.description || 'لا يوجد وصف'}</p>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-xl font-bold text-green-600">
                      متاح للمشتركين
                    </span>
                    {lesson.isPurchased ? (
                      <Button 
                        onClick={() => handleViewLesson(lesson)} 
                        className="bg-blue-600 hover:bg-blue-700"
                        disabled={loading}
                      >
                        عرض الحصة
                      </Button>
                    ) : (
                      <Button 
                        onClick={() => handlePurchaseLesson(lesson)} 
                        className="bg-green-600 hover:bg-green-700"
                        disabled={loading}
                      >
                        {loading ? 'جاري الدخول...' : 'دخول للحصة'}
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {lessons.length === 0 && !loading && (
          <div className="text-center py-12 animate-fade-in">
            <Card className="p-8 bg-white/90 backdrop-blur-sm">
              <p className="text-muted-foreground text-lg">لا توجد حصص متاحة لصفك الدراسي حالياً</p>
              <p className="text-sm mt-2">تواصل مع المعلم لإضافة المزيد من الحصص</p>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentPaidLessons;
