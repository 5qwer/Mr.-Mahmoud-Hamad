import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, MessageCircle, Phone, Calendar, User } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const StudentBlocked = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [student, setStudent] = useState<any>(null);
  const [blockReason, setBlockReason] = useState('');
  const [blockedAt, setBlockedAt] = useState('');

  useEffect(() => {
    const state = location.state;
    if (!state || !state.student) {
      navigate('/student/login');
      return;
    }

    setStudent(state.student);
    setBlockReason(state.blockReason || 'غير محدد');
    setBlockedAt(state.blockedAt || new Date().toISOString());
  }, [location.state, navigate]);

  const handleContactSupport = async () => {
    if (!student) return;

    try {
      // إرسال رسالة تلقائية للدعم مع معلومات الطالب
      const autoMessage = `
🚫 طالب محظور يطلب المساعدة

📋 معلومات الطالب:
👤 الاسم: ${student.full_name}
🎓 الصف: ${getGradeLabel(student.grade)}
📞 رقم الطالب: ${student.student_number || 'غير محدد'}
📱 رقم ولي الأمر: ${student.parent_number || 'غير محدد'}
⛔ سبب الحظر: ${blockReason}
📅 تاريخ الحظر: ${new Date(blockedAt).toLocaleString('ar-EG')}

الطالب يطلب مراجعة حالة الحظر والتواصل معه.
      `.trim();

      const { data, error } = await supabase
        .from('support_messages_new')
        .insert([{
          student_id: student.id,
          student_name: student.full_name,
          message: autoMessage,
          status: 'pending'
        }])
        .select()
        .single();

      if (error) {
        console.error('خطأ في إرسال رسالة للدعم:', error);
        toast.error('فشل في إرسال الرسالة للدعم');
        return;
      }

      console.log('تم إرسال رسالة تلقائية للدعم:', data);
      toast.success('تم إرسال رسالة للدعم الفني، سيتم التواصل معك قريباً');
      
      // توجيه للدعم مع إرسال معرف الطالب
      navigate('/student/support', { 
        state: { 
          student: student,
          autoMessageSent: true 
        }
      });

    } catch (error) {
      console.error('خطأ عام في التواصل مع الدعم:', error);
      toast.error('حدث خطأ في التواصل مع الدعم');
    }
  };

  const getGradeLabel = (grade: string) => {
    switch (grade) {
      case 'first': case '1': return 'الأول الثانوي العام';
      case 'second': case '2': return 'الثاني الثانوي العام';
      case 'third': case '3': return 'الثالث الثانوي العام';
      default: return grade;
    }
  };

  if (!student) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-orange-50 flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-8 text-center shadow-2xl border-red-200">
        <div className="mb-6">
          <div className="w-20 h-20 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center">
            <Shield className="w-10 h-10 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-red-600 mb-2">⛔ تم حظر الحساب</h1>
          <p className="text-muted-foreground">
            لا يمكنك الوصول إلى الحساب في الوقت الحالي
          </p>
        </div>

        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 text-right">
          <h3 className="font-bold text-red-700 mb-3 flex items-center justify-center gap-2">
            <User className="w-4 h-4" />
            معلومات الحظر
          </h3>
          
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="font-semibold">الطالب:</span>
              <span>{student.full_name}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-semibold">الصف:</span>
              <span>{getGradeLabel(student.grade)}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-semibold">السبب:</span>
              <span className="text-red-600">{blockReason}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-semibold">التاريخ:</span>
              <span>{new Date(blockedAt).toLocaleDateString('ar-EG')}</span>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <Button 
            onClick={handleContactSupport}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3"
            size="lg"
          >
            <MessageCircle className="w-5 h-5 ml-2" />
            تواصل مع الدعم
          </Button>

          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">
              للمساعدة العاجلة، تواصل مباشرة:
            </p>
            <div className="flex items-center justify-center gap-4 text-sm">
              <a 
                href="tel:01050747978" 
                className="flex items-center gap-1 text-blue-600 hover:text-blue-700"
              >
                <Phone className="w-3 h-3" />
                01050747978
              </a>
            </div>
          </div>

          <Button 
            variant="outline" 
            onClick={() => navigate('/student/login')}
            className="w-full"
          >
            العودة لتسجيل الدخول
          </Button>
        </div>

        <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-700 text-center">
            💡 نصيحة: تأكد من قراءة قوانين المنصة وتجنب المخالفات لضمان استمرار الخدمة
          </p>
        </div>
      </Card>
    </div>
  );
};

export default StudentBlocked;