
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  Eye, 
  Upload,
  Moon, 
  Sun,
  Search,
  BookOpen,
  Play,
  FileText
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

interface SubscriptionLesson {
  id: number;
  title: string;
  description: string;
  coverImage: string;
  videoUrl: string;
  pdfUrl?: string;
  homeworkUrl?: string;
  homeworkVideoUrl?: string;
  solutionUrl?: string;
  questions: ExamQuestion[];
  order: number;
}

interface ExamQuestion {
  id?: number;
  question: string;
  options: string[];
  correctAnswer: number;
}

interface Subscription {
  id: number;
  title: string;
  description: string;
  price: number;
  duration: string;
  coverImage: string;
  lessons: SubscriptionLesson[];
  grade: string;
  isPurchased: boolean;
  expiryDate?: string;
  createdAt: string;
}

const TeacherManageSubscriptions = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [backgroundImage, setBackgroundImage] = useState('');
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [selectedGrade, setSelectedGrade] = useState('1');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSubscriptionForm, setShowSubscriptionForm] = useState(false);
  const [editingSubscription, setEditingSubscription] = useState<Subscription | null>(null);
  const [selectedSubscription, setSelectedSubscription] = useState<Subscription | null>(null);
  const [showLessonForm, setShowLessonForm] = useState(false);
  const [editingLesson, setEditingLesson] = useState<SubscriptionLesson | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{[key: string]: number}>({});

  const [subscriptionData, setSubscriptionData] = useState({
    title: '',
    description: '',
    price: '',
    duration: '',
    coverImage: '',
    grade: '1'
  });

  const [lessonData, setLessonData] = useState({
    title: '',
    description: '',
    coverImage: '',
    videoUrl: '',
    pdfUrl: '',
    homeworkUrl: '',
    homeworkVideoUrl: '',
    solutionUrl: '',
    questions: [] as ExamQuestion[],
    order: 1
  });

  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const isDark = savedTheme === 'dark';
    setIsDarkMode(isDark);
    document.documentElement.classList.toggle('dark', isDark);
    
    const savedBackground = localStorage.getItem('appBackgroundImage');
    if (savedBackground) {
      setBackgroundImage(savedBackground);
    }

    loadSubscriptions();
  }, []);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', newTheme);
  };

  const loadSubscriptions = () => {
    const subs = JSON.parse(localStorage.getItem('subscriptions') || '[]');
    setSubscriptions(subs);
  };

  const filteredSubscriptions = subscriptions.filter(sub => 
    sub.grade === selectedGrade && 
    sub.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, field: string, isLesson = false) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    
    reader.onloadstart = () => {
      setUploadProgress(prev => ({...prev, [field]: 0}));
      toast.success(`بدء رفع ${field}...`);
    };
    
    reader.onprogress = (e) => {
      if (e.lengthComputable) {
        const percentComplete = Math.round((e.loaded / e.total) * 100);
        setUploadProgress(prev => ({...prev, [field]: percentComplete}));
      }
    };
    
    reader.onload = (e) => {
      const result = e.target?.result as string;
      
      if (isLesson) {
        setLessonData(prev => ({...prev, [field]: result}));
      } else {
        setSubscriptionData(prev => ({...prev, [field]: result}));
      }
      
      setUploadProgress(prev => {
        const newProgress = {...prev};
        delete newProgress[field];
        return newProgress;
      });
      
      toast.success(`✅ تم رفع ${field} بنجاح`);
    };
    
    reader.onerror = () => {
      setUploadProgress(prev => {
        const newProgress = {...prev};
        delete newProgress[field];
        return newProgress;
      });
      toast.error(`فشل في رفع ${field}`);
    };
    
    reader.readAsDataURL(file);
  };

  const handleSaveSubscription = () => {
    if (!subscriptionData.title.trim()) {
      toast.error('يرجى إدخال عنوان الاشتراك');
      return;
    }
    
    if (!subscriptionData.price || parseInt(subscriptionData.price) <= 0) {
      toast.error('يرجى إدخال سعر صحيح');
      return;
    }

    const newSubscription: Subscription = {
      id: editingSubscription?.id || Date.now(),
      title: subscriptionData.title,
      description: subscriptionData.description,
      price: parseInt(subscriptionData.price),
      duration: subscriptionData.duration,
      coverImage: subscriptionData.coverImage,
      grade: subscriptionData.grade,
      lessons: editingSubscription?.lessons || [],
      isPurchased: false,
      createdAt: editingSubscription?.createdAt || new Date().toISOString()
    };

    let updatedSubscriptions;
    if (editingSubscription) {
      updatedSubscriptions = subscriptions.map(sub => 
        sub.id === editingSubscription.id ? newSubscription : sub
      );
      toast.success('تم تحديث الاشتراك بنجاح');
    } else {
      updatedSubscriptions = [...subscriptions, newSubscription];
      toast.success('تم إضافة الاشتراك بنجاح');
    }

    localStorage.setItem('subscriptions', JSON.stringify(updatedSubscriptions));
    setSubscriptions(updatedSubscriptions);
    resetSubscriptionForm();
  };

  const handleSaveLesson = () => {
    if (!lessonData.title.trim()) {
      toast.error('يرجى إدخال عنوان الحصة');
      return;
    }
    
    if (!lessonData.videoUrl.trim()) {
      toast.error('يرجى رفع فيديو الشرح');
      return;
    }

    if (!selectedSubscription) return;

    const newLesson: SubscriptionLesson = {
      id: editingLesson?.id || Date.now(),
      title: lessonData.title,
      description: lessonData.description,
      coverImage: lessonData.coverImage,
      videoUrl: lessonData.videoUrl,
      pdfUrl: lessonData.pdfUrl,
      homeworkUrl: lessonData.homeworkUrl,
      homeworkVideoUrl: lessonData.homeworkVideoUrl,
      solutionUrl: lessonData.solutionUrl,
      questions: lessonData.questions,
      order: lessonData.order
    };

    const updatedSubscription = {
      ...selectedSubscription,
      lessons: editingLesson 
        ? selectedSubscription.lessons.map(lesson => 
            lesson.id === editingLesson.id ? newLesson : lesson
          )
        : [...selectedSubscription.lessons, newLesson]
    };

    const updatedSubscriptions = subscriptions.map(sub => 
      sub.id === selectedSubscription.id ? updatedSubscription : sub
    );

    localStorage.setItem('subscriptions', JSON.stringify(updatedSubscriptions));
    setSubscriptions(updatedSubscriptions);
    setSelectedSubscription(updatedSubscription);
    resetLessonForm();
    
    toast.success(editingLesson ? 'تم تحديث الحصة بنجاح' : 'تم إضافة الحصة بنجاح');
  };

  const resetSubscriptionForm = () => {
    setSubscriptionData({
      title: '',
      description: '',
      price: '',
      duration: '',
      coverImage: '',
      grade: '1'
    });
    setEditingSubscription(null);
    setShowSubscriptionForm(false);
  };

  const resetLessonForm = () => {
    setLessonData({
      title: '',
      description: '',
      coverImage: '',
      videoUrl: '',
      pdfUrl: '',
      homeworkUrl: '',
      homeworkVideoUrl: '',
      solutionUrl: '',
      questions: [],
      order: 1
    });
    setEditingLesson(null);
    setShowLessonForm(false);
  };

  const addQuestion = () => {
    const newQuestion: ExamQuestion = {
      question: '',
      options: ['', '', '', ''],
      correctAnswer: 0
    };
    
    setLessonData(prev => ({
      ...prev,
      questions: [...prev.questions, newQuestion]
    }));
  };

  const updateQuestion = (index: number, field: keyof ExamQuestion, value: string | string[] | number) => {
    setLessonData(prev => {
      const updatedQuestions = [...prev.questions];
      
      if (field === 'options' && Array.isArray(value)) {
        updatedQuestions[index].options = value;
      } else if (field === 'question' && typeof value === 'string') {
        updatedQuestions[index].question = value;
      } else if (field === 'correctAnswer' && typeof value === 'number') {
        updatedQuestions[index].correctAnswer = value;
      }
      
      return {...prev, questions: updatedQuestions};
    });
  };

  const removeQuestion = (index: number) => {
    setLessonData(prev => ({
      ...prev,
      questions: prev.questions.filter((_, i) => i !== index)
    }));
  };

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900' 
        : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
    }`}
      style={{
        backgroundImage: backgroundImage ? `url(${backgroundImage})` : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="flex justify-between items-center p-6 animate-fade-in">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/teacher/dashboard')}
            className={`rounded-xl ml-4 transition-all duration-300 hover:scale-110 border-2 ${
              isDarkMode 
                ? 'border-purple-400 hover:border-purple-300 hover:bg-purple-900/50' 
                : 'border-indigo-300 hover:border-indigo-400 hover:bg-indigo-50'
            }`}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className={`text-2xl font-bold ${
            isDarkMode ? 'text-white' : 'text-slate-800'
          }`}>
            📋 إدارة الاشتراكات
          </h1>
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className={`rounded-xl transition-all duration-300 hover:scale-110 border-2 ${
            isDarkMode 
              ? 'border-yellow-400 hover:border-yellow-300 hover:bg-yellow-900/30' 
              : 'border-orange-300 hover:border-orange-400 hover:bg-orange-50'
          }`}
        >
          {isDarkMode ? <Sun className="h-5 w-5 text-yellow-400" /> : <Moon className="h-5 w-5 text-orange-500" />}
        </Button>
      </div>

      <div className="container mx-auto px-6 py-8">
        <Tabs defaultValue="view" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="view" className="hover-lift">عرض الاشتراكات</TabsTrigger>
            <TabsTrigger value="create" className="hover-lift">إنشاء اشتراك</TabsTrigger>
          </TabsList>

          <TabsContent value="view" className="space-y-6">
            {/* فلاتر البحث */}
            <Card className={`p-8 shadow-xl border-0 transition-all duration-300 hover:shadow-2xl ${
              isDarkMode 
                ? 'bg-gradient-to-r from-slate-800/90 to-purple-800/90 backdrop-blur-lg' 
                : 'bg-gradient-to-r from-white/90 to-indigo-50/90 backdrop-blur-lg'
            }`}>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-base font-semibold">اختيار الصف</Label>
                  <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                    <SelectTrigger className="text-base">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">الأول الثانوي</SelectItem>
                      <SelectItem value="2">الثاني الثانوي</SelectItem>
                      <SelectItem value="3">الثالث الثانوي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-base font-semibold">البحث عن اشتراك</Label>
                  <div className="relative">
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      placeholder="اكتب اسم الاشتراك..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="text-right pr-10 text-base"
                    />
                  </div>
                </div>
              </div>
            </Card>

            {/* قائمة الاشتراكات */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSubscriptions.map((subscription, index) => (
                <Card 
                  key={subscription.id} 
                  className={`overflow-hidden hover:shadow-xl transition-all duration-300 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm hover-lift animate-scale-in`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="aspect-video bg-gradient-to-r from-blue-500 to-purple-600 relative">
                    {subscription.coverImage ? (
                      <img 
                        src={subscription.coverImage} 
                        alt={subscription.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center text-white">
                          <BookOpen className="w-16 h-16 mx-auto mb-2" />
                          <h3 className="text-lg font-bold">{subscription.title}</h3>
                        </div>
                      </div>
                    )}
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-green-500">
                        {subscription.lessons.length} حصة
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="p-4">
                    <h3 className="text-lg font-bold mb-2 text-shadow-sm">{subscription.title}</h3>
                    <p className="text-muted-foreground text-sm mb-3">{subscription.description}</p>
                    
                    <div className="space-y-2 mb-4 text-sm">
                      <div className="flex justify-between">
                        <span>السعر:</span>
                        <span className="font-bold text-green-600">{subscription.price} جنيه</span>
                      </div>
                      <div className="flex justify-between">
                        <span>المدة:</span>
                        <span>{subscription.duration} يوم</span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => setSelectedSubscription(subscription)}
                        className="flex-1 hover-lift"
                      >
                        <Eye className="w-4 h-4 ml-1" />
                        عرض
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSubscriptionData({
                            title: subscription.title,
                            description: subscription.description,
                            price: subscription.price.toString(),
                            duration: subscription.duration,
                            coverImage: subscription.coverImage,
                            grade: subscription.grade
                          });
                          setEditingSubscription(subscription);
                          setShowSubscriptionForm(true);
                        }}
                        className="hover-lift"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {filteredSubscriptions.length === 0 && (
              <div className="text-center py-12 animate-fade-in">
                <Card className={`p-8 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm`}>
                  <p className="text-muted-foreground text-lg">
                    {searchQuery ? 
                      `لا توجد اشتراكات تحتوي على "${searchQuery}"` : 
                      'لا توجد اشتراكات للصف المحدد'
                    }
                  </p>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="create" className="space-y-6">
            <Card className={`p-6 ${isDarkMode ? 'bg-gray-800/90' : 'bg-white/90'} backdrop-blur-sm animate-slide-in hover-lift`}>
              <h2 className="text-xl font-bold mb-6 text-shadow-sm">
                {editingSubscription ? 'تعديل الاشتراك' : 'إنشاء اشتراك جديد'}
              </h2>
              
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-base font-semibold">عنوان الاشتراك *</Label>
                    <Input
                      value={subscriptionData.title}
                      onChange={(e) => setSubscriptionData(prev => ({...prev, title: e.target.value}))}
                      placeholder="أدخل عنوان الاشتراك"
                      className="text-base"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-base font-semibold">السعر (جنيه) *</Label>
                    <Input
                      type="number"
                      value={subscriptionData.price}
                      onChange={(e) => setSubscriptionData(prev => ({...prev, price: e.target.value}))}
                      placeholder="0"
                      className="text-base"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-base font-semibold">المدة (بالأيام) *</Label>
                    <Input
                      type="number"
                      value={subscriptionData.duration}
                      onChange={(e) => setSubscriptionData(prev => ({...prev, duration: e.target.value}))}
                      placeholder="30"
                      className="text-base"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-base font-semibold">الصف الدراسي *</Label>
                    <Select 
                      value={subscriptionData.grade} 
                      onValueChange={(value) => setSubscriptionData(prev => ({...prev, grade: value}))}
                    >
                      <SelectTrigger className="text-base">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">الأول الثانوي</SelectItem>
                        <SelectItem value="2">الثاني الثانوي</SelectItem>
                        <SelectItem value="3">الثالث الثانوي</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-semibold">وصف الاشتراك</Label>
                  <Textarea
                    value={subscriptionData.description}
                    onChange={(e) => setSubscriptionData(prev => ({...prev, description: e.target.value}))}
                    placeholder="أدخل وصف الاشتراك"
                    rows={3}
                    className="text-base"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-semibold">صورة الغلاف</Label>
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleFileUpload(e, 'coverImage')}
                    className="text-base"
                  />
                  {uploadProgress.coverImage !== undefined && (
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                        style={{width: `${uploadProgress.coverImage}%`}}
                      ></div>
                    </div>
                  )}
                  {subscriptionData.coverImage && uploadProgress.coverImage === undefined && (
                    <div className="mt-2">
                      <p className="text-sm text-green-600 mb-2">✅ تم رفع صورة الغلاف</p>
                      <img 
                        src={subscriptionData.coverImage} 
                        alt="صورة الغلاف" 
                        className="w-20 h-20 object-cover rounded" 
                      />
                    </div>
                  )}
                </div>

                <div className="flex gap-4">
                  <Button 
                    onClick={handleSaveSubscription}
                    className="flex-1 hover-lift"
                    disabled={isUploading}
                  >
                    <Save className="w-4 h-4 ml-2" />
                    {editingSubscription ? 'تحديث الاشتراك' : 'حفظ الاشتراك'}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={resetSubscriptionForm}
                    className="hover-lift"
                  >
                    إلغاء
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* نافذة عرض تفاصيل الاشتراك وإدارة الحصص */}
        {selectedSubscription && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 animate-fade-in">
            <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg p-6 max-w-6xl w-full max-h-[90vh] overflow-y-auto animate-scale-in`}>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-shadow-sm">{selectedSubscription.title}</h2>
                <Button variant="outline" onClick={() => setSelectedSubscription(null)}>
                  إغلاق
                </Button>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <h3 className="font-bold mb-2">تفاصيل الاشتراك</h3>
                  <p className="text-muted-foreground mb-2">{selectedSubscription.description}</p>
                  <div className="space-y-1 text-sm">
                    <p><span className="font-semibold">السعر:</span> {selectedSubscription.price} جنيه</p>
                    <p><span className="font-semibold">المدة:</span> {selectedSubscription.duration} يوم</p>
                    <p><span className="font-semibold">عدد الحصص:</span> {selectedSubscription.lessons.length}</p>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <Button 
                    onClick={() => setShowLessonForm(true)}
                    className="flex items-center gap-2 hover-lift"
                  >
                    <Plus className="w-4 h-4" />
                    إضافة حصة جديدة
                  </Button>
                </div>
              </div>

              {/* قائمة الحصص */}
              <div className="space-y-4">
                <h3 className="text-lg font-bold">حصص الاشتراك</h3>
                
                {selectedSubscription.lessons.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">لا توجد حصص في هذا الاشتراك</p>
                    <Button 
                      onClick={() => setShowLessonForm(true)}
                      className="mt-4 hover-lift"
                    >
                      إضافة أول حصة
                    </Button>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 gap-4">
                    {selectedSubscription.lessons
                      .sort((a, b) => a.order - b.order)
                      .map((lesson, index) => (
                        <Card 
                          key={lesson.id} 
                          className={`p-4 ${isDarkMode ? 'bg-gray-700/50' : 'bg-gray-50'} hover-lift animate-scale-in`}
                          style={{ animationDelay: `${index * 0.1}s` }}
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div className="flex-1">
                              <h4 className="font-bold text-shadow-sm">{lesson.title}</h4>
                              <p className="text-sm text-muted-foreground">{lesson.description}</p>
                              <div className="flex gap-4 mt-2 text-xs">
                                <span>الترتيب: {lesson.order}</span>
                                <span>الأسئلة: {lesson.questions.length}</span>
                              </div>
                            </div>
                            
                            <div className="flex gap-1">
                              {lesson.videoUrl && <Play className="w-4 h-4 text-green-500" />}
                              {lesson.pdfUrl && <FileText className="w-4 h-4 text-blue-500" />}
                            </div>
                          </div>
                          
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setLessonData({
                                  title: lesson.title,
                                  description: lesson.description,
                                  coverImage: lesson.coverImage,
                                  videoUrl: lesson.videoUrl,
                                  pdfUrl: lesson.pdfUrl || '',
                                  homeworkUrl: lesson.homeworkUrl || '',
                                  homeworkVideoUrl: lesson.homeworkVideoUrl || '',
                                  solutionUrl: lesson.solutionUrl || '',
                                  questions: lesson.questions,
                                  order: lesson.order
                                });
                                setEditingLesson(lesson);
                                setShowLessonForm(true);
                              }}
                              className="flex-1 hover-lift"
                            >
                              <Edit className="w-3 h-3 ml-1" />
                              تعديل
                            </Button>
                            
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => {
                                if (confirm('هل أنت متأكد من حذف هذه الحصة؟')) {
                                  const updatedSubscription = {
                                    ...selectedSubscription,
                                    lessons: selectedSubscription.lessons.filter(l => l.id !== lesson.id)
                                  };
                                  
                                  const updatedSubscriptions = subscriptions.map(sub => 
                                    sub.id === selectedSubscription.id ? updatedSubscription : sub
                                  );
                                  
                                  localStorage.setItem('subscriptions', JSON.stringify(updatedSubscriptions));
                                  setSubscriptions(updatedSubscriptions);
                                  setSelectedSubscription(updatedSubscription);
                                  toast.success('تم حذف الحصة بنجاح');
                                }
                              }}
                              className="hover-lift"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </Card>
                      ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* نافذة إضافة/تعديل الحصة */}
        {showLessonForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 animate-fade-in">
            <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto animate-scale-in`}>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-shadow-sm">
                  {editingLesson ? 'تعديل الحصة' : 'إضافة حصة جديدة'}
                </h2>
                <Button variant="outline" onClick={resetLessonForm}>
                  إغلاق
                </Button>
              </div>

              <div className="space-y-6">
                {/* البيانات الأساسية */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-base font-semibold">عنوان الحصة *</Label>
                    <Input
                      value={lessonData.title}
                      onChange={(e) => setLessonData(prev => ({...prev, title: e.target.value}))}
                      placeholder="أدخل عنوان الحصة"
                      className="text-base"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-base font-semibold">ترتيب الحصة</Label>
                    <Input
                      type="number"
                      value={lessonData.order}
                      onChange={(e) => setLessonData(prev => ({...prev, order: parseInt(e.target.value) || 1}))}
                      className="text-base"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-semibold">وصف الحصة</Label>
                  <Textarea
                    value={lessonData.description}
                    onChange={(e) => setLessonData(prev => ({...prev, description: e.target.value}))}
                    placeholder="أدخل وصف الحصة"
                    rows={3}
                    className="text-base"
                  />
                </div>

                {/* رفع الملفات */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-base font-semibold">صورة الغلاف</Label>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'coverImage', true)}
                      className="text-base"
                    />
                    {uploadProgress.coverImage !== undefined && (
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                          style={{width: `${uploadProgress.coverImage}%`}}
                        ></div>
                      </div>
                    )}
                    {lessonData.coverImage && uploadProgress.coverImage === undefined && (
                      <p className="text-sm text-green-600">✅ تم رفع صورة الغلاف</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-base font-semibold">فيديو الشرح *</Label>
                    <Input
                      type="file"
                      accept="video/*"
                      onChange={(e) => handleFileUpload(e, 'videoUrl', true)}
                      className="text-base"
                    />
                    {uploadProgress.videoUrl !== undefined && (
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full transition-all duration-300" 
                          style={{width: `${uploadProgress.videoUrl}%`}}
                        ></div>
                      </div>
                    )}
                    {lessonData.videoUrl && uploadProgress.videoUrl === undefined && (
                      <p className="text-sm text-green-600">✅ تم رفع فيديو الشرح</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-base font-semibold">ملف PDF للشرح</Label>
                    <Input
                      type="file"
                      accept=".pdf"
                      onChange={(e) => handleFileUpload(e, 'pdfUrl', true)}
                      className="text-base"
                    />
                    {uploadProgress.pdfUrl !== undefined && (
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                          style={{width: `${uploadProgress.pdfUrl}%`}}
                        ></div>
                      </div>
                    )}
                    {lessonData.pdfUrl && uploadProgress.pdfUrl === undefined && (
                      <p className="text-sm text-green-600">✅ تم رفع ملف PDF</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-base font-semibold">فيديو الواجب</Label>
                    <Input
                      type="file"
                      accept="video/*"
                      onChange={(e) => handleFileUpload(e, 'homeworkVideoUrl', true)}
                      className="text-base"
                    />
                    {uploadProgress.homeworkVideoUrl !== undefined && (
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-purple-600 h-2 rounded-full transition-all duration-300" 
                          style={{width: `${uploadProgress.homeworkVideoUrl}%`}}
                        ></div>
                      </div>
                    )}
                    {lessonData.homeworkVideoUrl && uploadProgress.homeworkVideoUrl === undefined && (
                      <p className="text-sm text-green-600">✅ تم رفع فيديو الواجب</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-base font-semibold">ملف الواجب PDF</Label>
                    <Input
                      type="file"
                      accept=".pdf"
                      onChange={(e) => handleFileUpload(e, 'homeworkUrl', true)}
                      className="text-base"
                    />
                    {uploadProgress.homeworkUrl !== undefined && (
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-orange-600 h-2 rounded-full transition-all duration-300" 
                          style={{width: `${uploadProgress.homeworkUrl}%`}}
                        ></div>
                      </div>
                    )}
                    {lessonData.homeworkUrl && uploadProgress.homeworkUrl === undefined && (
                      <p className="text-sm text-green-600">✅ تم رفع ملف الواجب</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-base font-semibold">ملف حل الواجب PDF</Label>
                    <Input
                      type="file"
                      accept=".pdf"
                      onChange={(e) => handleFileUpload(e, 'solutionUrl', true)}
                      className="text-base"
                    />
                    {uploadProgress.solutionUrl !== undefined && (
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-red-600 h-2 rounded-full transition-all duration-300" 
                          style={{width: `${uploadProgress.solutionUrl}%`}}
                        ></div>
                      </div>
                    )}
                    {lessonData.solutionUrl && uploadProgress.solutionUrl === undefined && (
                      <p className="text-sm text-green-600">✅ تم رفع ملف الحل</p>
                    )}
                  </div>
                </div>

                {/* قسم الأسئلة */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-bold">أسئلة الامتحان</h3>
                    <Button 
                      type="button" 
                      onClick={addQuestion} 
                      variant="outline" 
                      size="sm"
                      className="hover-lift"
                    >
                      <Plus className="w-4 h-4 ml-2" />
                      إضافة سؤال
                    </Button>
                  </div>

                  {lessonData.questions.map((question, index) => (
                    <div key={index} className={`border rounded-lg p-4 ${isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'}`}>
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-semibold">السؤال {index + 1}</h4>
                        <Button
                          type="button"
                          onClick={() => removeQuestion(index)}
                          variant="destructive"
                          size="sm"
                          className="hover-lift"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="space-y-3">
                        <Input
                          placeholder="اكتب السؤال هنا"
                          value={question.question}
                          onChange={(e) => updateQuestion(index, 'question', e.target.value)}
                          className="text-right text-base"
                        />

                        <div className="grid grid-cols-2 gap-2">
                          {question.options.map((option, optionIndex) => (
                            <div key={optionIndex} className="flex items-center space-x-2">
                              <Input
                                placeholder={`الخيار ${optionIndex + 1}`}
                                value={option}
                                onChange={(e) => {
                                  const newOptions = [...question.options];
                                  newOptions[optionIndex] = e.target.value;
                                  updateQuestion(index, 'options', newOptions);
                                }}
                                className="text-right flex-1 text-base"
                              />
                              <input
                                type="radio"
                                name={`question-${index}`}
                                checked={question.correctAnswer === optionIndex}
                                onChange={() => updateQuestion(index, 'correctAnswer', optionIndex)}
                                className="ml-2"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-4">
                  <Button 
                    onClick={handleSaveLesson}
                    className="flex-1 hover-lift"
                    disabled={isUploading}
                  >
                    <Save className="w-4 h-4 ml-2" />
                    {editingLesson ? 'تحديث الحصة' : 'حفظ الحصة'}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={resetLessonForm}
                    className="hover-lift"
                  >
                    إلغاء
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeacherManageSubscriptions;
