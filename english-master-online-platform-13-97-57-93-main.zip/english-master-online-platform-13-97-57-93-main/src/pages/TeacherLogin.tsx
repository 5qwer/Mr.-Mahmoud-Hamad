
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, UserCheck, Eye, EyeOff } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const TeacherLogin = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    loginCode: '',
    loginNumber: ''
  });
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    // Clear any existing dummy data
    localStorage.removeItem('dummyData');
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('تجربة تسجيل الدخول بالبيانات:', formData);
    
    if (!formData.name || !formData.loginCode || !formData.loginNumber) {
      toast.error('يرجى ملء جميع الحقول');
      return;
    }

    // التحقق من بيانات المعلم مع تسجيل مفصل
    console.log('التحقق من البيانات:');
    console.log('الاسم المدخل:', formData.name);
    console.log('الكود المدخل:', formData.loginCode);
    console.log('الرقم المدخل:', formData.loginNumber);
    
    const correctName = 'Mahmoud';
    const correctCode = 'HHDV/58HR';
    const correctNumber = '01050747978';
    
    console.log('البيانات المطلوبة:');
    console.log('الاسم المطلوب:', correctName);
    console.log('الكود المطلوب:', correctCode);
    console.log('الرقم المطلوب:', correctNumber);
    
    // التحقق مع إزالة المسافات الإضافية
    const nameMatch = formData.name.trim() === correctName;
    const codeMatch = formData.loginCode.trim() === correctCode;
    const numberMatch = formData.loginNumber.trim() === correctNumber;
    
    console.log('نتائج المقارنة:');
    console.log('الاسم صحيح:', nameMatch);
    console.log('الكود صحيح:', codeMatch);
    console.log('الرقم صحيح:', numberMatch);

    if (nameMatch && codeMatch && numberMatch) {
      const teacherData = {
        name: formData.name.trim(),
        loginTime: new Date().toISOString()
      };
      
      localStorage.setItem('currentTeacher', JSON.stringify(teacherData));
      console.log('تم حفظ بيانات المعلم:', teacherData);
      
      // Play success sound
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApBnb/QUG4eIAAAAQ==');
      audio.play().catch(() => {});
      
      toast.success('تم تسجيل الدخول بنجاح');
      navigate('/teacher/dashboard');
    } else {
      let errorMessage = 'بيانات الدخول غير صحيحة. يرجى التحقق من البيانات المدخلة';
      
      console.log('خطأ في التسجيل:', errorMessage);
      toast.error(errorMessage);
    }
  };

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      {/* Header */}
      <div className="flex items-center p-4 animate-fade-in">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/')}
          className="rounded-full ml-4 hover:scale-110 transition-transform duration-300"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold text-primary mr-4 animate-pulse">👨‍🏫 مدرس</h1>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-md mx-auto p-8 animate-scale-in shadow-2xl hover:shadow-3xl transition-all duration-500 border-2 border-gradient-to-r from-blue-400 to-purple-500">
          <div className="text-center mb-8">
            <div className="relative">
              <UserCheck className="w-20 h-20 mx-auto mb-4 text-purple-500 animate-bounce" />
              <div className="absolute inset-0 w-20 h-20 mx-auto rounded-full bg-purple-200 opacity-20 animate-ping"></div>
            </div>
            <h2 className="text-3xl font-bold text-primary mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              تسجيل دخول المعلم
            </h2>
            <p className="text-muted-foreground animate-fade-in">
              أدخل بيانات الدخول الخاصة بك
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2 transform hover:scale-105 transition-transform duration-300">
              <Label htmlFor="name" className="text-lg font-semibold">الاسم</Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="أدخل الاسم"
                className="text-center text-lg py-3 border-2 border-blue-200 focus:border-blue-500 transition-all duration-300 rounded-xl"
                autoComplete="off"
              />
            </div>

            <div className="space-y-2 transform hover:scale-105 transition-transform duration-300">
              <Label htmlFor="loginCode" className="text-lg font-semibold">كود الدخول</Label>
              <div className="relative">
                <Input
                  id="loginCode"
                  type={showPassword ? "text" : "password"}
                  value={formData.loginCode}
                  onChange={(e) => setFormData({...formData, loginCode: e.target.value})}
                  placeholder="أدخل كود الدخول"
                  className="text-center text-lg py-3 border-2 border-blue-200 focus:border-blue-500 transition-all duration-300 rounded-xl pr-12"
                  autoComplete="off"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute left-2 top-1/2 transform -translate-y-1/2 hover:bg-blue-100"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div className="space-y-2 transform hover:scale-105 transition-transform duration-300">
              <Label htmlFor="loginNumber" className="text-lg font-semibold">رقم الدخول</Label>
              <Input
                id="loginNumber"
                type="tel"
                value={formData.loginNumber}
                onChange={(e) => setFormData({...formData, loginNumber: e.target.value})}
                placeholder="أدخل رقم الدخول"
                className="text-center text-lg py-3 border-2 border-blue-200 focus:border-blue-500 transition-all duration-300 rounded-xl"
                autoComplete="off"
              />
            </div>

            <Button 
              type="submit" 
              className="w-full py-4 text-lg font-bold bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-300 rounded-xl shadow-lg hover:shadow-xl"
            >
              🚀 تسجيل الدخول
            </Button>
          </form>

          <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl text-center animate-pulse">
            <div className="flex items-center justify-center space-x-2 text-blue-700">
              <span className="text-2xl">🔐</span>
              <p className="font-semibold">منطقة محمية</p>
            </div>
            <p className="text-sm text-blue-600 mt-2">
              للدخول تواصل مع الإدارة للحصول على بيانات الدخول
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default TeacherLogin;
