import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, UserPlus, Sun, Moon, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabaseDataManager } from '@/utils/supabaseDataManager';

const StudentRegister = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    studentId: '',
    parentPhone: '',
    password: '',
    confirmPassword: '',
    grade: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', newTheme);
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const isDark = savedTheme === 'dark';
    setIsDarkMode(isDark);
    document.documentElement.classList.toggle('dark', isDark);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    console.log('بيانات التسجيل:', formData);
    
    // التحقق من صحة البيانات
    if (!formData.fullName.trim()) {
      toast.error('يرجى إدخال الاسم الرباعي');
      setIsLoading(false);
      return;
    }

    if (!formData.studentId.trim()) {
      toast.error('يرجى إدخال رقم الطالب');
      setIsLoading(false);
      return;
    }

    if (!formData.parentPhone.trim()) {
      toast.error('يرجى إدخال رقم ولي الأمر');
      setIsLoading(false);
      return;
    }

    if (!formData.password.trim()) {
      toast.error('يرجى إدخال كلمة المرور');
      setIsLoading(false);
      return;
    }

    if (!formData.confirmPassword.trim()) {
      toast.error('يرجى تأكيد كلمة المرور');
      setIsLoading(false);
      return;
    }

    if (!formData.grade) {
      toast.error('يرجى اختيار الصف الدراسي');
      setIsLoading(false);
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast.error('❌ كلمة المرور وتأكيد كلمة المرور غير متطابقين');
      setIsLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      toast.error('❌ كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      setIsLoading(false);
      return;
    }

    try {
      // التحقق من وجود طالب بنفس الاسم أو الرقم
      const existingStudents = await supabaseDataManager.getStudents();
      const existingStudent = existingStudents.find((s: any) => 
        (s.full_name && s.full_name.trim() === formData.fullName.trim()) || 
        (s.student_number && s.student_number.trim() === formData.studentId.trim())
      );

      if (existingStudent) {
        if (existingStudent.full_name.trim() === formData.fullName.trim()) {
          toast.error('❌ يوجد طالب بنفس الاسم مسجل مسبقاً\nيرجى استخدام اسم مختلف');
        } else {
          toast.error('❌ يوجد طالب بنفس رقم الطالب مسجل مسبقاً\nيرجى استخدام رقم مختلف');
        }
        setIsLoading(false);
        return;
      }

      // إنشاء طالب جديد
      const newStudent = {
        fullName: formData.fullName.trim(),
        studentNumber: formData.studentId.trim(),
        parentNumber: formData.parentPhone.trim(),
        password: formData.password,
        grade: formData.grade,
        email: ''
      };

      // إضافة الطالب إلى Supabase
      const success = await supabaseDataManager.addStudent(newStudent);
      
      if (success) {
        // تسجيل دخول الطالب الجديد
        const createdStudent = await supabaseDataManager.authenticateStudent(formData.fullName.trim(), formData.password);
        
        if (createdStudent) {
          localStorage.setItem('currentStudent', JSON.stringify(createdStudent));
          
          // إضافة إشعار ترحيبي
          await supabaseDataManager.addNotification(
            createdStudent.id, 
            'general_message', 
            `مرحباً بك ${createdStudent.fullName}! تم إنشاء حساباك بنجاح. يمكنك الآن الاستفادة من جميع الخدمات المتاحة.`
          );

          console.log('تم إنشاء الطالب بنجاح:', createdStudent);
          
          toast.success(`🎉 مرحباً ${createdStudent.fullName}!\nتم إنشاء الحساب وتسجيل الدخول بنجاح`);
          
          // الانتقال إلى لوحة التحكم
          setTimeout(() => {
            navigate('/student/dashboard');
          }, 1000);
        }
      } else {
        toast.error('❌ حدث خطأ في إنشاء الحساب\nيرجى المحاولة مرة أخرى');
      }
    } catch (error: any) {
      console.error('خطأ في التسجيل:', error);
      toast.error(error.message || '❌ حدث خطأ في إنشاء الحساب\nيرجى المحاولة مرة أخرى');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`min-h-screen page-transition relative overflow-hidden ${
      isDarkMode 
        ? 'bg-gradient-to-br from-purple-900 via-blue-900 via-indigo-900 to-pink-900' 
        : 'bg-gradient-to-br from-pink-50 via-blue-50 via-purple-50 to-orange-50'
    }`}>
      {/* Enhanced Magical Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-gradient-to-r from-purple-400/30 to-pink-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-r from-blue-400/30 to-cyan-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-gradient-to-r from-emerald-400/30 to-teal-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-20 right-20 w-72 h-72 bg-gradient-to-r from-yellow-400/30 to-orange-500/30 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-float" style={{animationDelay: '1.5s'}}></div>
        
        {/* Floating Academic Icons */}
        <div className="absolute top-16 left-16 text-6xl text-blue-300/40 animate-bounce transform rotate-12">🎓</div>
        <div className="absolute top-28 right-28 text-5xl text-purple-300/40 animate-pulse transform -rotate-12">📚</div>
        <div className="absolute bottom-32 left-20 text-4xl text-green-300/35 animate-float transform rotate-45">⭐</div>
        <div className="absolute top-1/3 right-16 text-5xl text-pink-300/30 animate-float">✨</div>
        <div className="absolute bottom-16 right-1/3 text-4xl text-yellow-300/35 animate-bounce">🌟</div>
        <div className="absolute top-1/2 left-12 text-3xl text-cyan-300/30 animate-float">💫</div>
      </div>

      {/* Enhanced Header */}
      <div className="relative z-20 flex items-center justify-between p-6 beautiful-card border-b border-white/20" style={{background: 'linear-gradient(145deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))', backdropFilter: 'blur(20px)'}}>
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/student')}
            className="rounded-full ml-4 beautiful-card hover-lift animate-3d bg-white/10 border-white/30 text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold gradient-text mr-4 flex items-center gap-3">
            <span>✨</span>
            إنشاء حساب التميز الأكاديمي
            <span>✨</span>
          </h1>
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className="rounded-full beautiful-card hover-lift animate-3d bg-white/10 border-white/30 text-white hover:bg-white/20"
        >
          {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      {/* Enhanced Main Content */}
      <div className="relative z-10 container mx-auto px-4 py-12">
        <Card className="max-w-2xl mx-auto p-10 beautiful-card hover-lift animate-fade-in pulse-glow" style={{background: 'linear-gradient(145deg, rgba(255,255,255,0.15), rgba(255,255,255,0.05))', backdropFilter: 'blur(30px)', border: '2px solid rgba(255,255,255,0.3)'}}>
          <div className="text-center mb-10">
            <div className="relative mb-6">
              <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full blur-xl opacity-75 animate-pulse"></div>
              <UserPlus className="relative w-20 h-20 mx-auto mb-4 text-white p-4 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full animate-float shadow-2xl" />
            </div>
            <h2 className="text-4xl font-bold gradient-text mb-4 animate-fade-in flex items-center justify-center gap-3">
              <span>🌟</span>
              بناء مستقبلك التعليمي
              <span>🌟</span>
            </h2>
            <p className="text-muted-foreground text-xl animate-fade-in font-medium" style={{animationDelay: '0.2s'}}>
              ✨ انضم إلى أكاديمية التفوق والإبداع ✨
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-3 animate-fade-in" style={{animationDelay: '0.1s'}}>
              <Label htmlFor="fullName" className="text-lg font-bold text-white flex items-center gap-2">
                <span>👤</span>الاسم الرباعي المبارك
              </Label>
              <div className="relative">
                <Input
                  id="fullName"
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                  placeholder="أدخل اسمك الرباعي الكريم"
                  className="text-right py-4 px-6 text-lg rounded-2xl border-3 border-blue-300/50 focus:border-blue-500 transition-all duration-200 bg-white/10 backdrop-blur-sm text-white placeholder-white/60 shadow-xl"
                  required
                  disabled={isLoading}
                />
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-blue-300 text-xl">📝</div>
              </div>
            </div>

            <div className="space-y-3 animate-fade-in" style={{animationDelay: '0.2s'}}>
              <Label htmlFor="studentId" className="text-lg font-bold text-white flex items-center gap-2">
                <span>🎯</span>الرقم الأكاديمي
              </Label>
              <div className="relative">
                <Input
                  id="studentId"
                  type="text"
                  value={formData.studentId}
                  onChange={(e) => setFormData({...formData, studentId: e.target.value})}
                  placeholder="أدخل رقمك الأكاديمي المميز"
                  className="text-right py-4 px-6 text-lg rounded-2xl border-3 border-purple-300/50 focus:border-purple-500 transition-all duration-200 bg-white/10 backdrop-blur-sm text-white placeholder-white/60 shadow-xl"
                  required
                  disabled={isLoading}
                />
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-purple-300 text-xl">🔢</div>
              </div>
            </div>

            <div className="space-y-3 animate-fade-in" style={{animationDelay: '0.3s'}}>
              <Label htmlFor="parentPhone" className="text-lg font-bold text-white flex items-center gap-2">
                <span>📞</span>رقم ولي الأمر الكريم
              </Label>
              <div className="relative">
                <Input
                  id="parentPhone"
                  type="tel"
                  value={formData.parentPhone}
                  onChange={(e) => setFormData({...formData, parentPhone: e.target.value})}
                  placeholder="أدخل رقم ولي الأمر المحترم"
                  className="text-right py-4 px-6 text-lg rounded-2xl border-3 border-green-300/50 focus:border-green-500 transition-all duration-200 bg-white/10 backdrop-blur-sm text-white placeholder-white/60 shadow-xl"
                  required
                  disabled={isLoading}
                />
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-green-300 text-xl">📱</div>
              </div>
            </div>

            <div className="space-y-3 animate-fade-in" style={{animationDelay: '0.4s'}}>
              <Label htmlFor="grade" className="text-lg font-bold text-white flex items-center gap-2">
                <span>🎓</span>المرحلة الدراسية
              </Label>
              <Select 
                onValueChange={(value) => setFormData({...formData, grade: value})} 
                required
                disabled={isLoading}
              >
                <SelectTrigger className="py-4 px-6 text-lg rounded-2xl border-3 border-orange-300/50 focus:border-orange-500 bg-white/10 backdrop-blur-sm text-white">
                  <SelectValue placeholder="اختر مرحلتك التعليمية المباركة" />
                </SelectTrigger>
                <SelectContent className="bg-white/95 backdrop-blur-xl">
                  <SelectItem value="first">🥇 الأول الثانوي</SelectItem>
                  <SelectItem value="second">🥈 الثاني الثانوي</SelectItem>
                  <SelectItem value="third">🥉 الثالث الثانوي</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3 animate-fade-in" style={{animationDelay: '0.5s'}}>
              <Label htmlFor="password" className="text-lg font-bold text-white flex items-center gap-2">
                <span>🔐</span>كلمة المرور السرية
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  placeholder="أدخل كلمة مرور قوية (6 أحرف على الأقل)"
                  className="text-right py-4 px-6 text-lg rounded-2xl border-3 border-pink-300/50 focus:border-pink-500 transition-all duration-200 bg-white/10 backdrop-blur-sm text-white placeholder-white/60 shadow-xl"
                  required
                  minLength={6}
                  disabled={isLoading}
                />
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-pink-300 text-xl">🗝️</div>
              </div>
            </div>

            <div className="space-y-3 animate-fade-in" style={{animationDelay: '0.6s'}}>
              <Label htmlFor="confirmPassword" className="text-lg font-bold text-white flex items-center gap-2">
                <span>✅</span>تأكيد كلمة المرور
              </Label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                  placeholder="أعد إدخال كلمة المرور للتأكيد"
                  className="text-right py-4 px-6 text-lg rounded-2xl border-3 border-cyan-300/50 focus:border-cyan-500 transition-all duration-200 bg-white/10 backdrop-blur-sm text-white placeholder-white/60 shadow-xl"
                  required
                  minLength={6}
                  disabled={isLoading}
                />
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-cyan-300 text-xl">🔒</div>
              </div>
              {formData.password && formData.confirmPassword && (
                <div className="flex items-center text-sm mt-2">
                  {formData.password === formData.confirmPassword ? (
                    <div className="flex items-center text-green-300 font-medium">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      ✅ كلمة المرور متطابقة ومؤكدة
                    </div>
                  ) : (
                    <div className="text-red-300 font-medium">
                      ❌ كلمة المرور غير متطابقة
                    </div>
                  )}
                </div>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full py-5 text-xl font-bold rounded-2xl bg-gradient-to-r from-blue-500 via-purple-500 via-pink-500 to-orange-500 hover:from-blue-600 hover:via-purple-600 hover:via-pink-600 hover:to-orange-600 shadow-2xl hover:shadow-3xl transform hover:scale-105 hover-lift border-2 border-white/30" 
              disabled={isLoading}
              style={{animationDelay: '0.7s'}}
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-6 w-6 border-b-3 border-white mr-3"></div>
                  ⏳ جاري بناء حسابك الأكاديمي المتميز...
                </>
              ) : (
                <>
                  <span className="mr-3 text-2xl">🚀</span>
                  إطلاق رحلة التفوق الأكاديمي
                  <span className="ml-3 text-2xl">✨</span>
                </>
              )}
            </Button>
          </form>

          <div className="text-center mt-10 animate-fade-in" style={{animationDelay: '0.8s'}}>
            <p className="text-white/80 text-xl font-medium">
              لديك حساب بالفعل؟{' '}
              <Button
                variant="link"
                onClick={() => navigate('/student/login')}
                className="p-0 h-auto font-bold text-cyan-300 hover:text-cyan-200 text-xl underline"
                disabled={isLoading}
              >
                🎯 دخول الحساب الموجود
              </Button>
            </p>
          </div>

          <div className="mt-8 pt-6 border-t border-white/20 text-center animate-fade-in" style={{animationDelay: '0.9s'}}>
            <p className="text-white/70 font-bold text-lg flex items-center justify-center gap-2">
              <span>👨‍🏫</span>
              مستر محمود حمد
              <span>🎓</span>
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default StudentRegister;
