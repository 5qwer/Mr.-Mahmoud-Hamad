
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Gift, Plus, Search, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const SupportRewards = () => {
  const [students, setStudents] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [pointsToAdd, setPointsToAdd] = useState('');
  const [reason, setReason] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = () => {
    const allStudents = JSON.parse(localStorage.getItem('students') || '[]');
    setStudents(allStudents);
  };

  const filteredStudents = students.filter(student =>
    student.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const addPointsToStudent = () => {
    if (!selectedStudent || !pointsToAdd || !reason) {
      toast.error('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    const points = parseInt(pointsToAdd);
    if (points <= 0) {
      toast.error('يرجى إدخال عدد نقاط صحيح');
      return;
    }

    // Update student points
    const updatedStudents = students.map(student => 
      student.id === selectedStudent.id 
        ? { ...student, points: (student.points || 0) + points }
        : student
    );
    
    localStorage.setItem('students', JSON.stringify(updatedStudents));
    
    // Update current student if they're logged in
    const currentStudent = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (currentStudent && currentStudent.id === selectedStudent.id) {
      const updatedCurrentStudent = { ...currentStudent, points: (currentStudent.points || 0) + points };
      localStorage.setItem('currentStudent', JSON.stringify(updatedCurrentStudent));
    }
    
    // Log the reward transaction
    const rewardLog = {
      id: Date.now(),
      studentId: selectedStudent.id,
      studentName: selectedStudent.fullName,
      points: points,
      reason: reason,
      addedBy: 'الدعم الفني',
      timestamp: new Date().toISOString()
    };
    
    const rewardLogs = JSON.parse(localStorage.getItem('rewardLogs') || '[]');
    rewardLogs.unshift(rewardLog);
    localStorage.setItem('rewardLogs', JSON.stringify(rewardLogs));
    
    // Create notification for student
    const notification = {
      id: Date.now(),
      title: '🎉 تم إضافة نقاط مكافأة!',
      message: `تم إضافة ${points} نقطة إلى حسابك. السبب: ${reason}`,
      priority: 'normal',
      timestamp: new Date().toISOString(),
      isRead: false,
      targetUsers: [selectedStudent.id],
      createdBy: 'الدعم الفني'
    };
    
    const notifications = JSON.parse(localStorage.getItem('systemNotifications') || '[]');
    notifications.unshift(notification);
    localStorage.setItem('systemNotifications', JSON.stringify(notifications));
    
    setStudents(updatedStudents);
    setSelectedStudent(null);
    setPointsToAdd('');
    setReason('');
    
    toast.success(`تم إضافة ${points} نقطة للطالب ${selectedStudent.fullName} بنجاح!`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/support/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">🎁 إدارة مكافآت الطلاب</h1>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Add Points Section */}
        <Card className="p-6 mb-8">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
            <Gift className="w-6 h-6 text-purple-600" />
            إضافة نقاط مكافأة للطالب
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label className="text-base font-semibold">البحث عن الطالب</Label>
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
                  <Input
                    placeholder="ابحث بالاسم أو الإيميل..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="text-right pr-12"
                  />
                </div>
              </div>
              
              {searchQuery && (
                <div className="max-h-40 overflow-y-auto border rounded-lg p-2 space-y-2">
                  {filteredStudents.map((student) => (
                    <div
                      key={student.id}
                      onClick={() => setSelectedStudent(student)}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedStudent?.id === student.id 
                          ? 'bg-purple-100 border-purple-500' 
                          : 'bg-gray-50 hover:bg-gray-100'
                      }`}
                    >
                      <p className="font-semibold">{student.fullName}</p>
                      <p className="text-sm text-muted-foreground">{student.email}</p>
                      <p className="text-sm text-green-600">النقاط الحالية: {student.points || 0}</p>
                    </div>
                  ))}
                  
                  {filteredStudents.length === 0 && (
                    <p className="text-center text-muted-foreground py-4">لا توجد نتائج</p>
                  )}
                </div>
              )}
            </div>
            
            <div className="space-y-4">
              {selectedStudent && (
                <>
                  <Card className="p-4 bg-purple-50 border-purple-200">
                    <h3 className="font-bold text-lg">{selectedStudent.fullName}</h3>
                    <p className="text-muted-foreground">{selectedStudent.email}</p>
                    <p className="text-green-600 font-semibold">النقاط الحالية: {selectedStudent.points || 0}</p>
                  </Card>
                  
                  <div>
                    <Label className="text-base font-semibold">عدد النقاط المراد إضافتها</Label>
                    <Input
                      type="number"
                      min="1"
                      value={pointsToAdd}
                      onChange={(e) => setPointsToAdd(e.target.value)}
                      placeholder="أدخل عدد النقاط"
                      className="text-right"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-base font-semibold">سبب المكافأة</Label>
                    <Select value={reason} onValueChange={setReason}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر السبب" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="excellent_performance">أداء ممتاز</SelectItem>
                        <SelectItem value="good_behavior">سلوك حسن</SelectItem>
                        <SelectItem value="participation">مشاركة فعالة</SelectItem>
                        <SelectItem value="improvement">تحسن ملحوظ</SelectItem>
                        <SelectItem value="bonus">مكافأة إضافية</SelectItem>
                        <SelectItem value="other">سبب آخر</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Button
                    onClick={addPointsToStudent}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                    disabled={!pointsToAdd || !reason}
                  >
                    <Plus className="w-4 h-4 ml-2" />
                    إضافة النقاط
                  </Button>
                </>
              )}
            </div>
          </div>
        </Card>

        {/* Recent Rewards Log */}
        <Card className="p-6">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-500" />
            سجل المكافآت الأخيرة
          </h3>
          
          <div className="space-y-3 max-h-60 overflow-y-auto">
            {JSON.parse(localStorage.getItem('rewardLogs') || '[]').slice(0, 10).map((log: any) => (
              <div key={log.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-semibold">{log.studentName}</p>
                  <p className="text-sm text-muted-foreground">{log.reason}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(log.timestamp).toLocaleString('ar-EG')}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-600">+{log.points}</p>
                  <p className="text-xs text-muted-foreground">نقطة</p>
                </div>
              </div>
            ))}
            
            {JSON.parse(localStorage.getItem('rewardLogs') || '[]').length === 0 && (
              <div className="text-center py-8">
                <Gift className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p className="text-muted-foreground">لا توجد مكافآت مسجلة بعد</p>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default SupportRewards;
