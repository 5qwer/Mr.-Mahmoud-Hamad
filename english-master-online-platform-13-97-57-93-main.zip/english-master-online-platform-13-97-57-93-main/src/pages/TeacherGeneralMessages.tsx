
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowLeft, Send, Users, AlertTriangle, Info, Zap, Moon, Sun, Bell } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

const TeacherGeneralMessages = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [messageData, setMessageData] = useState({
    title: '',
    message: '',
    priority: 'normal' as 'urgent' | 'warning' | 'normal',
    targetGrades: [] as string[],
    targetAll: true
  });
  const [students, setStudents] = useState<any[]>([]);
  const [recentMessages, setRecentMessages] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    loadStudents();
    loadRecentMessages();
  }, []);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
  };

  const loadStudents = async () => {
    try {
      const { data, error } = await supabase
        .from('students')
        .select('id, full_name, grade');
      
      if (error) {
        console.error('Error loading students:', error);
        return;
      }
      
      setStudents(data || []);
    } catch (error) {
      console.error('Error loading students:', error);
    }
  };

  const loadRecentMessages = async () => {
    try {
      const { data, error } = await supabase
        .from('general_messages')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);
      
      if (error) {
        console.error('Error loading recent messages:', error);
        return;
      }
      
      setRecentMessages(data || []);
    } catch (error) {
      console.error('Error loading recent messages:', error);
    }
  };

  const handleGradeChange = (grade: string, checked: boolean) => {
    if (checked) {
      setMessageData(prev => ({
        ...prev,
        targetGrades: [...prev.targetGrades, grade]
      }));
    } else {
      setMessageData(prev => ({
        ...prev,
        targetGrades: prev.targetGrades.filter(g => g !== grade)
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!messageData.title || !messageData.message) {
      toast.error('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    setIsLoading(true);

    try {
      // إنشاء الرسالة في Supabase
      const { data, error } = await supabase
        .from('general_messages')
        .insert([{
          title: messageData.title,
          message: messageData.message,
          priority: messageData.priority,
          target_grades: messageData.targetAll ? [] : messageData.targetGrades,
          target_all: messageData.targetAll,
          created_by: 'المعلم'
        }])
        .select()
        .single();

      if (error) {
        console.error('Error creating message:', error);
        toast.error('حدث خطأ أثناء إرسال الرسالة');
        return;
      }

      toast.success('تم إرسال الرسالة بنجاح');
      
      // إعادة تعيين النموذج
      setMessageData({
        title: '',
        message: '',
        priority: 'normal',
        targetGrades: [],
        targetAll: true
      });
      
      // إعادة تحميل الرسائل الحديثة
      loadRecentMessages();
      
    } catch (error) {
      console.error('Error:', error);
      toast.error('حدث خطأ أثناء إرسال الرسالة');
    } finally {
      setIsLoading(false);
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent': return <Zap className="w-4 h-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      default: return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'عاجل';
      case 'warning': return 'تنبيه';
      default: return 'عادي';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 border-red-500 text-red-700';
      case 'warning': return 'bg-yellow-100 border-yellow-500 text-yellow-700';
      default: return 'bg-blue-100 border-blue-500 text-blue-700';
    }
  };

  const getGradeLabel = (grade: string) => {
    switch (grade) {
      case '1': case 'first': return 'الأول الثانوي';
      case '2': case 'second': return 'الثاني الثانوي';
      case '3': case 'third': return 'الثالث الثانوي';
      case 'all': return 'جميع الصفوف';
      default: return grade;
    }
  };

  const getTargetDescription = (msg: any) => {
    if (msg.target_all) {
      return 'جميع الطلاب';
    }
    if (msg.target_grades && msg.target_grades.length > 0) {
      return msg.target_grades.map((grade: string) => getGradeLabel(grade)).join(', ');
    }
    return 'غير محدد';
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/teacher/dashboard')}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">📢 رسائل عامة للطلاب</h1>
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={toggleTheme}
          className="rounded-full"
        >
          {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Send Message Form */}
          <Card className="p-6">
            <h2 className="text-lg font-bold mb-6 flex items-center gap-2">
              <Send className="w-5 h-5 text-blue-600" />
              إرسال رسالة عامة
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">عنوان الرسالة *</Label>
                <Input
                  id="title"
                  value={messageData.title}
                  onChange={(e) => setMessageData({...messageData, title: e.target.value})}
                  placeholder="أدخل عنوان الرسالة"
                  className="text-right"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="priority">أهمية الرسالة *</Label>
                <Select value={messageData.priority} onValueChange={(value: any) => setMessageData({...messageData, priority: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر مستوى الأهمية" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="normal">
                      <div className="flex items-center gap-2">
                        <Info className="w-4 h-4 text-blue-500" />
                        عادي - في قائمة الإشعارات
                      </div>
                    </SelectItem>
                    <SelectItem value="warning">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-500" />
                        تنبيه - في مقدمة القائمة
                      </div>
                    </SelectItem>
                    <SelectItem value="urgent">
                      <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-red-500" />
                        عاجل - نافذة منبثقة
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">نص الرسالة *</Label>
                <Textarea
                  id="message"
                  value={messageData.message}
                  onChange={(e) => setMessageData({...messageData, message: e.target.value})}
                  placeholder="اكتب نص الرسالة هنا..."
                  className="text-right min-h-32"
                  required
                />
              </div>

              <div className="space-y-4">
                <Label>المستهدفون</Label>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="targetAll"
                    checked={messageData.targetAll}
                    onCheckedChange={(checked) => setMessageData({...messageData, targetAll: !!checked})}
                  />
                  <Label htmlFor="targetAll" className="cursor-pointer">جميع الطلاب</Label>
                </div>

                {!messageData.targetAll && (
                  <div className="space-y-2">
                    <Label>الصفوف المستهدفة</Label>
                    <div className="space-y-2">
                      {['1', '2', '3'].map((grade) => (
                        <div key={grade} className="flex items-center space-x-2">
                          <Checkbox
                            id={grade}
                            checked={messageData.targetGrades.includes(grade)}
                            onCheckedChange={(checked) => handleGradeChange(grade, !!checked)}
                          />
                          <Label htmlFor={grade} className="cursor-pointer">
                            {getGradeLabel(grade)}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                <Send className="w-4 h-4 ml-2" />
                {isLoading ? 'جارٍ الإرسال...' : 'إرسال الرسالة'}
              </Button>
            </form>
          </Card>

          {/* Recent Messages */}
          <Card className="p-6">
            <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
              <Bell className="w-5 h-5 text-purple-600" />
              الرسائل المرسلة مؤخراً
            </h3>
            
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {recentMessages.map((msg) => (
                <div key={msg.id} className={`p-4 rounded-lg border-2 ${getPriorityColor(msg.priority)}`}>
                  <div className="flex items-center gap-2 mb-2">
                    {getPriorityIcon(msg.priority)}
                    <h4 className="font-bold">{msg.title}</h4>
                    <span className="text-xs opacity-75">
                      {getPriorityLabel(msg.priority)}
                    </span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={async () => {
                        if (window.confirm('هل تريد حذف هذه الرسالة؟')) {
                          try {
                            const { error } = await supabase
                              .from('general_messages')
                              .delete()
                              .eq('id', msg.id);
                            
                            if (error) throw error;
                            
                            toast.success('تم حذف الرسالة بنجاح');
                            loadRecentMessages();
                          } catch (error) {
                            console.error('Error deleting message:', error);
                            toast.error('فشل في حذف الرسالة');
                          }
                        }
                      }}
                      className="ml-auto text-red-500 hover:text-red-700"
                    >
                      🗑️
                    </Button>
                  </div>
                  
                  <p className="text-sm mb-3">{msg.message}</p>
                  
                  <div className="flex justify-between items-center text-xs opacity-75">
                    <span>
                      {getTargetDescription(msg)}
                    </span>
                    <span>
                      {new Date(msg.created_at).toLocaleString('ar-EG')}
                    </span>
                  </div>
                </div>
              ))}
              
              {recentMessages.length === 0 && (
                <div className="text-center py-8">
                  <Bell className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                  <p className="text-muted-foreground">لم يتم إرسال أي رسائل بعد</p>
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TeacherGeneralMessages;
