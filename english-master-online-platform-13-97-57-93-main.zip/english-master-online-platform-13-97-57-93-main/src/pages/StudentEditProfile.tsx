
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, UserCog, Shield, Send } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { dataManager } from '@/utils/dataManager';

const StudentEditProfile = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [formData, setFormData] = useState({
    fullName: '',
    studentId: '',
    parentPhone: '',
    grade: '',
    password: ''
  });
  const [editData, setEditData] = useState({
    newFullName: '',
    newStudentId: '',
    newParentPhone: '',
    newGrade: '',
    newPassword: '',
    confirmPassword: '',
    reason: ''
  });
  const [step, setStep] = useState<'view' | 'edit' | 'verify'>('view');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    
    setCurrentStudent(student);
    setFormData({
      fullName: student.fullName || '',
      studentId: student.studentId || '',
      parentPhone: student.parentPhone || '',
      grade: student.grade || '',
      password: ''
    });
  }, [navigate]);

  const handleVerification = () => {
    if (!currentStudent) return;

    // Check password
    if (formData.password !== currentStudent.password) {
      toast.error('كلمة المرور غير صحيحة');
      return;
    }

    setStep('edit');
  };

  const handleEditRequest = () => {
    if (!currentStudent) return;

    // Validate new password if provided
    if (editData.newPassword && editData.newPassword !== editData.confirmPassword) {
      toast.error('كلمة المرور الجديدة غير متطابقة');
      return;
    }

    if (editData.newPassword && editData.newPassword.length < 6) {
      toast.error('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      return;
    }

    if (!editData.reason.trim()) {
      toast.error('يرجى كتابة سبب التغيير');
      return;
    }

    setIsLoading(true);

    // Check what's being changed
    const changes = [];
    if (editData.newFullName && editData.newFullName !== currentStudent.fullName) {
      changes.push(`الاسم: من "${currentStudent.fullName}" إلى "${editData.newFullName}"`);
    }
    if (editData.newStudentId && editData.newStudentId !== currentStudent.studentId) {
      changes.push(`رقم الطالب: من "${currentStudent.studentId}" إلى "${editData.newStudentId}"`);
    }
    if (editData.newParentPhone && editData.newParentPhone !== currentStudent.parentPhone) {
      changes.push(`رقم ولي الأمر: من "${currentStudent.parentPhone}" إلى "${editData.newParentPhone}"`);
    }
    if (editData.newGrade && editData.newGrade !== currentStudent.grade) {
      const gradeNames = { 'first': 'الأول الثانوي', 'second': 'الثاني الثانوي', 'third': 'الثالث الثانوي' };
      changes.push(`الصف: من "${gradeNames[currentStudent.grade as keyof typeof gradeNames] || currentStudent.grade}" إلى "${gradeNames[editData.newGrade as keyof typeof gradeNames] || editData.newGrade}"`);
    }
    if (editData.newPassword) {
      changes.push('كلمة المرور: تم طلب تغييرها');
    }

    if (changes.length === 0) {
      toast.error('لم يتم تحديد أي تغييرات');
      setIsLoading(false);
      return;
    }

    // Send request to support
    const requestMessage = `طلب تعديل بيانات الطالب:
الطالب: ${currentStudent.fullName}
رقم الطالب: ${currentStudent.studentId}

التغييرات المطلوبة:
${changes.join('\n')}

سبب التغيير: ${editData.reason}

يرجى الموافقة على هذا الطلب لتفعيل التغييرات.`;

    const success = dataManager.addSupportMessage(
      currentStudent.id.toString(),
      {
        from: 'student',
        message: requestMessage,
        read: false,
        image: ''
      }
    );

    if (success) {
      // Send auto-reply
      setTimeout(() => {
        dataManager.addSupportMessage(
          currentStudent.id.toString(),
          {
            from: 'support',
            message: 'تم استلام طلب تعديل البيانات. سيتم مراجعته والرد عليك في أقرب وقت ممكن.',
            read: true,
            supportName: 'نظام الدعم الآلي'
          }
        );
      }, 1000);

      toast.success('تم إرسال طلب التعديل للدعم الفني بنجاح');
      
      setTimeout(() => {
        navigate('/student/dashboard');
      }, 2000);
    } else {
      toast.error('فشل في إرسال الطلب. حاول مرة أخرى');
    }

    setIsLoading(false);
  };

  const renderViewStep = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <UserCog className="w-16 h-16 mx-auto mb-4 text-blue-500" />
        <h2 className="text-2xl font-bold text-primary mb-2">البيانات الحالية</h2>
        <p className="text-muted-foreground">لتعديل البيانات، يرجى إدخال كلمة المرور للتحقق</p>
      </div>

      <div className="space-y-4">
        <div>
          <Label className="text-lg font-medium">الاسم الرباعي</Label>
          <div className="p-3 bg-gray-100 dark:bg-gray-700 rounded-lg text-right">
            {currentStudent?.fullName}
          </div>
        </div>

        <div>
          <Label className="text-lg font-medium">رقم الطالب</Label>
          <div className="p-3 bg-gray-100 dark:bg-gray-700 rounded-lg text-right">
            {currentStudent?.studentId}
          </div>
        </div>

        <div>
          <Label className="text-lg font-medium">رقم ولي الأمر</Label>
          <div className="p-3 bg-gray-100 dark:bg-gray-700 rounded-lg text-right">
            {currentStudent?.parentPhone}
          </div>
        </div>

        <div>
          <Label className="text-lg font-medium">الصف الدراسي</Label>
          <div className="p-3 bg-gray-100 dark:bg-gray-700 rounded-lg text-right">
            {currentStudent?.grade === 'first' ? 'الأول الثانوي' :
             currentStudent?.grade === 'second' ? 'الثاني الثانوي' :
             currentStudent?.grade === 'third' ? 'الثالث الثانوي' : currentStudent?.grade}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="password" className="text-lg font-medium text-red-600">
            <Shield className="inline w-4 h-4 mr-1" />
            كلمة المرور (للتحقق)
          </Label>
          <Input
            id="password"
            type="password"
            value={formData.password}
            onChange={(e) => setFormData({...formData, password: e.target.value})}
            placeholder="أدخل كلمة المرور الحالية"
            className="text-right"
            required
          />
        </div>
      </div>

      <Button 
        onClick={handleVerification}
        className="w-full py-3 text-lg font-semibold"
        disabled={!formData.password.trim()}
      >
        التحقق والمتابعة
      </Button>
    </div>
  );

  const renderEditStep = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <UserCog className="w-16 h-16 mx-auto mb-4 text-green-500" />
        <h2 className="text-2xl font-bold text-primary mb-2">تعديل البيانات</h2>
        <p className="text-muted-foreground">املأ الحقول التي تريد تغييرها فقط</p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label className="text-lg font-medium">الاسم الرباعي الجديد (اختياري)</Label>
          <Input
            value={editData.newFullName}
            onChange={(e) => setEditData({...editData, newFullName: e.target.value})}
            placeholder={`الحالي: ${currentStudent?.fullName}`}
            className="text-right"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-lg font-medium">رقم الطالب الجديد (اختياري)</Label>
          <Input
            value={editData.newStudentId}
            onChange={(e) => setEditData({...editData, newStudentId: e.target.value})}
            placeholder={`الحالي: ${currentStudent?.studentId}`}
            className="text-right"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-lg font-medium">رقم ولي الأمر الجديد (اختياري)</Label>
          <Input
            value={editData.newParentPhone}
            onChange={(e) => setEditData({...editData, newParentPhone: e.target.value})}
            placeholder={`الحالي: ${currentStudent?.parentPhone}`}
            className="text-right"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-lg font-medium">الصف الدراسي الجديد (اختياري)</Label>
          <Select onValueChange={(value) => setEditData({...editData, newGrade: value})}>
            <SelectTrigger className="text-right">
              <SelectValue placeholder={`الحالي: ${
                currentStudent?.grade === 'first' ? 'الأول الثانوي' :
                currentStudent?.grade === 'second' ? 'الثاني الثانوي' :
                currentStudent?.grade === 'third' ? 'الثالث الثانوي' : currentStudent?.grade
              }`} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="first">الأول الثانوي</SelectItem>
              <SelectItem value="second">الثاني الثانوي</SelectItem>
              <SelectItem value="third">الثالث الثانوي</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label className="text-lg font-medium">كلمة المرور الجديدة (اختياري)</Label>
          <Input
            type="password"
            value={editData.newPassword}
            onChange={(e) => setEditData({...editData, newPassword: e.target.value})}
            placeholder="اتركها فارغة إذا لم تريد تغييرها"
            className="text-right"
          />
        </div>

        {editData.newPassword && (
          <div className="space-y-2">
            <Label className="text-lg font-medium">تأكيد كلمة المرور الجديدة</Label>
            <Input
              type="password"
              value={editData.confirmPassword}
              onChange={(e) => setEditData({...editData, confirmPassword: e.target.value})}
              placeholder="أعد إدخال كلمة المرور الجديدة"
              className="text-right"
            />
          </div>
        )}

        <div className="space-y-2">
          <Label className="text-lg font-medium text-red-600">سبب التغيير (مطلوب)</Label>
          <Textarea
            value={editData.reason}
            onChange={(e) => setEditData({...editData, reason: e.target.value})}
            placeholder="اشرح سبب طلب تعديل البيانات..."
            className="text-right min-h-[100px]"
            required
          />
        </div>
      </div>

      <div className="flex gap-3">
        <Button 
          onClick={() => setStep('view')}
          variant="outline"
          className="flex-1"
        >
          العودة
        </Button>
        <Button 
          onClick={handleEditRequest}
          className="flex-1"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              جاري الإرسال...
            </>
          ) : (
            <>
              <Send className="w-4 h-4 mr-2" />
              إرسال طلب التعديل
            </>
          )}
        </Button>
      </div>
    </div>
  );

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-slate-900 via-gray-800 to-slate-900' 
        : 'bg-gradient-to-br from-gray-50 via-blue-50 to-white'
    }`} style={{
      backgroundImage: localStorage.getItem('appBackgroundImage') ? `url(${localStorage.getItem('appBackgroundImage')})` : undefined,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed'
    }}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/student/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">⚙️ تعديل البيانات</h1>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-2xl mx-auto p-8 bg-white/95 dark:bg-gray-800/95 backdrop-blur-sm shadow-xl rounded-2xl">
          {step === 'view' && renderViewStep()}
          {step === 'edit' && renderEditStep()}
        </Card>
      </div>
    </div>
  );
};

export default StudentEditProfile;
