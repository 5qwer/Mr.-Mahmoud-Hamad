
import React, { useEffect, useState } from "react";
import { db, storage } from "../firebase";
import { firebaseDataManager } from "../utils/firebaseDataManager";

const CheckFirebase = () => {
  const [isInitializing, setIsInitializing] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    console.log("✅ تم الاتصال بقاعدة البيانات:", db);
    console.log("✅ التخزين مفعل:", storage);
    
    // Initialize default data
    const initializeData = async () => {
      setIsInitializing(true);
      try {
        await firebaseDataManager.initializeDefaultData();
        setIsInitialized(true);
        console.log("✅ تم تهيئة البيانات الافتراضية في Firestore");
      } catch (error) {
        console.error("❌ خطأ في تهيئة البيانات:", error);
      } finally {
        setIsInitializing(false);
      }
    };

    initializeData();
  }, []);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center p-8 bg-card rounded-lg shadow-lg max-w-md">
        <h1 className="text-2xl font-bold text-foreground mb-4">
          ✅ Firebase متصل بنجاح
        </h1>
        <p className="text-muted-foreground mb-4">
          تحقق من وحدة التحكم في المتصفح لرؤية تفاصيل الاتصال
        </p>
        
        {isInitializing && (
          <div className="mb-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
            <p className="text-sm text-muted-foreground">جاري تهيئة البيانات الافتراضية...</p>
          </div>
        )}
        
        {isInitialized && (
          <div className="bg-green-100 dark:bg-green-900 p-3 rounded-lg">
            <p className="text-green-800 dark:text-green-200 text-sm font-medium">
              ✅ تم تهيئة البيانات الافتراضية بنجاح
            </p>
          </div>
        )}
        
        <div className="mt-6 space-y-2 text-sm text-muted-foreground">
          <p>بيانات تجريبية متاحة:</p>
          <p>• أحمد محمد علي - كلمة المرور: 123456</p>
          <p>• فاطمة سعد محمود - كلمة المرور: 789012</p>
        </div>
      </div>
    </div>
  );
};

export default CheckFirebase;
