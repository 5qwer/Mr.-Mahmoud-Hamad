
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, BookOpen, Play, Clock, User, Video, FileText, Briefcase } from 'lucide-react';
import { toast } from 'sonner';
import { supabaseDataManager } from '@/utils/supabaseDataManager';
import LessonContentViewer from '@/components/LessonContentViewer';

interface Lesson {
  id: number;
  title: string;
  description: string;
  order_number: number;
  video_url: string;
  pdf_url: string;
  homework_url: string;
  homework_video_url: string;
  solution_url: string;
  cover_image: string;
  grade: string;
}

interface Subscription {
  id: number;
  title: string;
  description: string;
  grade: string;
  lessons: Lesson[];
}

const StudentSubscriptionLessons = () => {
  const { subscriptionId } = useParams();
  const navigate = useNavigate();
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student');
      return;
    }
    setCurrentStudent(student);
    loadSubscriptionLessons();
  }, [subscriptionId, navigate]);

  const loadSubscriptionLessons = async () => {
    if (!subscriptionId) return;
    
    try {
      setLoading(true);
      console.log('جلب دروس الاشتراك مع البيانات الصحيحة:', subscriptionId);
      
      const subscriptionData = await supabaseDataManager.getSubscriptionById(parseInt(subscriptionId));
      console.log('بيانات الاشتراك المحملة مع الحصص الصحيحة:', subscriptionData);
      
      if (subscriptionData) {
        setSubscription(subscriptionData);
        // Set first lesson as default if available
        if (subscriptionData.lessons && subscriptionData.lessons.length > 0) {
          const sortedLessons = subscriptionData.lessons.sort((a: Lesson, b: Lesson) => a.order_number - b.order_number);
          console.log('الحصص مرتبة:', sortedLessons);
          setSelectedLesson(sortedLessons[0]);
          console.log('الحصة المختارة:', sortedLessons[0]);
        }
      } else {
        toast.error('لم يتم العثور على بيانات الاشتراك');
      }
    } catch (error) {
      console.error('خطأ في تحميل دروس الاشتراك:', error);
      toast.error('حدث خطأ في تحميل الدروس');
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async (message: string, questionImage?: File) => {
    if (!currentStudent || !selectedLesson) return;

    try {
      console.log('إرسال رسالة للمدرس:', {
        studentId: currentStudent.id,
        lessonId: selectedLesson.id,
        message,
        image: questionImage
      });
      
      toast.success('تم إرسال السؤال للمدرس بنجاح');
    } catch (error) {
      console.error('خطأ في إرسال الرسالة:', error);
      throw error;
    }
  };

  const getGradeText = (grade: string) => {
    switch (grade) {
      case '1': return 'الأول الثانوي';
      case '2': return 'الثاني الثانوي';
      case '3': return 'الثالث الثانوي';
      default: return 'غير محدد';
    }
  };

  const getLessonContentCount = (lesson: Lesson) => {
    let count = 0;
    if (lesson.video_url) count++;
    if (lesson.pdf_url) count++;
    if (lesson.homework_url) count++;
    if (lesson.homework_video_url) count++;
    return count;
  };

  const getLessonContentIcons = (lesson: Lesson) => {
    const icons = [];
    if (lesson.video_url) icons.push(<Video key="video" className="w-3 h-3 text-blue-500" />);
    if (lesson.pdf_url) icons.push(<FileText key="pdf" className="w-3 h-3 text-green-500" />);
    if (lesson.homework_url) icons.push(<Briefcase key="homework" className="w-3 h-3 text-orange-500" />);
    if (lesson.homework_video_url) icons.push(<Play key="homework-video" className="w-3 h-3 text-purple-500" />);
    return icons;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جار تحميل الدروس...</p>
        </div>
      </div>
    );
  }

  if (!subscription) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <Card className="p-8 text-center">
          <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 mb-2">لم يتم العثور على الاشتراك</h2>
          <p className="text-gray-600 mb-4">الاشتراك المطلوب غير موجود أو تم حذفه</p>
          <Button onClick={() => navigate('/student/subscriptions')}>
            العودة للاشتراكات
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="icon"
                onClick={() => navigate('/student/subscriptions')}
                className="rounded-full"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">{subscription.title}</h1>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="secondary">
                    <User className="w-4 h-4 ml-2" />
                    {getGradeText(subscription.grade)}
                  </Badge>
                  <Badge variant="outline">
                    <BookOpen className="w-4 h-4 ml-2" />
                    {subscription.lessons?.length || 0} حصة
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Lessons Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-4 sticky top-24">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                قائمة الحصص
              </h3>
              
              {subscription.lessons && subscription.lessons.length > 0 ? (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {subscription.lessons
                    .sort((a: Lesson, b: Lesson) => a.order_number - b.order_number)
                    .map((lesson: Lesson) => (
                      <Button
                        key={lesson.id}
                        variant={selectedLesson?.id === lesson.id ? "default" : "outline"}
                        className="w-full justify-start text-right h-auto p-3 hover:bg-blue-50 transition-colors"
                        onClick={() => {
                          console.log('اختيار الحصة:', lesson);
                          setSelectedLesson(lesson);
                        }}
                      >
                        <div className="text-right w-full">
                          <div className="font-medium line-clamp-2 text-sm">{lesson.title}</div>
                          <div className="text-xs opacity-70 flex items-center justify-between mt-2">
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              <span>الحصة {lesson.order_number}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <span className="text-xs">{getLessonContentCount(lesson)} محتوى</span>
                            </div>
                          </div>
                          <div className="flex justify-end gap-1 mt-1">
                            {getLessonContentIcons(lesson)}
                          </div>
                        </div>
                      </Button>
                    ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-500">لا توجد حصص متاحة</p>
                </div>
              )}
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {selectedLesson ? (
              <div>
                <div className="mb-4 p-4 bg-blue-50 rounded-lg">
                  <h3 className="font-bold text-blue-900">الحصة المختارة:</h3>
                  <p className="text-blue-700">{selectedLesson.title}</p>
                  <p className="text-sm text-blue-600 mt-1">
                    فيديو الشرح: {selectedLesson.video_url ? '✅ متوفر' : '❌ غير متوفر'} | 
                    ملف PDF: {selectedLesson.pdf_url ? '✅ متوفر' : '❌ غير متوفر'} | 
                    الواجب: {selectedLesson.homework_url ? '✅ متوفر' : '❌ غير متوفر'}
                  </p>
                </div>
                <LessonContentViewer
                  lesson={selectedLesson}
                  studentId={currentStudent?.id}
                  onSendMessage={handleSendMessage}
                />
              </div>
            ) : (
              <Card className="p-8 text-center">
                <Play className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-2">اختر حصة للمشاهدة</h3>
                <p className="text-gray-600">اختر حصة من القائمة الجانبية لبدء المشاهدة</p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentSubscriptionLessons;
