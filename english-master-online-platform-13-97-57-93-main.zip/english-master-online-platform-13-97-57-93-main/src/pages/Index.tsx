import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Moon, Sun, BookOpen, GraduationCap, Heart, Star, Trophy, Target, ArrowRight, Sparkles, Globe, Users, Award, Zap, Brain, Lightbulb, Rocket, Crown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Index = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showWelcome, setShowWelcome] = useState(true);
  const [clickCount, setClickCount] = useState(0);
  const [showHiddenButtons, setShowHiddenButtons] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    const isDark = savedTheme === 'dark';
    setIsDarkMode(isDark);
    document.documentElement.classList.toggle('dark', isDark);

    // التحقق من حالة تسجيل الدخول الموجودة وإعادة التوجيه التلقائي
    const checkExistingLogin = () => {
      // التحقق من تسجيل دخول الطالب
      const currentStudent = localStorage.getItem('currentStudent');
      if (currentStudent) {
        try {
          const studentData = JSON.parse(currentStudent);
          console.log('تم العثور على جلسة طالب موجودة:', studentData);
          navigate('/student/dashboard');
          return;
        } catch (error) {
          console.error('خطأ في قراءة بيانات الطالب:', error);
          localStorage.removeItem('currentStudent');
        }
      }

      // التحقق من تسجيل دخول المدرس
      const currentTeacher = localStorage.getItem('currentTeacher');
      if (currentTeacher) {
        try {
          const teacherData = JSON.parse(currentTeacher);
          console.log('تم العثور على جلسة مدرس موجودة:', teacherData);
          navigate('/teacher/dashboard');
          return;
        } catch (error) {
          console.error('خطأ في قراءة بيانات المدرس:', error);
          localStorage.removeItem('currentTeacher');
        }
      }

      // التحقق من تسجيل دخول الدعم
      const currentSupport = localStorage.getItem('currentSupport');
      if (currentSupport) {
        try {
          const supportData = JSON.parse(currentSupport);
          console.log('تم العثور على جلسة دعم موجودة:', supportData);
          navigate('/support/dashboard');
          return;
        } catch (error) {
          console.error('خطأ في قراءة بيانات الدعم:', error);
          localStorage.removeItem('currentSupport');
        }
      }
    };

    // تشغيل التحقق بعد تحميل الصفحة بـ 500 ميلي ثانية
    const timeoutId = setTimeout(checkExistingLogin, 500);

    return () => clearTimeout(timeoutId);
  }, [navigate]);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', newTheme);
  };

  const handleEnterApp = () => {
    navigate('/student');
  };

  const handleHomeworkClick = () => {
    const newCount = clickCount + 1;
    setClickCount(newCount);
    
    if (newCount >= 5) {
      setShowHiddenButtons(true);
      setClickCount(0);
    }
    
    setTimeout(() => {
      setClickCount(0);
    }, 2000);
  };

  if (showWelcome) {
    return (
      <div className="min-h-screen relative overflow-hidden">
        {/* Enhanced Educational 3D Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-900 via-blue-900 via-indigo-900 to-purple-900">
          {/* Optimized Educational Network Pattern */}
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-10 left-10 w-48 h-48 border border-emerald-400/30 rounded-full will-change-transform"></div>
            <div className="absolute top-32 right-20 w-32 h-32 border border-blue-400/25 rounded-full will-change-transform"></div>
            <div className="absolute bottom-20 left-32 w-40 h-40 border border-purple-400/25 rounded-full will-change-transform"></div>
          </div>

          {/* Optimized Educational Floating Elements */}
          <div className="absolute inset-0">
            {[...Array(15)].map((_, i) => (
              <div
                key={i}
                className={`absolute animate-float will-change-transform ${
                  i % 4 === 0 ? 'text-4xl' : 
                  i % 4 === 1 ? 'text-3xl' :
                  'w-2 h-2 bg-white/30 rounded-full'
                }`}
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 2}s`,
                  animationDuration: `${4 + Math.random() * 2}s`,
                }}
              >
                {i % 4 === 0 && '📚'}
                {i % 4 === 1 && '🎓'}
              </div>
            ))}
          </div>

          {/* Optimized Educational Icons */}
          <div className="absolute top-20 left-12 text-emerald-300/30 will-change-transform">
            <Brain size={60} className="opacity-50" />
          </div>
          <div className="absolute top-32 right-20 text-blue-300/30 will-change-transform">
            <BookOpen size={65} className="opacity-50" />
          </div>
          <div className="absolute bottom-40 left-20 text-green-300/30 will-change-transform">
            <GraduationCap size={50} className="opacity-50" />
          </div>
        </div>

        {/* Enhanced Educational Header */}
        <div className="relative z-20 flex justify-between items-center p-8">
          <div className="animate-slide-up">
            <div className="bg-black/60 backdrop-blur-2xl px-12 py-8 rounded-3xl border-3 border-emerald-400/40 shadow-2xl transform-gpu hover:scale-105 transition-all duration-300" style={{transform: 'perspective(1000px) rotateY(5deg)'}}>
              <h1 className="text-white text-4xl font-black bg-gradient-to-r from-emerald-200 via-blue-200 via-cyan-200 to-purple-200 bg-clip-text text-transparent drop-shadow-2xl">
                🎓 منصة التعليم المتطورة 📚
              </h1>
            </div>
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            className="rounded-full bg-black/50 border-white/50 text-white hover:bg-white/30 backdrop-blur-2xl hover:scale-110 transition-all duration-300 shadow-2xl transform-gpu"
          >
            {isDarkMode ? <Sun className="h-7 w-7" /> : <Moon className="h-7 w-7" />}
          </Button>
        </div>

        {/* Enhanced Educational Main Content */}
        <div className="relative z-20 container mx-auto px-4 md:px-8 py-6 max-w-7xl">
          <Card className="p-6 md:p-16 bg-black/50 backdrop-blur-3xl border-3 border-white/40 text-white animate-rise-from-ground shadow-2xl rounded-3xl transform-gpu hover:scale-[1.02] transition-all duration-500" style={{transform: 'perspective(2000px) rotateX(2deg)'}}>
            <div className="text-center mb-8 md:mb-16">
              <div 
                className="relative mx-auto w-40 h-40 md:w-56 md:h-56 mb-8 md:mb-12 animate-rise-from-ground transform-gpu" 
                style={{animationDelay: '0.2s', transform: 'perspective(1000px) rotateY(10deg)'}}
              >
                <div className="absolute -inset-2 md:-inset-4 rounded-full bg-gradient-to-r from-emerald-400/30 via-blue-400/30 to-purple-400/30"></div>
                <img 
                  src="/lovable-uploads/dfec8824-a3a7-417b-b7ed-fa90a3b92a6c.png" 
                  alt="مستر محمود حمد"
                  className="w-full h-full rounded-full object-cover border-4 border-white/70 shadow-2xl relative z-10 transform-gpu hover:scale-110 transition-all duration-500"
                  style={{ filter: 'drop-shadow(0 0 50px rgba(255, 255, 255, 0.6))' }}
                />
              </div>
              
              <h1 
                className="text-4xl sm:text-6xl md:text-8xl lg:text-9xl font-black mb-6 md:mb-10 animate-rise-from-ground bg-gradient-to-r from-emerald-200 via-white via-blue-200 via-cyan-200 via-purple-200 to-pink-200 bg-clip-text text-transparent drop-shadow-2xl transform-gpu px-2"
                style={{
                  animationDelay: '0.4s',
                  textShadow: '0 0 60px rgba(255, 255, 255, 0.5)',
                  filter: 'drop-shadow(0 0 40px rgba(255, 255, 255, 0.4))',
                  transform: 'perspective(1000px) rotateX(5deg)',
                  lineHeight: '1.1'
                }}
              >
                مستر محمود حمد
              </h1>
              <p className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl mb-8 md:mb-12 animate-rise-from-ground font-black bg-gradient-to-r from-white via-emerald-100 via-cyan-100 to-white bg-clip-text text-transparent px-2" 
                 style={{
                   animationDelay: '0.6s',
                   filter: 'drop-shadow(0 0 30px rgba(255, 255, 255, 0.4))',
                   lineHeight: '1.2'
                 }}>
                🎯 مدرس أول لغة إنجليزية متخصص 🌟
              </p>
            </div>

            {/* Hidden buttons that appear after 5 clicks */}
            {showHiddenButtons && (
              <div className="flex justify-center gap-8 mb-12 animate-rise-from-ground">
                <Button 
                  onClick={() => navigate('/teacher')}
                  className="px-10 py-6 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-black rounded-3xl shadow-2xl text-xl transform-gpu hover:scale-110 transition-all duration-300"
                  style={{transform: 'perspective(1000px) rotateY(-5deg)'}}
                >
                  👨‍🏫 دخول المدرس
                </Button>
                <Button 
                  onClick={() => navigate('/support')}
                  className="px-10 py-6 bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white font-black rounded-3xl shadow-2xl text-xl transform-gpu hover:scale-110 transition-all duration-300"
                  style={{transform: 'perspective(1000px) rotateY(5deg)'}}
                >
                  🛠️ دخول الدعم
                </Button>
              </div>
            )}

            {/* Enhanced Educational Platform Features */}
            <div className="space-y-8 md:space-y-12 text-lg md:text-xl leading-relaxed text-center">
              <div className="bg-black/70 backdrop-blur-2xl rounded-3xl p-6 md:p-12 border-3 border-white/40 animate-rise-from-ground shadow-2xl transform-gpu hover:scale-105 transition-all duration-500" style={{animationDelay: '0.8s', transform: 'perspective(1500px) rotateX(3deg)'}}>
                <p className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl mb-6 md:mb-10 font-black bg-gradient-to-r from-emerald-300 via-cyan-300 via-blue-300 to-purple-300 bg-clip-text text-transparent drop-shadow-2xl px-2"
                   style={{ filter: 'drop-shadow(0 0 40px rgba(255, 255, 255, 0.5))', lineHeight: '1.2' }}>
                  🎓 منصة تعليمية متطورة عالمية الطراز 🌍
                </p>
                <p className="text-xl sm:text-2xl md:text-3xl lg:text-4xl mb-6 md:mb-10 bg-gradient-to-r from-white via-emerald-100 via-cyan-100 to-white bg-clip-text text-transparent font-black px-2"
                   style={{ filter: 'drop-shadow(0 0 25px rgba(255, 255, 255, 0.4))', lineHeight: '1.2' }}>
                  🚀 التكنولوجيا المتقدمة تلتقي بالتعليم المتميز 💡
                </p>
                <p className="text-lg sm:text-xl md:text-2xl bg-gradient-to-r from-white/95 via-emerald-100 via-blue-100 to-white/95 bg-clip-text text-transparent font-bold px-2"
                   style={{ filter: 'drop-shadow(0 0 20px rgba(255, 255, 255, 0.3))', lineHeight: '1.3' }}>
                  منصة تعليمية ثورية تجمع بين أحدث التقنيات وأفضل الممارسات التعليمية لتقديم تجربة تعليمية استثنائية لا مثيل لها
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-10">
                <div className="bg-black/60 backdrop-blur-2xl rounded-3xl p-6 md:p-10 border-3 border-emerald-400/40 animate-rise-from-ground shadow-2xl transform-gpu hover:scale-110 hover:rotate-1 transition-all duration-500" style={{animationDelay: '1.0s', transform: 'perspective(1000px) rotateY(-10deg)'}}>
                  <Brain className="w-16 h-16 md:w-20 md:h-20 mx-auto mb-6 md:mb-8 text-emerald-400 animate-bounce drop-shadow-2xl" 
                         style={{ filter: 'drop-shadow(0 0 30px rgba(52, 211, 153, 0.8))' }} />
                  <p className="bg-gradient-to-r from-white via-emerald-100 to-white bg-clip-text text-transparent font-black text-lg md:text-xl px-2"
                     style={{ filter: 'drop-shadow(0 0 20px rgba(255, 255, 255, 0.4))', lineHeight: '1.3' }}>
                    🧠 تطوير القدرات العقلية والفكرية من خلال منهجية تعليمية متطورة
                  </p>
                </div>
                
                <div className="bg-black/60 backdrop-blur-2xl rounded-3xl p-6 md:p-10 border-3 border-blue-400/40 animate-rise-from-ground shadow-2xl transform-gpu hover:scale-110 hover:rotate-1 transition-all duration-500" style={{animationDelay: '1.2s', transform: 'perspective(1000px) rotateX(5deg)'}}>
                  <BookOpen className="w-16 h-16 md:w-20 md:h-20 mx-auto mb-6 md:mb-8 text-blue-400 animate-pulse drop-shadow-2xl" 
                                 style={{ filter: 'drop-shadow(0 0 30px rgba(96, 165, 250, 0.8))' }} />
                  <p className="bg-gradient-to-r from-white via-blue-100 to-white bg-clip-text text-transparent font-black text-lg md:text-xl px-2"
                     style={{ filter: 'drop-shadow(0 0 20px rgba(255, 255, 255, 0.4))', lineHeight: '1.3' }}>
                    📚 مكتبة تعليمية شاملة ومتنوعة تضم أحدث المناهج والمراجع العلمية
                  </p>
                </div>

                <div className="bg-black/60 backdrop-blur-2xl rounded-3xl p-6 md:p-10 border-3 border-purple-400/40 animate-rise-from-ground shadow-2xl transform-gpu hover:scale-110 hover:rotate-1 transition-all duration-500" style={{animationDelay: '1.4s', transform: 'perspective(1000px) rotateY(10deg)'}}>
                  <Crown className="w-16 h-16 md:w-20 md:h-20 mx-auto mb-6 md:mb-8 text-purple-400 animate-bounce drop-shadow-2xl" 
                                 style={{ filter: 'drop-shadow(0 0 30px rgba(168, 85, 247, 0.8))' }} />
                  <p className="bg-gradient-to-r from-white via-purple-100 to-white bg-clip-text text-transparent font-black text-lg md:text-xl px-2"
                     style={{ filter: 'drop-shadow(0 0 20px rgba(255, 255, 255, 0.4))', lineHeight: '1.3' }}>
                    👑 شهادات ومكافآت عالمية معترف بها دولياً مع نظام تقييم متطور
                  </p>
                </div>
              </div>

              <div className="bg-black/60 backdrop-blur-2xl rounded-3xl p-6 md:p-12 border-3 border-white/40 animate-rise-from-ground shadow-2xl transform-gpu hover:scale-105 transition-all duration-500" style={{animationDelay: '1.6s', transform: 'perspective(1500px) rotateX(-2deg)'}}>
                <h3 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black mb-6 md:mb-10 bg-gradient-to-r from-green-300 via-blue-300 via-cyan-300 to-purple-300 bg-clip-text text-transparent drop-shadow-2xl px-2"
                    style={{ filter: 'drop-shadow(0 0 35px rgba(255, 255, 255, 0.5))', lineHeight: '1.2' }}>
                  🚀 تجربة تعليمية متكاملة ومتطورة وتفاعلية:
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 text-sm sm:text-base md:text-lg lg:text-xl">
                  <div className="bg-gradient-to-r from-pink-500/50 to-purple-500/50 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 md:border-3 border-white/50 font-black backdrop-blur-sm shadow-2xl transform-gpu hover:scale-110 hover:rotate-2 transition-all duration-300" style={{transform: 'perspective(800px) rotateY(-5deg)', lineHeight: '1.2'}}>
                    <div className="text-center">✨ شرح تفاعلي متطور</div>
                  </div>
                  <div 
                    className="bg-gradient-to-r from-blue-500/50 to-cyan-500/50 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 md:border-3 border-white/50 font-black backdrop-blur-sm shadow-2xl cursor-pointer transform-gpu hover:scale-110 hover:rotate-2 transition-all duration-300"
                    onClick={handleHomeworkClick}
                    style={{transform: 'perspective(800px) rotateX(3deg)', lineHeight: '1.2'}}
                  >
                    <div className="text-center">📚 واجبات ذكية تفاعلية</div>
                  </div>
                  <div className="bg-gradient-to-r from-green-500/50 to-emerald-500/50 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 md:border-3 border-white/50 font-black backdrop-blur-sm shadow-2xl transform-gpu hover:scale-110 hover:rotate-2 transition-all duration-300" style={{transform: 'perspective(800px) rotateY(5deg)', lineHeight: '1.2'}}>
                    <div className="text-center">💡 حلول مبتكرة ذكية</div>
                  </div>
                  <div className="bg-gradient-to-r from-yellow-500/50 to-orange-500/50 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 md:border-3 border-white/50 font-black backdrop-blur-sm shadow-2xl transform-gpu hover:scale-110 hover:rotate-2 transition-all duration-300" style={{transform: 'perspective(800px) rotateX(-3deg)', lineHeight: '1.2'}}>
                    <div className="text-center">🎯 امتحانات تكيفية</div>
                  </div>
                  <div className="bg-gradient-to-r from-purple-500/50 to-pink-500/50 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 md:border-3 border-white/50 font-black backdrop-blur-sm shadow-2xl transform-gpu hover:scale-110 hover:rotate-2 transition-all duration-300" style={{transform: 'perspective(800px) rotateY(-3deg)', lineHeight: '1.2'}}>
                    <div className="text-center">📊 تقييم فوري متقدم</div>
                  </div>
                  <div className="bg-gradient-to-r from-red-500/50 to-pink-500/50 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 md:border-3 border-white/50 font-black backdrop-blur-sm shadow-2xl transform-gpu hover:scale-110 hover:rotate-2 transition-all duration-300" style={{transform: 'perspective(800px) rotateX(4deg)', lineHeight: '1.2'}}>
                    <div className="text-center">🎁 نظام مكافآت متميز</div>
                  </div>
                  <div className="bg-gradient-to-r from-indigo-500/50 to-blue-500/50 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 md:border-3 border-white/50 font-black backdrop-blur-sm shadow-2xl transform-gpu hover:scale-110 hover:rotate-2 transition-all duration-300" style={{transform: 'perspective(800px) rotateY(3deg)', lineHeight: '1.2'}}>
                    <div className="text-center">🔄 تعلم تكيفي ذكي</div>
                  </div>
                  <div className="bg-gradient-to-r from-teal-500/50 to-green-500/50 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 md:border-3 border-white/50 font-black backdrop-blur-sm shadow-2xl transform-gpu hover:scale-110 hover:rotate-2 transition-all duration-300" style={{transform: 'perspective(800px) rotateX(-2deg)', lineHeight: '1.2'}}>
                    <div className="text-center">🌐 متابعة دولية شاملة</div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-green-500/60 via-blue-500/60 via-cyan-500/60 to-purple-500/60 backdrop-blur-2xl rounded-3xl p-6 md:p-12 border-3 border-white/50 animate-rise-from-ground shadow-2xl transform-gpu hover:scale-105 transition-all duration-500" style={{animationDelay: '1.8s', transform: 'perspective(1500px) rotateY(2deg)'}}>
                <p className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black mb-6 md:mb-10 bg-gradient-to-r from-white via-yellow-100 to-white bg-clip-text text-transparent drop-shadow-2xl px-2"
                   style={{ filter: 'drop-shadow(0 0 35px rgba(255, 255, 255, 0.5))', lineHeight: '1.2' }}>
                  🙏 شكراً لثقتكم... مرحباً بكم في مستقبل التعليم
                </p>
                <p className="mb-6 md:mb-10 bg-gradient-to-r from-white/95 via-cyan-100 to-white/95 bg-clip-text text-transparent font-black text-lg sm:text-xl md:text-2xl lg:text-3xl px-2"
                   style={{ filter: 'drop-shadow(0 0 25px rgba(255, 255, 255, 0.4))', lineHeight: '1.3' }}>
                  💬 انضموا إلى آلاف الطلاب حول العالم في رحلة التعلم الرقمي المتطور
                </p>
                <p className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black bg-gradient-to-r from-yellow-300 via-orange-300 to-red-300 bg-clip-text text-transparent drop-shadow-2xl px-2"
                   style={{ filter: 'drop-shadow(0 0 40px rgba(255, 255, 255, 0.5))', lineHeight: '1.2' }}>
                  🚀 ابدأ رحلتك التعليمية العالمية المتطورة الآن
                </p>
              </div>
            </div>

            {/* Enhanced Enter Button */}
            <div className="text-center mt-12 md:mt-20 animate-rise-from-ground" style={{animationDelay: '2.0s'}}>
              <div className="relative transform-gpu hover:scale-110 transition-all duration-500">
                <div className="absolute -inset-3 md:-inset-6 bg-gradient-to-r from-emerald-600 via-cyan-600 via-blue-600 via-purple-600 to-pink-600 rounded-3xl blur opacity-80 animate-pulse-custom"></div>
                <Button 
                  onClick={handleEnterApp}
                  className="relative px-8 sm:px-12 md:px-24 py-6 md:py-10 text-xl sm:text-2xl md:text-3xl lg:text-4xl font-black bg-gradient-to-r from-emerald-500 via-cyan-500 via-blue-500 via-purple-500 to-pink-500 hover:from-emerald-600 hover:via-cyan-600 hover:via-blue-600 hover:via-purple-600 hover:to-pink-600 transform hover:scale-110 transition-all duration-500 rounded-3xl shadow-2xl border-3 border-white/50 backdrop-blur-sm transform-gpu"
                  style={{ 
                    filter: 'drop-shadow(0 0 50px rgba(255, 255, 255, 0.4))',
                    transform: 'perspective(1000px) rotateX(5deg)',
                    lineHeight: '1.2'
                  }}
                >
                  <ArrowRight className="w-8 h-8 md:w-12 md:h-12 ml-2 md:ml-4 animate-bounce" />
                  🎓 دخول المنصة 🌟
                </Button>
              </div>
            </div>

            {/* Enhanced Links Section */}
            <div className="mt-12 md:mt-24 animate-rise-from-ground" style={{animationDelay: '2.2s'}}>
              <div className="text-center mb-6 md:mb-10">
                <p className="text-lg sm:text-xl md:text-2xl lg:text-3xl font-black bg-gradient-to-r from-white via-cyan-100 to-white bg-clip-text text-transparent px-2"
                   style={{ lineHeight: '1.2' }}>
                  📱 اسحب لأسفل للمزيد من الروابط والخدمات التعليمية
                </p>
                <div className="animate-bounce mt-4 md:mt-6">
                  <ArrowRight className="w-8 h-8 md:w-10 md:h-10 mx-auto text-white/80 transform rotate-90" />
                </div>
              </div>
              
              {/* Enhanced Links Area */}
              <div className="bg-black/40 backdrop-blur-2xl rounded-3xl p-6 md:p-10 border-2 border-white/30 transform-gpu hover:scale-105 transition-all duration-500" style={{transform: 'perspective(1500px) rotateX(2deg)'}}>
                <h3 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-black mb-6 md:mb-8 text-center bg-gradient-to-r from-emerald-300 via-cyan-300 to-blue-300 bg-clip-text text-transparent px-2"
                    style={{ lineHeight: '1.2' }}>
                  🔗 روابط مهمة وخدمات تعليمية إضافية
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
                  <div className="bg-white/15 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 border-white/30 hover:bg-white/25 transition-all duration-300 cursor-pointer transform-gpu hover:scale-110 hover:rotate-1" style={{transform: 'perspective(800px) rotateY(-3deg)'}}>
                    <h4 className="text-lg sm:text-xl md:text-2xl font-black mb-3 md:mb-4 text-emerald-300">📞 التواصل المباشر</h4>
                    <p className="text-white/90 text-sm sm:text-base md:text-lg" style={{ lineHeight: '1.3' }}>تواصل مع المدرس مباشرة عبر الواتساب للحصول على الدعم الفوري</p>
                  </div>
                  <div className="bg-white/15 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 border-white/30 hover:bg-white/25 transition-all duration-300 cursor-pointer transform-gpu hover:scale-110 hover:rotate-1" style={{transform: 'perspective(800px) rotateY(3deg)'}}>
                    <h4 className="text-lg sm:text-xl md:text-2xl font-black mb-3 md:mb-4 text-blue-300">📚 مكتبة الموارد</h4>
                    <p className="text-white/90 text-sm sm:text-base md:text-lg" style={{ lineHeight: '1.3' }}>الوصول إلى مكتبة شاملة من الموارد التعليمية المتطورة</p>
                  </div>
                  <div className="bg-white/15 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 border-white/30 hover:bg-white/25 transition-all duration-300 cursor-pointer transform-gpu hover:scale-110 hover:rotate-1" style={{transform: 'perspective(800px) rotateX(2deg)'}}>
                    <h4 className="text-lg sm:text-xl md:text-2xl font-black mb-3 md:mb-4 text-purple-300">🎥 قناة اليوتيوب</h4>
                    <p className="text-white/90 text-sm sm:text-base md:text-lg" style={{ lineHeight: '1.3' }}>شاهد الدروس المجانية المتميزة على قناتنا الرسمية</p>
                  </div>
                  <div className="bg-white/15 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 border-white/30 hover:bg-white/25 transition-all duration-300 cursor-pointer transform-gpu hover:scale-110 hover:rotate-1" style={{transform: 'perspective(800px) rotateX(-2deg)'}}>
                    <h4 className="text-lg sm:text-xl md:text-2xl font-black mb-3 md:mb-4 text-green-300">💬 مجموعة التليجرام</h4>
                    <p className="text-white/90 text-sm sm:text-base md:text-lg" style={{ lineHeight: '1.3' }}>انضم لمجموعة الطلاب للمناقشات التعليمية والإعلانات</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return null;
};

export default Index;
