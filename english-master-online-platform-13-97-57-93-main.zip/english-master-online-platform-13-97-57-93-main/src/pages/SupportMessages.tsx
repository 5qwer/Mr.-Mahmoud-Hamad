
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Send, MessageCircle, Clock, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface SupportMessage {
  id: string;
  student_id: string;
  student_name: string;
  message: string;
  image_url: string | null;
  support_reply: string | null;
  support_name: string | null;
  status: string;
  created_at: string;
  replied_at: string | null;
  updated_at: string;
}

const SupportMessages = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState<SupportMessage | null>(null);
  const [replyText, setReplyText] = useState('');
  const [currentSupport, setCurrentSupport] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    // التحقق من جلسة الدعم الفني
    const supportSession = JSON.parse(localStorage.getItem('currentSupport') || 'null');
    if (!supportSession) {
      navigate('/support');
      return;
    }
    setCurrentSupport(supportSession);
    
    loadMessages();
  }, [navigate]);

  const loadMessages = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('support_messages_new')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('خطأ في تحميل الرسائل:', error);
        toast.error('فشل في تحميل الرسائل');
        return;
      }

      setMessages(data || []);
    } catch (error) {
      console.error('خطأ عام في تحميل الرسائل:', error);
      toast.error('حدث خطأ في تحميل الرسائل');
    } finally {
      setLoading(false);
    }
  };

  const handleReplyToMessage = async () => {
    if (!selectedMessage || !replyText.trim() || !currentSupport) {
      toast.error('يرجى كتابة رد');
      return;
    }

    try {
      const { error } = await supabase
        .from('support_messages_new')
        .update({
          support_reply: replyText.trim(),
          support_name: currentSupport.name,
          status: 'replied',
          replied_at: new Date().toISOString()
        })
        .eq('id', selectedMessage.id);

      if (error) {
        console.error('خطأ في الرد على الرسالة:', error);
        toast.error('فشل في إرسال الرد');
        return;
      }

      toast.success('تم إرسال الرد بنجاح');
      setReplyText('');
      setSelectedMessage(null);
      loadMessages();
    } catch (error) {
      console.error('خطأ عام في الرد:', error);
      toast.error('حدث خطأ في الرد');
    }
  };

  const formatDateTime = (dateString: string | null) => {
    if (!dateString) return 'لم يسجل بعد';
    return new Date(dateString).toLocaleString('ar-EG', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="destructive" className="flex items-center gap-1">
          <Clock className="w-3 h-3" />
          في الانتظار
        </Badge>;
      case 'replied':
        return <Badge variant="default" className="bg-green-500 flex items-center gap-1">
          <CheckCircle className="w-3 h-3" />
          تم الرد
        </Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/support/dashboard')}
            className="rounded-full ml-4"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary mr-4">
            💬 رسائل الدعم الفني
          </h1>
        </div>
        
        {currentSupport && (
          <div className="text-sm text-muted-foreground">
            مرحباً {currentSupport.name}
          </div>
        )}
      </div>

      <div className="container mx-auto px-4 py-8 space-y-6">
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold">{messages.length}</p>
                <p className="text-sm text-muted-foreground">إجمالي الرسائل</p>
              </div>
              <MessageCircle className="h-8 w-8 text-blue-500" />
            </div>
          </Card>
          
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold text-orange-500">
                  {messages.filter(m => m.status === 'pending').length}
                </p>
                <p className="text-sm text-muted-foreground">في الانتظار</p>
              </div>
              <Clock className="h-8 w-8 text-orange-500" />
            </div>
          </Card>
          
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold text-green-500">
                  {messages.filter(m => m.status === 'replied').length}
                </p>
                <p className="text-sm text-muted-foreground">تم الرد عليها</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </Card>
        </div>

        {/* Messages List */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">رسائل الطلاب</h2>
            <Button 
              onClick={loadMessages} 
              variant="outline" 
              size="sm"
            >
              تحديث
            </Button>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">جاري تحميل الرسائل...</p>
            </div>
          ) : messages.length === 0 ? (
            <div className="text-center py-8">
              <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground">لا توجد رسائل دعم فني</p>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => (
                <Card key={message.id} className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-semibold text-primary">
                        {message.student_name}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {formatDateTime(message.created_at)}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusBadge(message.status)}
                      {message.status === 'pending' && (
                        <Button
                          size="sm"
                          onClick={() => setSelectedMessage(message)}
                          variant="outline"
                        >
                          رد
                        </Button>
                      )}
                    </div>
                  </div>
                  
                  <div className="mb-3">
                    <p className="text-sm bg-gray-50 p-3 rounded border-r-4 border-blue-500">
                      {message.message}
                    </p>
                    {message.image_url && (
                      <img 
                        src={message.image_url} 
                        alt="مرفق الرسالة"
                        className="mt-2 max-w-xs rounded border"
                      />
                    )}
                  </div>

                  {message.support_reply && (
                    <div className="mt-3 p-3 bg-green-50 rounded border-r-4 border-green-500">
                      <p className="text-sm font-medium text-green-900">
                        رد {message.support_name}:
                      </p>
                      <p className="text-sm text-green-800">{message.support_reply}</p>
                      <p className="text-xs text-green-600 mt-1">
                        {formatDateTime(message.replied_at)}
                      </p>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )}
        </Card>

        {/* Reply Modal */}
        {selectedMessage && (
          <Card className="p-6">
            <h3 className="text-lg font-bold mb-4">
              الرد على رسالة {selectedMessage.student_name}
            </h3>
            
            <div className="mb-4 p-3 bg-gray-50 rounded">
              <p className="text-sm font-medium">الرسالة الأصلية:</p>
              <p className="text-sm">{selectedMessage.message}</p>
              {selectedMessage.image_url && (
                <img 
                  src={selectedMessage.image_url} 
                  alt="مرفق الرسالة"
                  className="mt-2 max-w-xs rounded border"
                />
              )}
            </div>
            
            <div className="space-y-4">
              <Textarea
                placeholder="اكتب ردك هنا..."
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                className="min-h-[100px]"
              />
              
              <div className="flex items-center space-x-2">
                <Button onClick={handleReplyToMessage} className="mr-2">
                  <Send className="w-4 h-4 ml-2" />
                  إرسال الرد
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSelectedMessage(null);
                    setReplyText('');
                  }}
                >
                  إلغاء
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default SupportMessages;
