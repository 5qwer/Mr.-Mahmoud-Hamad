
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Upload, Package, Eye, CreditCard, MessageSquare, Book, MessageCircle, UserX, Settings, Moon, Sun, Link } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import TeacherFinancials from '@/components/TeacherFinancials';

const TeacherDashboard = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentTeacher, setCurrentTeacher] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const teacher = JSON.parse(localStorage.getItem('currentTeacher') || 'null');
    if (!teacher) {
      navigate('/teacher');
      return;
    }
    setCurrentTeacher(teacher);
  }, [navigate]);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
  };

  const menuItems = [
    {
      title: '📥 رفع حصة مدفوعة',
      description: 'إضافة حصص تعليمية جديدة للطلاب المتميزين',
      icon: Upload,
      route: '/teacher/upload-lesson',
      gradient: 'from-cyan-400 via-blue-500 to-purple-600',
      bgImage: '🎬',
      extraEmoji: '⭐',
      shadow: 'shadow-cyan-500/40',
      bgPattern: '🎥🔥📚💎',
      glowColor: 'shadow-[0_0_50px_rgba(6,182,212,0.5)]',
      borderGlow: 'border-cyan-400/50'
    },
    {
      title: '🔄 تغيير بيانات الدخول',
      description: 'تحديث بيانات الحساب والأمان الشخصي',
      icon: Settings,
      route: '/teacher/change-profile',
      gradient: 'from-orange-400 via-red-500 to-pink-600',
      bgImage: '⚙️',
      extraEmoji: '🔧',
      shadow: 'shadow-orange-500/40',
      bgPattern: '🔒🛡️⚡🔑',
      glowColor: 'shadow-[0_0_50px_rgba(251,146,60,0.5)]',
      borderGlow: 'border-orange-400/50'
    },
    {
      title: '📦 إدارة الاشتراكات',
      description: 'إنشاء وإدارة الباقات والاشتراكات الشهرية',
      icon: Package,
      route: '/teacher/subscriptions',
      gradient: 'from-purple-400 via-violet-500 to-indigo-600',
      bgImage: '📦',
      extraEmoji: '💎',
      shadow: 'shadow-purple-500/40',
      bgPattern: '💰🎁📋✨',
      glowColor: 'shadow-[0_0_50px_rgba(168,85,247,0.5)]',
      borderGlow: 'border-purple-400/50'
    },
    {
      title: '👀 مراقبة الدعم الفني',
      description: 'متابعة وإشراف على عمل فريق الدعم',
      icon: Eye,
      route: '/teacher/support-monitoring',
      gradient: 'from-indigo-400 via-blue-500 to-cyan-600',
      bgImage: '👁️',
      extraEmoji: '🔍',
      shadow: 'shadow-indigo-500/40',
      bgPattern: '👥🔍💻📊',
      glowColor: 'shadow-[0_0_50px_rgba(99,102,241,0.5)]',
      borderGlow: 'border-indigo-400/50'
    },
    {
      title: '💸 عرض عمليات التحويل',
      description: 'مراجعة ومتابعة عمليات الدفع المؤكدة',
      icon: CreditCard,
      route: '/teacher/payment-transfers',
      gradient: 'from-emerald-400 via-green-500 to-teal-600',
      bgImage: '💰',
      extraEmoji: '✨',
      shadow: 'shadow-emerald-500/40',
      bgPattern: '💳💸🏦📈',
      glowColor: 'shadow-[0_0_50px_rgba(16,185,129,0.5)]',
      borderGlow: 'border-emerald-400/50'
    },
    {
      title: '💳 إدارة وسائل الدفع',
      description: 'إضافة وحذف وتعديل طرق الدفع المتاحة',
      icon: CreditCard,
      route: '/teacher/payment-methods',
      gradient: 'from-teal-400 via-cyan-500 to-blue-600',
      bgImage: '💳',
      extraEmoji: '🏦',
      shadow: 'shadow-teal-500/40',
      bgPattern: '🔄💰⚡🎯',
      glowColor: 'shadow-[0_0_50px_rgba(20,184,166,0.5)]',
      borderGlow: 'border-teal-400/50'
    },
    {
      title: '📢 رسائل عامة للطلاب',
      description: 'إرسال إشعارات وتحديثات جماعية',
      icon: MessageSquare,
      route: '/teacher/general-messages',
      gradient: 'from-pink-400 via-rose-500 to-red-600',
      bgImage: '📢',
      extraEmoji: '📣',
      shadow: 'shadow-pink-500/40',
      bgPattern: '💌📨🔔📯',
      glowColor: 'shadow-[0_0_50px_rgba(236,72,153,0.5)]',
      borderGlow: 'border-pink-400/50'
    },
    {
      title: '📚 إدارة الكتب',
      description: 'رفع وإدارة المناهج والكتب المدرسية',
      icon: Book,
      route: '/teacher/manage-books',
      gradient: 'from-amber-400 via-yellow-500 to-orange-600',
      bgImage: '📚',
      extraEmoji: '📖',
      shadow: 'shadow-amber-500/40',
      bgPattern: '📝📄🎓💡',
      glowColor: 'shadow-[0_0_50px_rgba(245,158,11,0.5)]',
      borderGlow: 'border-amber-400/50'
    },
    {
      title: '💬 رسائل الطلاب',
      description: 'الرد على استفسارات ومحادثات الطلاب',
      icon: MessageCircle,
      route: '/teacher/student-messages',
      gradient: 'from-cyan-400 via-teal-500 to-green-600',
      bgImage: '💬',
      extraEmoji: '💌',
      shadow: 'shadow-cyan-500/40',
      bgPattern: '👨‍🎓💭🗨️❤️',
      glowColor: 'shadow-[0_0_50px_rgba(6,182,212,0.5)]',
      borderGlow: 'border-cyan-400/50'
    },
    {
      title: '🚫 حظر الطلاب',
      description: 'إدارة وحظر الطلاب المخالفين للقوانين',
      icon: UserX,
      route: '/teacher/block-students',
      gradient: 'from-red-400 via-rose-500 to-pink-600',
      bgImage: '🚫',
      extraEmoji: '⛔',
      shadow: 'shadow-red-500/40',
      bgPattern: '🛑⚠️🔒❌',
      glowColor: 'shadow-[0_0_50px_rgba(239,68,68,0.5)]',
      borderGlow: 'border-red-400/50'
    },
    {
      title: '🔗 إدارة الروابط',
      description: 'إضافة وإدارة الروابط التعليمية المفيدة',
      icon: Link,
      route: '/teacher/manage-links',
      gradient: 'from-violet-400 via-purple-500 to-indigo-600',
      bgImage: '🔗',
      extraEmoji: '🌐',
      shadow: 'shadow-violet-500/40',
      bgPattern: '🌍📎💻🎯',
      glowColor: 'shadow-[0_0_50px_rgba(139,92,246,0.5)]',
      borderGlow: 'border-violet-400/50'
    }
  ];

  const handleLogout = () => {
    localStorage.removeItem('currentTeacher');
    toast.success('تم تسجيل الخروج بنجاح');
    navigate('/');
  };

  return (
    <div className={`min-h-screen transition-all duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-slate-800 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-slate-50 via-blue-50 via-purple-50 to-pink-50'
    } relative overflow-hidden`}>
      
      {/* Animated Background Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 text-6xl animate-float opacity-20">👨‍🏫</div>
        <div className="absolute top-20 right-20 text-5xl animate-float opacity-20" style={{animationDelay: '0.5s'}}>📚</div>
        <div className="absolute bottom-20 left-20 text-5xl animate-float opacity-20" style={{animationDelay: '1s'}}>⭐</div>
        <div className="absolute bottom-10 right-10 text-6xl animate-float opacity-20" style={{animationDelay: '1.5s'}}>🎓</div>
        <div className="absolute top-1/2 left-1/4 text-4xl animate-float opacity-15" style={{animationDelay: '2s'}}>💡</div>
        <div className="absolute top-1/3 right-1/3 text-4xl animate-float opacity-15" style={{animationDelay: '2.5s'}}>✨</div>
        <div className="absolute top-2/3 left-1/3 text-3xl animate-float opacity-15" style={{animationDelay: '3s'}}>🔥</div>
        <div className="absolute bottom-1/3 right-1/4 text-3xl animate-float opacity-15" style={{animationDelay: '3.5s'}}>🚀</div>
      </div>

      {/* Enhanced Header */}
      <div className="flex items-center justify-between p-6 backdrop-blur-xl border-b border-white/20 bg-white/10 shadow-lg">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate('/')}
            className="rounded-full ml-4 backdrop-blur-md hover:scale-110 transition-all duration-200 bg-white/20 border-white/30 hover:bg-white/30"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold gradient-text mr-4 flex items-center gap-3">
            <span className="text-4xl animate-float">👨‍🏫</span>
            مركز قيادة التعليم المتطور
            <span className="text-3xl animate-float" style={{animationDelay: '0.5s'}}>⚡</span>
          </h1>
        </div>
        
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            className="rounded-full backdrop-blur-md hover:scale-110 transition-all duration-200 bg-white/20 border-white/30 hover:bg-white/30"
          >
            {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          <Button onClick={handleLogout} variant="outline" className="backdrop-blur-md hover:scale-105 transition-all duration-200 bg-white/20 border-white/30 hover:bg-white/30 flex items-center gap-2">
            <span>🚪</span>
            تسجيل الخروج
          </Button>
        </div>
      </div>

      {/* Enhanced Welcome Card */}
      {currentTeacher && (
        <div className="container mx-auto px-4 mb-8">
          <Card className="backdrop-blur-xl bg-gradient-to-r from-white/20 via-white/10 to-white/20 border-2 border-white/30 shadow-2xl hover:shadow-3xl transition-all duration-300 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10"></div>
            <div className="relative p-10 text-center">
              <div className="text-8xl mb-6 animate-float">👨‍🏫</div>
              <h2 className="text-4xl font-bold gradient-text mb-4 flex items-center justify-center gap-3">
                <span className="animate-float">🌟</span>
                مرحباً بك أستاذ {currentTeacher.name} المحترم
                <span className="animate-float" style={{animationDelay: '0.5s'}}>🌟</span>
              </h2>
              <p className="text-muted-foreground text-xl font-medium">
                تم تسجيل الدخول في: {new Date(currentTeacher.loginTime).toLocaleString('ar-EG')}
              </p>
              <div className="flex justify-center gap-3 mt-6">
                <span className="text-3xl animate-float">⭐</span>
                <span className="text-3xl animate-float" style={{animationDelay: '0.5s'}}>✨</span>
                <span className="text-3xl animate-float" style={{animationDelay: '1s'}}>🎯</span>
                <span className="text-3xl animate-float" style={{animationDelay: '1.5s'}}>🔥</span>
                <span className="text-3xl animate-float" style={{animationDelay: '2s'}}>🚀</span>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Enhanced Financial Overview */}
      <div className="container mx-auto px-4 mb-8">
        <TeacherFinancials />
      </div>

      {/* Enhanced Menu Grid with Magical Effects */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {menuItems.map((item, index) => (
            <Card 
              key={index} 
              className={`group cursor-pointer relative overflow-hidden transform transition-all duration-500 hover:scale-105 hover:-translate-y-2 ${item.glowColor} ${item.shadow} backdrop-blur-xl bg-gradient-to-br from-white/15 via-white/10 to-transparent border-2 ${item.borderGlow} hover:border-white/50`}
              onClick={() => navigate(item.route)}
              style={{
                boxShadow: '0 25px 50px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.2)'
              }}
            >
              {/* Magical Background Effects */}
              <div className={`absolute inset-0 bg-gradient-to-br ${item.gradient} opacity-10 group-hover:opacity-25 transition-all duration-500`}></div>
              
              {/* Floating Background Emoji */}
              <div className="absolute top-4 right-4 text-8xl opacity-10 group-hover:opacity-30 group-hover:scale-110 transition-all duration-500 animate-float">
                {item.bgImage}
              </div>
              
              {/* Decorative Pattern */}
              <div className="absolute bottom-2 left-2 opacity-5 group-hover:opacity-20 transition-all duration-500">
                {item.bgPattern.split('').map((emoji, i) => (
                  <span key={i} className="inline-block text-2xl animate-float mr-1" style={{animationDelay: `${i * 0.3}s`}}>
                    {emoji}
                  </span>
                ))}
              </div>
              
              {/* Shimmer Effect */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 animate-pulse"></div>
              </div>
              
              <div className="relative p-8 z-10">
                <div className="flex items-center mb-6">
                  <div className={`p-6 rounded-3xl bg-gradient-to-br ${item.gradient} mr-6 shadow-2xl group-hover:scale-125 group-hover:rotate-6 transition-all duration-500 border border-white/20`}>
                    <item.icon className="h-12 w-12 text-white drop-shadow-lg" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="font-bold text-2xl gradient-text group-hover:scale-105 transition-transform duration-300">{item.title}</h3>
                      <span className="text-3xl animate-float group-hover:scale-125 transition-all duration-300">{item.extraEmoji}</span>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed font-medium opacity-80 group-hover:opacity-100 transition-opacity duration-300">{item.description}</p>
                  </div>
                </div>
                
                {/* Enhanced Action Bar */}
                <div className="flex justify-between items-center opacity-40 group-hover:opacity-100 transition-all duration-300">
                  <div className="flex gap-2">
                    <span className="text-2xl animate-float">✨</span>
                    <span className="text-2xl animate-float" style={{animationDelay: '0.3s'}}>⭐</span>
                    <span className="text-2xl animate-float" style={{animationDelay: '0.6s'}}>🎯</span>
                  </div>
                  <div className="text-right bg-gradient-to-r from-white/10 to-white/20 backdrop-blur-sm px-4 py-2 rounded-full border border-white/20">
                    <span className="text-sm font-bold gradient-text">اضغط للدخول</span>
                  </div>
                </div>
              </div>
              
              {/* Magical Border Glow */}
              <div className={`absolute inset-0 rounded-xl bg-gradient-to-br ${item.gradient} opacity-0 group-hover:opacity-30 transition-all duration-500 blur-xl`}></div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
