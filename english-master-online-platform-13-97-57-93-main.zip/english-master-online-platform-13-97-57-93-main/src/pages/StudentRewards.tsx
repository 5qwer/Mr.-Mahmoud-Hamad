
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Gift, Star, Trophy, Zap, Crown, Target } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { dataManager } from '@/utils/dataManager';

const StudentRewards = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<any>(null);
  const [availableRewards, setAvailableRewards] = useState<any[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    setIsDarkMode(savedTheme === 'dark');
    
    const student = JSON.parse(localStorage.getItem('currentStudent') || 'null');
    if (!student) {
      navigate('/student/login');
      return;
    }
    setCurrentStudent(student);

    // Load available rewards
    loadRewards();
  }, [navigate]);

  const loadRewards = () => {
    // Define available rewards based on points
    const rewards = [
      {
        id: 1,
        title: 'حصة مجانية',
        description: 'احصل على حصة مجانية من اختيارك',
        cost: 100,
        icon: '🎓',
        type: 'free_lesson',
        color: 'from-blue-500 to-blue-600'
      },
      {
        id: 2,
        title: 'خصم 50%',
        description: 'خصم 50% على الحصة التالية',
        cost: 50,
        icon: '💰',
        type: 'discount_50',
        color: 'from-green-500 to-green-600'
      },
      {
        id: 3,
        title: 'نقاط إضافية',
        description: 'احصل على 25 نقطة إضافية',
        cost: 75,
        icon: '⭐',
        type: 'bonus_points',
        color: 'from-yellow-500 to-yellow-600'
      },
      {
        id: 4,
        title: 'شارة الامتياز',
        description: 'شارة خاصة تظهر في ملفك الشخصي',
        cost: 150,
        icon: '🏆',
        type: 'badge',
        color: 'from-purple-500 to-purple-600'
      },
      {
        id: 5,
        title: 'اشتراك مجاني لأسبوع',
        description: 'اشتراك مجاني لمدة أسبوع في أي باقة',
        cost: 200,
        icon: '👑',
        type: 'free_subscription',
        color: 'from-red-500 to-red-600'
      }
    ];

    setAvailableRewards(rewards);
  };

  const claimReward = (reward: any) => {
    if (!currentStudent) return;

    const currentPoints = currentStudent.points || 0;
    
    if (currentPoints < reward.cost) {
      toast.error(`تحتاج إلى ${reward.cost - currentPoints} نقطة إضافية لاستبدال هذه المكافأة`);
      return;
    }

    // Deduct points
    const updatedStudent = {
      ...currentStudent,
      points: currentPoints - reward.cost
    };

    // Add reward to student's achievements
    if (!updatedStudent.achievements) updatedStudent.achievements = [];
    updatedStudent.achievements.push({
      id: Date.now(),
      rewardId: reward.id,
      title: reward.title,
      description: reward.description,
      claimedAt: new Date().toISOString(),
      type: reward.type
    });

    // Update student data
    dataManager.updateStudent(currentStudent.id.toString(), updatedStudent);
    localStorage.setItem('currentStudent', JSON.stringify(updatedStudent));
    setCurrentStudent(updatedStudent);

    // Add activity log
    dataManager.addActivityLog(
      currentStudent.id.toString(), 
      'reward_claimed', 
      `تم استبدال ${reward.title} بـ ${reward.cost} نقطة`
    );

    // Special handling for different reward types
    handleRewardEffect(reward, updatedStudent);

    toast.success(`🎉 تم استبدال ${reward.title} بنجاح!`);
  };

  const handleRewardEffect = (reward: any, student: any) => {
    switch (reward.type) {
      case 'bonus_points':
        // Add bonus points
        const bonusStudent = {
          ...student,
          points: student.points + 25,
          totalPoints: (student.totalPoints || 0) + 25
        };
        dataManager.updateStudent(student.id.toString(), bonusStudent);
        localStorage.setItem('currentStudent', JSON.stringify(bonusStudent));
        setCurrentStudent(bonusStudent);
        
        dataManager.addActivityLog(
          student.id.toString(),
          'bonus_points',
          'تم إضافة 25 نقطة إضافية كمكافأة'
        );
        break;
        
      case 'free_lesson':
        // Add a voucher for free lesson
        dataManager.addNotification(
          student.id,
          'free_lesson_voucher',
          'لديك قسيمة حصة مجانية! يمكنك استخدامها في أي حصة تريدها'
        );
        break;
        
      case 'discount_50':
        // Add discount voucher
        dataManager.addNotification(
          student.id,
          'discount_voucher',
          'لديك قسيمة خصم 50% على الحصة التالية!'
        );
        break;
        
      case 'free_subscription':
        // Add free subscription voucher
        dataManager.addNotification(
          student.id,
          'free_subscription_voucher',
          'لديك قسيمة اشتراك مجاني لمدة أسبوع! تواصل مع الدعم لتفعيلها'
        );
        break;
    }
  };

  const getLevelInfo = (totalPoints: number) => {
    const level = Math.floor(totalPoints / 100) + 1;
    const currentLevelPoints = totalPoints % 100;
    const nextLevelPoints = 100 - currentLevelPoints;
    
    return { level, currentLevelPoints, nextLevelPoints };
  };

  const getPointsFromExams = () => {
    if (!currentStudent?.examResults) return 0;
    
    return currentStudent.examResults.reduce((total: number, exam: any) => {
      if (exam.passed) {
        return total + Math.max(1, Math.floor(exam.percentage / 10));
      }
      return total;
    }, 0);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900' 
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`} style={{
      backgroundImage: localStorage.getItem('appBackgroundImage') ? `url(${localStorage.getItem('appBackgroundImage')})` : undefined,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed'
    }}>
      <div className="flex items-center p-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate('/student/dashboard')}
          className="rounded-full ml-4"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold text-primary mr-4">🎁 المكافآت</h1>
      </div>

      <div className="container mx-auto px-4 py-8">
        {currentStudent && (
          <>
            {/* Points Overview */}
            <Card className="p-6 mb-6 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm">
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full mb-4">
                  <Star className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-2xl font-bold mb-2">نقاطك الحالية</h2>
                <div className="text-4xl font-bold text-yellow-600 mb-2">
                  {currentStudent.points || 0}
                </div>
                <p className="text-muted-foreground">
                  إجمالي النقاط المكتسبة: {currentStudent.totalPoints || 0}
                </p>
              </div>

              {/* Level Progress */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">
                    المستوى {getLevelInfo(currentStudent.totalPoints || 0).level}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {getLevelInfo(currentStudent.totalPoints || 0).nextLevelPoints} نقطة للمستوى التالي
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-yellow-400 to-orange-500 h-3 rounded-full transition-all duration-300"
                    style={{ 
                      width: `${(getLevelInfo(currentStudent.totalPoints || 0).currentLevelPoints / 100) * 100}%` 
                    }}
                  ></div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <Trophy className="w-6 h-6 mx-auto mb-1 text-green-500" />
                  <p className="text-sm text-muted-foreground">امتحانات ناجحة</p>
                  <p className="font-bold">{currentStudent.examResults?.filter((e: any) => e.passed).length || 0}</p>
                </div>
                <div>
                  <Target className="w-6 h-6 mx-auto mb-1 text-blue-500" />
                  <p className="text-sm text-muted-foreground">متوسط الدرجات</p>
                  <p className="font-bold">{currentStudent.averageScore || 0}%</p>
                </div>
              </div>
            </Card>

            {/* How to Earn Points */}
            <Card className="p-4 mb-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
              <h3 className="font-bold mb-3 flex items-center">
                <Zap className="w-5 h-5 mr-2 text-yellow-500" />
                كيفية كسب النقاط
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>اجتياز امتحان (1-10 نقاط حسب الدرجة)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>إكمال حصة كاملة (5 نقاط)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span>تسجيل دخول يومي (1 نقطة)</span>
                </div>
              </div>
            </Card>

            {/* Available Rewards */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {availableRewards.map((reward) => (
                <Card 
                  key={reward.id}
                  className="p-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm hover:shadow-lg transition-all duration-300"
                >
                  <div className={`w-full h-32 bg-gradient-to-r ${reward.color} rounded-lg flex items-center justify-center mb-4`}>
                    <div className="text-4xl">{reward.icon}</div>
                  </div>
                  
                  <h3 className="font-bold text-lg mb-2">{reward.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{reward.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span className="font-bold text-yellow-600">{reward.cost}</span>
                    </div>
                    
                    <Button
                      size="sm"
                      onClick={() => claimReward(reward)}
                      disabled={(currentStudent.points || 0) < reward.cost}
                      className={`${
                        (currentStudent.points || 0) >= reward.cost
                          ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700'
                          : 'opacity-50 cursor-not-allowed'
                      }`}
                    >
                      {(currentStudent.points || 0) >= reward.cost ? 'استبدال' : 'غير متاح'}
                    </Button>
                  </div>
                </Card>
              ))}
            </div>

            {/* Claimed Rewards */}
            {currentStudent.achievements && currentStudent.achievements.length > 0 && (
              <Card className="p-4 mt-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
                <h3 className="font-bold mb-4 flex items-center">
                  <Crown className="w-5 h-5 mr-2 text-purple-500" />
                  المكافآت المستبدلة
                </h3>
                
                <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                  {currentStudent.achievements.slice(0, 6).map((achievement: any) => (
                    <div 
                      key={achievement.id}
                      className="flex items-center space-x-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600"
                    >
                      <Gift className="w-5 h-5 text-purple-500" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{achievement.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(achievement.claimedAt).toLocaleDateString('ar-EG')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default StudentRewards;
