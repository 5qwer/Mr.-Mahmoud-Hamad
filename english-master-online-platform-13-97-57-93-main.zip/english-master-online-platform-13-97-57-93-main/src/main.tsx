
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { errorCorrection } from './utils/errorCorrection'
import { dataManager } from './utils/dataManager'

// Initialize error correction system
errorCorrection.initialize();

// Initialize data manager
dataManager.initialize();

// Add welcome sound on first page load
const playInitialWelcome = () => {
  const hasPlayedWelcome = sessionStorage.getItem('welcomeSoundPlayed');
  if (!hasPlayedWelcome) {
    // Create a gentle welcome chime
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 523.25; // C5 note
      oscillator.type = 'sine';
      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
      
      sessionStorage.setItem('welcomeSoundPlayed', 'true');
    } catch (error) {
      console.log('تعذر تشغيل صوت الترحيب:', error);
    }
  }
};

// Play welcome sound after a short delay
setTimeout(playInitialWelcome, 1000);

createRoot(document.getElementById("root")!).render(<App />);
