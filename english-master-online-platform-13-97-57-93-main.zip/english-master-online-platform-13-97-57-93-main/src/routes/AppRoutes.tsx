
import { Routes, Route } from "react-router-dom";
import { lazy, Suspense } from "react";
import { Skeleton } from "@/components/ui/skeleton";

// Critical pages - loaded immediately
import Index from "@/pages/Index";
import NotFound from "@/pages/NotFound";

// Lazy load all other pages
const CheckFirebase = lazy(() => import("@/pages/CheckFirebase"));
const StudentInterface = lazy(() => import("@/pages/StudentInterface"));
const StudentLogin = lazy(() => import("@/pages/StudentLogin"));
const StudentRegister = lazy(() => import("@/pages/StudentRegister"));
const StudentEditProfile = lazy(() => import("@/pages/StudentEditProfile"));
const StudentDashboard = lazy(() => import("@/pages/StudentDashboard"));
const StudentBooks = lazy(() => import("@/pages/StudentBooks"));
const StudentWallet = lazy(() => import("@/pages/StudentWallet"));
const StudentSubscriptions = lazy(() => import("@/pages/StudentSubscriptions"));
const StudentSubscriptionDetails = lazy(() => import("@/pages/StudentSubscriptionDetails"));
const StudentLessonViewer = lazy(() => import("@/pages/StudentLessonViewer"));
const StudentPaidLessons = lazy(() => import("@/pages/StudentPaidLessons"));
const StudentRewards = lazy(() => import("@/pages/StudentRewards"));
const StudentActivity = lazy(() => import("@/pages/StudentActivity"));
const StudentNotifications = lazy(() => import("@/pages/StudentNotifications"));
const StudentSupport = lazy(() => import("@/pages/StudentSupport"));
const StudentFeatureDetail = lazy(() => import("@/pages/StudentFeatureDetail"));
const StudentBookDetails = lazy(() => import("@/pages/StudentBookDetails"));
const StudentBookReceipt = lazy(() => import("@/pages/StudentBookReceipt"));
const StudentBlocked = lazy(() => import("@/pages/StudentBlocked"));

const TeacherLogin = lazy(() => import("@/pages/TeacherLogin"));
const TeacherDashboard = lazy(() => import("@/pages/TeacherDashboard"));
const TeacherUploadLesson = lazy(() => import("@/pages/TeacherUploadLesson"));
const TeacherManageBooks = lazy(() => import("@/pages/TeacherManageBooks"));
const TeacherSubscriptions = lazy(() => import("@/pages/TeacherSubscriptions"));
const TeacherSubscriptionDetails = lazy(() => import("@/pages/TeacherSubscriptionDetails"));
const TeacherManageSubscriptions = lazy(() => import("@/pages/TeacherManageSubscriptions"));
const TeacherChangeProfile = lazy(() => import("@/pages/TeacherChangeProfile"));
const TeacherPaymentMethods = lazy(() => import("@/pages/TeacherPaymentMethods"));
const TeacherPaymentTransfers = lazy(() => import("@/pages/TeacherPaymentTransfers"));
const TeacherGeneralMessages = lazy(() => import("@/pages/TeacherGeneralMessages"));
const TeacherStudentMessages = lazy(() => import("@/pages/TeacherStudentMessages"));
const TeacherBlockStudents = lazy(() => import("@/pages/TeacherBlockStudents"));
const TeacherSupportMonitoring = lazy(() => import("@/pages/TeacherSupportMonitoring"));

const SupportLogin = lazy(() => import("@/pages/SupportLogin"));
const SupportDashboard = lazy(() => import("@/pages/SupportDashboard"));
const SupportMessages = lazy(() => import("@/pages/SupportMessages"));
const SupportPayments = lazy(() => import("@/pages/SupportPayments"));
const SupportRewards = lazy(() => import("@/pages/SupportRewards"));
const SupportBlockStudents = lazy(() => import("@/pages/SupportBlockStudents"));
const SupportBookReservations = lazy(() => import("@/pages/SupportBookReservations"));

const LoadingSkeleton = () => (
  <div className="min-h-screen p-4 space-y-4">
    <Skeleton className="h-12 w-full" />
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <Skeleton className="h-32 w-full" />
      <Skeleton className="h-32 w-full" />
      <Skeleton className="h-32 w-full" />
    </div>
  </div>
);

export function AppRoutes() {
  return (
    <Suspense fallback={<LoadingSkeleton />}>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/check" element={<CheckFirebase />} />
        
        {/* Student Routes */}
        <Route path="/student" element={<StudentInterface />} />
        <Route path="/student/login" element={<StudentLogin />} />
        <Route path="/student/register" element={<StudentRegister />} />
        <Route path="/student/edit-profile" element={<StudentEditProfile />} />
        <Route path="/student/dashboard" element={<StudentDashboard />} />
        <Route path="/student/books" element={<StudentBooks />} />
        <Route path="/student/book-details/:bookId" element={<StudentBookDetails />} />
        <Route path="/student/book-receipt/:bookId" element={<StudentBookReceipt />} />
        <Route path="/student/wallet" element={<StudentWallet />} />
        <Route path="/student/subscriptions" element={<StudentSubscriptions />} />
        <Route path="/student/subscription-details/:subscriptionId" element={<StudentSubscriptionDetails />} />
        <Route path="/student/lesson/:lessonId" element={<StudentLessonViewer />} />
        <Route path="/student/paid-lessons" element={<StudentPaidLessons />} />
        <Route path="/student/rewards" element={<StudentRewards />} />
        <Route path="/student/activity" element={<StudentActivity />} />
        <Route path="/student/notifications" element={<StudentNotifications />} />
          <Route path="/student/support" element={<StudentSupport />} />
          <Route path="/student/blocked" element={<StudentBlocked />} />
        <Route path="/student/feature/:featureId" element={<StudentFeatureDetail />} />
        
        {/* Teacher Routes */}
        <Route path="/teacher" element={<TeacherLogin />} />
        <Route path="/teacher/dashboard" element={<TeacherDashboard />} />
        <Route path="/teacher/upload-lesson" element={<TeacherUploadLesson />} />
        <Route path="/teacher/manage-books" element={<TeacherManageBooks />} />
        <Route path="/teacher/subscriptions" element={<TeacherSubscriptions />} />
        <Route path="/teacher/subscription-details/:subscriptionId" element={<TeacherSubscriptionDetails />} />
        <Route path="/teacher/manage-subscriptions" element={<TeacherManageSubscriptions />} />
        <Route path="/teacher/change-profile" element={<TeacherChangeProfile />} />
        <Route path="/teacher/payment-methods" element={<TeacherPaymentMethods />} />
        <Route path="/teacher/payment-transfers" element={<TeacherPaymentTransfers />} />
        <Route path="/teacher/general-messages" element={<TeacherGeneralMessages />} />
        <Route path="/teacher/student-messages" element={<TeacherStudentMessages />} />
        <Route path="/teacher/block-students" element={<TeacherBlockStudents />} />
        <Route path="/teacher/support-monitoring" element={<TeacherSupportMonitoring />} />
        
        {/* Support Routes */}
        <Route path="/support" element={<SupportLogin />} />
        <Route path="/support/dashboard" element={<SupportDashboard />} />
        <Route path="/support/messages" element={<SupportMessages />} />
        <Route path="/support/payments" element={<SupportPayments />} />
        <Route path="/support/rewards" element={<SupportRewards />} />
        <Route path="/support/block-students" element={<SupportBlockStudents />} />
        <Route path="/support/book-reservations" element={<SupportBookReservations />} />
        
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}
