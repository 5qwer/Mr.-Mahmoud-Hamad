export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      active_student_sessions: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          last_activity: string
          session_token: string
          student_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          last_activity?: string
          session_token: string
          student_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          last_activity?: string
          session_token?: string
          student_id?: string
        }
        Relationships: []
      }
      activity_logs: {
        Row: {
          created_at: string
          description: string
          id: string
          metadata: Json | null
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description: string
          id?: string
          metadata?: Json | null
          type: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string
          id?: string
          metadata?: Json | null
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      available_books: {
        Row: {
          category: string
          cover_image: string | null
          created_at: string
          created_by: string | null
          description: string | null
          duration: number | null
          file_size: string | null
          grade: string
          id: string
          pickup_location: string
          price: number
          subject: string
          title: string
          updated_at: string
        }
        Insert: {
          category?: string
          cover_image?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          duration?: number | null
          file_size?: string | null
          grade: string
          id?: string
          pickup_location: string
          price: number
          subject?: string
          title: string
          updated_at?: string
        }
        Update: {
          category?: string
          cover_image?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          duration?: number | null
          file_size?: string | null
          grade?: string
          id?: string
          pickup_location?: string
          price?: number
          subject?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      book_reservations: {
        Row: {
          book_grade: string
          book_price: number
          book_subject: string
          book_title: string
          created_at: string
          id: string
          notes: string | null
          pickup_location: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          student_grade: string
          student_id: string
          student_name: string
          updated_at: string
        }
        Insert: {
          book_grade: string
          book_price: number
          book_subject: string
          book_title: string
          created_at?: string
          id?: string
          notes?: string | null
          pickup_location: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          student_grade: string
          student_id: string
          student_name: string
          updated_at?: string
        }
        Update: {
          book_grade?: string
          book_price?: number
          book_subject?: string
          book_title?: string
          created_at?: string
          id?: string
          notes?: string | null
          pickup_location?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          student_grade?: string
          student_id?: string
          student_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      books: {
        Row: {
          cover_image: string | null
          created_at: string
          description: string | null
          file_size: string | null
          file_url: string | null
          grade: string
          id: string
          subject: string
          title: string
        }
        Insert: {
          cover_image?: string | null
          created_at?: string
          description?: string | null
          file_size?: string | null
          file_url?: string | null
          grade: string
          id?: string
          subject: string
          title: string
        }
        Update: {
          cover_image?: string | null
          created_at?: string
          description?: string | null
          file_size?: string | null
          file_url?: string | null
          grade?: string
          id?: string
          subject?: string
          title?: string
        }
        Relationships: []
      }
      exam_results: {
        Row: {
          created_at: string
          id: string
          lesson_id: number
          passed: boolean
          percentage: number
          score: number
          total_questions: number
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          lesson_id: number
          passed?: boolean
          percentage: number
          score: number
          total_questions: number
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          lesson_id?: number
          passed?: boolean
          percentage?: number
          score?: number
          total_questions?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "exam_results_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_results_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
          {
            foreignKeyName: "exam_results_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "user_subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
        ]
      }
      exam_results_auth: {
        Row: {
          created_at: string | null
          id: string
          lesson_id: number | null
          passed: boolean | null
          percentage: number
          score: number
          total_questions: number
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          lesson_id?: number | null
          passed?: boolean | null
          percentage: number
          score: number
          total_questions: number
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          lesson_id?: number | null
          passed?: boolean | null
          percentage?: number
          score?: number
          total_questions?: number
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "exam_results_auth_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exam_results_auth_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
          {
            foreignKeyName: "exam_results_auth_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "user_subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
        ]
      }
      general_messages: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          message: string
          priority: string
          target_all: boolean | null
          target_grades: string[] | null
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          message: string
          priority?: string
          target_all?: boolean | null
          target_grades?: string[] | null
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          message?: string
          priority?: string
          target_all?: boolean | null
          target_grades?: string[] | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      lesson_exams: {
        Row: {
          correct_option: number
          created_at: string
          id: string
          lesson_id: number
          option_1: string
          option_2: string
          option_3: string
          option_4: string
          order_number: number
          question_text: string
          updated_at: string
        }
        Insert: {
          correct_option: number
          created_at?: string
          id?: string
          lesson_id: number
          option_1: string
          option_2: string
          option_3: string
          option_4: string
          order_number?: number
          question_text: string
          updated_at?: string
        }
        Update: {
          correct_option?: number
          created_at?: string
          id?: string
          lesson_id?: number
          option_1?: string
          option_2?: string
          option_3?: string
          option_4?: string
          order_number?: number
          question_text?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lesson_exams_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lesson_exams_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
          {
            foreignKeyName: "lesson_exams_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "user_subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
        ]
      }
      lesson_purchases: {
        Row: {
          id: string
          lesson_id: number
          purchase_price: number
          purchased_at: string
          student_id: string
        }
        Insert: {
          id?: string
          lesson_id: number
          purchase_price: number
          purchased_at?: string
          student_id: string
        }
        Update: {
          id?: string
          lesson_id?: number
          purchase_price?: number
          purchased_at?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lesson_purchases_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      lesson_questions: {
        Row: {
          correct_answer: string
          created_at: string
          id: string
          lesson_id: number
          option_a: string
          option_b: string
          option_c: string
          option_d: string
          order_number: number
          question: string
          updated_at: string
        }
        Insert: {
          correct_answer: string
          created_at?: string
          id?: string
          lesson_id: number
          option_a: string
          option_b: string
          option_c: string
          option_d: string
          order_number?: number
          question: string
          updated_at?: string
        }
        Update: {
          correct_answer?: string
          created_at?: string
          id?: string
          lesson_id?: number
          option_a?: string
          option_b?: string
          option_c?: string
          option_d?: string
          order_number?: number
          question?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_lesson_questions_lesson_id"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_lesson_questions_lesson_id"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
          {
            foreignKeyName: "fk_lesson_questions_lesson_id"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "user_subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
        ]
      }
      lessons: {
        Row: {
          cover_image: string | null
          created_at: string
          description: string | null
          grade: string
          homework_url: string | null
          homework_video_url: string | null
          id: number
          order_number: number
          pdf_url: string | null
          price: number
          solution_url: string | null
          subscription_id: number | null
          title: string
          updated_at: string
          video_url: string | null
        }
        Insert: {
          cover_image?: string | null
          created_at?: string
          description?: string | null
          grade?: string
          homework_url?: string | null
          homework_video_url?: string | null
          id?: number
          order_number?: number
          pdf_url?: string | null
          price: number
          solution_url?: string | null
          subscription_id?: number | null
          title: string
          updated_at?: string
          video_url?: string | null
        }
        Update: {
          cover_image?: string | null
          created_at?: string
          description?: string | null
          grade?: string
          homework_url?: string | null
          homework_video_url?: string | null
          id?: number
          order_number?: number
          pdf_url?: string | null
          price?: number
          solution_url?: string | null
          subscription_id?: number | null
          title?: string
          updated_at?: string
          video_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_lessons_subscription"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["subscription_id"]
          },
          {
            foreignKeyName: "fk_lessons_subscription"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          created_at: string | null
          from_type: string
          id: string
          image_url: string | null
          message: string
          read: boolean | null
          to_type: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          from_type: string
          id?: string
          image_url?: string | null
          message: string
          read?: boolean | null
          to_type: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          from_type?: string
          id?: string
          image_url?: string | null
          message?: string
          read?: boolean | null
          to_type?: string
          user_id?: string | null
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          data: Json | null
          id: string
          message: string
          read: boolean
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          data?: Json | null
          id?: string
          message: string
          read?: boolean
          type: string
          user_id: string
        }
        Update: {
          created_at?: string
          data?: Json | null
          id?: string
          message?: string
          read?: boolean
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      payment_methods: {
        Row: {
          created_at: string
          id: number
          name: string
          number: string
        }
        Insert: {
          created_at?: string
          id?: number
          name: string
          number: string
        }
        Update: {
          created_at?: string
          id?: number
          name?: string
          number?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          block_reason: string | null
          completed_lessons: number
          created_at: string
          full_name: string
          grade: string
          id: string
          is_blocked: boolean
          login_code: string | null
          login_number: string | null
          parent_number: string | null
          points: number
          student_number: string | null
          total_lessons: number
          updated_at: string
          user_id: string
          user_type: string | null
          wallet_balance: number
        }
        Insert: {
          block_reason?: string | null
          completed_lessons?: number
          created_at?: string
          full_name: string
          grade?: string
          id?: string
          is_blocked?: boolean
          login_code?: string | null
          login_number?: string | null
          parent_number?: string | null
          points?: number
          student_number?: string | null
          total_lessons?: number
          updated_at?: string
          user_id: string
          user_type?: string | null
          wallet_balance?: number
        }
        Update: {
          block_reason?: string | null
          completed_lessons?: number
          created_at?: string
          full_name?: string
          grade?: string
          id?: string
          is_blocked?: boolean
          login_code?: string | null
          login_number?: string | null
          parent_number?: string | null
          points?: number
          student_number?: string | null
          total_lessons?: number
          updated_at?: string
          user_id?: string
          user_type?: string | null
          wallet_balance?: number
        }
        Relationships: []
      }
      purchased_lessons: {
        Row: {
          id: string
          lesson_id: number
          purchased_at: string
          user_id: string
        }
        Insert: {
          id?: string
          lesson_id: number
          purchased_at?: string
          user_id: string
        }
        Update: {
          id?: string
          lesson_id?: number
          purchased_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "purchased_lessons_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchased_lessons_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
          {
            foreignKeyName: "purchased_lessons_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "user_subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
        ]
      }
      rewards: {
        Row: {
          created_at: string
          id: string
          lesson_id: number | null
          points: number
          reason: string | null
          student_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          lesson_id?: number | null
          points?: number
          reason?: string | null
          student_id: string
        }
        Update: {
          created_at?: string
          id?: string
          lesson_id?: number | null
          points?: number
          reason?: string | null
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "rewards_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_activity: {
        Row: {
          activity_type: string
          created_at: string
          description: string
          id: string
          lesson_id: number | null
          metadata: Json | null
          student_id: string
        }
        Insert: {
          activity_type: string
          created_at?: string
          description: string
          id?: string
          lesson_id?: number | null
          metadata?: Json | null
          student_id: string
        }
        Update: {
          activity_type?: string
          created_at?: string
          description?: string
          id?: string
          lesson_id?: number | null
          metadata?: Json | null
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_activity_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_blocks: {
        Row: {
          action: string
          blocked_by: string
          created_at: string
          id: string
          reason: string | null
          student_id: string
        }
        Insert: {
          action: string
          blocked_by: string
          created_at?: string
          id?: string
          reason?: string | null
          student_id: string
        }
        Update: {
          action?: string
          blocked_by?: string
          created_at?: string
          id?: string
          reason?: string | null
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_blocks_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_teacher_messages: {
        Row: {
          answered_at: string | null
          created_at: string
          id: string
          is_answered: boolean
          lesson_id: number
          message_image: string | null
          message_text: string | null
          student_id: string
          student_name: string
          teacher_reply: string | null
        }
        Insert: {
          answered_at?: string | null
          created_at?: string
          id?: string
          is_answered?: boolean
          lesson_id: number
          message_image?: string | null
          message_text?: string | null
          student_id: string
          student_name: string
          teacher_reply?: string | null
        }
        Update: {
          answered_at?: string | null
          created_at?: string
          id?: string
          is_answered?: boolean
          lesson_id?: number
          message_image?: string | null
          message_text?: string | null
          student_id?: string
          student_name?: string
          teacher_reply?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "student_teacher_messages_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_teacher_messages_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
          {
            foreignKeyName: "student_teacher_messages_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "user_subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
        ]
      }
      students: {
        Row: {
          block_reason: string | null
          blocked_at: string | null
          blocked_by: string | null
          completed_lessons: number
          created_at: string
          email: string | null
          full_name: string
          grade: string
          id: string
          is_blocked: boolean
          parent_number: string | null
          password: string
          points: number
          student_number: string | null
          total_lessons: number
          updated_at: string
          user_id: string | null
          wallet_balance: number
        }
        Insert: {
          block_reason?: string | null
          blocked_at?: string | null
          blocked_by?: string | null
          completed_lessons?: number
          created_at?: string
          email?: string | null
          full_name: string
          grade?: string
          id?: string
          is_blocked?: boolean
          parent_number?: string | null
          password: string
          points?: number
          student_number?: string | null
          total_lessons?: number
          updated_at?: string
          user_id?: string | null
          wallet_balance?: number
        }
        Update: {
          block_reason?: string | null
          blocked_at?: string | null
          blocked_by?: string | null
          completed_lessons?: number
          created_at?: string
          email?: string | null
          full_name?: string
          grade?: string
          id?: string
          is_blocked?: boolean
          parent_number?: string | null
          password?: string
          points?: number
          student_number?: string | null
          total_lessons?: number
          updated_at?: string
          user_id?: string | null
          wallet_balance?: number
        }
        Relationships: []
      }
      students_auth: {
        Row: {
          block_reason: string | null
          class_grade: string
          completed_lessons: number | null
          created_at: string | null
          full_name: string
          id: string
          is_blocked: boolean | null
          parent_phone: string | null
          points: number | null
          student_code: string | null
          total_lessons: number | null
          updated_at: string | null
          user_id: string | null
          wallet_balance: number | null
        }
        Insert: {
          block_reason?: string | null
          class_grade?: string
          completed_lessons?: number | null
          created_at?: string | null
          full_name: string
          id?: string
          is_blocked?: boolean | null
          parent_phone?: string | null
          points?: number | null
          student_code?: string | null
          total_lessons?: number | null
          updated_at?: string | null
          user_id?: string | null
          wallet_balance?: number | null
        }
        Update: {
          block_reason?: string | null
          class_grade?: string
          completed_lessons?: number | null
          created_at?: string | null
          full_name?: string
          id?: string
          is_blocked?: boolean | null
          parent_phone?: string | null
          points?: number | null
          student_code?: string | null
          total_lessons?: number | null
          updated_at?: string | null
          user_id?: string | null
          wallet_balance?: number | null
        }
        Relationships: []
      }
      subscription_lessons: {
        Row: {
          id: string
          lesson_id: number
          subscription_id: number
        }
        Insert: {
          id?: string
          lesson_id: number
          subscription_id: number
        }
        Update: {
          id?: string
          lesson_id?: number
          subscription_id?: number
        }
        Relationships: [
          {
            foreignKeyName: "subscription_lessons_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscription_lessons_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
          {
            foreignKeyName: "subscription_lessons_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "user_subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
          {
            foreignKeyName: "subscription_lessons_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["subscription_id"]
          },
          {
            foreignKeyName: "subscription_lessons_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          cover_image: string | null
          created_at: string
          description: string | null
          duration_days: number
          grade: string
          id: number
          image_path: string | null
          price: number
          title: string
          updated_at: string
        }
        Insert: {
          cover_image?: string | null
          created_at?: string
          description?: string | null
          duration_days?: number
          grade?: string
          id?: number
          image_path?: string | null
          price: number
          title: string
          updated_at?: string
        }
        Update: {
          cover_image?: string | null
          created_at?: string
          description?: string | null
          duration_days?: number
          grade?: string
          id?: number
          image_path?: string | null
          price?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      subscriptions_users: {
        Row: {
          expires_at: string
          id: string
          is_active: boolean | null
          purchased_at: string | null
          subscription_id: number | null
          user_id: string
        }
        Insert: {
          expires_at: string
          id?: string
          is_active?: boolean | null
          purchased_at?: string | null
          subscription_id?: number | null
          user_id: string
        }
        Update: {
          expires_at?: string
          id?: string
          is_active?: boolean | null
          purchased_at?: string | null
          subscription_id?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_users_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["subscription_id"]
          },
          {
            foreignKeyName: "subscriptions_users_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_users_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      support_messages: {
        Row: {
          created_at: string
          from_type: string
          id: string
          image_url: string | null
          message: string
          read: boolean
          support_name: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          from_type: string
          id?: string
          image_url?: string | null
          message: string
          read?: boolean
          support_name?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          from_type?: string
          id?: string
          image_url?: string | null
          message?: string
          read?: boolean
          support_name?: string | null
          user_id?: string
        }
        Relationships: []
      }
      support_messages_new: {
        Row: {
          created_at: string
          id: string
          image_url: string | null
          message: string
          replied_at: string | null
          status: string
          student_id: string
          student_name: string
          support_name: string | null
          support_reply: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          image_url?: string | null
          message: string
          replied_at?: string | null
          status?: string
          student_id: string
          student_name: string
          support_name?: string | null
          support_reply?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          image_url?: string | null
          message?: string
          replied_at?: string | null
          status?: string
          student_id?: string
          student_name?: string
          support_name?: string | null
          support_reply?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      support_staff: {
        Row: {
          code: string
          created_at: string
          full_name: string
          id: string
          is_active: boolean
          last_login: string | null
        }
        Insert: {
          code: string
          created_at?: string
          full_name: string
          id?: string
          is_active?: boolean
          last_login?: string | null
        }
        Update: {
          code?: string
          created_at?: string
          full_name?: string
          id?: string
          is_active?: boolean
          last_login?: string | null
        }
        Relationships: []
      }
      support_team: {
        Row: {
          code: string
          created_at: string
          id: string
          last_login: string | null
          last_logout: string | null
          name: string
          online: boolean
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          last_login?: string | null
          last_logout?: string | null
          name: string
          online?: boolean
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          last_login?: string | null
          last_logout?: string | null
          name?: string
          online?: boolean
        }
        Relationships: []
      }
      teacher_notifications: {
        Row: {
          created_at: string
          id: string
          message: string
          read: boolean
          student_id: string | null
          student_name: string | null
          title: string
          type: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          read?: boolean
          student_id?: string | null
          student_name?: string | null
          title: string
          type: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          read?: boolean
          student_id?: string | null
          student_name?: string | null
          title?: string
          type?: string
        }
        Relationships: []
      }
      teachers: {
        Row: {
          created_at: string
          id: string
          last_login: string | null
          login_code: string
          login_number: string
          name: string
        }
        Insert: {
          created_at?: string
          id?: string
          last_login?: string | null
          login_code: string
          login_number: string
          name: string
        }
        Update: {
          created_at?: string
          id?: string
          last_login?: string | null
          login_code?: string
          login_number?: string
          name?: string
        }
        Relationships: []
      }
      user_sessions: {
        Row: {
          created_at: string | null
          is_active: boolean | null
          session_token: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          is_active?: boolean | null
          session_token: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          is_active?: boolean | null
          session_token?: string
          user_id?: string
        }
        Relationships: []
      }
      user_subscriptions: {
        Row: {
          expires_at: string
          id: string
          purchased_at: string
          subscription_id: number
          user_id: string
        }
        Insert: {
          expires_at: string
          id?: string
          purchased_at?: string
          subscription_id: number
          user_id: string
        }
        Update: {
          expires_at?: string
          id?: string
          purchased_at?: string
          subscription_id?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_subscriptions_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["subscription_id"]
          },
          {
            foreignKeyName: "user_subscriptions_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      wallet_requests: {
        Row: {
          amount: number
          created_at: string
          id: string
          message: string | null
          payment_method: string
          reject_reason: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          transfer_id: string
          transfer_image: string | null
          transfer_number: string
          transfer_time: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          message?: string | null
          payment_method: string
          reject_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          transfer_id: string
          transfer_image?: string | null
          transfer_number: string
          transfer_time: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          message?: string | null
          payment_method?: string
          reject_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          transfer_id?: string
          transfer_image?: string | null
          transfer_number?: string
          transfer_time?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wallet_requests_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      wallet_transactions: {
        Row: {
          amount: number
          created_at: string
          description: string | null
          id: string
          lesson_id: number | null
          student_id: string
          type: string
        }
        Insert: {
          amount: number
          created_at?: string
          description?: string | null
          id?: string
          lesson_id?: number | null
          student_id: string
          type: string
        }
        Update: {
          amount?: number
          created_at?: string
          description?: string | null
          id?: string
          lesson_id?: number | null
          student_id?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "wallet_transactions_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      wallet_transactions_auth: {
        Row: {
          amount: number
          created_at: string | null
          description: string | null
          id: string
          lesson_id: number | null
          type: string
          user_id: string | null
        }
        Insert: {
          amount: number
          created_at?: string | null
          description?: string | null
          id?: string
          lesson_id?: number | null
          type: string
          user_id?: string | null
        }
        Update: {
          amount?: number
          created_at?: string | null
          description?: string | null
          id?: string
          lesson_id?: number | null
          type?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wallet_transactions_auth_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wallet_transactions_auth_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
          {
            foreignKeyName: "wallet_transactions_auth_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "user_subscription_lessons_view"
            referencedColumns: ["lesson_id"]
          },
        ]
      }
      wallets: {
        Row: {
          balance: number | null
          created_at: string | null
          id: string
          last_transaction_date: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          balance?: number | null
          created_at?: string | null
          id?: string
          last_transaction_date?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          balance?: number | null
          created_at?: string | null
          id?: string
          last_transaction_date?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      subscription_lessons_view: {
        Row: {
          duration_days: number | null
          homework_url: string | null
          homework_video_url: string | null
          lesson_cover: string | null
          lesson_created_at: string | null
          lesson_description: string | null
          lesson_grade: string | null
          lesson_id: number | null
          lesson_price: number | null
          lesson_title: string | null
          order_number: number | null
          pdf_url: string | null
          solution_url: string | null
          subscription_cover: string | null
          subscription_description: string | null
          subscription_grade: string | null
          subscription_id: number | null
          subscription_price: number | null
          subscription_title: string | null
          video_url: string | null
        }
        Relationships: []
      }
      user_subscription_lessons_view: {
        Row: {
          duration_days: number | null
          expires_at: string | null
          homework_url: string | null
          homework_video_url: string | null
          is_active: boolean | null
          lesson_cover: string | null
          lesson_created_at: string | null
          lesson_description: string | null
          lesson_grade: string | null
          lesson_id: number | null
          lesson_price: number | null
          lesson_title: string | null
          order_number: number | null
          pdf_url: string | null
          purchased_at: string | null
          solution_url: string | null
          subscription_cover: string | null
          subscription_description: string | null
          subscription_grade: string | null
          subscription_id: number | null
          subscription_price: number | null
          subscription_title: string | null
          user_id: string | null
          video_url: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_users_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscription_lessons_view"
            referencedColumns: ["subscription_id"]
          },
          {
            foreignKeyName: "subscriptions_users_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_users_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      authenticate_student: {
        Args: { student_name: string; student_password: string }
        Returns: {
          id: string
          full_name: string
          grade: string
          parent_number: string
          student_number: string
          wallet_balance: number
          points: number
          completed_lessons: number
          total_lessons: number
          is_blocked: boolean
          block_reason: string
        }[]
      }
      authenticate_support: {
        Args: { support_name: string; support_code: string }
        Returns: {
          id: string
          full_name: string
        }[]
      }
      authenticate_support_team: {
        Args: { support_name: string; support_code: string }
        Returns: {
          id: string
          name: string
        }[]
      }
      authenticate_teacher: {
        Args: {
          teacher_name: string
          teacher_code: string
          teacher_number: string
        }
        Returns: {
          id: string
          name: string
        }[]
      }
      check_active_session: {
        Args: { p_student_id: string }
        Returns: boolean
      }
      check_protected_fields_unchanged: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      cleanup_expired_sessions: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      create_student_session: {
        Args: { p_student_id: string; p_session_token: string }
        Returns: boolean
      }
      create_student_with_auth: {
        Args: {
          student_email: string
          student_password: string
          student_name: string
          student_number: string
          parent_phone: string
          student_grade: string
        }
        Returns: {
          success: boolean
          message: string
          student_id: string
        }[]
      }
      deduct_balance: {
        Args: { student_id: string; amount: number }
        Returns: undefined
      }
      delete_subscription_safely: {
        Args: { subscription_id_param: number }
        Returns: undefined
      }
      end_student_session: {
        Args: { p_session_token: string }
        Returns: boolean
      }
      get_student_by_credentials: {
        Args: { student_email: string; student_password: string }
        Returns: {
          id: string
          full_name: string
          grade: string
          parent_number: string
          student_number: string
          wallet_balance: number
          points: number
          completed_lessons: number
          total_lessons: number
          is_blocked: boolean
          block_reason: string
          email: string
          user_id: string
        }[]
      }
      get_student_profile: {
        Args: { student_user_id: string }
        Returns: {
          id: string
          full_name: string
          grade: string
          parent_number: string
          student_number: string
          wallet_balance: number
          points: number
          completed_lessons: number
          total_lessons: number
          is_blocked: boolean
          block_reason: string
          created_at: string
        }[]
      }
      get_subscription_lessons: {
        Args: { subscription_id_param: number }
        Returns: {
          lesson_id: number
          lesson_title: string
          lesson_description: string
          lesson_price: number
          lesson_cover: string
          video_url: string
          pdf_url: string
          homework_url: string
          homework_video_url: string
          solution_url: string
          order_number: number
          lesson_grade: string
          lesson_created_at: string
        }[]
      }
      get_user_subscription_lessons: {
        Args: { user_id_param: string }
        Returns: {
          subscription_id: number
          subscription_title: string
          lesson_id: number
          lesson_title: string
          lesson_description: string
          video_url: string
          pdf_url: string
          homework_url: string
          homework_video_url: string
          solution_url: string
          order_number: number
          expires_at: string
        }[]
      }
      insert_user_session: {
        Args: { p_user_id: string; p_session_token: string }
        Returns: undefined
      }
      process_wallet_approval_transaction: {
        Args: {
          p_request_id: string
          p_student_id: string
          p_amount_to_add: number
          p_payment_method: string
          p_transfer_number: string
        }
        Returns: Json
      }
      toggle_student_block: {
        Args: {
          p_student_id: string
          p_action: string
          p_reason?: string
          p_blocked_by?: string
        }
        Returns: Json
      }
      update_session_activity: {
        Args: { p_session_token: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
