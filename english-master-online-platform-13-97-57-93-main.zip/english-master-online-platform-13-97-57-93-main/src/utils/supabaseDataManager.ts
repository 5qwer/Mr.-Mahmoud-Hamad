import { supabase } from '@/integrations/supabase/client';

interface Profile {
  id: string;
  updated_at?: string;
  full_name?: string;
  grade?: string;
  parent_number?: string;
  student_number?: string;
  wallet_balance?: number;
  points?: number;
  completed_lessons?: number;
  total_lessons?: number;
  is_blocked?: boolean;
  block_reason?: string;
}

class SupabaseDataManager {
  async getProfile(userId: string): Promise<Profile | null> {
    try {
      console.log('Fetching profile for user:', userId);
      
      const { data, error } = await supabase
        .from('profiles')
        .select(`full_name, grade, parent_number, student_number, wallet_balance, points, completed_lessons, total_lessons, is_blocked, block_reason`)
        .eq('user_id', userId)
        .single();

      if (error) {
        console.error('Error fetching profile:', error.message);
        return null;
      }

      if (!data) {
        console.log('No profile found for user:', userId);
        return null;
      }

      // Create a new profile object explicitly
      const profile: Profile = {
        id: userId,
        full_name: data.full_name || undefined,
        grade: data.grade || undefined,
        parent_number: data.parent_number || undefined,
        student_number: data.student_number || undefined,
        wallet_balance: data.wallet_balance || undefined,
        points: data.points || undefined,
        completed_lessons: data.completed_lessons || undefined,
        total_lessons: data.total_lessons || undefined,
        is_blocked: data.is_blocked || undefined,
        block_reason: data.block_reason || undefined
      };

      console.log('Profile fetched successfully:', profile);
      return profile;
    } catch (error: any) {
      console.error('Unexpected error fetching profile:', error.message);
      return null;
    }
  }

  // إضافة وظائف إدارة الجلسات
  async checkActiveSession(studentId: string): Promise<boolean> {
    try {
      const { data, error } = await supabase.rpc('check_active_session', {
        p_student_id: studentId
      });

      if (error) {
        console.error('Error checking active session:', error.message);
        return false;
      }

      return data || false;
    } catch (error: any) {
      console.error('Unexpected error checking active session:', error.message);
      return false;
    }
  }

  async createStudentSession(studentId: string): Promise<{ success: boolean; sessionToken?: string }> {
    try {
      // توليد session token فريد
      const sessionToken = `session_${studentId}_${Date.now()}_${Math.random().toString(36).substring(2)}`;
      
      const { data, error } = await supabase.rpc('create_student_session', {
        p_student_id: studentId,
        p_session_token: sessionToken
      });

      if (error) {
        console.error('Error creating student session:', error.message);
        return { success: false };
      }

      // حفظ session token في localStorage للاستخدام لاحقاً
      localStorage.setItem('student_session_token', sessionToken);
      
      return { success: true, sessionToken };
    } catch (error: any) {
      console.error('Unexpected error creating student session:', error.message);
      return { success: false };
    }
  }

  async endStudentSession(): Promise<boolean> {
    try {
      const sessionToken = localStorage.getItem('student_session_token');
      if (!sessionToken) {
        return true; // لا توجد جلسة للإنهاء
      }

      const { data, error } = await supabase.rpc('end_student_session', {
        p_session_token: sessionToken
      });

      if (error) {
        console.error('Error ending student session:', error.message);
        return false;
      }

      // إزالة session token من localStorage
      localStorage.removeItem('student_session_token');
      
      return true;
    } catch (error: any) {
      console.error('Unexpected error ending student session:', error.message);
      return false;
    }
  }

  async updateSessionActivity(): Promise<boolean> {
    try {
      const sessionToken = localStorage.getItem('student_session_token');
      if (!sessionToken) {
        return false;
      }

      const { data, error } = await supabase.rpc('update_session_activity', {
        p_session_token: sessionToken
      });

      if (error) {
        console.error('Error updating session activity:', error.message);
        return false;
      }

      return true;
    } catch (error: any) {
      console.error('Unexpected error updating session activity:', error.message);
      return false;
    }
  }

  async updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile | null> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', userId)
        .select()
        .single();

      if (error) {
        console.error('Error updating profile:', error.message);
        return null;
      }

      return data || null;
    } catch (error: any) {
      console.error('Unexpected error updating profile:', error.message);
      return null;
    }
  }

  // تحديث رصيد الطالب مع خصم المبلغ نهائياً
  async deductStudentBalance(studentId: string, amount: number, description: string, lessonId?: number): Promise<boolean> {
    try {
      console.log('خصم المبلغ من رصيد الطالب:', { studentId, amount, description });

      // الحصول على الرصيد الحالي
      const { data: student, error: fetchError } = await supabase
        .from('students')
        .select('wallet_balance')
        .eq('id', studentId)
        .single();

      if (fetchError || !student) {
        console.error('خطأ في الحصول على بيانات الطالب:', fetchError);
        return false;
      }

      const currentBalance = student.wallet_balance || 0;
      
      if (currentBalance < amount) {
        console.error('الرصيد غير كافي');
        return false;
      }

      const newBalance = currentBalance - amount;

      // تحديث الرصيد في جدول الطلاب
      const { error: updateError } = await supabase
        .from('students')
        .update({ 
          wallet_balance: newBalance,
          updated_at: new Date().toISOString()
        })
        .eq('id', studentId);

      if (updateError) {
        console.error('خطأ في تحديث رصيد الطالب:', updateError);
        return false;
      }

      // إضافة سجل المعاملة
      await this.addWalletTransaction(studentId, 'deduct', amount, description, lessonId);

      console.log('تم خصم المبلغ بنجاح:', { oldBalance: currentBalance, newBalance, amountDeducted: amount });
      return true;

    } catch (error: any) {
      console.error('خطأ غير متوقع في خصم المبلغ:', error.message);
      return false;
    }
  }

  async addWalletTransaction(studentId: string, type: string, amount: number, description: string, lessonId?: number): Promise<void> {
    try {
      const { error } = await supabase
        .from('wallet_transactions')
        .insert([{
          student_id: studentId,
          type: type,
          amount: amount,
          description: description,
          lesson_id: lessonId,
          created_at: new Date().toISOString()
        }]);

      if (error) {
        console.error('خطأ في إضافة معاملة المحفظة:', error);
      } else {
        console.log('تم إضافة معاملة المحفظة بنجاح');
      }
    } catch (error: any) {
      console.error('خطأ غير متوقع في إضافة معاملة المحفظة:', error.message);
    }
  }

  async authenticateStudent(fullName: string, password: string): Promise<any | null> {
    try {
      console.log('محاولة تسجيل دخول الطالب:', { fullName, password });
      
      const { data, error } = await supabase
        .rpc('authenticate_student', {
          student_name: fullName,
          student_password: password
        });

      if (error) {
        console.error('Authentication error:', error.message);
        return null;
      }

      if (!data || data.length === 0) {
        console.log('بيانات الدخول غير صحيحة');
        return null;
      }

      const student = data[0];
      console.log('تم العثور على الطالب:', student);

      // التحقق من وجود جلسة نشطة
      const hasActiveSession = await this.checkActiveSession(student.id);
      if (hasActiveSession) {
        console.log('يوجد جلسة نشطة للطالب');
        throw new Error('⚠️ يوجد شخص آخر مسجل دخول بهذا الحساب حالياً. يرجى المحاولة لاحقاً أو التواصل مع الدعم الفني.');
      }

      return student;
    } catch (error: any) {
      console.error('Unexpected authentication error:', error.message);
      throw error;
    }
  }

  async updateStudent(studentId: string, updates: any): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('students')
        .update(updates)
        .eq('id', studentId);

      if (error) {
        console.error('Error updating student:', error.message);
        return false;
      }

      return true;
    } catch (error: any) {
      console.error('Unexpected error updating student:', error.message);
      return false;
    }
  }

  async getStudentById(studentId: string): Promise<any | null> {
    try {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('id', studentId)
        .single();

      if (error) {
        console.error('Error fetching student:', error.message);
        return null;
      }

      return data;
    } catch (error: any) {
      console.error('Unexpected error fetching student:', error.message);
      return null;
    }
  }

  async getSubscriptionById(subscriptionId: number): Promise<any | null> {
    try {
      console.log('جلب تفاصيل الاشتراك:', subscriptionId);

      // First get the subscription details
      const { data: subscription, error: subscriptionError } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('id', subscriptionId)
        .single();

      if (subscriptionError) {
        console.error('خطأ في جلب بيانات الاشتراك:', subscriptionError.message);
        return null;
      }

      if (!subscription) {
        console.log('لم يتم العثور على الاشتراك');
        return null;
      }

      console.log('تم جلب بيانات الاشتراك:', subscription);

      // Now get the lessons for this subscription through the junction table
      const { data: subscriptionLessons, error: lessonsError } = await supabase
        .from('subscription_lessons')
        .select(`
          lesson_id,
          lessons (
            id,
            title,
            description,
            video_url,
            pdf_url,
            homework_url,
            homework_video_url,
            solution_url,
            cover_image,
            grade,
            order_number,
            price,
            created_at,
            updated_at
          )
        `)
        .eq('subscription_id', subscriptionId);

      if (lessonsError) {
        console.error('خطأ في جلب دروس الاشتراك:', lessonsError.message);
        // Don't return null, just return subscription without lessons
        return {
          ...subscription,
          lessons: []
        };
      }

      // Extract lessons from the junction table response
      const lessons = subscriptionLessons?.map(sl => sl.lessons).filter(Boolean) || [];
      console.log('دروس الاشتراك المحملة:', lessons);

      return {
        ...subscription,
        lessons: lessons
      };
    } catch (error: any) {
      console.error('خطأ غير متوقع في جلب تفاصيل الاشتراك:', error.message);
      return null;
    }
  }

  async addLessonToSubscription(subscriptionId: number, lessonId: number): Promise<any> {
    try {
      console.log('ربط الحصة بالاشتراك:', { subscriptionId, lessonId });

      // Check if the relationship already exists
      const { data: existing, error: checkError } = await supabase
        .from('subscription_lessons')
        .select('id')
        .eq('subscription_id', subscriptionId)
        .eq('lesson_id', lessonId)
        .single();

      if (checkError && checkError.code !== 'PGRST116') {
        console.error('خطأ في التحقق من وجود الربط:', checkError.message);
        throw checkError;
      }

      if (existing) {
        console.log('الربط موجود بالفعل');
        return existing;
      }

      // Add the lesson to subscription relationship
      const { data, error } = await supabase
        .from('subscription_lessons')
        .insert([{ subscription_id: subscriptionId, lesson_id: lessonId }])
        .select()
        .single();

      if (error) {
        console.error('خطأ في ربط الحصة بالاشتراك:', error.message);
        throw error;
      }

      console.log('تم ربط الحصة بالاشتراك بنجاح:', data);
      return data;
    } catch (error: any) {
      console.error('خطأ غير متوقع في ربط الحصة بالاشتراك:', error.message);
      throw error;
    }
  }

  async getStudentStats(studentId: string): Promise<any> {
    // Return mock stats for now
    return {
      level: 1,
      progressPercentage: 65,
      completedLessons: 5,
      totalLessons: 10,
      averageScore: 85,
      totalExamsTaken: 3,
      totalPoints: 120,
      walletBalance: 50,
      nextLevelPoints: 80
    };
  }

  async getNotifications(userId: string): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching notifications:', error.message);
        return [];
      }

      return data || [];
    } catch (error: any) {
      console.error('Unexpected error fetching notifications:', error.message);
      return [];
    }
  }

  async addActivityLog(userId: string, type: string, description: string): Promise<void> {
    try {
      // تجاهل activity logs مؤقتاً لتجنب مشاكل RLS
      // يمكن إضافتها لاحقاً عند تطبيق نظام مصادقة Supabase
      console.log(`Activity Log: ${type} - ${description} for user ${userId}`);
    } catch (error: any) {
      console.error('Unexpected error adding activity log:', error.message);
    }
  }

  async getLessonById(lessonId: number): Promise<any | null> {
    try {
      const { data, error } = await supabase
        .from('lessons')
        .select('*')
        .eq('id', lessonId)
        .single();

      if (error) {
        console.error('Error fetching lesson:', error.message);
        return null;
      }

      return data;
    } catch (error: any) {
      console.error('Unexpected error fetching lesson:', error.message);
      return null;
    }
  }

  async getStudents(): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('students')
        .select('*');

      if (error) {
        console.error('Error fetching students:', error.message);
        return [];
      }

      return data || [];
    } catch (error: any) {
      console.error('Unexpected error fetching students:', error.message);
      return [];
    }
  }

  async addStudent(studentData: any): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('students')
        .insert([{
          full_name: studentData.fullName,
          student_number: studentData.studentNumber,
          parent_number: studentData.parentNumber,
          password: studentData.password,
          grade: studentData.grade,
          email: studentData.email || '',
          wallet_balance: 0,
          points: 0,
          completed_lessons: 0,
          total_lessons: 0,
          is_blocked: false
        }]);

      if (error) {
        console.error('Error adding student:', error.message);
        return false;
      }

      return true;
    } catch (error: any) {
      console.error('Unexpected error adding student:', error.message);
      return false;
    }
  }

  async addNotification(userId: string, type: string, message: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('notifications')
        .insert([{
          user_id: userId,
          type,
          message
        }]);

      if (error) {
        console.error('Error adding notification:', error.message);
      }
    } catch (error: any) {
      console.error('Unexpected error adding notification:', error.message);
    }
  }

  async getStudentSubscriptions(studentId: string): Promise<any[]> {
    try {
      // الحصول على اشتراكات الطالب
      const { data: userSubs, error: userSubsError } = await supabase
        .from('subscriptions_users')
        .select(`
          *,
          subscriptions (
            id,
            title,
            description,
            price,
            duration_days,
            cover_image,
            grade
          )
        `)
        .eq('user_id', studentId);

      if (userSubsError) {
        console.error('Error fetching user subscriptions:', userSubsError.message);
        return [];
      }

      if (!userSubs || userSubs.length === 0) {
        return [];
      }

      // الحصول على الحصص لكل اشتراك
      const subscriptionsWithLessons = await Promise.all(
        userSubs.map(async (userSub: any) => {
          const subscription = userSub.subscriptions;
          if (!subscription) return null;

          // الحصول على حصص هذا الاشتراك
          const { data: lessons, error: lessonsError } = await supabase
            .from('subscription_lessons')
            .select(`
              lessons (
                id,
                title,
                description,
                video_url,
                pdf_url,
                homework_url,
                homework_video_url,
                solution_url,
                order_number,
                cover_image
              )
            `)
            .eq('subscription_id', subscription.id);

          if (lessonsError) {
            console.error('Error fetching lessons for subscription:', lessonsError.message);
          }

          const lessonsList = lessons?.map((item: any) => item.lessons).filter(Boolean) || [];

          return {
            id: subscription.id,
            title: subscription.title,
            description: subscription.description,
            price: subscription.price,
            duration_days: subscription.duration_days,
            coverImage: subscription.cover_image,
            grade: subscription.grade,
            purchasedAt: userSub.purchased_at,
            expiresAt: userSub.expires_at,
            isActive: userSub.is_active,
            lessons: lessonsList
          };
        })
      );

      return subscriptionsWithLessons.filter(Boolean);
    } catch (error: any) {
      console.error('Unexpected error fetching student subscriptions:', error.message);
      return [];
    }
  }

  async getSubscriptionsByGrade(grade: string): Promise<any[]> {
    try {
      console.log('جلب الاشتراكات للصف:', grade);
      
      // تحويل الصف من نص إلى رقم إذا لزم الأمر
      let gradeFilter = grade;
      if (grade === 'first' || grade === '1') gradeFilter = '1';
      else if (grade === 'second' || grade === '2') gradeFilter = '2';
      else if (grade === 'third' || grade === '3') gradeFilter = '3';
      
      console.log('البحث بالصف المحول:', gradeFilter);

      const { data, error } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('grade', gradeFilter);

      if (error) {
        console.error('خطأ في جلب الاشتراكات:', error.message);
        return [];
      }

      console.log('تم جلب الاشتراكات:', data);
      
      // تحويل البيانات لتتناسب مع الواجهة
      const transformedData = (data || []).map(subscription => ({
        id: subscription.id,
        title: subscription.title,
        description: subscription.description,
        price: subscription.price,
        duration: subscription.duration_days.toString(),
        coverImage: subscription.cover_image,
        grade: subscription.grade,
        lessons: [], // سيتم ملؤها لاحقاً عند الحاجة
        isPurchased: false // سيتم تحديثها في الواجهة
      }));

      console.log('البيانات المحولة:', transformedData);
      return transformedData;
    } catch (error: any) {
      console.error('خطأ غير متوقع في جلب الاشتراكات:', error.message);
      return [];
    }
  }

  async purchaseSubscription(userId: string, subscriptionId: number): Promise<boolean> {
    try {
      // Get subscription details
      const subscription = await this.getSubscriptionById(subscriptionId);
      if (!subscription) {
        throw new Error('Subscription not found');
      }

      // خصم المبلغ من رصيد الطالب
      const success = await this.deductStudentBalance(
        userId, 
        subscription.price, 
        `شراء اشتراك: ${subscription.title}`,
        null
      );

      if (!success) {
        return false;
      }

      // Add to user subscriptions
      const { error } = await supabase
        .from('subscriptions_users')
        .insert([{
          user_id: userId,
          subscription_id: subscriptionId,
          is_active: true,
          expires_at: new Date(Date.now() + subscription.duration_days * 24 * 60 * 60 * 1000).toISOString()
        }]);

      if (error) {
        console.error('Error purchasing subscription:', error.message);
        return false;
      }

      return true;
    } catch (error: any) {
      console.error('Unexpected error purchasing subscription:', error.message);
      return false;
    }
  }

  async getAllSubscriptions(): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('subscriptions')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching all subscriptions:', error.message);
        return [];
      }

      return data || [];
    } catch (error: any) {
      console.error('Unexpected error fetching all subscriptions:', error.message);
      return [];
    }
  }

  async getAllLessons(): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('lessons')
        .select('*')
        .order('order_number', { ascending: true });

      if (error) {
        console.error('Error fetching all lessons:', error.message);
        return [];
      }

      return data || [];
    } catch (error: any) {
      console.error('Unexpected error fetching all lessons:', error.message);
      return [];
    }
  }

  async createSubscription(subscriptionData: any, files: any = {}): Promise<any> {
    try {
      console.log('بدء إنشاء الاشتراك:', subscriptionData);

      // رفع صورة الغلاف إذا كانت موجودة
      let coverImageUrl = null;
      if (files.coverImage) {
        console.log('رفع صورة الغلاف...');
        try {
          coverImageUrl = await this.uploadFile(files.coverImage, 'subscription-images');
          console.log('تم رفع صورة الغلاف بنجاح:', coverImageUrl);
        } catch (error) {
          console.warn('فشل في رفع صورة الغلاف:', error);
        }
      }

      // إنشاء الاشتراك
      const { data, error } = await supabase
        .from('subscriptions')
        .insert([{
          title: subscriptionData.title,
          description: subscriptionData.description,
          price: subscriptionData.price,
          duration_days: subscriptionData.duration_days || 30,
          grade: subscriptionData.grade,
          cover_image: coverImageUrl
        }])
        .select()
        .single();

      if (error) {
        console.error('خطأ في إنشاء الاشتراك:', error);
        throw new Error(`فشل في حفظ الاشتراك: ${error.message}`);
      }

      console.log('تم إنشاء الاشتراك بنجاح:', data);
      return data;

    } catch (error: any) {
      console.error('خطأ في إنشاء الاشتراك:', error);
      throw error;
    }
  }

  async deleteSubscription(subscriptionId: number): Promise<void> {
    try {
      console.log('محاولة حذف الاشتراك:', subscriptionId);
      
      // استخدام الدالة الآمنة لحذف الاشتراك مع جميع البيانات المرتبطة
      const { error } = await supabase.rpc('delete_subscription_safely', {
        subscription_id_param: subscriptionId
      });

      if (error) {
        console.error('خطأ في حذف الاشتراك:', error.message);
        throw new Error(`فشل في حذف الاشتراك: ${error.message}`);
      }

      console.log('تم حذف الاشتراك بنجاح');
      
    } catch (error: any) {
      console.error('خطأ غير متوقع في حذف الاشتراك:', error.message);
      throw error;
    }
  }

  async createLesson(lessonData: any, files: any = {}) {
    try {
      console.log('بدء إنشاء الحصة:', lessonData);

      // التحقق من البيانات المطلوبة
      if (!lessonData.title || !lessonData.grade) {
        throw new Error('عنوان الحصة والصف الدراسي مطلوبان');
      }

      // رفع الملفات أولاً
      const uploadedFiles: any = {};

      if (files.coverImage) {
        console.log('رفع صورة الحصة...');
        try {
          const coverImageUrl = await this.uploadFile(files.coverImage, 'lesson-images');
          uploadedFiles.cover_image = coverImageUrl;
          console.log('تم رفع صورة الحصة بنجاح:', coverImageUrl);
        } catch (error) {
          console.warn('فشل في رفع صورة الحصة:', error);
        }
      }

      if (files.explanationVideo) {
        console.log('رفع فيديو الشرح...');
        try {
          const videoUrl = await this.uploadFile(files.explanationVideo, 'lesson-videos');
          uploadedFiles.video_url = videoUrl;
          console.log('تم رفع فيديو الشرح بنجاح:', videoUrl);
        } catch (error) {
          console.warn('فشل في رفع فيديو الشرح:', error);
        }
      }

      if (files.explanationFile) {
        console.log('رفع ملف الشرح...');
        try {
          const fileUrl = await this.uploadFile(files.explanationFile, 'lesson-files');
          uploadedFiles.pdf_url = fileUrl;
          console.log('تم رفع ملف الشرح بنجاح:', fileUrl);
        } catch (error) {
          console.warn('فشل في رفع ملف الشرح:', error);
        }
      }

      if (files.homeworkVideo) {
        console.log('رفع فيديو الواجب...');
        try {
          const homeworkVideoUrl = await this.uploadFile(files.homeworkVideo, 'homework-videos');
          uploadedFiles.homework_video_url = homeworkVideoUrl;
          console.log('تم رفع فيديو الواجب بنجاح:', homeworkVideoUrl);
        } catch (error) {
          console.warn('فشل في رفع فيديو الواجب:', error);
        }
      }

      if (files.homeworkSolution) {
        console.log('رفع ملف حل الواجب...');
        try {
          const solutionUrl = await this.uploadFile(files.homeworkSolution, 'solution-files');
          uploadedFiles.solution_url = solutionUrl;
          console.log('تم رفع ملف حل الواجب بنجاح:', solutionUrl);
        } catch (error) {
          console.warn('فشل في رفع ملف حل الواجب:', error);
        }
      }

      // إنشاء بيانات الحصة النهائية
      const finalLessonData = {
        title: lessonData.title,
        description: lessonData.description || null,
        price: lessonData.price || 0,
        grade: lessonData.grade,
        order_number: lessonData.order_number || 1,
        homework_url: lessonData.homework || null,
        ...uploadedFiles
      };

      console.log('إدراج الحصة في قاعدة البيانات:', finalLessonData);

      // إدراج الحصة في قاعدة البيانات
      const { data, error } = await supabase
        .from('lessons')
        .insert([finalLessonData])
        .select()
        .single();

      if (error) {
        console.error('خطأ في إدراج الحصة:', error);
        throw new Error(`فشل في حفظ الحصة: ${error.message}`);
      }

      if (!data) {
        throw new Error('لم يتم إرجاع بيانات الحصة بعد الإنشاء');
      }

      console.log('تم إنشاء الحصة بنجاح:', data);
      return data;

    } catch (error: any) {
      console.error('خطأ في إنشاء الحصة:', error);
      
      if (error.message) {
        throw error;
      } else {
        throw new Error('حدث خطأ غير متوقع أثناء إنشاء الحصة');
      }
    }
  }

  async uploadFile(file: File, bucket: string): Promise<string> {
    try {
      if (!file) {
        throw new Error('لم يتم تحديد ملف للرفع');
      }

      console.log(`رفع ملف إلى ${bucket}:`, file.name, 'حجم:', file.size);

      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${fileName}`;

      console.log('مسار الملف:', filePath);

      const { data, error } = await supabase.storage
        .from(bucket)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) {
        console.error(`خطأ في رفع الملف إلى ${bucket}:`, error);
        throw new Error(`فشل في رفع الملف: ${error.message}`);
      }

      console.log('تم رفع الملف بنجاح:', data);

      // الحصول على URL العام للملف
      const { data: urlData } = supabase.storage
        .from(bucket)
        .getPublicUrl(filePath);

      if (!urlData?.publicUrl) {
        throw new Error('فشل في الحصول على رابط الملف');
      }

      console.log('رابط الملف العام:', urlData.publicUrl);
      return urlData.publicUrl;

    } catch (error: any) {
      console.error('خطأ في رفع الملف:', error);
      throw error;
    }
  }

  async getLessonsBySubscriptionId(subscriptionId: number): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('lessons')
        .select('*')
        .eq('subscription_id', subscriptionId);

      if (error) {
        console.error('Error fetching lessons:', error.message);
        return [];
      }

      return data || [];
    } catch (error: any) {
      console.error('Unexpected error fetching lessons:', error.message);
      return [];
    }
  }

  // شراء حصة منفردة
  async purchaseLesson(studentId: string, lessonId: number): Promise<boolean> {
    try {
      // الحصول على تفاصيل الحصة
      const lesson = await this.getLessonById(lessonId);
      if (!lesson) {
        throw new Error('الحصة غير موجودة');
      }

      // خصم المبلغ من رصيد الطالب
      const success = await this.deductStudentBalance(
        studentId, 
        lesson.price, 
        `شراء حصة: ${lesson.title}`,
        lessonId
      );

      if (!success) {
        return false;
      }

      // إضافة الحصة للحصص المشتراة
      const { error } = await supabase
        .from('lesson_purchases')
        .insert([{
          student_id: studentId,
          lesson_id: lessonId,
          purchase_price: lesson.price
        }]);

      if (error) {
        console.error('Error recording lesson purchase:', error.message);
        return false;
      }

      return true;
    } catch (error: any) {
      console.error('Unexpected error purchasing lesson:', error.message);
      return false;
    }
  }
}

export const supabaseDataManager = new SupabaseDataManager();
