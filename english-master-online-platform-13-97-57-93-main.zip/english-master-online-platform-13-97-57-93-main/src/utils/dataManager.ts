interface Student {
  id: string;
  fullName: string;
  studentNumber: string;
  parentNumber: string;
  password: string;
  grade: string;
  email?: string;
  walletBalance: number;
  points: number;
  completedLessons: number;
  totalLessons: number;
  examResults: any[];
  purchasedLessons: string[];
  subscriptions: string[];
  notifications: any[];
  isBlocked: boolean;
  blockReason?: string;
  blockedAt?: string;
  createdAt: string;
  totalPoints?: number;
  averageScore?: number;
  achievements?: any[];
}

interface WalletRequest {
  id: string;
  studentId: string;
  studentName: string;
  phoneNumber: string;
  amount: number;
  paymentMethod: string;
  transferId: string;
  transferTime: string;
  transferNumber: string;
  transferImage?: string;
  message?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  rejectReason?: string;
}

interface SupportMessage {
  id: string;
  message: string;
  from: 'student' | 'support';
  read: boolean;
  timestamp: string;
  image?: string;
  supportName?: string;
}

interface ActivityLog {
  id: string;
  type: string;
  description: string;
  timestamp: string;
  metadata?: any;
}

interface Lesson {
  id: number;
  title: string;
  description: string;
  price: number;
  coverImage: string;
  videoUrl?: string;
  homeworkVideoUrl?: string;
  pdfUrl?: string;
  homeworkUrl?: string;
  solutionUrl?: string;
  isPurchased: boolean;
  isCompleted: boolean;
  grade: string;
  order: number;
}

interface Subscription {
  id: number;
  title: string;
  description: string;
  price: number;
  duration: string;
  coverImage: string;
  lessons: number[];
  isPurchased: boolean;
  expiryDate?: string;
  grade: string;
}

interface StudentStats {
  totalPoints: number;
  level: number;
  nextLevelPoints: number;
  completedLessons: number;
  totalLessons: number;
  progressPercentage: number;
  averageScore: number;
  totalExamsTaken: number;
  walletBalance: number;
}

interface PaymentMethod {
  id: number;
  name: string;
  number: string;
  createdAt: string;
}

interface Book {
  id: string;
  title: string;
  subject: string;
  grade: string;
  description?: string;
  coverImage?: string;
  fileUrl?: string;
  fileSize?: string;
  createdAt: string;
}

interface Notification {
  id: number;
  studentId: number;
  type: string;
  message: string;
  read: boolean;
  timestamp: string;
  data?: any;
}

class DataManager {
  constructor() {
    this.initializeDefaultData();
  }

  // Helper method to normalize grade values
  private normalizeGrade(grade: string): string {
    if (!grade) return '1';
    const gradeStr = grade.toString().toLowerCase();
    if (gradeStr === 'first' || gradeStr === '1' || gradeStr === 'الأول') return '1';
    if (gradeStr === 'second' || gradeStr === '2' || gradeStr === 'الثاني') return '2';
    if (gradeStr === 'third' || gradeStr === '3' || gradeStr === 'الثالث') return '3';
    return '1'; // Default fallback
  }

  // Initialize method
  initialize(): void {
    this.validateAndCorrectData();
    this.initializeDefaultData();
  }

  // Student Methods
  getStudents(): Student[] {
    try {
      const students = localStorage.getItem('students');
      return students ? JSON.parse(students) : [];
    } catch (error) {
      console.error('Error loading students:', error);
      return [];
    }
  }

  addStudent(student: Omit<Student, 'id' | 'createdAt'>): boolean {
    try {
      const students = this.getStudents();
      const newStudent: Student = {
        ...student,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        walletBalance: student.walletBalance || 0,
        points: student.points || 0,
        completedLessons: student.completedLessons || 0,
        totalLessons: student.totalLessons || 0,
        examResults: student.examResults || [],
        purchasedLessons: student.purchasedLessons || [],
        subscriptions: student.subscriptions || [],
        notifications: student.notifications || [],
        isBlocked: student.isBlocked || false,
        grade: this.normalizeGrade(student.grade)
      };
      
      students.push(newStudent);
      localStorage.setItem('students', JSON.stringify(students));
      
      console.log('Student added successfully:', newStudent);
      return true;
    } catch (error) {
      console.error('Error adding student:', error);
      return false;
    }
  }

  updateStudent(id: string, updates: Partial<Student>): boolean {
    try {
      const students = this.getStudents();
      const index = students.findIndex(s => s.id === id);
      
      if (index === -1) {
        console.error('Student not found:', id);
        return false;
      }
      
      // Normalize grade if being updated
      if (updates.grade) {
        updates.grade = this.normalizeGrade(updates.grade);
      }
      
      students[index] = { ...students[index], ...updates };
      localStorage.setItem('students', JSON.stringify(students));
      
      console.log('Student updated successfully:', students[index]);
      return true;
    } catch (error) {
      console.error('Error updating student:', error);
      return false;
    }
  }

  getStudentById(id: string): Student | null {
    try {
      const students = this.getStudents();
      return students.find(s => s.id === id) || null;
    } catch (error) {
      console.error('Error getting student by ID:', error);
      return null;
    }
  }

  authenticateStudent(fullName: string, password: string): Student | null {
    try {
      const students = this.getStudents();
      console.log('Authenticating student:', { fullName, studentsCount: students.length });
      
      const student = students.find(s => 
        s.fullName && s.fullName.trim().toLowerCase() === fullName.trim().toLowerCase() &&
        s.password && s.password.trim() === password.trim()
      );
      
      if (student) {
        console.log('Student found:', student);
        if (student.isBlocked) {
          throw new Error(`تم حظر هذا الحساب. السبب: ${student.blockReason || 'غير محدد'}`);
        }
        return student;
      }
      
      console.log('Student not found');
      return null;
      
    } catch (error) {
      console.error('Authentication error:', error);
      throw error;
    }
  }

  // Student Stats Method
  getStudentStats(studentId: string): StudentStats {
    try {
      const student = this.getStudentById(studentId);
      if (!student) {
        return {
          totalPoints: 0,
          level: 1,
          nextLevelPoints: 100,
          completedLessons: 0,
          totalLessons: 0,
          progressPercentage: 0,
          averageScore: 0,
          totalExamsTaken: 0,
          walletBalance: 0
        };
      }

      const totalPoints = student.totalPoints || student.points || 0;
      const level = Math.floor(totalPoints / 100) + 1;
      const nextLevelPoints = (level * 100) - totalPoints;
      const completedLessons = student.completedLessons || 0;
      const totalLessons = this.getLessonsByGrade(student.grade).length;
      const progressPercentage = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;
      
      const examResults = student.examResults || [];
      const totalExamsTaken = examResults.length;
      const averageScore = totalExamsTaken > 0 
        ? Math.round(examResults.reduce((sum: number, exam: any) => sum + (exam.percentage || 0), 0) / totalExamsTaken)
        : 0;

      return {
        totalPoints,
        level,
        nextLevelPoints,
        completedLessons,
        totalLessons,
        progressPercentage,
        averageScore,
        totalExamsTaken,
        walletBalance: student.walletBalance || 0
      };
    } catch (error) {
      console.error('Error getting student stats:', error);
      return {
        totalPoints: 0,
        level: 1,
        nextLevelPoints: 100,
        completedLessons: 0,
        totalLessons: 0,
        progressPercentage: 0,
        averageScore: 0,
        totalExamsTaken: 0,
        walletBalance: 0
      };
    }
  }

  // Lesson Methods
  getLessons(): Lesson[] {
    try {
      const lessons = localStorage.getItem('lessons');
      const parsedLessons = lessons ? JSON.parse(lessons) : [];
      console.log('Loaded lessons:', parsedLessons);
      return parsedLessons;
    } catch (error) {
      console.error('Error loading lessons:', error);
      return [];
    }
  }

  getLessonsByGrade(grade: string): Lesson[] {
    try {
      const normalizedGrade = this.normalizeGrade(grade);
      const allLessons = this.getLessons();
      const filteredLessons = allLessons.filter(lesson => {
        const lessonGrade = this.normalizeGrade(lesson.grade);
        return lessonGrade === normalizedGrade;
      });
      console.log(`Lessons for grade ${normalizedGrade}:`, filteredLessons);
      return filteredLessons;
    } catch (error) {
      console.error('Error getting lessons by grade:', error);
      return [];
    }
  }

  // Subscription Methods
  getSubscriptions(): Subscription[] {
    try {
      const subscriptions = localStorage.getItem('subscriptions');
      const parsedSubscriptions = subscriptions ? JSON.parse(subscriptions) : [];
      console.log('Loaded subscriptions:', parsedSubscriptions);
      return parsedSubscriptions;
    } catch (error) {
      console.error('Error loading subscriptions:', error);
      return [];
    }
  }

  getSubscriptionsByGrade(grade: string): Subscription[] {
    try {
      const normalizedGrade = this.normalizeGrade(grade);
      const allSubscriptions = this.getSubscriptions();
      const filteredSubscriptions = allSubscriptions.filter(sub => {
        const subGrade = this.normalizeGrade(sub.grade);
        return subGrade === normalizedGrade;
      });
      console.log(`Subscriptions for grade ${normalizedGrade}:`, filteredSubscriptions);
      return filteredSubscriptions;
    } catch (error) {
      console.error('Error getting subscriptions by grade:', error);
      return [];
    }
  }

  // Wallet Request Methods
  getWalletRequests(): WalletRequest[] {
    try {
      const requests = localStorage.getItem('walletRequests');
      const parsedRequests = requests ? JSON.parse(requests) : [];
      console.log('Loaded wallet requests:', parsedRequests);
      return parsedRequests;
    } catch (error) {
      console.error('Error loading wallet requests:', error);
      return [];
    }
  }

  addWalletRequest(request: Omit<WalletRequest, 'id' | 'createdAt'>): boolean {
    try {
      const requests = this.getWalletRequests();
      const newRequest: WalletRequest = {
        ...request,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        status: 'pending'
      };
      
      requests.push(newRequest);
      localStorage.setItem('walletRequests', JSON.stringify(requests));
      
      console.log('Wallet request added successfully:', newRequest);
      return true;
    } catch (error) {
      console.error('Error adding wallet request:', error);
      return false;
    }
  }

  updateWalletRequest(id: string, updates: Partial<WalletRequest>): boolean {
    try {
      const requests = this.getWalletRequests();
      const index = requests.findIndex(r => r.id === id);
      
      if (index === -1) {
        console.error('Wallet request not found:', id);
        return false;
      }
      
      requests[index] = { ...requests[index], ...updates };
      localStorage.setItem('walletRequests', JSON.stringify(requests));
      
      console.log('Wallet request updated successfully:', requests[index]);
      return true;
    } catch (error) {
      console.error('Error updating wallet request:', error);
      return false;
    }
  }

  // Enhanced Support Message Methods with Teacher Integration
  getSupportMessages(studentId: string): SupportMessage[] {
    try {
      const messages = localStorage.getItem(`supportMessages_${studentId}`);
      const parsedMessages = messages ? JSON.parse(messages) : [];
      console.log(`Support messages for student ${studentId}:`, parsedMessages);
      return parsedMessages;
    } catch (error) {
      console.error('Error loading support messages:', error);
      return [];
    }
  }

  addSupportMessage(studentId: string, message: Omit<SupportMessage, 'id' | 'timestamp'>): boolean {
    try {
      const messages = this.getSupportMessages(studentId);
      const newMessage: SupportMessage = {
        ...message,
        id: Date.now().toString(),
        timestamp: new Date().toISOString()
      };
      
      messages.push(newMessage);
      localStorage.setItem(`supportMessages_${studentId}`, JSON.stringify(messages));
      
      // If message is from student, notify teacher
      if (message.from === 'student') {
        this.notifyTeacherOfNewMessage(studentId, newMessage.message);
        
        // Send notification to student about message being sent
        this.addNotification(parseInt(studentId), 'support_message', 'تم إرسال رسالتك للدعم الفني بنجاح');
      }
      
      // If message is from support, send notification to student
      if (message.from === 'support') {
        this.addNotification(parseInt(studentId), 'support_message', `رد من الدعم الفني: ${newMessage.message.substring(0, 50)}...`);
      }
      
      console.log('Support message added successfully:', newMessage);
      return true;
    } catch (error) {
      console.error('Error adding support message:', error);
      return false;
    }
  }

  // New method to notify teacher of new student messages
  notifyTeacherOfNewMessage(studentId: string, messageContent: string): void {
    try {
      const student = this.getStudentById(studentId);
      if (!student) return;

      // Add to teacher notifications (using a general teacher storage)
      const teacherNotifications = JSON.parse(localStorage.getItem('teacherNotifications') || '[]');
      const newNotification = {
        id: Date.now(),
        type: 'student_message',
        title: 'رسالة جديدة من الطالب',
        message: `رسالة من ${student.fullName}: ${messageContent.substring(0, 50)}...`,
        studentId: studentId,
        studentName: student.fullName,
        timestamp: new Date().toISOString(),
        read: false
      };
      
      teacherNotifications.unshift(newNotification);
      
      // Keep only last 100 notifications
      if (teacherNotifications.length > 100) {
        teacherNotifications.splice(100);
      }
      
      localStorage.setItem('teacherNotifications', JSON.stringify(teacherNotifications));
      console.log('Teacher notified of new student message:', newNotification);
    } catch (error) {
      console.error('Error notifying teacher:', error);
    }
  }

  // Get teacher notifications
  getTeacherNotifications(): any[] {
    try {
      const notifications = localStorage.getItem('teacherNotifications');
      return notifications ? JSON.parse(notifications) : [];
    } catch (error) {
      console.error('Error loading teacher notifications:', error);
      return [];
    }
  }

  // Mark teacher notification as read
  markTeacherNotificationAsRead(notificationId: number): boolean {
    try {
      const notifications = this.getTeacherNotifications();
      const notification = notifications.find(n => n.id === notificationId);
      
      if (notification) {
        notification.read = true;
        localStorage.setItem('teacherNotifications', JSON.stringify(notifications));
        console.log('Teacher notification marked as read:', notificationId);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error marking teacher notification as read:', error);
      return false;
    }
  }

  // Enhanced notification system - send notification from teacher to specific student
  sendNotificationToStudent(studentId: number, type: string, message: string, data?: any): boolean {
    try {
      const notification: Notification = {
        id: Date.now(),
        studentId,
        type,
        message,
        read: false,
        timestamp: new Date().toISOString(),
        data
      };
      
      const notifications = this.getNotifications(studentId);
      notifications.unshift(notification);
      
      // Keep only last 100 notifications
      if (notifications.length > 100) {
        notifications.splice(100);
      }
      
      localStorage.setItem(`notifications_${studentId}`, JSON.stringify(notifications));
      
      console.log('Notification sent to student successfully:', notification);
      return true;
    } catch (error) {
      console.error('Error sending notification to student:', error);
      return false;
    }
  }

  // Send notification to all students in a specific grade
  sendNotificationToGrade(grade: string, type: string, message: string, data?: any): number {
    try {
      const students = this.getStudents();
      const normalizedGrade = this.normalizeGrade(grade);
      let sentCount = 0;
      
      students.forEach(student => {
        if (this.normalizeGrade(student.grade) === normalizedGrade && !student.isBlocked) {
          if (this.sendNotificationToStudent(parseInt(student.id), type, message, data)) {
            sentCount++;
          }
        }
      });
      
      console.log(`Sent notification to ${sentCount} students in grade ${normalizedGrade}`);
      return sentCount;
    } catch (error) {
      console.error('Error sending notification to grade:', error);
      return 0;
    }
  }

  // Send notification to all students
  sendNotificationToAllStudents(type: string, message: string, data?: any): number {
    try {
      const students = this.getStudents();
      let sentCount = 0;
      
      students.forEach(student => {
        if (!student.isBlocked) {
          if (this.sendNotificationToStudent(parseInt(student.id), type, message, data)) {
            sentCount++;
          }
        }
      });
      
      console.log(`Sent notification to ${sentCount} students`);
      return sentCount;
    } catch (error) {
      console.error('Error sending notification to all students:', error);
      return 0;
    }
  }

  // Activity Log Methods
  getActivityLog(studentId: string): ActivityLog[] {
    try {
      const log = localStorage.getItem(`activityLog_${studentId}`);
      return log ? JSON.parse(log) : [];
    } catch (error) {
      console.error('Error loading activity log:', error);
      return [];
    }
  }

  addActivityLog(studentId: string, type: string, description: string): boolean {
    try {
      const log = this.getActivityLog(studentId);
      const newActivity: ActivityLog = {
        id: Date.now().toString(),
        type,
        description,
        timestamp: new Date().toISOString()
      };
      
      log.unshift(newActivity);
      
      // Keep only last 50 activities
      if (log.length > 50) {
        log.splice(50);
      }
      
      localStorage.setItem(`activityLog_${studentId}`, JSON.stringify(log));
      
      console.log('Activity logged successfully:', newActivity);
      return true;
    } catch (error) {
      console.error('Error adding activity log:', error);
      return false;
    }
  }

  // Payment Methods
  getPaymentMethods(): PaymentMethod[] {
    try {
      const methods = localStorage.getItem('paymentMethods');
      return methods ? JSON.parse(methods) : [];
    } catch (error) {
      console.error('Error loading payment methods:', error);
      return [];
    }
  }

  addPaymentMethod(name: string, number: string): PaymentMethod {
    try {
      const methods = this.getPaymentMethods();
      const newMethod: PaymentMethod = {
        id: Date.now(),
        name: name.trim(),
        number: number.trim(),
        createdAt: new Date().toISOString()
      };
      
      methods.push(newMethod);
      localStorage.setItem('paymentMethods', JSON.stringify(methods));
      
      console.log('Payment method added successfully:', newMethod);
      return newMethod;
    } catch (error) {
      console.error('Error adding payment method:', error);
      throw error;
    }
  }

  removePaymentMethod(id: number): boolean {
    try {
      const methods = this.getPaymentMethods();
      const filteredMethods = methods.filter(m => m.id !== id);
      
      if (filteredMethods.length === methods.length) {
        console.error('Payment method not found:', id);
        return false;
      }
      
      localStorage.setItem('paymentMethods', JSON.stringify(filteredMethods));
      console.log('Payment method removed successfully:', id);
      return true;
    } catch (error) {
      console.error('Error removing payment method:', error);
      return false;
    }
  }

  // Books Methods - Enhanced to sync with student grade
  getBooks(): Book[] {
    try {
      const books = localStorage.getItem('books');
      return books ? JSON.parse(books) : [];
    } catch (error) {
      console.error('Error loading books:', error);
      return [];
    }
  }

  getBooksByGrade(grade: string): Book[] {
    try {
      const normalizedGrade = this.normalizeGrade(grade);
      const allBooks = this.getBooks();
      const filteredBooks = allBooks.filter(book => {
        const bookGrade = this.normalizeGrade(book.grade);
        return bookGrade === normalizedGrade;
      });
      console.log(`Books for grade ${normalizedGrade}:`, filteredBooks);
      return filteredBooks;
    } catch (error) {
      console.error('Error getting books by grade:', error);
      return [];
    }
  }

  // Notifications Methods
  getNotifications(studentId: number): Notification[] {
    try {
      const notifications = localStorage.getItem(`notifications_${studentId}`);
      return notifications ? JSON.parse(notifications) : [];
    } catch (error) {
      console.error('Error loading notifications:', error);
      return [];
    }
  }

  addNotification(studentId: number, type: string, message: string): boolean {
    try {
      const notifications = this.getNotifications(studentId);
      const newNotification: Notification = {
        id: Date.now(),
        studentId,
        type,
        message,
        read: false,
        timestamp: new Date().toISOString()
      };
      
      notifications.unshift(newNotification);
      
      // Keep only last 100 notifications
      if (notifications.length > 100) {
        notifications.splice(100);
      }
      
      localStorage.setItem(`notifications_${studentId}`, JSON.stringify(notifications));
      
      console.log('Notification added successfully:', newNotification);
      return true;
    } catch (error) {
      console.error('Error adding notification:', error);
      return false;
    }
  }

  markNotificationAsRead(studentId: number, notificationId: number): boolean {
    try {
      const notifications = this.getNotifications(studentId);
      const notification = notifications.find(n => n.id === notificationId);
      
      if (notification) {
        notification.read = true;
        localStorage.setItem(`notifications_${studentId}`, JSON.stringify(notifications));
        console.log('Notification marked as read:', notificationId);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error marking notification as read:', error);
      return false;
    }
  }

  markAllNotificationsAsRead(studentId: number): boolean {
    try {
      const notifications = this.getNotifications(studentId);
      notifications.forEach(n => n.read = true);
      localStorage.setItem(`notifications_${studentId}`, JSON.stringify(notifications));
      console.log('All notifications marked as read for student:', studentId);
      return true;
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
      return false;
    }
  }

  // Data validation method
  validateAndCorrectData(): void {
    try {
      console.log('Starting data validation and correction...');
      
      // Check and fix students data
      const students = this.getStudents();
      let studentsFixed = false;
      
      students.forEach(student => {
        if (!student.grade || typeof student.grade !== 'string') {
          student.grade = '1';
          studentsFixed = true;
        }
        if (typeof student.walletBalance !== 'number') {
          student.walletBalance = 0;
          studentsFixed = true;
        }
        if (!Array.isArray(student.purchasedLessons)) {
          student.purchasedLessons = [];
          studentsFixed = true;
        }
        if (!Array.isArray(student.subscriptions)) {
          student.subscriptions = [];
          studentsFixed = true;
        }
      });
      
      if (studentsFixed) {
        localStorage.setItem('students', JSON.stringify(students));
        console.log('Students data corrected');
      }
      
      console.log('Data validation completed');
    } catch (error) {
      console.error('Error during data validation:', error);
    }
  }

  // Enhanced initialize default data method
  initializeDefaultData(): void {
    try {
      // Initialize sample students if none exist
      if (this.getStudents().length === 0) {
        console.log('Initializing sample students...');
        
        const sampleStudents = [
          {
            fullName: 'أحمد محمد علي',
            studentNumber: '123456',
            parentNumber: '01012345678',
            password: '123456',
            grade: '1',
            walletBalance: 100,
            points: 0,
            completedLessons: 0,
            totalLessons: 0,
            examResults: [],
            purchasedLessons: [],
            subscriptions: [],
            notifications: [],
            isBlocked: false
          },
          {
            fullName: 'فاطمة سعد محمود',
            studentNumber: '789012',
            parentNumber: '01087654321',
            password: '789012',
            grade: '2',
            walletBalance: 50,
            points: 0,
            completedLessons: 0,
            totalLessons: 0,
            examResults: [],
            purchasedLessons: [],
            subscriptions: [],
            notifications: [],
            isBlocked: false
          }
        ];
        
        sampleStudents.forEach(student => this.addStudent(student));
      }

      // Initialize sample lessons if none exist
      if (this.getLessons().length === 0) {
        console.log('Initializing sample lessons...');
        
        const sampleLessons = [
          {
            id: 1,
            title: 'Present Simple Tense',
            description: 'شرح قاعدة المضارع البسيط مع الأمثلة والتمارين',
            price: 25,
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            pdfUrl: 'https://example.com/lesson1.pdf',
            homeworkUrl: 'https://example.com/homework1.pdf',
            solutionUrl: 'https://example.com/solution1.pdf',
            duration: '45 دقيقة',
            isPurchased: false,
            isCompleted: false,
            grade: '1',
            order: 1
          },
          {
            id: 2,
            title: 'Present Continuous Tense',
            description: 'شرح قاعدة المضارع المستمر مع الأمثلة والتمارين',
            price: 30,
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
            pdfUrl: 'https://example.com/lesson2.pdf',
            homeworkUrl: 'https://example.com/homework2.pdf',
            solutionUrl: 'https://example.com/solution2.pdf',
            duration: '50 دقيقة',
            isPurchased: false,
            isCompleted: false,
            grade: '1',
            order: 2
          },
          {
            id: 3,
            title: 'Past Simple Tense',
            description: 'شرح قاعدة الماضي البسيط مع الأمثلة والتمارين',
            price: 35,
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            pdfUrl: 'https://example.com/lesson3.pdf',
            homeworkUrl: 'https://example.com/homework3.pdf',
            solutionUrl: 'https://example.com/solution3.pdf',
            duration: '40 دقيقة',
            isPurchased: false,
            isCompleted: false,
            grade: '2',
            order: 1
          }
        ];
        
        localStorage.setItem('lessons', JSON.stringify(sampleLessons));
      }

      // Initialize sample subscriptions if none exist
      if (this.getSubscriptions().length === 0) {
        console.log('Initializing sample subscriptions...');
        
        const sampleSubscriptions = [
          {
            id: 1,
            title: 'اشتراك الصف الأول الثانوي - شهري',
            description: 'جميع حصص الصف الأول الثانوي لمدة شهر كامل مع الامتحانات والواجبات',
            price: 100,
            duration: '30',
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            lessons: [1, 2],
            isPurchased: false,
            grade: '1'
          },
          {
            id: 2,
            title: 'اشتراك الصف الثاني الثانوي - شهري',
            description: 'جميع حصص الصف الثاني الثانوي لمدة شهر كامل مع الامتحانات والواجبات',
            price: 120,
            duration: '30',
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            lessons: [3],
            isPurchased: false,
            grade: '2'
          }
        ];
        
        localStorage.setItem('subscriptions', JSON.stringify(sampleSubscriptions));
      }

      // Initialize sample payment methods if none exist
      if (this.getPaymentMethods().length === 0) {
        console.log('Initializing sample payment methods...');
        
        const samplePaymentMethods = [
          {
            id: 1,
            name: 'فودافون كاش',
            number: '01050747978',
            createdAt: new Date().toISOString()
          },
          {
            id: 2,
            name: 'إنستاباي',
            number: '01050747978',
            createdAt: new Date().toISOString()
          }
        ];
        
        localStorage.setItem('paymentMethods', JSON.stringify(samplePaymentMethods));
      }

      // Initialize sample books if none exist - updated with more books for each grade
      if (this.getBooks().length === 0) {
        console.log('Initializing sample books...');
        
        const sampleBooks = [
          {
            id: '1',
            title: 'كتاب اللغة الإنجليزية - الصف الأول الثانوي',
            subject: 'اللغة الإنجليزية',
            grade: '1',
            description: 'الكتاب المدرسي الرسمي للصف الأول الثانوي',
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            fileUrl: 'https://example.com/book1.pdf',
            fileSize: '15 MB',
            createdAt: new Date().toISOString()
          },
          {
            id: '2',
            title: 'كتاب اللغة الإنجليزية - الصف الثاني الثانوي',
            subject: 'اللغة الإنجليزية',
            grade: '2',
            description: 'الكتاب المدرسي الرسمي للصف الثاني الثانوي',
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            fileUrl: 'https://example.com/book2.pdf',
            fileSize: '18 MB',
            createdAt: new Date().toISOString()
          },
          {
            id: '3',
            title: 'كتاب اللغة الإنجليزية - الصف الثالث الثانوي',
            subject: 'اللغة الإنجليزية',
            grade: '3',
            description: 'الكتاب المدرسي الرسمي للصف الثالث الثانوي',
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            fileUrl: 'https://example.com/book3.pdf',
            fileSize: '20 MB',
            createdAt: new Date().toISOString()
          },
          {
            id: '4',
            title: 'مذكرة القواعد - الأول الثانوي',
            subject: 'اللغة الإنجليزية',
            grade: '1',
            description: 'مذكرة شاملة لقواعد اللغة الإنجليزية للصف الأول الثانوي',
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            fileUrl: 'https://example.com/grammar1.pdf',
            fileSize: '12 MB',
            createdAt: new Date().toISOString()
          },
          {
            id: '5',
            title: 'مذكرة القواعد - الثاني الثانوي',
            subject: 'اللغة الإنجليزية',
            grade: '2',
            description: 'مذكرة شاملة لقواعد اللغة الإنجليزية للصف الثاني الثانوي',
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            fileUrl: 'https://example.com/grammar2.pdf',
            fileSize: '14 MB',
            createdAt: new Date().toISOString()
          },
          {
            id: '6',
            title: 'مذكرة القواعد - الثالث الثانوي',
            subject: 'اللغة الإنجليزية',
            grade: '3',
            description: 'مذكرة شاملة لقواعد اللغة الإنجليزية للصف الثالث الثانوي',
            coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
            fileUrl: 'https://example.com/grammar3.pdf',
            fileSize: '16 MB',
            createdAt: new Date().toISOString()
          }
        ];
        
        localStorage.setItem('books', JSON.stringify(sampleBooks));
        console.log('تم إنشاء كتب تجريبية:', sampleBooks.length, 'كتاب');
      }

      console.log('Default data initialization completed');
    } catch (error) {
      console.error('Error initializing default data:', error);
    }
  }
}

export const dataManager = new DataManager();
