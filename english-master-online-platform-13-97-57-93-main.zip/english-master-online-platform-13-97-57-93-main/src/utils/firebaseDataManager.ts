
import { 
  collection, 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  getDocs, 
  addDoc, 
  query, 
  where, 
  orderBy, 
  limit,
  deleteDoc,
  writeBatch
} from 'firebase/firestore';
import { db } from '../firebase';

interface Student {
  id: string;
  fullName: string;
  studentNumber: string;
  parentNumber: string;
  password: string;
  grade: string;
  email?: string;
  walletBalance: number;
  points: number;
  completedLessons: number;
  totalLessons: number;
  examResults: any[];
  purchasedLessons: string[];
  subscriptions: string[];
  notifications: any[];
  isBlocked: boolean;
  blockReason?: string;
  blockedAt?: string;
  createdAt: string;
  totalPoints?: number;
  averageScore?: number;
  achievements?: any[];
}

interface WalletRequest {
  id: string;
  studentId: string;
  studentName: string;
  phoneNumber: string;
  amount: number;
  paymentMethod: string;
  transferId: string;
  transferTime: string;
  transferNumber: string;
  transferImage?: string;
  message?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  rejectReason?: string;
}

interface Lesson {
  id: number;
  title: string;
  description: string;
  price: number;
  coverImage: string;
  videoUrl?: string;
  homeworkVideoUrl?: string;
  pdfUrl?: string;
  homeworkUrl?: string;
  solutionUrl?: string;
  isPurchased: boolean;
  isCompleted: boolean;
  grade: string;
  order: number;
}

interface Subscription {
  id: number;
  title: string;
  description: string;
  price: number;
  duration: string;
  coverImage: string;
  lessons: number[];
  isPurchased: boolean;
  expiryDate?: string;
  grade: string;
}

class FirebaseDataManager {
  // Helper method to normalize grade values
  private normalizeGrade(grade: string): string {
    if (!grade) return '1';
    const gradeStr = grade.toString().toLowerCase();
    if (gradeStr === 'first' || gradeStr === '1' || gradeStr === 'الأول') return '1';
    if (gradeStr === 'second' || gradeStr === '2' || gradeStr === 'الثاني') return '2';
    if (gradeStr === 'third' || gradeStr === '3' || gradeStr === 'الثالث') return '3';
    return '1';
  }

  // Student Methods
  async getStudents(): Promise<Student[]> {
    try {
      const studentsRef = collection(db, 'students');
      const snapshot = await getDocs(studentsRef);
      const students = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Student[];
      console.log('Loaded students from Firestore:', students.length);
      return students;
    } catch (error) {
      console.error('Error loading students from Firestore:', error);
      return [];
    }
  }

  async addStudent(student: Omit<Student, 'id' | 'createdAt'>): Promise<boolean> {
    try {
      const newStudent = {
        ...student,
        createdAt: new Date().toISOString(),
        walletBalance: student.walletBalance || 0,
        points: student.points || 0,
        completedLessons: student.completedLessons || 0,
        totalLessons: student.totalLessons || 0,
        examResults: student.examResults || [],
        purchasedLessons: student.purchasedLessons || [],
        subscriptions: student.subscriptions || [],
        notifications: student.notifications || [],
        isBlocked: student.isBlocked || false,
        grade: this.normalizeGrade(student.grade)
      };
      
      const docRef = await addDoc(collection(db, 'students'), newStudent);
      console.log('Student added to Firestore with ID:', docRef.id);
      return true;
    } catch (error) {
      console.error('Error adding student to Firestore:', error);
      return false;
    }
  }

  async updateStudent(id: string, updates: Partial<Student>): Promise<boolean> {
    try {
      if (updates.grade) {
        updates.grade = this.normalizeGrade(updates.grade);
      }
      
      const studentRef = doc(db, 'students', id);
      await updateDoc(studentRef, updates);
      console.log('Student updated in Firestore:', id);
      return true;
    } catch (error) {
      console.error('Error updating student in Firestore:', error);
      return false;
    }
  }

  async getStudentById(id: string): Promise<Student | null> {
    try {
      const studentRef = doc(db, 'students', id);
      const snapshot = await getDoc(studentRef);
      
      if (snapshot.exists()) {
        return {
          id: snapshot.id,
          ...snapshot.data()
        } as Student;
      }
      return null;
    } catch (error) {
      console.error('Error getting student by ID from Firestore:', error);
      return null;
    }
  }

  async authenticateStudent(fullName: string, password: string): Promise<Student | null> {
    try {
      const studentsRef = collection(db, 'students');
      const q = query(
        studentsRef,
        where('fullName', '==', fullName.trim()),
        where('password', '==', password.trim())
      );
      const snapshot = await getDocs(q);
      
      if (!snapshot.empty) {
        const doc = snapshot.docs[0];
        const student = {
          id: doc.id,
          ...doc.data()
        } as Student;
        
        if (student.isBlocked) {
          throw new Error(`تم حظر هذا الحساب. السبب: ${student.blockReason || 'غير محدد'}`);
        }
        
        console.log('Student authenticated from Firestore:', student);
        return student;
      }
      
      console.log('Authentication failed - student not found');
      return null;
    } catch (error) {
      console.error('Authentication error:', error);
      throw error;
    }
  }

  // Lessons Methods
  async getLessons(): Promise<Lesson[]> {
    try {
      const lessonsRef = collection(db, 'lessons');
      const snapshot = await getDocs(lessonsRef);
      const lessons = snapshot.docs.map(doc => ({
        ...doc.data()
      })) as Lesson[];
      console.log('Loaded lessons from Firestore:', lessons.length);
      return lessons;
    } catch (error) {
      console.error('Error loading lessons from Firestore:', error);
      return [];
    }
  }

  async getLessonsByGrade(grade: string): Promise<Lesson[]> {
    try {
      const normalizedGrade = this.normalizeGrade(grade);
      const lessonsRef = collection(db, 'lessons');
      const q = query(lessonsRef, where('grade', '==', normalizedGrade));
      const snapshot = await getDocs(q);
      const lessons = snapshot.docs.map(doc => ({
        ...doc.data()
      })) as Lesson[];
      console.log(`Loaded lessons for grade ${normalizedGrade} from Firestore:`, lessons.length);
      return lessons;
    } catch (error) {
      console.error('Error loading lessons by grade from Firestore:', error);
      return [];
    }
  }

  // Subscriptions Methods
  async getSubscriptions(): Promise<Subscription[]> {
    try {
      const subscriptionsRef = collection(db, 'subscriptions');
      const snapshot = await getDocs(subscriptionsRef);
      const subscriptions = snapshot.docs.map(doc => ({
        ...doc.data()
      })) as Subscription[];
      console.log('Loaded subscriptions from Firestore:', subscriptions.length);
      return subscriptions;
    } catch (error) {
      console.error('Error loading subscriptions from Firestore:', error);
      return [];
    }
  }

  async getSubscriptionsByGrade(grade: string): Promise<Subscription[]> {
    try {
      const normalizedGrade = this.normalizeGrade(grade);
      const subscriptionsRef = collection(db, 'subscriptions');
      const q = query(subscriptionsRef, where('grade', '==', normalizedGrade));
      const snapshot = await getDocs(q);
      const subscriptions = snapshot.docs.map(doc => ({
        ...doc.data()
      })) as Subscription[];
      console.log(`Loaded subscriptions for grade ${normalizedGrade} from Firestore:`, subscriptions.length);
      return subscriptions;
    } catch (error) {
      console.error('Error loading subscriptions by grade from Firestore:', error);
      return [];
    }
  }

  // Wallet Request Methods
  async getWalletRequests(): Promise<WalletRequest[]> {
    try {
      const walletRequestsRef = collection(db, 'walletRequests');
      const q = query(walletRequestsRef, orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const requests = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as WalletRequest[];
      console.log('Loaded wallet requests from Firestore:', requests.length);
      return requests;
    } catch (error) {
      console.error('Error loading wallet requests from Firestore:', error);
      return [];
    }
  }

  async addWalletRequest(request: Omit<WalletRequest, 'id' | 'createdAt'>): Promise<boolean> {
    try {
      const newRequest = {
        ...request,
        createdAt: new Date().toISOString(),
        status: 'pending' as const
      };
      
      const docRef = await addDoc(collection(db, 'walletRequests'), newRequest);
      console.log('Wallet request added to Firestore with ID:', docRef.id);
      return true;
    } catch (error) {
      console.error('Error adding wallet request to Firestore:', error);
      return false;
    }
  }

  async updateWalletRequest(id: string, updates: Partial<WalletRequest>): Promise<boolean> {
    try {
      const requestRef = doc(db, 'walletRequests', id);
      await updateDoc(requestRef, updates);
      console.log('Wallet request updated in Firestore:', id);
      return true;
    } catch (error) {
      console.error('Error updating wallet request in Firestore:', error);
      return false;
    }
  }

  // Notifications Methods
  async addNotification(studentId: string, type: string, message: string): Promise<boolean> {
    try {
      const notification = {
        studentId,
        type,
        message,
        read: false,
        timestamp: new Date().toISOString()
      };
      
      await addDoc(collection(db, 'notifications'), notification);
      console.log('Notification added to Firestore for student:', studentId);
      return true;
    } catch (error) {
      console.error('Error adding notification to Firestore:', error);
      return false;
    }
  }

  async getNotifications(studentId: string): Promise<any[]> {
    try {
      const notificationsRef = collection(db, 'notifications');
      const q = query(
        notificationsRef, 
        where('studentId', '==', studentId),
        orderBy('timestamp', 'desc'),
        limit(100)
      );
      const snapshot = await getDocs(q);
      const notifications = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      console.log(`Loaded notifications for student ${studentId} from Firestore:`, notifications.length);
      return notifications;
    } catch (error) {
      console.error('Error loading notifications from Firestore:', error);
      return [];
    }
  }

  // Activity Log Methods
  async addActivityLog(studentId: string, type: string, description: string): Promise<boolean> {
    try {
      const activity = {
        studentId,
        type,
        description,
        timestamp: new Date().toISOString()
      };
      
      await addDoc(collection(db, 'activityLogs'), activity);
      console.log('Activity log added to Firestore for student:', studentId);
      return true;
    } catch (error) {
      console.error('Error adding activity log to Firestore:', error);
      return false;
    }
  }

  async getActivityLog(studentId: string): Promise<any[]> {
    try {
      const activityLogsRef = collection(db, 'activityLogs');
      const q = query(
        activityLogsRef,
        where('studentId', '==', studentId),
        orderBy('timestamp', 'desc'),
        limit(50)
      );
      const snapshot = await getDocs(q);
      const activities = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      console.log(`Loaded activity log for student ${studentId} from Firestore:`, activities.length);
      return activities;
    } catch (error) {
      console.error('Error loading activity log from Firestore:', error);
      return [];
    }
  }

  // Initialize default data in Firestore
  async initializeDefaultData(): Promise<void> {
    try {
      console.log('Initializing default data in Firestore...');
      
      // Check if data already exists
      const studentsSnapshot = await getDocs(collection(db, 'students'));
      if (!studentsSnapshot.empty) {
        console.log('Default data already exists in Firestore');
        return;
      }

      // Add sample students
      const sampleStudents = [
        {
          fullName: 'أحمد محمد علي',
          studentNumber: '123456',
          parentNumber: '01012345678',
          password: '123456',
          grade: '1',
          walletBalance: 100,
          points: 0,
          completedLessons: 0,
          totalLessons: 0,
          examResults: [],
          purchasedLessons: [],
          subscriptions: [],
          notifications: [],
          isBlocked: false
        },
        {
          fullName: 'فاطمة سعد محمود',
          studentNumber: '789012',
          parentNumber: '01087654321',
          password: '789012',
          grade: '2',
          walletBalance: 50,
          points: 0,
          completedLessons: 0,
          totalLessons: 0,
          examResults: [],
          purchasedLessons: [],
          subscriptions: [],
          notifications: [],
          isBlocked: false
        }
      ];

      for (const student of sampleStudents) {
        await this.addStudent(student);
      }

      // Add sample lessons
      const sampleLessons = [
        {
          id: 1,
          title: 'Present Simple Tense',
          description: 'شرح قاعدة المضارع البسيط مع الأمثلة والتمارين',
          price: 25,
          coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
          pdfUrl: 'https://example.com/lesson1.pdf',
          homeworkUrl: 'https://example.com/homework1.pdf',
          solutionUrl: 'https://example.com/solution1.pdf',
          isPurchased: false,
          isCompleted: false,
          grade: '1',
          order: 1
        },
        {
          id: 2,
          title: 'Present Continuous Tense',
          description: 'شرح قاعدة المضارع المستمر مع الأمثلة والتمارين',
          price: 30,
          coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
          pdfUrl: 'https://example.com/lesson2.pdf',
          homeworkUrl: 'https://example.com/homework2.pdf',
          solutionUrl: 'https://example.com/solution2.pdf',
          isPurchased: false,
          isCompleted: false,
          grade: '1',
          order: 2
        }
      ];

      for (const lesson of sampleLessons) {
        await setDoc(doc(db, 'lessons', lesson.id.toString()), lesson);
      }

      // Add sample subscriptions
      const sampleSubscriptions = [
        {
          id: 1,
          title: 'اشتراك الصف الأول الثانوي - شهري',
          description: 'جميع حصص الصف الأول الثانوي لمدة شهر كامل مع الامتحانات والواجبات',
          price: 100,
          duration: '30',
          coverImage: '/lovable-uploads/bfa488fb-fbfa-4b12-91e4-9319f8fbca20.png',
          lessons: [1, 2],
          isPurchased: false,
          grade: '1'
        }
      ];

      for (const subscription of sampleSubscriptions) {
        await setDoc(doc(db, 'subscriptions', subscription.id.toString()), subscription);
      }

      console.log('Default data initialized in Firestore successfully');
    } catch (error) {
      console.error('Error initializing default data in Firestore:', error);
    }
  }
}

export const firebaseDataManager = new FirebaseDataManager();
