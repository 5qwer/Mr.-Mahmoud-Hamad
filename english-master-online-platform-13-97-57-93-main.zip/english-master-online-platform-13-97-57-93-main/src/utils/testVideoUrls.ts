
// روابط فيديوهات تجريبية تعمل بشكل صحيح
export const testVideoUrls = [
  // فيديوهات تعليمية من Big Buck Bunny
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4'
];

// دالة للحصول على رابط فيديو عشوائي
export const getRandomVideoUrl = () => {
  return testVideoUrls[Math.floor(Math.random() * testVideoUrls.length)];
};

// دالة للحصول على رابط فيديو حسب الفهرس
export const getVideoUrlByIndex = (index: number) => {
  return testVideoUrls[index % testVideoUrls.length];
};
