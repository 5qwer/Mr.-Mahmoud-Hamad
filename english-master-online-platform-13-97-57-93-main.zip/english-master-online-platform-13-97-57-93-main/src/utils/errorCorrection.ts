
interface ErrorLog {
  id: string;
  timestamp: string;
  userId?: string;
  userType: 'student' | 'teacher' | 'support';
  error: string;
  page: string;
  browserInfo: string;
  fixed: boolean;
}

interface DataBackup {
  timestamp: string;
  version: string;
  students: any[];
  teachers: any[];
  support: any[];
  lessons: any[];
  subscriptions: any[];
  payments: any[];
  messages: any[];
  settings: any;
}

export class ErrorCorrectionSystem {
  private static instance: ErrorCorrectionSystem;
  
  public static getInstance(): ErrorCorrectionSystem {
    if (!ErrorCorrectionSystem.instance) {
      ErrorCorrectionSystem.instance = new ErrorCorrectionSystem();
    }
    return ErrorCorrectionSystem.instance;
  }

  // Safe JSON operations
  private safeJsonParse<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key);
      if (item === null) return defaultValue;
      return JSON.parse(item) || defaultValue;
    } catch (error) {
      console.error(`Error parsing ${key}:`, error);
      return defaultValue;
    }
  }

  private safeJsonStringify(key: string, value: any): boolean {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error(`Error saving ${key}:`, error);
      return false;
    }
  }

  // Log errors for debugging
  public logError(error: string | Error | unknown, page: string, userId?: string, userType: 'student' | 'teacher' | 'support' = 'student') {
    try {
      let errorMessage: string;
      if (typeof error === 'string') {
        errorMessage = error;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      } else {
        errorMessage = String(error) || 'Unknown error';
      }

      const errorLog: ErrorLog = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        userId,
        userType,
        error: errorMessage,
        page: page || window.location.pathname || 'Unknown page',
        browserInfo: navigator.userAgent || 'Unknown browser',
        fixed: false
      };

      const existingLogs = this.safeJsonParse<ErrorLog[]>('errorLogs', []);
      existingLogs.unshift(errorLog);
      
      // Keep only last 100 errors
      if (existingLogs.length > 100) {
        existingLogs.splice(100);
      }
      
      this.safeJsonStringify('errorLogs', existingLogs);
      console.error('Error logged:', errorLog);
    } catch (logError) {
      console.error('Failed to log error:', logError);
    }
  }

  // Get all error logs
  public getErrorLogs(): ErrorLog[] {
    return this.safeJsonParse<ErrorLog[]>('errorLogs', []);
  }

  // Mark error as fixed
  public markErrorAsFixed(errorId: string): boolean {
    try {
      const logs = this.getErrorLogs();
      const updatedLogs = logs.map(log => 
        log.id === errorId ? { ...log, fixed: true } : log
      );
      return this.safeJsonStringify('errorLogs', updatedLogs);
    } catch (error) {
      console.error('Error marking error as fixed:', error);
      return false;
    }
  }

  // Backup all application data
  public backupData(): DataBackup | null {
    try {
      const backup: DataBackup = {
        timestamp: new Date().toISOString(),
        version: '2.0',
        students: this.safeJsonParse('students', []),
        teachers: this.safeJsonParse('teacherData', null),
        support: this.safeJsonParse('supportList', []),
        lessons: this.safeJsonParse('lessons', []),
        subscriptions: this.safeJsonParse('subscriptions', []),
        payments: this.safeJsonParse('pendingPayments', []),
        messages: this.getAllMessages(),
        settings: {
          theme: localStorage.getItem('theme'),
          backgroundImage: localStorage.getItem('appBackgroundImage'),
          paymentMethods: this.safeJsonParse('paymentMethods', [])
        }
      };

      this.safeJsonStringify('dataBackup', backup);
      
      // Also create timestamped backup
      const backupKey = `backup_${Date.now()}`;
      this.safeJsonStringify(backupKey, backup);
      
      // Keep only last 5 timestamped backups
      this.cleanupOldBackups();
      
      console.log('تم إنشاء نسخة احتياطية:', backup.timestamp);
      return backup;
    } catch (error) {
      console.error('خطأ في إنشاء النسخة الاحتياطية:', error);
      this.logError(`Backup failed: ${error}`, 'ErrorCorrectionSystem');
      return null;
    }
  }

  // Clean up old backups
  private cleanupOldBackups(): void {
    try {
      const backupKeys: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('backup_')) {
          backupKeys.push(key);
        }
      }
      
      // Sort by timestamp (newest first)
      backupKeys.sort((a, b) => {
        const timestampA = parseInt(a.split('_')[1]);
        const timestampB = parseInt(b.split('_')[1]);
        return timestampB - timestampA;
      });
      
      // Remove old backups (keep only 5 most recent)
      for (let i = 5; i < backupKeys.length; i++) {
        localStorage.removeItem(backupKeys[i]);
      }
    } catch (error) {
      console.error('Error cleaning up old backups:', error);
    }
  }

  // Restore data from backup
  public restoreFromBackup(backup?: DataBackup): boolean {
    try {
      const backupToUse = backup || this.safeJsonParse<DataBackup>('dataBackup', null);
      
      if (!backupToUse) {
        console.warn('لم يتم العثور على نسخة احتياطية');
        return false;
      }

      // Restore data with validation
      if (Array.isArray(backupToUse.students)) {
        this.safeJsonStringify('students', backupToUse.students);
      }
      
      if (backupToUse.teachers) {
        this.safeJsonStringify('teacherData', backupToUse.teachers);
      }
      
      if (Array.isArray(backupToUse.support)) {
        this.safeJsonStringify('supportList', backupToUse.support);
      }
      
      if (Array.isArray(backupToUse.lessons)) {
        this.safeJsonStringify('lessons', backupToUse.lessons);
      }
      
      if (Array.isArray(backupToUse.subscriptions)) {
        this.safeJsonStringify('subscriptions', backupToUse.subscriptions);
      }
      
      if (Array.isArray(backupToUse.payments)) {
        this.safeJsonStringify('pendingPayments', backupToUse.payments);
      }
      
      if (backupToUse.settings) {
        const { theme, backgroundImage, paymentMethods } = backupToUse.settings;
        
        if (theme && ['light', 'dark'].includes(theme)) {
          localStorage.setItem('theme', theme);
        }
        
        if (backgroundImage) {
          localStorage.setItem('appBackgroundImage', backgroundImage);
        }
        
        if (Array.isArray(paymentMethods)) {
          this.safeJsonStringify('paymentMethods', paymentMethods);
        }
      }

      console.log('تم استعادة البيانات بنجاح من النسخة الاحتياطية');
      return true;
    } catch (error) {
      console.error('خطأ في استعادة البيانات:', error);
      this.logError(`Restore failed: ${error}`, 'ErrorCorrectionSystem');
      return false;
    }
  }

  // Get all messages from different sources
  private getAllMessages(): any[] {
    try {
      const messages: any[] = [];
      
      // Get support messages
      const students = this.safeJsonParse('students', []);
      students.forEach((student: any) => {
        if (student && student.id) {
          const supportMessages = this.safeJsonParse(`support_chat_${student.id}`, []);
          if (Array.isArray(supportMessages)) {
            messages.push(...supportMessages.map((msg: any) => ({ 
              ...msg, 
              studentId: student.id, 
              type: 'support' 
            })));
          }
        }
      });

      // Get teacher messages
      const teacherMessages = this.safeJsonParse('teacherMessages', []);
      if (Array.isArray(teacherMessages)) {
        messages.push(...teacherMessages.map((msg: any) => ({ ...msg, type: 'teacher' })));
      }

      return messages;
    } catch (error) {
      console.error('Error getting messages:', error);
      return [];
    }
  }

  // Check for data integrity issues
  public checkDataIntegrity(): { issues: string[], fixes: string[] } {
    const issues: string[] = [];
    const fixes: string[] = [];

    try {
      // Check students data
      const students = this.safeJsonParse('students', []);
      if (!Array.isArray(students)) {
        issues.push('بيانات الطلاب تالفة');
        this.safeJsonStringify('students', []);
        fixes.push('إعادة تعيين بيانات الطلاب');
      } else {
        // Validate each student
        const validStudents = students.filter(student => 
          student && typeof student === 'object' && student.id && student.fullName
        );
        
        if (validStudents.length !== students.length) {
          issues.push('بعض بيانات الطلاب غير صحيحة');
          this.safeJsonStringify('students', validStudents);
          fixes.push('إزالة البيانات التالفة للطلاب');
        }
      }

      // Check support list
      const supportList = this.safeJsonParse('supportList', []);
      if (!Array.isArray(supportList)) {
        issues.push('قائمة الدعم تالفة');
        this.safeJsonStringify('supportList', []);
        fixes.push('إعادة تعيين قائمة الدعم');
      }

      // Check lessons
      const lessons = this.safeJsonParse('lessons', []);
      if (!Array.isArray(lessons)) {
        issues.push('بيانات الحصص تالفة');
        this.safeJsonStringify('lessons', []);
        fixes.push('إعادة تعيين بيانات الحصص');
      }

      // Check payment methods
      const paymentMethods = this.safeJsonParse('paymentMethods', []);
      if (!Array.isArray(paymentMethods)) {
        issues.push('بيانات طرق الدفع تالفة');
        this.safeJsonStringify('paymentMethods', []);
        fixes.push('إعادة تعيين طرق الدفع');
      }

      // Check theme setting
      const theme = localStorage.getItem('theme');
      if (theme && !['light', 'dark'].includes(theme)) {
        issues.push('إعداد الثيم غير صحيح');
        localStorage.setItem('theme', 'light');
        fixes.push('إعادة تعيين الثيم إلى الوضع الفاتح');
      }

      // Check for localStorage quota
      const usage = this.getStorageUsage();
      if (usage.percentage > 90) {
        issues.push('مساحة التخزين ممتلئة تقريباً');
        fixes.push('يُنصح بتنظيف البيانات القديمة');
      }

    } catch (error) {
      issues.push(`فشل فحص سلامة البيانات: ${error}`);
      this.logError(`Integrity check error: ${error}`, 'ErrorCorrectionSystem');
    }

    return { issues, fixes };
  }

  // Get storage usage information
  public getStorageUsage(): { used: number, total: number, percentage: number } {
    try {
      let used = 0;
      for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
          used += localStorage[key].length;
        }
      }
      
      // Approximate localStorage limit (usually 5-10MB)
      const total = 5 * 1024 * 1024; // 5MB
      const percentage = Math.round((used / total) * 100);
      
      return { used, total, percentage };
    } catch (error) {
      console.error('Error calculating storage usage:', error);
      return { used: 0, total: 0, percentage: 0 };
    }
  }

  // Auto-fix common issues
  public autoFixIssues(): string[] {
    const fixes: string[] = [];

    try {
      // Ensure required arrays exist
      const requiredArrays = [
        'students', 'supportList', 'lessons', 'subscriptions', 
        'pendingPayments', 'paymentMethods', 'confirmedTransfers'
      ];

      requiredArrays.forEach(key => {
        try {
          const data = this.safeJsonParse(key, []);
          if (!Array.isArray(data)) {
            this.safeJsonStringify(key, []);
            fixes.push(`إصلاح هيكل بيانات ${key}`);
          }
        } catch {
          this.safeJsonStringify(key, []);
          fixes.push(`إعادة تعيين البيانات التالفة ${key}`);
        }
      });

      // Ensure theme is valid
      const theme = localStorage.getItem('theme');
      if (!theme || !['light', 'dark'].includes(theme)) {
        localStorage.setItem('theme', 'light');
        fixes.push('إصلاح إعداد الثيم');
      }

      // Ensure students have required fields
      const students = this.safeJsonParse('students', []);
      if (Array.isArray(students)) {
        const fixedStudents = students.map((student: any) => {
          if (!student || typeof student !== 'object') return null;
          
          return {
            ...student,
            id: student.id || Date.now(),
            fullName: student.fullName || 'مجهول',
            balance: typeof student.balance === 'number' ? student.balance : 0,
            points: typeof student.points === 'number' ? student.points : 0,
            isBlocked: typeof student.isBlocked === 'boolean' ? student.isBlocked : false,
            walletBalance: typeof student.walletBalance === 'number' ? student.walletBalance : 0,
            createdAt: student.createdAt || new Date().toISOString()
          };
        }).filter(Boolean);
        
        if (JSON.stringify(students) !== JSON.stringify(fixedStudents)) {
          this.safeJsonStringify('students', fixedStudents);
          fixes.push('إصلاح حقول بيانات الطلاب');
        }
      }

      // Fix payment methods
      const paymentMethods = this.safeJsonParse('paymentMethods', []);
      if (Array.isArray(paymentMethods)) {
        const validMethods = paymentMethods.filter((method: any) => 
          method && method.id && method.name && method.number && 
          method.name.trim() !== '' && method.number.trim() !== ''
        );
        
        if (validMethods.length !== paymentMethods.length) {
          this.safeJsonStringify('paymentMethods', validMethods);
          fixes.push('إزالة طرق الدفع غير الصحيحة');
        }
      }

    } catch (error) {
      console.error('خطأ في الإصلاح التلقائي:', error);
      this.logError(`Auto-fix error: ${error}`, 'ErrorCorrectionSystem');
      fixes.push('حدث خطأ أثناء الإصلاح التلقائي');
    }

    return fixes;
  }

  // Advanced diagnostic system
  public runDiagnostics(): { 
    status: 'healthy' | 'warning' | 'critical',
    report: {
      storage: any,
      integrity: any,
      performance: any,
      errors: any
    }
  } {
    try {
      const storage = this.getStorageUsage();
      const integrity = this.checkDataIntegrity();
      const errors = this.getErrorLogs().slice(0, 10); // Last 10 errors
      
      // Performance check - avoid variable shadowing by using different name
      const performanceInfo = {
        loadTime: Date.now(),
        memoryUsage: (window.performance as any)?.memory ? (window.performance as any).memory.usedJSHeapSize : 'غير متاح'
      };

      let status: 'healthy' | 'warning' | 'critical' = 'healthy';
      
      if (integrity.issues.length > 0) {
        status = 'warning';
      }
      
      if (storage.percentage > 95 || errors.length > 5) {
        status = 'critical';
      }

      return {
        status,
        report: {
          storage,
          integrity,
          performance: performanceInfo,
          errors
        }
      };
    } catch (error) {
      console.error('خطأ في تشغيل التشخيصات:', error);
      return {
        status: 'critical',
        report: {
          storage: { used: 0, total: 0, percentage: 0 },
          integrity: { issues: ['فشل التشخيص'], fixes: [] },
          performance: { loadTime: 0, memoryUsage: 'غير متاح' },
          errors: []
        }
      };
    }
  }

  // Initialize error correction on app start
  public initialize(): void {
    console.log('تم تهيئة نظام تصحيح الأخطاء');
    
    try {
      // Run diagnostics
      const diagnostics = this.runDiagnostics();
      console.log('تقرير التشخيص:', diagnostics);
      
      // Run auto-fix on startup
      const fixes = this.autoFixIssues();
      if (fixes.length > 0) {
        console.log('الإصلاحات التلقائية المطبقة:', fixes);
      }

      // Check data integrity
      const { issues, fixes: integrityFixes } = this.checkDataIntegrity();
      if (issues.length > 0) {
        console.warn('مشاكل في سلامة البيانات:', issues);
        console.log('الإصلاحات المطبقة:', integrityFixes);
      }

      // Create backup
      this.backupData();
      
      // Set up periodic health checks
      this.setupPeriodicChecks();
      
    } catch (error) {
      console.error('خطأ في تهيئة نظام تصحيح الأخطاء:', error);
      this.logError(`Initialization error: ${error}`, 'ErrorCorrectionSystem');
    }
  }

  // Setup periodic health checks
  private setupPeriodicChecks(): void {
    // Run health check every 5 minutes
    setInterval(() => {
      try {
        const diagnostics = this.runDiagnostics();
        
        if (diagnostics.status === 'critical') {
          console.warn('⚠️ حالة النظام حرجة - يتطلب تدخل');
          this.autoFixIssues();
        }
        
        // Create backup every hour
        if (Date.now() % (60 * 60 * 1000) < 5 * 60 * 1000) { // Within 5 minutes of the hour
          this.backupData();
        }
      } catch (error) {
        console.error('خطأ في الفحص الدوري:', error);
      }
    }, 5 * 60 * 1000); // 5 minutes
  }
}

// Initialize the error correction system
export const errorCorrection = ErrorCorrectionSystem.getInstance();

// Enhanced global error handling
window.addEventListener('error', (event) => {
  const errorMessage = event.error?.message || event.message || 'Unknown error';
  const stack = event.error?.stack || 'No stack trace';
  
  errorCorrection.logError(
    `${errorMessage}\nStack: ${stack}`,
    window.location.pathname
  );
});

window.addEventListener('unhandledrejection', (event) => {
  const reason = event.reason?.toString() || 'Unknown promise rejection';
  
  errorCorrection.logError(
    `Promise rejection: ${reason}`,
    window.location.pathname
  );
});

// Handle quota exceeded errors
window.addEventListener('error', (event) => {
  if (event.error?.name === 'QuotaExceededError' || 
      event.message?.includes('quota') ||
      event.message?.includes('storage')) {
    
    console.warn('⚠️ تم تجاوز حد التخزين - تشغيل التنظيف التلقائي');
    errorCorrection.autoFixIssues();
  }
});
