
import React, { useState, useEffect } from 'react';
import { X, AlertTriangle } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface ErrorToastProps {
  title: string;
  message: string;
  onClose: () => void;
  duration?: number;
}

const ErrorToast = ({ title, message, onClose, duration = 8000 }: ErrorToastProps) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onClose, 300);
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onClose]);

  if (!isVisible) return null;

  return (
    <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-md mx-4">
      <Card className="bg-red-500 text-white p-4 shadow-lg animate-slide-down">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-6 h-6 mt-1 flex-shrink-0" />
          <div className="flex-1">
            <div className="font-bold text-lg mb-2">{title}</div>
            <div 
              className="text-sm leading-relaxed whitespace-pre-line font-mono bg-red-600/30 p-3 rounded border"
              style={{ fontFamily: 'monospace', fontSize: '12px' }}
            >
              {message}
            </div>
          </div>
          <button
            onClick={() => {
              setIsVisible(false);
              setTimeout(onClose, 300);
            }}
            className="text-white hover:text-red-200 transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </Card>
    </div>
  );
};

export default ErrorToast;
