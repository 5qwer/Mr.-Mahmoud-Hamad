
import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Play, 
  FileText, 
  BookOpen, 
  HelpCircle, 
  Send, 
  Download,
  CheckCircle,
  Clock,
  User,
  MessageSquare,
  Image as ImageIcon,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import EnhancedVideoPlayer from './EnhancedVideoPlayer';

interface LessonContent {
  id: number;
  title: string;
  description: string;
  order_number: number;
  video_url: string;
  pdf_url: string;
  homework_url: string;
  homework_video_url: string;
  solution_url: string;
  cover_image: string;
  grade: string;
}

interface LessonContentViewerProps {
  lesson: LessonContent;
  studentId: string;
  onSendMessage?: (message: string, questionImage?: File) => void;
}

const LessonContentViewer: React.FC<LessonContentViewerProps> = ({ 
  lesson, 
  studentId, 
  onSendMessage 
}) => {
  const [activeSection, setActiveSection] = useState<'video' | 'pdf' | 'homework' | 'homework_video' | 'test'>('video');
  const [watchProgress, setWatchProgress] = useState(0);
  const [questionText, setQuestionText] = useState('');
  const [questionImage, setQuestionImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleVideoProgress = (currentTime: number, duration: number) => {
    if (duration > 0) {
      const progress = (currentTime / duration) * 100;
      setWatchProgress(Math.floor(progress));
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('حجم الصورة كبير جداً. يرجى اختيار صورة أصغر من 5 ميجابايت');
        return;
      }
      setQuestionImage(file);
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSendQuestion = async () => {
    if (!questionText.trim() && !questionImage) {
      toast.error('يرجى كتابة سؤال أو رفع صورة');
      return;
    }

    setIsSubmitting(true);
    try {
      if (onSendMessage) {
        await onSendMessage(questionText, questionImage || undefined);
        setQuestionText('');
        setQuestionImage(null);
        setImagePreview('');
        toast.success('تم إرسال السؤال للمدرس بنجاح');
      }
    } catch (error) {
      toast.error('حدث خطأ في إرسال السؤال');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownload = (url: string, filename: string) => {
    if (!url) {
      toast.error('الرابط غير متوفر');
      return;
    }
    
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getGradeText = (grade: string) => {
    switch (grade) {
      case '1': return 'الأول الثانوي';
      case '2': return 'الثاني الثانوي';
      case '3': return 'الثالث الثانوي';
      default: return 'غير محدد';
    }
  };

  const renderPdfViewer = (url: string, title: string) => {
    if (!url) {
      return (
        <div className="w-full h-96 border rounded-lg flex items-center justify-center bg-gray-50">
          <div className="text-center text-gray-500">
            <AlertCircle className="w-12 h-12 mx-auto mb-2" />
            <p>الملف غير متوفر</p>
          </div>
        </div>
      );
    }

    return (
      <div className="w-full h-96 border rounded-lg overflow-hidden bg-gray-50">
        <iframe
          src={url}
          className="w-full h-full"
          title={title}
          onError={() => toast.error('خطأ في تحميل الملف')}
        />
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Lesson Header */}
      <Card className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 border-none shadow-lg">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-gray-900 mb-2">{lesson.title}</h1>
            <p className="text-gray-600 mb-4 leading-relaxed">{lesson.description}</p>
            <div className="flex items-center gap-4 flex-wrap">
              <Badge variant="secondary" className="px-3 py-1">
                <User className="w-4 h-4 ml-2" />
                {getGradeText(lesson.grade)}
              </Badge>
              <Badge variant="outline" className="px-3 py-1">
                <Clock className="w-4 h-4 ml-2" />
                الحصة رقم {lesson.order_number}
              </Badge>
              {watchProgress > 0 && (
                <Badge className="bg-green-100 text-green-800 px-3 py-1">
                  <CheckCircle className="w-4 h-4 ml-2" />
                  تم المشاهدة {watchProgress}%
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Content Navigation */}
        <div className="flex flex-wrap gap-2">
          {lesson.video_url && (
            <Button
              variant={activeSection === 'video' ? 'default' : 'outline'}
              onClick={() => setActiveSection('video')}
              className="flex items-center gap-2"
            >
              <Play className="w-4 h-4" />
              فيديو الشرح
            </Button>
          )}
          
          {lesson.pdf_url && (
            <Button
              variant={activeSection === 'pdf' ? 'default' : 'outline'}
              onClick={() => setActiveSection('pdf')}
              className="flex items-center gap-2"
            >
              <FileText className="w-4 h-4" />
              ملف الشرح
            </Button>
          )}
          
          {lesson.homework_url && (
            <Button
              variant={activeSection === 'homework' ? 'default' : 'outline'}
              onClick={() => setActiveSection('homework')}
              className="flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4" />
              الواجب
            </Button>
          )}
          
          {lesson.homework_video_url && (
            <Button
              variant={activeSection === 'homework_video' ? 'default' : 'outline'}
              onClick={() => setActiveSection('homework_video')}
              className="flex items-center gap-2"
            >
              <Play className="w-4 h-4" />
              فيديو حل الواجب
            </Button>
          )}
          
          <Button
            variant={activeSection === 'test' ? 'default' : 'outline'}
            onClick={() => setActiveSection('test')}
            className="flex items-center gap-2"
          >
            <HelpCircle className="w-4 h-4" />
            اسأل المدرس
          </Button>
        </div>
      </Card>

      {/* Content Display */}
      <Card className="p-0 overflow-hidden shadow-lg">
        {activeSection === 'video' && lesson.video_url && (
          <div className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Play className="w-5 h-5 text-blue-600" />
              فيديو الشرح
            </h3>
            <div className="rounded-lg overflow-hidden">
              <EnhancedVideoPlayer
                src={lesson.video_url}
                title={lesson.title}
                grade={lesson.grade}
                onProgress={handleVideoProgress}
              />
            </div>
          </div>
        )}

        {activeSection === 'pdf' && (
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <FileText className="w-5 h-5 text-green-600" />
                ملف الشرح
              </h3>
              {lesson.pdf_url && (
                <Button
                  onClick={() => handleDownload(lesson.pdf_url, `${lesson.title} - ملف الشرح.pdf`)}
                  className="flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  تحميل الملف
                </Button>
              )}
            </div>
            {renderPdfViewer(lesson.pdf_url, "ملف الشرح")}
          </div>
        )}

        {activeSection === 'homework' && (
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-orange-600" />
                الواجب
              </h3>
              {lesson.homework_url && (
                <Button
                  onClick={() => handleDownload(lesson.homework_url, `${lesson.title} - الواجب.pdf`)}
                  className="flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  تحميل الواجب
                </Button>
              )}
            </div>
            {renderPdfViewer(lesson.homework_url, "الواجب")}
          </div>
        )}

        {activeSection === 'homework_video' && lesson.homework_video_url && (
          <div className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Play className="w-5 h-5 text-purple-600" />
              فيديو حل الواجب
            </h3>
            <div className="rounded-lg overflow-hidden">
              <EnhancedVideoPlayer
                src={lesson.homework_video_url}
                title={`${lesson.title} - حل الواجب`}
                grade={lesson.grade}
              />
            </div>
          </div>
        )}

        {activeSection === 'test' && (
          <div className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-red-600" />
              اسأل المدرس
            </h3>
            
            <div className="space-y-6 max-w-2xl">
              <div>
                <label className="block text-sm font-medium mb-2">اكتب سؤالك هنا:</label>
                <Textarea
                  value={questionText}
                  onChange={(e) => setQuestionText(e.target.value)}
                  placeholder="اكتب سؤالك أو استفسارك للمدرس..."
                  rows={4}
                  className="w-full resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">أو ارفع صورة للسؤال:</label>
                <div className="flex items-center gap-4">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="flex-1"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    className="shrink-0"
                  >
                    <ImageIcon className="w-4 h-4 ml-2" />
                    اختر صورة
                  </Button>
                </div>
                {imagePreview && (
                  <div className="mt-3">
                    <img 
                      src={imagePreview} 
                      alt="معاينة السؤال" 
                      className="max-w-xs h-32 object-cover rounded border shadow-sm"
                    />
                  </div>
                )}
              </div>

              <Separator />

              <Button
                onClick={handleSendQuestion}
                disabled={isSubmitting || (!questionText.trim() && !questionImage)}
                className="w-full flex items-center gap-2 py-3"
              >
                {isSubmitting ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <Send className="w-4 h-4" />
                )}
                إرسال السؤال للمدرس
              </Button>

              <div className="text-sm text-gray-500 text-center p-4 bg-blue-50 rounded-lg">
                💡 سيتم إرسال سؤالك للمدرس وسيرد عليك في أقرب وقت
              </div>
            </div>
          </div>
        )}

        {/* Fallback for missing content */}
        {activeSection === 'video' && !lesson.video_url && (
          <div className="p-6">
            <div className="flex items-center justify-center h-64 text-gray-500">
              <div className="text-center">
                <AlertCircle className="w-12 h-12 mx-auto mb-2" />
                <p>فيديو الشرح غير متوفر حالياً</p>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'homework_video' && !lesson.homework_video_url && (
          <div className="p-6">
            <div className="flex items-center justify-center h-64 text-gray-500">
              <div className="text-center">
                <AlertCircle className="w-12 h-12 mx-auto mb-2" />
                <p>فيديو حل الواجب غير متوفر حالياً</p>
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

export default LessonContentViewer;
