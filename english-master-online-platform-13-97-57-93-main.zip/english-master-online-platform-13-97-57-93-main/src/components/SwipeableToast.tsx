
import { useState, useRef, useEffect } from 'react';
import { X } from 'lucide-react';

interface SwipeableToastProps {
  message: string;
  type: 'success' | 'error' | 'info';
  onDismiss: () => void;
  duration?: number;
}

const SwipeableToast = ({ message, type, onDismiss, duration = 4000 }: SwipeableToastProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [dragDistance, setDragDistance] = useState(0);
  const [startX, setStartX] = useState(0);
  const toastRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss();
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onDismiss]);

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true);
    setStartX(e.touches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    
    const currentX = e.touches[0].clientX;
    const distance = currentX - startX;
    setDragDistance(distance);
  };

  const handleTouchEnd = () => {
    if (Math.abs(dragDistance) > 100) {
      onDismiss();
    } else {
      setDragDistance(0);
    }
    setIsDragging(false);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setStartX(e.clientX);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    
    const distance = e.clientX - startX;
    setDragDistance(distance);
  };

  const handleMouseUp = () => {
    if (Math.abs(dragDistance) > 100) {
      onDismiss();
    } else {
      setDragDistance(0);
    }
    setIsDragging(false);
  };

  const getTypeStyles = () => {
    switch (type) {
      case 'success':
        return 'bg-green-500 border-green-400';
      case 'error':
        return 'bg-red-500 border-red-400';
      default:
        return 'bg-blue-500 border-blue-400';
    }
  };

  return (
    <div
      ref={toastRef}
      className={`fixed top-4 right-4 z-50 ${getTypeStyles()} text-white px-4 py-3 rounded-lg border shadow-lg cursor-grab select-none transform transition-all duration-200`}
      style={{
        transform: `translateX(${dragDistance}px) ${Math.abs(dragDistance) > 50 ? 'scale(0.95)' : 'scale(1)'}`,
        opacity: Math.abs(dragDistance) > 50 ? 0.7 : 1
      }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">{message}</span>
        <button
          onClick={onDismiss}
          className="mr-2 hover:bg-white/20 rounded-full p-1 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
      
      {/* إرشادات الإزاحة */}
      <div className="text-xs opacity-75 mt-1">
        اسحب يميناً أو يساراً للإخفاء
      </div>
    </div>
  );
};

export default SwipeableToast;
