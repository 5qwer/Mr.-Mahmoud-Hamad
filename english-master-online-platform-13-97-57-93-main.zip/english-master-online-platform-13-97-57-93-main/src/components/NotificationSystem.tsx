
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, AlertTriangle, Info, Zap, X } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';

// استخدام النوع من Supabase بدلاً من تعريف واجهة محلية
type Notification = Tables<'general_messages'>;

interface NotificationSystemProps {
  currentUser: any;
  userType: 'student' | 'teacher' | 'support';
}

const NotificationSystem = ({ currentUser, userType }: NotificationSystemProps) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showUrgentModal, setShowUrgentModal] = useState(false);
  const [urgentNotification, setUrgentNotification] = useState<Notification | null>(null);
  const [readNotifications, setReadNotifications] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadNotifications();
    
    // Check for urgent notifications every 30 seconds
    const interval = setInterval(() => {
      checkForUrgentNotifications();
    }, 30000);
    
    return () => clearInterval(interval);
  }, [currentUser]);

  const loadNotifications = async () => {
    try {
      console.log('Loading notifications for user:', currentUser?.grade, userType);
      
      const { data, error } = await supabase
        .from('general_messages')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error('Error loading notifications:', error);
        return;
      }
      
      console.log('Loaded general messages:', data);
      
    // Load hidden notifications
    const hiddenNotifications = JSON.parse(localStorage.getItem(`hiddenNotifications_${currentUser?.id}`) || '[]');
    const hiddenNotificationsSet = new Set(hiddenNotifications);
    
    // Filter notifications for current user
    const userNotifications = (data || []).filter((notif) => {
      // Don't show hidden notifications
      if (hiddenNotificationsSet.has(notif.id)) return false;
      
      if (userType === 'teacher' || userType === 'support') return true;
      if (userType === 'student' && currentUser) {
        // If target_all is true, show to all students
        if (notif.target_all) return true;
        // If specific grades are targeted, check if user's grade matches
        if (notif.target_grades && notif.target_grades.length > 0) {
          const userGrade = currentUser.grade?.toString() || '1';
          return notif.target_grades.includes(userGrade);
        }
      }
      return false;
    });
      
      console.log('Filtered notifications for user:', userNotifications);
      setNotifications(userNotifications);
      
      // Load read notifications from localStorage
      const readNotifs = JSON.parse(localStorage.getItem(`readNotifications_${currentUser?.id}`) || '[]');
      setReadNotifications(new Set(readNotifs));
      
    } catch (error) {
      console.error('Error loading notifications:', error);
    }
  };

  const checkForUrgentNotifications = () => {
    const urgentUnread = notifications.find((notif) => 
      notif.priority === 'urgent' && 
      !readNotifications.has(notif.id)
    );
    
    if (urgentUnread && !showUrgentModal) {
      setUrgentNotification(urgentUnread);
      setShowUrgentModal(true);
      
      // Play urgent sound
      try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        oscillator.frequency.value = 880;
        oscillator.type = 'square';
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.5);
      } catch (error) {
        console.log('Could not play urgent sound:', error);
      }
    }
  };

  const markAsRead = (notificationId: string) => {
    const newReadNotifications = new Set(readNotifications);
    newReadNotifications.add(notificationId);
    setReadNotifications(newReadNotifications);
    
    // Save to localStorage
    const readArray = Array.from(newReadNotifications);
    localStorage.setItem(`readNotifications_${currentUser?.id}`, JSON.stringify(readArray));
  };

  const dismissUrgentNotification = () => {
    if (urgentNotification) {
      markAsRead(urgentNotification.id);
    }
    setShowUrgentModal(false);
    setUrgentNotification(null);
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent': return <Zap className="w-4 h-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      default: return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 border-red-500 text-red-700';
      case 'warning': return 'bg-yellow-100 border-yellow-500 text-yellow-700';
      default: return 'bg-blue-100 border-blue-500 text-blue-700';
    }
  };

  return (
    <>
      {/* Urgent Notification Modal */}
      {showUrgentModal && urgentNotification && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <Card className="p-6 max-w-md w-full bg-red-50 border-red-500 border-2 animate-pulse">
            <div className="flex items-center gap-3 mb-4">
              <Zap className="w-8 h-8 text-red-500" />
              <div>
                <h3 className="text-lg font-bold text-red-700">إشعار عاجل!</h3>
                <p className="text-sm text-red-600">{urgentNotification.title}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={dismissUrgentNotification}
                className="ml-auto"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-red-700 mb-4">{urgentNotification.message}</p>
            <Button 
              onClick={dismissUrgentNotification}
              className="w-full bg-red-600 hover:bg-red-700"
            >
              تم الاطلاع
            </Button>
          </Card>
        </div>
      )}

      {/* Regular Notifications List */}
      <div className="space-y-3">
        {notifications.map((notification) => {
          const isRead = readNotifications.has(notification.id);
          return (
            <Card 
              key={notification.id}
              className={`p-4 ${getPriorityColor(notification.priority)} ${
                !isRead ? 'border-l-4' : 'opacity-75'
              }`}
            >
              <div className="flex items-start gap-3">
                {getPriorityIcon(notification.priority)}
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-bold">{notification.title}</h4>
                    <Badge variant={notification.priority === 'urgent' ? 'destructive' : 'secondary'}>
                      {notification.priority === 'urgent' ? 'عاجل' : 
                       notification.priority === 'warning' ? 'تنبيه' : 'عادي'}
                    </Badge>
                    {!isRead && (
                      <Badge className="bg-blue-500">جديد</Badge>
                    )}
                  </div>
                  <p className="text-sm mb-2">{notification.message}</p>
                  <p className="text-xs opacity-75">
                    {new Date(notification.created_at).toLocaleString('ar-EG')}
                  </p>
                </div>
                <div className="flex flex-col gap-2">
                  {!isRead && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => markAsRead(notification.id)}
                    >
                      تم القراءة
                    </Button>
                  )}
                  {notification.priority === 'urgent' && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        // إخفاء الإشعار من الصفحة (لا يحذفه من قاعدة البيانات)
                        const hiddenNotifications = JSON.parse(localStorage.getItem(`hiddenNotifications_${currentUser?.id}`) || '[]');
                        hiddenNotifications.push(notification.id);
                        localStorage.setItem(`hiddenNotifications_${currentUser?.id}`, JSON.stringify(hiddenNotifications));
                        
                        // إعادة تحميل الإشعارات
                        window.location.reload();
                      }}
                      className="text-red-500 hover:text-red-700"
                    >
                      🗑️ إخفاء
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          );
        })}
        
        {notifications.length === 0 && (
          <Card className="p-6 text-center">
            <Bell className="w-12 h-12 mx-auto mb-3 text-gray-400" />
            <p className="text-gray-500">لا توجد إشعارات</p>
          </Card>
        )}
      </div>
    </>
  );
};

export default NotificationSystem;
