
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingUp, Users, Eye, Clock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

const TeacherFinancials = () => {
  const [walletRequests, setWalletRequests] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [showStudentModal, setShowStudentModal] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // Load wallet requests from Supabase
      const { data: requests, error: requestsError } = await supabase
        .from('wallet_requests')
        .select('*')
        .order('created_at', { ascending: false });

      if (requestsError) {
        console.error('خطأ في جلب طلبات المحفظة:', requestsError);
      } else {
        setWalletRequests(requests || []);
      }

      // Load students from Supabase
      const { data: studentsData, error: studentsError } = await supabase
        .from('students')
        .select('*')
        .order('created_at', { ascending: false });

      if (studentsError) {
        console.error('خطأ في جلب الطلاب:', studentsError);
      } else {
        setStudents(studentsData || []);
      }
    } catch (error) {
      console.error('خطأ في تحميل البيانات:', error);
    }
  };

  const getTotalRevenue = () => {
    return walletRequests
      .filter(r => r.status === 'approved')
      .reduce((sum, r) => sum + r.amount, 0);
  };

  const getPendingAmount = () => {
    return walletRequests
      .filter(r => r.status === 'pending')
      .reduce((sum, r) => sum + r.amount, 0);
  };

  const getRecentTransactions = () => {
    return walletRequests
      .filter(r => r.status === 'approved')
      .sort((a, b) => new Date(b.reviewed_at || b.created_at).getTime() - new Date(a.reviewed_at || a.created_at).getTime())
      .slice(0, 5);
  };

  const handleViewStudent = (studentId: string) => {
    const student = students.find(s => s.id === studentId);
    if (student) {
      setSelectedStudent({
        ...student,
        fullName: student.full_name,
        studentNumber: student.student_number,
        parentNumber: student.parent_number,
        walletBalance: student.wallet_balance,
        isBlocked: student.is_blocked,
        blockReason: student.block_reason,
        createdAt: student.created_at
      });
      setShowStudentModal(true);
    }
  };

  return (
    <div className="space-y-6">
      {/* Financial Overview */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-100 rounded-full">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">المبلغ المستلم</p>
              <p className="text-xl font-bold text-green-600">{getTotalRevenue()} جنيه</p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-yellow-100 rounded-full">
              <Clock className="w-5 h-5 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">العمليات المعلقة</p>
              <p className="text-xl font-bold text-yellow-600">{getPendingAmount()} جنيه</p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-full">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">إجمالي الطلاب</p>
              <p className="text-xl font-bold text-blue-600">{students.length}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Transactions */}
      <Card className="p-6">
        <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-green-600" />
          آخر العمليات المؤكدة
        </h3>
        
        <div className="space-y-3">
          {getRecentTransactions().map((transaction) => {
            const student = students.find(s => s.id === transaction.user_id);
            return (
              <div key={transaction.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <DollarSign className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-semibold">
                      {student?.full_name || 'طالب غير محدد'}
                      <Button
                        variant="link"
                        size="sm"
                        className="p-0 h-auto ml-2"
                        onClick={() => handleViewStudent(transaction.user_id)}
                      >
                        <Eye className="w-3 h-3" />
                      </Button>
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(transaction.reviewed_at || transaction.created_at).toLocaleString('ar-EG')}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-green-600">+{transaction.amount} جنيه</p>
                  <p className="text-xs text-muted-foreground">{transaction.payment_method}</p>
                </div>
              </div>
            );
          })}
          
          {getRecentTransactions().length === 0 && (
            <p className="text-center text-muted-foreground py-4">لا توجد عمليات مؤكدة حديثة</p>
          )}
        </div>
      </Card>

      {/* Student Details Modal */}
      {showStudentModal && selectedStudent && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="p-6 max-w-md w-full mx-4 max-h-96 overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold">تفاصيل الطالب</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowStudentModal(false)}
              >
                ✕
              </Button>
            </div>
            
            <div className="space-y-3">
              <div>
                <p className="text-sm text-muted-foreground">الاسم الكامل</p>
                <p className="font-semibold">{selectedStudent.fullName}</p>
              </div>
              
              <div>
                <p className="text-sm text-muted-foreground">رقم الطالب</p>
                <p className="font-semibold">{selectedStudent.studentNumber}</p>
              </div>
              
              <div>
                <p className="text-sm text-muted-foreground">الصف الدراسي</p>
                <p className="font-semibold">
                  {selectedStudent.grade === 'first' ? 'الأول الثانوي' :
                   selectedStudent.grade === 'second' ? 'الثاني الثانوي' : 'الثالث الثانوي'}
                </p>
              </div>
              
              <div>
                <p className="text-sm text-muted-foreground">رصيد المحفظة</p>
                <p className="font-semibold text-green-600">{selectedStudent.walletBalance || 0} جنيه</p>
              </div>
              
              <div>
                <p className="text-sm text-muted-foreground">النقاط</p>
                <p className="font-semibold text-purple-600">{selectedStudent.points || 0} نقطة</p>
              </div>
              
              <div>
                <p className="text-sm text-muted-foreground">الحالة</p>
                <Badge variant={selectedStudent.isBlocked ? 'destructive' : 'default'}>
                  {selectedStudent.isBlocked ? 'محظور' : 'نشط'}
                </Badge>
              </div>
              
              <div>
                <p className="text-sm text-muted-foreground">تاريخ التسجيل</p>
                <p className="font-semibold">
                  {new Date(selectedStudent.createdAt).toLocaleDateString('ar-EG')}
                </p>
              </div>
              
              {selectedStudent.parentNumber && (
                <div>
                  <p className="text-sm text-muted-foreground">رقم ولي الأمر</p>
                  <p className="font-semibold">{selectedStudent.parentNumber}</p>
                </div>
              )}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default TeacherFinancials;
