
import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Settings, SkipBack, SkipForward, Maximize, Minimize } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface EnhancedVideoPlayerProps {
  src: string;
  title: string;
  grade: string;
  onProgress?: (currentTime: number, duration: number) => void;
}

const EnhancedVideoPlayer: React.FC<EnhancedVideoPlayerProps> = ({ 
  src, 
  title, 
  grade,
  onProgress 
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [showControls, setShowControls] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [watermarkPosition, setWatermarkPosition] = useState({ x: 20, y: 20 });
  const [videoError, setVideoError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const hideControlsTimeoutRef = useRef<NodeJS.Timeout>();

  // Grade text mapping
  const getGradeText = (grade: string) => {
    switch (grade) {
      case '1': return 'الأول الثانوي';
      case '2': return 'الثاني الثانوي';
      case '3': return 'الثالث الثانوي';
      default: return 'غير محدد';
    }
  };

  // Watermark movement every 20 seconds
  useEffect(() => {
    const moveWatermark = () => {
      if (containerRef.current) {
        const container = containerRef.current;
        const maxX = Math.max(0, container.clientWidth - 200);
        const maxY = Math.max(0, container.clientHeight - 50);
        
        setWatermarkPosition({
          x: Math.random() * maxX,
          y: Math.random() * maxY
        });
      }
    };

    moveWatermark();
    const interval = setInterval(moveWatermark, 20000);
    return () => clearInterval(interval);
  }, []);

  // Auto-hide controls after 3 seconds of inactivity
  const resetHideControlsTimer = () => {
    setShowControls(true);
    if (hideControlsTimeoutRef.current) {
      clearTimeout(hideControlsTimeoutRef.current);
    }
    if (isPlaying) {
      hideControlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
  };

  // Video event handlers
  const handlePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        const playPromise = videoRef.current.play();
        if (playPromise !== undefined) {
          playPromise.catch(error => {
            console.error('Error playing video:', error);
            setVideoError(true);
          });
        }
      }
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const current = videoRef.current.currentTime;
      const total = videoRef.current.duration;
      setCurrentTime(current);
      if (onProgress) {
        onProgress(current, total);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      setIsLoading(false);
      setVideoError(false);
    }
  };

  const handleVideoError = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
    console.error('Video error:', e);
    setVideoError(true);
    setIsLoading(false);
  };

  const handleCanPlay = () => {
    setIsLoading(false);
    setVideoError(false);
  };

  const handleSeek = (time: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = Math.max(0, Math.min(time, duration));
    }
  };

  const handleSkipBack = () => {
    handleSeek(currentTime - 5);
  };

  const handleSkipForward = () => {
    handleSeek(currentTime + 5);
  };

  const handleVolumeChange = (newVolume: number) => {
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
      setVolume(newVolume);
      setIsMuted(newVolume === 0);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      const newMuted = !isMuted;
      videoRef.current.muted = newMuted;
      setIsMuted(newMuted);
    }
  };

  const toggleFullscreen = () => {
    if (containerRef.current) {
      if (!isFullscreen) {
        if (containerRef.current.requestFullscreen) {
          containerRef.current.requestFullscreen();
        }
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        }
      }
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleVideoClick = (e: React.MouseEvent) => {
    e.preventDefault();
    const rect = videoRef.current?.getBoundingClientRect();
    if (rect) {
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      if (Math.abs(clickX - centerX) < 80 && Math.abs(clickY - centerY) < 80) {
        handlePlay();
      } else {
        setShowControls(!showControls);
      }
    }
    resetHideControlsTimer();
  };

  const handleMouseMove = () => {
    resetHideControlsTimer();
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    handleSeek(pos * duration);
  };

  useEffect(() => {
    return () => {
      if (hideControlsTimeoutRef.current) {
        clearTimeout(hideControlsTimeoutRef.current);
      }
    };
  }, []);

  // Reset error when src changes
  useEffect(() => {
    setVideoError(false);
    setIsLoading(true);
  }, [src]);

  return (
    <div 
      ref={containerRef}
      className="relative w-full bg-black rounded-lg overflow-hidden group cursor-pointer"
      style={{ aspectRatio: '16/9' }}
      onMouseMove={handleMouseMove}
      onMouseLeave={() => setShowControls(isPlaying ? false : true)}
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        src={src}
        className="w-full h-full object-cover"
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onCanPlay={handleCanPlay}
        onError={handleVideoError}
        onContextMenu={handleContextMenu}
        onClick={handleVideoClick}
        controlsList="nodownload nofullscreen noremoteplayback"
        disablePictureInPicture
        preload="metadata"
        crossOrigin="anonymous"
        style={{ pointerEvents: 'auto' }}
      />

      {/* Moving Watermark */}
      <div
        className="absolute pointer-events-none select-none z-20 transition-all duration-1000 ease-in-out"
        style={{
          left: `${watermarkPosition.x}px`,
          top: `${watermarkPosition.y}px`,
          transform: 'translate(0, 0)'
        }}
      >
        <span 
          className="font-bold text-lg opacity-80"
          style={{ 
            color: '#ff0000',
            textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
            userSelect: 'none',
            pointerEvents: 'none',
            fontFamily: 'Arial, sans-serif'
          }}
        >
          {getGradeText(grade)}
        </span>
      </div>

      {/* Error Message */}
      {videoError && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80 z-30">
          <div className="text-center text-white">
            <div className="text-red-500 text-6xl mb-4">⚠️</div>
            <h3 className="text-xl font-bold mb-2">خطأ في تحميل الفيديو</h3>
            <p className="text-gray-300 mb-4">لا يمكن تشغيل الفيديو حالياً</p>
            <Button
              onClick={() => {
                setVideoError(false);
                setIsLoading(true);
                if (videoRef.current) {
                  videoRef.current.load();
                }
              }}
              className="bg-red-600 hover:bg-red-700"
            >
              إعادة المحاولة
            </Button>
          </div>
        </div>
      )}

      {/* Loading Overlay */}
      {isLoading && !videoError && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-20">
          <div className="text-center text-white">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
            <p>جار تحميل الفيديو...</p>
          </div>
        </div>
      )}

      {/* Play Button Overlay */}
      {!isPlaying && !isLoading && !videoError && (
        <div className="absolute inset-0 flex items-center justify-center z-10">
          <Button
            size="lg"
            onClick={handlePlay}
            className="rounded-full w-20 h-20 bg-white/20 hover:bg-white/30 backdrop-blur-sm border-none"
          >
            <Play className="w-8 h-8 text-white ml-1" />
          </Button>
        </div>
      )}

      {/* Controls */}
      <div 
        className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-4 z-30 transition-opacity duration-300 ${
          showControls ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {/* Progress Bar */}
        <div className="mb-4">
          <div 
            className="w-full bg-white/20 rounded-full h-2 cursor-pointer"
            onClick={handleProgressClick}
          >
            <div 
              className="bg-red-500 h-2 rounded-full transition-all duration-200"
              style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
            />
          </div>
        </div>

        {/* Control Buttons */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              size="sm"
              variant="ghost"
              onClick={handleSkipBack}
              className="text-white hover:bg-white/20 p-2"
            >
              <SkipBack className="w-5 h-5" />
            </Button>

            <Button
              size="sm"
              variant="ghost"
              onClick={handlePlay}
              className="text-white hover:bg-white/20 p-2"
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
            </Button>

            <Button
              size="sm"
              variant="ghost"
              onClick={handleSkipForward}
              className="text-white hover:bg-white/20 p-2"
            >
              <SkipForward className="w-5 h-5" />
            </Button>

            <div className="flex items-center gap-2 ml-3">
              <Button
                size="sm"
                variant="ghost"
                onClick={toggleMute}
                className="text-white hover:bg-white/20 p-2"
              >
                {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </Button>
              
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={isMuted ? 0 : volume}
                onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                className="w-20 h-2 bg-white/20 rounded-full accent-red-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-white text-sm font-medium">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>

            <Button
              size="sm"
              variant="ghost"
              className="text-white hover:bg-white/20 p-2"
            >
              <Settings className="w-5 h-5" />
            </Button>

            <Button
              size="sm"
              variant="ghost"
              onClick={toggleFullscreen}
              className="text-white hover:bg-white/20 p-2"
            >
              {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedVideoPlayer;
