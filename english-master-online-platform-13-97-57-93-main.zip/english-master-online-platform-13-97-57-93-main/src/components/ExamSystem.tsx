
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, Clock, Award } from 'lucide-react';
import { toast } from 'sonner';

interface ExamQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
}

interface ExamSystemProps {
  questions: ExamQuestion[];
  lessonId: number;
  studentId: number;
  onExamComplete: (passed: boolean, score: number) => void;
  maxAttempts?: number;
}

const ExamSystem = ({ questions, lessonId, studentId, onExamComplete, maxAttempts = 3 }: ExamSystemProps) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [timeLeft, setTimeLeft] = useState(0);
  const [examStarted, setExamStarted] = useState(false);
  const [examFinished, setExamFinished] = useState(false);
  const [score, setScore] = useState(0);
  const [attempts, setAttempts] = useState(0);

  // حساب الوقت المخصص للامتحان (دقيقتان لكل سؤال)
  const examDuration = questions.length * 2 * 60;

  useEffect(() => {
    // تحميل عدد المحاولات السابقة
    const savedAttempts = localStorage.getItem(`exam_attempts_${lessonId}_${studentId}`);
    if (savedAttempts) {
      setAttempts(parseInt(savedAttempts));
    }
  }, [lessonId, studentId]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (examStarted && !examFinished && timeLeft > 0) {
      timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
    } else if (timeLeft === 0 && examStarted && !examFinished) {
      // انتهاء الوقت
      handleFinishExam();
    }

    return () => clearTimeout(timer);
  }, [timeLeft, examStarted, examFinished]);

  const startExam = () => {
    if (attempts >= maxAttempts) {
      toast.error(`لقد استنفدت جميع المحاولات المسموحة (${maxAttempts})`);
      return;
    }

    setExamStarted(true);
    setTimeLeft(examDuration);
    setAnswers(new Array(questions.length).fill(-1));
    setCurrentQuestion(0);
    setExamFinished(false);
    
    const newAttempts = attempts + 1;
    setAttempts(newAttempts);
    localStorage.setItem(`exam_attempts_${lessonId}_${studentId}`, newAttempts.toString());
    
    toast.success('بدأ الامتحان - حظاً موفقاً!');
  };

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answerIndex;
    setAnswers(newAnswers);
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleFinishExam = () => {
    if (answers.includes(-1)) {
      const unanswered = answers.filter(a => a === -1).length;
      if (!confirm(`لديك ${unanswered} سؤال لم تجب عليه. هل تريد إنهاء الامتحان؟`)) {
        return;
      }
    }

    // حساب النتيجة
    let correctAnswers = 0;
    questions.forEach((question, index) => {
      if (answers[index] === question.correctAnswer) {
        correctAnswers++;
      }
    });

    const finalScore = Math.round((correctAnswers / questions.length) * 100);
    const passed = finalScore >= 50;

    setScore(finalScore);
    setExamFinished(true);

    // حفظ النتيجة
    const examResult = {
      lessonId,
      studentId,
      score: finalScore,
      passed,
      attempt: attempts,
      timestamp: new Date().toISOString(),
      answers,
      correctAnswers
    };

    const savedResults = JSON.parse(localStorage.getItem('examResults') || '[]');
    savedResults.push(examResult);
    localStorage.setItem('examResults', JSON.stringify(savedResults));

    // إشعار المعلم بالنتيجة
    if (passed) {
      toast.success(`مبروك! نجحت في الامتحان بدرجة ${finalScore}%`);
    } else {
      toast.error(`للأسف لم تنجح. درجتك ${finalScore}%. يمكنك المحاولة مرة أخرى`);
    }

    onExamComplete(passed, finalScore);
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-green-600';
    if (score >= 70) return 'text-blue-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (!examStarted) {
    return (
      <Card className="p-6 text-center">
        <h3 className="text-xl font-bold mb-4">🧪 امتحان الحصة</h3>
        <div className="mb-4">
          <p className="text-muted-foreground mb-2">عدد الأسئلة: {questions.length}</p>
          <p className="text-muted-foreground mb-2">المدة المتاحة: {Math.round(examDuration / 60)} دقيقة</p>
          <p className="text-muted-foreground mb-2">النجاح: 50% أو أكثر</p>
          <p className="text-muted-foreground">المحاولات: {attempts}/{maxAttempts}</p>
        </div>
        
        {attempts >= maxAttempts ? (
          <div className="text-red-600">
            <XCircle className="w-16 h-16 mx-auto mb-4" />
            <p>لقد استنفدت جميع المحاولات المسموحة</p>
          </div>
        ) : (
          <Button onClick={startExam} size="lg" className="bg-blue-600 hover:bg-blue-700">
            بدء الامتحان
          </Button>
        )}
      </Card>
    );
  }

  if (examFinished) {
    return (
      <Card className="p-6 text-center">
        <div className="mb-4">
          {score >= 50 ? (
            <Award className="w-16 h-16 mx-auto mb-4 text-green-600" />
          ) : (
            <XCircle className="w-16 h-16 mx-auto mb-4 text-red-600" />
          )}
        </div>
        
        <h3 className="text-xl font-bold mb-4">نتيجة الامتحان</h3>
        <div className={`text-3xl font-bold mb-4 ${getScoreColor(score)}`}>
          {score}%
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
          <div>
            <p className="text-muted-foreground">الإجابات الصحيحة</p>
            <p className="font-bold text-green-600">
              {answers.filter((answer, index) => answer === questions[index].correctAnswer).length}
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">إجمالي الأسئلة</p>
            <p className="font-bold">{questions.length}</p>
          </div>
        </div>

        <Badge variant={score >= 50 ? "default" : "destructive"} className="mb-4">
          {score >= 50 ? "نجح" : "لم ينجح"}
        </Badge>

        {score < 50 && attempts < maxAttempts && (
          <div className="mt-4">
            <p className="text-sm text-muted-foreground mb-2">
              يمكنك المحاولة مرة أخرى. المحاولات المتبقية: {maxAttempts - attempts}
            </p>
            <Button onClick={() => {
              setExamStarted(false);
              setExamFinished(false);
            }}>
              محاولة جديدة
            </Button>
          </div>
        )}
      </Card>
    );
  }

  const currentQ = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <Card className="p-6">
      {/* شريط التقدم والوقت */}
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4" />
          <span className={`font-mono ${timeLeft < 300 ? 'text-red-600' : 'text-blue-600'}`}>
            {formatTime(timeLeft)}
          </span>
        </div>
        <div className="text-sm text-muted-foreground">
          السؤال {currentQuestion + 1} من {questions.length}
        </div>
      </div>

      {/* شريط التقدم */}
      <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
        <div 
          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
          style={{ width: `${progress}%` }}
        ></div>
      </div>

      {/* السؤال */}
      <div className="mb-6">
        <h4 className="text-lg font-semibold mb-4">{currentQ.question}</h4>
        
        <div className="space-y-3">
          {currentQ.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerSelect(index)}
              className={`w-full text-right p-4 border rounded-lg transition-all hover:shadow-md ${
                answers[currentQuestion] === index 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className={`w-5 h-5 rounded-full border-2 ${
                  answers[currentQuestion] === index 
                    ? 'border-blue-500 bg-blue-500' 
                    : 'border-gray-300'
                }`}>
                  {answers[currentQuestion] === index && (
                    <CheckCircle className="w-3 h-3 text-white m-0.5" />
                  )}
                </div>
                <span>{option}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* أزرار التنقل */}
      <div className="flex justify-between items-center">
        <Button
          variant="outline"
          onClick={handlePreviousQuestion}
          disabled={currentQuestion === 0}
        >
          السؤال السابق
        </Button>

        <div className="flex gap-2">
          {currentQuestion === questions.length - 1 ? (
            <Button 
              onClick={handleFinishExam}
              className="bg-green-600 hover:bg-green-700"
            >
              إنهاء الامتحان
            </Button>
          ) : (
            <Button
              onClick={handleNextQuestion}
              disabled={answers[currentQuestion] === -1}
            >
              السؤال التالي
            </Button>
          )}
        </div>
      </div>

      {/* مؤشر الإجابات */}
      <div className="mt-4 pt-4 border-t">
        <div className="flex flex-wrap gap-2 justify-center">
          {questions.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentQuestion(index)}
              className={`w-8 h-8 rounded-full text-sm font-bold border-2 ${
                index === currentQuestion
                  ? 'border-blue-500 bg-blue-500 text-white'
                  : answers[index] !== -1
                  ? 'border-green-500 bg-green-100 text-green-700'
                  : 'border-gray-300 bg-gray-100 text-gray-500'
              }`}
            >
              {index + 1}
            </button>
          ))}
        </div>
      </div>
    </Card>
  );
};

export default ExamSystem;
