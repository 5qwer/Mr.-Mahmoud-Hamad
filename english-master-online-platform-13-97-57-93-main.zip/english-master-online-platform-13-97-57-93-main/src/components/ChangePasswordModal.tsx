
import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { X, Lock, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';

interface ChangePasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: any;
  userType: 'student' | 'teacher' | 'support';
}

const ChangePasswordModal = ({ isOpen, onClose, currentUser, userType }: ChangePasswordModalProps) => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPasswords, setShowPasswords] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen || !currentUser) return null;

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Validate current password
      if (currentPassword !== currentUser.password) {
        toast.error('كلمة المرور الحالية غير صحيحة');
        return;
      }

      // Validate new password
      if (newPassword.length < 6) {
        toast.error('كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل');
        return;
      }

      if (newPassword !== confirmPassword) {
        toast.error('كلمة المرور الجديدة وتأكيدها غير متطابقين');
        return;
      }

      // Update password based on user type
      let storageKey = '';
      let currentStorageKey = '';
      
      switch (userType) {
        case 'student':
          storageKey = 'students';
          currentStorageKey = 'currentStudent';
          break;
        case 'teacher':
          storageKey = 'teachers';
          currentStorageKey = 'currentTeacher';
          break;
        case 'support':
          storageKey = 'supportUsers';
          currentStorageKey = 'currentSupport';
          break;
      }

      // Update in users list
      const users = JSON.parse(localStorage.getItem(storageKey) || '[]');
      const updatedUsers = users.map((user: any) => 
        user.id === currentUser.id 
          ? { ...user, password: newPassword }
          : user
      );
      localStorage.setItem(storageKey, JSON.stringify(updatedUsers));

      // Update current user
      const updatedCurrentUser = { ...currentUser, password: newPassword };
      localStorage.setItem(currentStorageKey, JSON.stringify(updatedCurrentUser));

      // Create notification for password change
      const notification = {
        id: Date.now(),
        title: '🔒 تم تغيير كلمة المرور',
        message: 'تم تغيير كلمة المرور بنجاح. إذا لم تقم بهذا التغيير، تواصل مع الدعم الفني فوراً.',
        priority: 'warning',
        timestamp: new Date().toISOString(),
        isRead: false,
        targetUsers: [currentUser.id],
        createdBy: 'النظام'
      };
      
      const notifications = JSON.parse(localStorage.getItem('systemNotifications') || '[]');
      notifications.unshift(notification);
      localStorage.setItem('systemNotifications', JSON.stringify(notifications));

      // Reset form
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      
      toast.success('✅ تم تغيير كلمة المرور بنجاح!');
      onClose();
      
    } catch (error) {
      console.error('خطأ في تغيير كلمة المرور:', error);
      toast.error('حدث خطأ في تغيير كلمة المرور');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <Card className="p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <Lock className="w-6 h-6 text-blue-600" />
            تغيير كلمة المرور
          </h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <form onSubmit={handleChangePassword} className="space-y-4">
          <div>
            <Label htmlFor="currentPassword">كلمة المرور الحالية</Label>
            <div className="relative">
              <Input
                id="currentPassword"
                type={showPasswords ? 'text' : 'password'}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="text-right pr-12"
                required
                disabled={isLoading}
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setShowPasswords(!showPasswords)}
                className="absolute left-2 top-1/2 transform -translate-y-1/2"
              >
                {showPasswords ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          <div>
            <Label htmlFor="newPassword">كلمة المرور الجديدة</Label>
            <Input
              id="newPassword"
              type={showPasswords ? 'text' : 'password'}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="text-right"
              required
              minLength={6}
              disabled={isLoading}
            />
          </div>

          <div>
            <Label htmlFor="confirmPassword">تأكيد كلمة المرور الجديدة</Label>
            <Input
              id="confirmPassword"
              type={showPasswords ? 'text' : 'password'}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="text-right"
              required
              minLength={6}
              disabled={isLoading}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="submit"
              className="flex-1"
              disabled={isLoading || !currentPassword || !newPassword || !confirmPassword}
            >
              {isLoading ? 'جاري التغيير...' : 'تغيير كلمة المرور'}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
            >
              إلغاء
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default ChangePasswordModal;
