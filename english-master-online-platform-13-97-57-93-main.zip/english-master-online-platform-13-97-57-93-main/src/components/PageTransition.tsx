
import { ReactNode, useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

interface PageTransitionProps {
  children: ReactNode;
}

const PageTransition = ({ children }: PageTransitionProps) => {
  const location = useLocation();
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [displayChildren, setDisplayChildren] = useState(children);

  useEffect(() => {
    setDisplayChildren(children);
  }, [children]);

  const pageContainerStyles: React.CSSProperties = {
    minHeight: '100vh',
    overflowX: 'hidden'
  };

  const pageContentStyles: React.CSSProperties = {
    willChange: 'opacity',
    transition: 'opacity 0.1s ease-out',
    opacity: 1,
  };

  return (
    <div style={pageContainerStyles} className="page-container">
      <div 
        style={pageContentStyles}
        className="page-content"
      >
        {displayChildren}
      </div>
    </div>
  );
};

export default PageTransition;
