import { useEffect, useRef, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Play, Pause, Volume2, VolumeX, SkipBack, SkipForward } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';

interface SecureVideoPlayerProps {
  src: string;
  title: string;
  videoType?: 'explanation' | 'homework';
  onVideoEnd?: () => void;
  onVideoStart?: () => void;
  onTimeUpdate?: (currentTime: number, duration: number) => void;
}

const SecureVideoPlayer = ({ src, title, videoType = 'explanation', onVideoEnd, onVideoStart, onTimeUpdate }: SecureVideoPlayerProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const watermarkRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isBuffering, setIsBuffering] = useState(false);
  const [studentName, setStudentName] = useState('');
  const [studentGrade, setStudentGrade] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [playbackSpeed, setPlaybackSpeed] = useState('1');
  const [videoQuality, setVideoQuality] = useState('auto');
  const [controlsTimeout, setControlsTimeout] = useState<NodeJS.Timeout | null>(null);

  // Load student data from Supabase
  const loadStudentData = useCallback(async () => {
    try {
      const currentStudent = JSON.parse(localStorage.getItem('currentStudent') || '{}');
      console.log('Current student from localStorage:', currentStudent);
      
      if (currentStudent.id) {
        // Try to get student data from students table first
        const { data: studentData, error: studentError } = await supabase
          .from('students')
          .select('full_name, grade')
          .eq('id', currentStudent.id)
          .single();

        if (studentData && !studentError) {
          console.log('Student data from Supabase:', studentData);
          setStudentName(studentData.full_name || currentStudent.fullName || 'طالب');
          
          // Set grade text based on grade value
          const grade = studentData.grade || currentStudent.grade || 'الأول';
          let gradeText = '';
          switch(grade) {
            case 'first':
            case 'الأول':
            case '1':
              gradeText = 'الأول الثانوي العام';
              break;
            case 'second':
            case 'الثاني':
            case '2':
              gradeText = 'الثاني الثانوي العام';
              break;
            case 'third':
            case 'الثالث':
            case '3':
              gradeText = 'الثالث الثانوي العام';
              break;
            default:
              gradeText = grade.includes('ثانوي') ? grade : `${grade} الثانوي العام`;
          }
          setStudentGrade(gradeText);
        } else {
          console.log('No student data found in Supabase, using localStorage data');
          setStudentName(currentStudent.fullName || currentStudent.full_name || 'طالب');
          
          const grade = currentStudent.grade || 'الأول الثانوي';
          let gradeText = '';
          switch(grade) {
            case 'first':
            case 'الأول':
            case '1':
              gradeText = 'الأول الثانوي العام';
              break;
            case 'second':
            case 'الثاني':
            case '2':
              gradeText = 'الثاني الثانوي العام';
              break;
            case 'third':
            case 'الثالث':
            case '3':
              gradeText = 'الثالث الثانوي العام';
              break;
            default:
              gradeText = grade.includes('ثانوي') ? grade : `${grade} الثانوي العام`;
          }
          setStudentGrade(gradeText);
        }
      } else {
        console.log('No student ID found, using default values');
        setStudentName(currentStudent.fullName || currentStudent.full_name || 'طالب');
        setStudentGrade('الأول الثانوي العام');
      }
      
      console.log('Final student name set:', studentName);
      console.log('Final student grade set:', studentGrade);
    } catch (error) {
      console.error('Error loading student data:', error);
      // Fallback to localStorage data
      const currentStudent = JSON.parse(localStorage.getItem('currentStudent') || '{}');
      setStudentName(currentStudent.fullName || currentStudent.full_name || 'طالب');
      setStudentGrade('الأول الثانوي العام');
    }
  }, []);

  // Enhanced security measures
  const implementAdvancedSecurity = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    // Disable right-click context menu
    const preventRightClick = (e: MouseEvent) => {
      e.preventDefault();
      console.log('🚫 محاولة نقر يمين محظورة');
      return false;
    };

    // Disable keyboard shortcuts
    const preventKeyboardShortcuts = (e: KeyboardEvent) => {
      // Disable F12, Ctrl+Shift+I, Ctrl+U, Ctrl+S, Print Screen
      if (e.key === 'F12' || 
          (e.ctrlKey && e.shiftKey && e.key === 'I') ||
          (e.ctrlKey && e.key === 'u') ||
          (e.ctrlKey && e.key === 's') ||
          e.key === 'PrintScreen' ||
          (e.ctrlKey && e.key === 'p') ||
          (e.metaKey && e.key === 'p')) {
        e.preventDefault();
        console.log('🚫 اختصار لوحة مفاتيح محظور');
        return false;
      }
    };

    // Disable drag and drop
    const preventDragDrop = (e: DragEvent) => {
      e.preventDefault();
      return false;
    };

    // Disable text selection
    const preventSelection = (e: Event) => {
      e.preventDefault();
      return false;
    };

    // Disable pointer events for video overlay
    const overlay = document.createElement('div');
    overlay.style.cssText = `
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: transparent;
      z-index: 999;
      pointer-events: none;
      user-select: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
    `;
    video.parentNode?.appendChild(overlay);

    // Advanced CSS protection
    video.style.cssText += `
      user-select: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      pointer-events: auto;
      -webkit-touch-callout: none;
      -webkit-user-drag: none;
      -khtml-user-drag: none;
      -moz-user-drag: none;
      -o-user-drag: none;
      user-drag: none;
    `;

    // Event listeners
    video.addEventListener('contextmenu', preventRightClick);
    video.addEventListener('dragstart', preventDragDrop);
    video.addEventListener('selectstart', preventSelection);
    document.addEventListener('keydown', preventKeyboardShortcuts);
    document.addEventListener('selectstart', preventSelection);

    // Disable print
    window.addEventListener('beforeprint', (e) => {
      e.preventDefault();
      console.log('🚫 محاولة طباعة محظورة');
      return false;
    });

    return () => {
      video.removeEventListener('contextmenu', preventRightClick);
      video.removeEventListener('dragstart', preventDragDrop);
      video.removeEventListener('selectstart', preventSelection);
      document.removeEventListener('keydown', preventKeyboardShortcuts);
      document.removeEventListener('selectstart', preventSelection);
      if (overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
    };
  }, []);

  // Monitor developer tools and screen recording
  const monitorSecurityThreats = useCallback(() => {
    let devToolsOpen = false;
    let lastInnerWidth = window.innerWidth;
    let lastInnerHeight = window.innerHeight;

    const checkDevTools = () => {
      const video = videoRef.current;
      if (!video) return;

      const threshold = 160;
      const widthThreshold = lastInnerWidth - window.innerWidth;
      const heightThreshold = lastInnerHeight - window.innerHeight;

      if (Math.abs(widthThreshold) > threshold || Math.abs(heightThreshold) > threshold) {
        if (!devToolsOpen) {
          devToolsOpen = true;
          console.clear();
          console.log('%c🚫 تم اكتشاف محاولة فتح أدوات التطوير!', 'color: red; font-size: 30px; font-weight: bold;');
          video.pause();
          setIsPlaying(false);
          
          // Show warning overlay
          const warningDiv = document.createElement('div');
          warningDiv.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 0, 0, 0.9);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
            z-index: 99999;
            text-align: center;
          `;
          warningDiv.innerHTML = '⚠️<br/>تم إيقاف الفيديو<br/>محاولة غير مسموحة!';
          document.body.appendChild(warningDiv);
          
          setTimeout(() => {
            if (warningDiv.parentNode) {
              warningDiv.parentNode.removeChild(warningDiv);
            }
            devToolsOpen = false;
          }, 3000);
        }
      }

      lastInnerWidth = window.innerWidth;
      lastInnerHeight = window.innerHeight;
    };

    // Screen recording detection
    const detectScreenRecording = () => {
      // @ts-ignore
      if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
        const originalGetDisplayMedia = navigator.mediaDevices.getDisplayMedia;
        // @ts-ignore
        navigator.mediaDevices.getDisplayMedia = function(...args) {
          console.log('🚫 محاولة تسجيل شاشة محظورة!');
          const video = videoRef.current;
          if (video) {
            video.pause();
            setIsPlaying(false);
          }
          throw new Error('Screen recording is not allowed');
        };
      }
    };

    detectScreenRecording();
    const interval = setInterval(checkDevTools, 500);
    
    return () => clearInterval(interval);
  }, []);

  // Create simplified dynamic watermark
  const createDynamicWatermark = useCallback(() => {
    const watermark = watermarkRef.current;
    if (!watermark) return;

    const updateWatermark = () => {
      if (watermark) {
        const x = Math.random() * 70 + 15; // 15-85%
        const y = Math.random() * 70 + 15; // 15-85%
        
        watermark.style.left = `${x}%`;
        watermark.style.top = `${y}%`;
        watermark.style.transform = `translate(-50%, -50%)`;
      }
    };

    updateWatermark();
    // تحديث الموقع كل 20 ثانية
    const interval = setInterval(updateWatermark, 20000);
    
    return () => clearInterval(interval);
  }, [studentName, studentGrade]);

  // Auto hide controls after 3 seconds
  const resetControlsTimeout = useCallback(() => {
    if (controlsTimeout) {
      clearTimeout(controlsTimeout);
    }
    
    setShowControls(true);
    const timeout = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
      }
    }, 3000);
    
    setControlsTimeout(timeout);
  }, [controlsTimeout, isPlaying]);

  // Handle fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  useEffect(() => {
    // Load student data first
    loadStudentData();
    
    const cleanupSecurity = implementAdvancedSecurity();
    const cleanupMonitoring = monitorSecurityThreats();
    const cleanupWatermark = createDynamicWatermark();

    // Additional protection
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && videoRef.current && isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
        console.log('🚫 فيديو متوقف - تغيير نافذة محظور');
      }
    });

    return () => {
      if (cleanupSecurity) cleanupSecurity();
      cleanupMonitoring();
      if (cleanupWatermark) cleanupWatermark();
      if (controlsTimeout) {
        clearTimeout(controlsTimeout);
      }
    };
  }, [loadStudentData, implementAdvancedSecurity, monitorSecurityThreats, createDynamicWatermark, isPlaying, controlsTimeout]);

  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
    } else {
      video.play().catch(error => {
        console.error('خطأ في تشغيل الفيديو:', error);
        setIsBuffering(false);
      });
      if (onVideoStart && currentTime === 0) {
        onVideoStart();
      }
    }
    setIsPlaying(!isPlaying);
    resetControlsTimeout();
  }, [isPlaying, onVideoStart, currentTime, resetControlsTimeout]);

  const toggleMute = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = !isMuted;
    setIsMuted(!isMuted);
    resetControlsTimeout();
  }, [isMuted, resetControlsTimeout]);

  const toggleFullscreen = useCallback(async () => {
    const container = containerRef.current;
    if (!container) return;

    try {
      if (!document.fullscreenElement) {
        await container.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
      resetControlsTimeout();
    } catch (error) {
      console.error('خطأ في تبديل ملء الشاشة:', error);
    }
  }, [resetControlsTimeout]);

  const skipBackward = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    video.currentTime = Math.max(0, video.currentTime - 5);
    resetControlsTimeout();
  }, [resetControlsTimeout]);

  const skipForward = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    video.currentTime = Math.min(video.duration, video.currentTime + 5);
    resetControlsTimeout();
  }, [resetControlsTimeout]);

  const changePlaybackSpeed = useCallback((speed: string) => {
    const video = videoRef.current;
    if (!video) return;

    video.playbackRate = parseFloat(speed);
    setPlaybackSpeed(speed);
    resetControlsTimeout();
  }, [resetControlsTimeout]);

  const handleVideoClick = useCallback((e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const videoWidth = rect.width;
    const centerStart = videoWidth * 0.3;
    const centerEnd = videoWidth * 0.7;

    // Double click in center area - toggle play/pause
    if (e.detail === 2 && clickX >= centerStart && clickX <= centerEnd) {
      togglePlay();
      return;
    }

    // Single click on edges - toggle controls
    if (e.detail === 1 && (clickX < centerStart || clickX > centerEnd)) {
      setShowControls(prev => !prev);
      resetControlsTimeout();
    }
  }, [togglePlay, resetControlsTimeout]);

  const handleMouseMove = useCallback(() => {
    resetControlsTimeout();
  }, [resetControlsTimeout]);

  const handleTimeUpdate = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    setCurrentTime(video.currentTime);
    
    if (onTimeUpdate) {
      onTimeUpdate(video.currentTime, video.duration);
    }
    
    if (video.currentTime >= video.duration - 1) {
      setIsPlaying(false);
      if (onVideoEnd) {
        onVideoEnd();
      }
    }
  }, [onTimeUpdate, onVideoEnd]);

  const handleLoadedMetadata = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    setDuration(video.duration);
  }, []);

  const formatTime = useCallback((time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }, []);

  const handleSeek = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video) return;

    const newTime = parseFloat(e.target.value);
    
    // Prevent excessive seeking forward
    if (newTime > currentTime + 10) {
      return;
    }
    
    video.currentTime = newTime;
    setCurrentTime(newTime);
    resetControlsTimeout();
  }, [currentTime, resetControlsTimeout]);

  return (
    <div 
      ref={containerRef}
      className={`relative bg-black rounded-lg overflow-hidden ${isFullscreen ? 'fixed inset-0 z-[9999]' : ''}`}
      style={{ position: 'relative' }}
      onMouseMove={handleMouseMove}
    >
      <video
        ref={videoRef}
        src={src}
        className="w-full aspect-video cursor-pointer"
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onWaiting={() => setIsBuffering(true)}
        onCanPlay={() => setIsBuffering(false)}
        controlsList="nodownload nofullscreen noremoteplaybook"
        disablePictureInPicture
        playsInline
        preload="metadata"
        onClick={handleVideoClick}
        style={{
          userSelect: 'none',
          WebkitUserSelect: 'none',
          pointerEvents: 'auto'
        }}
      />
      
      {/* Enhanced Student Info Watermark with full name */}
      <div
        ref={watermarkRef}
        className="absolute pointer-events-none select-none"
        style={{
          fontSize: isFullscreen ? '18px' : '14px',
          color: '#dc2626',
          textShadow: '2px 2px 4px rgba(0, 0, 0, 0.8)',
          zIndex: 1000,
          fontFamily: 'Arial, sans-serif',
          fontWeight: 'bold',
          userSelect: 'none',
          WebkitUserSelect: 'none',
          opacity: 0.9,
          lineHeight: '1.3',
          backgroundColor: 'rgba(0, 0, 0, 0.3)',
          padding: '4px 8px',
          borderRadius: '4px',
          border: '1px solid rgba(220, 38, 38, 0.5)'
        }}
      >
        {studentName || 'طالب'}<br/>{studentGrade || 'الأول الثانوي العام'}
      </div>

      {/* Loading indicator */}
      {isBuffering && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-white border-t-transparent"></div>
        </div>
      )}
      
      {/* Custom controls */}
      <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <div className="p-4 space-y-3">
          {/* Progress bar */}
          <div className="flex items-center gap-2 text-white text-sm">
            <span>{formatTime(currentTime)}</span>
            <input
              type="range"
              min="0"
              max={duration || 0}
              value={currentTime}
              onChange={handleSeek}
              className="flex-1 h-1 bg-white/30 rounded-lg appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${(currentTime / duration) * 100}%, rgba(255,255,255,0.3) ${(currentTime / duration) * 100}%, rgba(255,255,255,0.3) 100%)`
              }}
            />
            <span>{formatTime(duration)}</span>
          </div>

          {/* Main controls */}
          <div className="flex items-center justify-between text-white">
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={skipBackward}
                className="text-white hover:bg-white/20"
                disabled={isBuffering}
              >
                <SkipBack className="w-4 h-4" />
              </Button>
              
              <Button
                size="sm"
                variant="ghost"
                onClick={togglePlay}
                className="text-white hover:bg-white/20"
                disabled={isBuffering}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </Button>

              <Button
                size="sm"
                variant="ghost"
                onClick={skipForward}
                className="text-white hover:bg-white/20"
                disabled={isBuffering}
              >
                <SkipForward className="w-4 h-4" />
              </Button>
              
              <Button
                size="sm"
                variant="ghost"
                onClick={toggleMute}
                className="text-white hover:bg-white/20"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>
            </div>

            <div className="flex items-center gap-2">
              {/* Speed control */}
              <Select value={playbackSpeed} onValueChange={changePlaybackSpeed}>
                <SelectTrigger className="w-16 h-8 text-xs bg-transparent border-white/30 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0.5">0.5x</SelectItem>
                  <SelectItem value="0.75">0.75x</SelectItem>
                  <SelectItem value="1">1x</SelectItem>
                  <SelectItem value="1.25">1.25x</SelectItem>
                  <SelectItem value="1.5">1.5x</SelectItem>
                  <SelectItem value="2">2x</SelectItem>
                </SelectContent>
              </Select>

              {/* Quality control */}
              <Select value={videoQuality} onValueChange={setVideoQuality}>
                <SelectTrigger className="w-16 h-8 text-xs bg-transparent border-white/30 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">تلقائي</SelectItem>
                  <SelectItem value="720p">720p</SelectItem>
                  <SelectItem value="480p">480p</SelectItem>
                  <SelectItem value="360p">360p</SelectItem>
                </SelectContent>
              </Select>

              <Button
                size="sm"
                variant="ghost"
                onClick={toggleFullscreen}
                className="text-white hover:bg-white/20"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  {isFullscreen ? (
                    <path d="M4 8V6a2 2 0 012-2h2M4 12v2a2 2 0 002 2h2m8-12h2a2 2 0 012 2v2m-4 8h2a2 2 0 002-2v-2" stroke="currentColor" strokeWidth="2" fill="none"/>
                  ) : (
                    <path fillRule="evenodd" d="M3 4a1 1 0 011-1h4a1 1 0 010 2H6.414l2.293 2.293a1 1 0 11-1.414 1.414L5 6.414V8a1 1 0 01-2 0V4zm9 1a1 1 0 010-2h4a1 1 0 011 1v4a1 1 0 01-2 0V6.414l-2.293 2.293a1 1 0 11-1.414-1.414L13.586 5H12zm-9 7a1 1 0 012 0v1.586l2.293-2.293a1 1 0 111.414 1.414L6.414 15H8a1 1 0 010 2H4a1 1 0 01-1-1v-4zm13-1a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 010-2h1.586l-2.293-2.293a1 1 0 111.414-1.414L15 13.586V12a1 1 0 011-1z" clipRule="evenodd" />
                  )}
                </svg>
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Security warning overlay */}
      <div className="absolute top-2 left-2 right-2 text-center pointer-events-none">
        <div className={`px-3 py-1 rounded text-xs opacity-80 ${
          videoType === 'homework' 
            ? 'bg-orange-600/90 text-white' 
            : 'bg-red-600/90 text-white'
        }`}>
          ⚠️ {videoType === 'homework' ? 'فيديو الواجب' : 'فيديو الشرح'} - محظور تسجيل أو التقاط الفيديو
        </div>
      </div>

      {/* Anti-screenshot overlay */}
      <div 
        className="absolute inset-0 pointer-events-none select-none"
        style={{
          background: 'transparent',
          userSelect: 'none',
          WebkitUserSelect: 'none',
          zIndex: 998
        }}
      />

      {/* Instructions overlay when controls are hidden */}
      {!showControls && !isBuffering && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-center pointer-events-none opacity-0 hover:opacity-100 transition-opacity">
          <p className="text-sm bg-black/50 px-3 py-1 rounded">
            انقر على الجوانب لإظهار التحكم • انقر مرتين في المنتصف للإيقاف/التشغيل
          </p>
        </div>
      )}
    </div>
  );
};

export default SecureVideoPlayer;
