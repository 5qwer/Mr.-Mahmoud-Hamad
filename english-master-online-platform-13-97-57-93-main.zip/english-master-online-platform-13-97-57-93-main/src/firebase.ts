
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyClwaquaBwzupzgFwQqTSwriSGz5aEJ_ZI",
  authDomain: "mahmoud-382a5.firebaseapp.com",
  projectId: "mahmoud-382a5",
  storageBucket: "mahmoud-382a5.appspot.com",
  messagingSenderId: "540745059785",
  appId: "1:540745059785:web:6001383ed5b701a4612c18"
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const storage = getStorage(app);
