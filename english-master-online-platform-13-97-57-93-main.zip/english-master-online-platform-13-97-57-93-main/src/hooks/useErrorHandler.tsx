
import { useState, useCallback } from 'react';
import ErrorToast from '@/components/ErrorToast';

interface ErrorInfo {
  id: string;
  title: string;
  message: string;
}

export const useErrorHandler = () => {
  const [errors, setErrors] = useState<ErrorInfo[]>([]);

  const showError = useCallback((title: string, message: string) => {
    const id = Date.now().toString();
    const newError: ErrorInfo = { id, title, message };
    
    setErrors(prev => [...prev, newError]);
  }, []);

  const removeError = useCallback((id: string) => {
    setErrors(prev => prev.filter(error => error.id !== id));
  }, []);

  const ErrorToasts = () => (
    <>
      {errors.map((error) => (
        <ErrorToast
          key={error.id}
          title={error.title}
          message={error.message}
          onClose={() => removeError(error.id)}
        />
      ))}
    </>
  );

  return { showError, ErrorToasts };
};
